#!/usr/bin/env python3
"""
GitHub Actions CI Visualization

Generates static HTML files with interactive visualizations of CI job data.
Reads JSON data from ci_job_collector.py and produces:
- index.html: Landing page with summary and links
- statistics.html: All charts (trends, capacity, runner analysis)
- month_YYYY-MM.html: Daily Gantt-style timeline per runner

Usage:
    python3 ci_visualization.py
    python3 ci_visualization.py --input ci_jobs.json --output ./output
"""

import argparse
import datetime
import glob
import html as html_mod
import json
import os
import sys
from collections import defaultdict

# Timeline constants
PIXELS_PER_HOUR = 265
ROW_HEIGHT = 28
TOTAL_WIDTH = PIXELS_PER_HOUR * 24  # 6360px for 24h

# Valid OS names for per-platform charts; excludes test categories
# like materialx, rtx, slangpy that follow the same naming pattern
VALID_OS = {"linux", "macos", "windows"}


def parse_args():
    parser = argparse.ArgumentParser(
        description="Generate CI analytics HTML from job data."
    )
    parser.add_argument("--input", default="ci_jobs.json", help="Input JSON file (legacy single-file mode)")
    parser.add_argument(
        "--input-dir",
        help="Input directory containing monthly ci_jobs_YYYY-MM.json files (preferred over --input)",
    )
    parser.add_argument(
        "--pr-input", default="pr_merges.json",
        help="Input JSON file with merged PR data (default: pr_merges.json)",
    )
    parser.add_argument("--output", default="ci_analytics", help="Output directory")
    return parser.parse_args()


def validate_config(config):
    """Validate expected config structure."""
    if not isinstance(config, dict):
        raise ValueError("Config root must be an object.")
    label_groups = config.get("label_groups", [])
    if not isinstance(label_groups, list):
        raise ValueError("Config 'label_groups' must be a list.")
    for i, group in enumerate(label_groups):
        if not isinstance(group, dict):
            raise ValueError(f"label_groups[{i}] must be an object.")
        if "name" not in group or not isinstance(group["name"], str) or not group["name"]:
            raise ValueError(f"label_groups[{i}].name must be a non-empty string.")
        labels = group.get("labels")
        if not isinstance(labels, list) or not all(isinstance(l, str) and l for l in labels):
            raise ValueError(f"label_groups[{i}].labels must be a list of non-empty strings.")
        if "runner_count" in group and (
            not isinstance(group["runner_count"], int) or group["runner_count"] < 0
        ):
            raise ValueError(f"label_groups[{i}].runner_count must be a non-negative integer.")
    # Validate runner_name_prefixes
    prefixes = config.get("runner_name_prefixes", [])
    if not isinstance(prefixes, list):
        raise ValueError("Config 'runner_name_prefixes' must be a list.")
    for i, p in enumerate(prefixes):
        if not isinstance(p, dict):
            raise ValueError(f"runner_name_prefixes[{i}] must be an object.")
        prefix = p.get("prefix")
        if not isinstance(prefix, str) or not prefix:
            raise ValueError(f"runner_name_prefixes[{i}].prefix must be a non-empty string.")
        if "name" not in p or not isinstance(p["name"], str) or not p["name"]:
            raise ValueError(f"runner_name_prefixes[{i}].name must be a non-empty string.")

    non_prod = config.get("non_production_periods", {})
    if not isinstance(non_prod, dict):
        raise ValueError("Config 'non_production_periods' must be an object.")
    if "runners" in non_prod and not isinstance(non_prod["runners"], dict):
        raise ValueError("Config 'non_production_periods.runners' must be an object.")


def load_config():
    """Load runner group config from runner_config.json."""
    config_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "runner_config.json"
    )
    default = {"label_groups": [], "non_production_periods": {"runners": {}}}
    if not os.path.exists(config_path):
        return default
    try:
        with open(config_path, encoding="utf-8") as f:
            config = json.load(f)
        validate_config(config)
        return config
    except (OSError, json.JSONDecodeError, ValueError) as e:
        print(f"Error: invalid runner config at {config_path}: {e}", file=sys.stderr)
        sys.exit(2)


def classify_group(labels, config, runner_name=""):
    """Map runner name or job labels to a runner group name.

    Checks runner name prefixes first (scale set runners have empty labels),
    then falls back to label matching for legacy/static runners.
    """
    # Check runner name prefix first (scale set runners have no labels)
    if runner_name:
        for prefix_group in config.get("runner_name_prefixes", []):
            if runner_name.startswith(prefix_group["prefix"]):
                return prefix_group["name"], prefix_group.get("self_hosted", False)
    # Then try label matching
    label_set = set(labels) if labels else set()
    for group in config.get("label_groups", []):
        required = set(group["labels"])
        if required <= label_set:
            return group["name"], group.get("self_hosted", False)
    return "Other", False


def parse_dt(s):
    if not s:
        return None
    return datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))


def format_duration(seconds):
    if seconds is None or seconds < 0:
        return "N/A"
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h {m:02d}m"


# --- Shared HTML ---

CHARTJS_CDN = "https://cdn.jsdelivr.net/npm/chart.js"

CONCLUSION_COLORS = {
    "success": "#28a745",
    "failure": "#dc3545",
    "cancelled": "#ffc107",
    "skipped": "#6c757d",
}

CHART_PALETTE = [
    "#0d6efd",
    "#28a745",
    "#ffc107",
    "#dc3545",
    "#6f42c1",
    "#fd7e14",
    "#20c997",
    "#e83e8c",
    "#17a2b8",
    "#6610f2",
]


def chart_section(chart_id, title, description="", canvas_style=""):
    """Generate HTML for a chart section with anchor link and download button."""
    desc_html = f'\n<p style="color:#6c757d;font-size:0.9em">{description}</p>' if description else ""
    style_attr = f' style="{canvas_style}"' if canvas_style else ""
    title_attr = html_mod.escape(title, quote=True)
    desc_attr = html_mod.escape(description, quote=True) if description else ""
    return f"""<div class="chart-section" id="{chart_id}">
  <h2>{title} <a class="anchor" href="#{chart_id}">#</a>
  <select class="download-btn" onchange="downloadChart('{chart_id}_canvas', this.value); this.selectedIndex=0">
    <option value="" disabled selected>Download PNG</option>
    <option value="transparent">Transparent</option>
    <option value="white">White background</option>
  </select>
  <select class="download-btn" onchange="copyChart('{chart_id}_canvas', this.value); this.selectedIndex=0">
    <option value="" disabled selected>Copy PNG</option>
    <option value="transparent">Transparent</option>
    <option value="white">White background</option>
  </select></h2>{desc_html}
  <div class="chart-container"{style_attr}><canvas id="{chart_id}_canvas" data-title="{title_attr}" data-desc="{desc_attr}"></canvas></div>
</div>"""


DOWNLOAD_JS = """
function wrapText(ctx, text, maxWidth) {
  if (!text) return [];
  var words = text.split(/\\s+/);
  var lines = [];
  var cur = '';
  for (var i = 0; i < words.length; i++) {
    var test = cur ? (cur + ' ' + words[i]) : words[i];
    if (ctx.measureText(test).width > maxWidth && cur) {
      lines.push(cur);
      cur = words[i];
    } else {
      cur = test;
    }
  }
  if (cur) lines.push(cur);
  return lines;
}
function renderChartPng(canvasId, bg) {
  var canvas = document.getElementById(canvasId);
  if (!canvas || !bg) return null;
  var title = canvas.getAttribute('data-title') || '';
  var desc = canvas.getAttribute('data-desc') || '';
  var pad = 16;
  var titleFont = 'bold 18px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  var descFont = '12px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  var titleLineH = 22;
  var descLineH = 16;
  var maxTextW = canvas.width;
  var probe = document.createElement('canvas').getContext('2d');
  probe.font = titleFont;
  var titleLines = wrapText(probe, title, maxTextW);
  probe.font = descFont;
  var descLines = wrapText(probe, desc, maxTextW);
  var headerH = titleLines.length * titleLineH + descLines.length * descLineH;
  if (headerH > 0) headerH += pad;
  var tmp = document.createElement('canvas');
  tmp.width = canvas.width + pad * 2;
  tmp.height = canvas.height + headerH + pad;
  var ctx = tmp.getContext('2d');
  if (bg === 'white') {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, tmp.width, tmp.height);
  }
  var y = pad;
  if (titleLines.length) {
    ctx.font = titleFont;
    ctx.fillStyle = '#212529';
    for (var i = 0; i < titleLines.length; i++) {
      ctx.fillText(titleLines[i], pad, y + titleLineH - 6);
      y += titleLineH;
    }
  }
  if (descLines.length) {
    ctx.font = descFont;
    ctx.fillStyle = '#6c757d';
    for (var j = 0; j < descLines.length; j++) {
      ctx.fillText(descLines[j], pad, y + descLineH - 4);
      y += descLineH;
    }
  }
  ctx.drawImage(canvas, pad, headerH);
  return tmp;
}
function downloadChart(canvasId, bg) {
  var tmp = renderChartPng(canvasId, bg);
  if (!tmp) return;
  var link = document.createElement('a');
  link.download = canvasId.replace('_canvas', '') + '.png';
  link.href = tmp.toDataURL('image/png', 1.0);
  link.click();
}
function copyChart(canvasId, bg) {
  var tmp = renderChartPng(canvasId, bg);
  if (!tmp) return;
  if (!window.isSecureContext || !navigator.clipboard || !window.ClipboardItem) {
    console.error('Clipboard API not available (requires HTTPS or localhost)');
    downloadChart(canvasId, bg);
    return;
  }
  tmp.toBlob(function(blob) {
    navigator.clipboard.write([new ClipboardItem({'image/png': blob})]).catch(function(err) {
      console.error('Failed to copy chart to clipboard:', err);
    });
  }, 'image/png');
}
"""


def nav_html(active=""):
    links = [
        ("index.html", "Home"),
        ("statistics.html", "Statistics"),
        ("health.html", "Health"),
        ("status.html", "Status"),
    ]
    items = []
    for href, label in links:
        cls = ' style="font-weight:bold;text-decoration:underline"' if label.lower() == active.lower() else ""
        items.append(f'<a href="{href}"{cls}>{label}</a>')
    return f"""<nav style="background:#343a40;padding:10px 20px;color:white;font-family:sans-serif">
  <strong>Slang CI Analytics</strong> &nbsp;|&nbsp; {' &nbsp;|&nbsp; '.join(items)}
</nav>"""


def page_template(title, body, active=""):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title} - Slang CI Analytics</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 0; background: #fff; color: #333; }}
  nav a {{ color: #adb5bd; text-decoration: none; }}
  nav a:hover {{ color: white; }}
  .container {{ max-width: 1400px; margin: 0 auto; padding: 20px; }}
  h1, h2, h3 {{ color: #212529; }}
  table {{ border-collapse: collapse; width: 100%; }}
  th, td {{ border: 1px solid #dee2e6; padding: 8px; text-align: left; }}
  th {{ background: #f8f9fa; }}
  .chart-container {{ position: relative; width: 100%; max-width: 1200px; margin: 20px 0; }}
  .chart-section {{ margin-bottom: 30px; }}
  .chart-section h2 {{ display: flex; align-items: center; gap: 8px; }}
  .chart-section h2 a.anchor {{ color: #adb5bd; text-decoration: none; font-size: 0.7em; visibility: hidden; }}
  .chart-section:hover h2 a.anchor {{ visibility: visible; }}
  .chart-section h2 a.anchor:hover {{ color: #0d6efd; }}
  .download-btn {{ font-size: 12px; color: #6c757d; cursor: pointer; border: 1px solid #dee2e6; background: white; padding: 2px 8px; border-radius: 4px; margin-left: 8px; -webkit-appearance: none; appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='5'%3E%3Cpath d='M0 0l4 5 4-5z' fill='%236c757d'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right 6px center; padding-right: 20px; }}
  .download-btn:hover {{ background: #f8f9fa; color: #333; }}
  .stat-card {{ display: inline-block; background: #f8f9fa; border-radius: 8px; padding: 15px 25px; margin: 5px; text-align: center; }}
  .stat-card .value {{ font-size: 2em; font-weight: bold; color: #212529; }}
  .stat-card .label {{ font-size: 0.9em; color: #6c757d; }}
</style>
</head>
<body>
{nav_html(active)}
<div class="container">
{body}
</div>
</body>
</html>"""


# --- Data processing ---


def process_jobs(jobs_data, config):
    """Process raw job data into structures needed for visualization."""
    # Filter out skipped jobs for most analysis
    active_jobs = [j for j in jobs_data if j.get("conclusion") != "skipped"]
    warn_no_build_test = True

    # Exclude current (incomplete) day — only generate full days
    today_str = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")

    # Group by date
    jobs_by_date = defaultdict(list)
    for job in active_jobs:
        created = job.get("created_at")
        if not created:
            continue
        try:
            dt = parse_dt(created)
            date_str = dt.strftime("%Y-%m-%d")
            if date_str == today_str:
                continue
            jobs_by_date[date_str].append(job)
        except (ValueError, TypeError):
            continue

    # Group by month
    jobs_by_month = defaultdict(list)
    for date_str, djobs in jobs_by_date.items():
        month = date_str[:7]
        jobs_by_month[month].extend(djobs)

    # Classify runner groups
    for job in jobs_data:
        group, is_sh = classify_group(job.get("labels", []), config, job.get("runner_name", ""))
        job["_group"] = group
        job["_self_hosted"] = is_sh

    # Compute per-run turnaround time:
    # earliest job created_at to latest job completed_at for each run_id.
    # Group by the date of the earliest created_at.
    # Computed separately for the main CI workflow ("CI") and all workflows.
    runs = defaultdict(list)
    for job in active_jobs:
        run_id = job.get("run_id")
        if run_id:
            runs[run_id].append(job)

    turnaround_by_date = defaultdict(list)  # date -> list of turnaround minutes
    ci_turnaround_by_date = defaultdict(list)  # same but only "CI" workflow
    ci_sol_by_date = defaultdict(list)  # speed of light per CI run
    build_wait_by_date = defaultdict(list)  # build queue wait per CI run
    test_wait_by_date = defaultdict(list)  # test queue wait (after build) per CI run
    for run_id, run_jobs in runs.items():
        # Find earliest job created_at and latest completed_at
        earliest_job = None
        latest = None
        for j in run_jobs:
            c = parse_dt(j.get("created_at"))
            d = parse_dt(j.get("completed_at"))
            if c and (earliest_job is None or c < earliest_job):
                earliest_job = c
            if d and (latest is None or d > latest):
                latest = d

        if not earliest_job or not latest or latest <= earliest_job:
            continue

        # Use run_created_at (when the workflow was triggered) as the start,
        # since that's when the developer starts waiting.
        # But for re-runs, run_created_at is the *original* trigger time
        # which can be days earlier. Detect this: if run_created_at is more
        # than 10 minutes before the first job, it's a re-run and we use
        # the job timestamp instead.
        run_start = earliest_job
        rc = run_jobs[0].get("run_created_at")
        if rc:
            run_trigger = parse_dt(rc)
            if run_trigger and (earliest_job - run_trigger).total_seconds() < 600:
                run_start = run_trigger

        turnaround_min = (latest - run_start).total_seconds() / 60
        date_str = run_start.strftime("%Y-%m-%d")
        turnaround_by_date[date_str].append(turnaround_min)
        wf_name = run_jobs[0].get("workflow_name", "")
        if wf_name == "CI":
            ci_turnaround_by_date[date_str].append(turnaround_min)

            # Speed of light: max across platforms of (longest build + longest test).
            # This is the fastest possible turnaround with full parallelization,
            # limited only by the critical path of build->test per platform.
            platform_times = defaultdict(lambda: {"build": 0, "test": 0})
            for j in run_jobs:
                dur = j.get("duration_seconds") or 0
                if dur <= 0:
                    continue
                jname = j.get("name", "")
                if jname.startswith("build-"):
                    os_name = jname.split("-", 2)[1]
                    if os_name not in VALID_OS:
                        continue
                    platform_times[os_name]["build"] = max(
                        platform_times[os_name]["build"], dur
                    )
                    warn_no_build_test = False
                elif jname.startswith("test-"):
                    os_name = jname.split("-", 2)[1]
                    if os_name not in VALID_OS:
                        continue
                    platform_times[os_name]["test"] = max(
                        platform_times[os_name]["test"], dur
                    )
                    warn_no_build_test = False
            if platform_times:
                sol = max(
                    (t["build"] + t["test"]) for t in platform_times.values()
                )
                ci_sol_by_date[date_str].append(sol / 60)

            # Build wait: run trigger to first build job started
            # Test wait: last build completed to first test started (per platform)
            build_starts = []
            build_ends_by_os = defaultdict(list)
            test_starts_by_os = defaultdict(list)
            for j in run_jobs:
                jname = j.get("name", "")
                started = parse_dt(j.get("started_at"))
                completed = parse_dt(j.get("completed_at"))
                if jname.startswith("build-") and started:
                    os_name = jname.split("-", 2)[1]
                    if os_name not in VALID_OS:
                        continue
                    build_starts.append(started)
                    if completed:
                        build_ends_by_os[os_name].append(completed)
                elif jname.startswith("test-") and started:
                    os_name = jname.split("-", 2)[1]
                    if os_name not in VALID_OS:
                        continue
                    test_starts_by_os[os_name].append(started)

            if build_starts and run_start:
                first_build = min(build_starts)
                bw = (first_build - run_start).total_seconds() / 60
                if bw >= 0:
                    build_wait_by_date[date_str].append(bw)

            # Test wait per platform: gap between last build end and first test start
            test_waits = []
            for os_name in test_starts_by_os:
                if os_name in build_ends_by_os and test_starts_by_os[os_name]:
                    last_build = max(build_ends_by_os[os_name])
                    first_test = min(test_starts_by_os[os_name])
                    tw = (first_test - last_build).total_seconds() / 60
                    if tw >= 0:
                        test_waits.append(tw)
            if test_waits:
                # Use max across platforms (worst case wait)
                test_wait_by_date[date_str].append(max(test_waits))

    if warn_no_build_test:
        print(
            "Warning: No jobs matched 'build-*' or 'test-*' naming; "
            "CI build/test breakdowns may be empty.",
            file=sys.stderr,
        )

    # Merge queue statistics per date.
    # A merge queue "check" is a CI workflow run with event=merge_group.
    # We count success/failure/cancelled per run (not per job).
    # Import shared helper for PR number extraction
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from gh_api import parse_merge_queue_pr_number

    mq_runs_by_date = defaultdict(lambda: {"success": 0, "failure": 0, "cancelled": 0, "total": 0})
    mq_tat_by_date = defaultdict(list)  # turnaround times for merge queue runs
    mq_recent_failures = []  # most recent merge queue failures (for table)
    for run_id, run_jobs in runs.items():
        if not run_jobs:
            continue
        if run_jobs[0].get("event") != "merge_group":
            continue
        if run_jobs[0].get("workflow_name") != "CI":
            continue

        # Determine run conclusion from jobs
        conclusions = [j.get("conclusion") for j in run_jobs]
        if "failure" in conclusions:
            conclusion = "failure"
        elif "cancelled" in conclusions and "success" not in conclusions:
            conclusion = "cancelled"
        elif all(c == "success" for c in conclusions if c):
            conclusion = "success"
        else:
            conclusion = "cancelled"

        # Date from earliest created_at
        earliest = None
        latest = None
        for j in run_jobs:
            c = parse_dt(j.get("created_at"))
            d = parse_dt(j.get("completed_at"))
            if c and (earliest is None or c < earliest):
                earliest = c
            if d and (latest is None or d > latest):
                latest = d
        if not earliest:
            continue

        date_str = earliest.strftime("%Y-%m-%d")
        if date_str == today_str:
            continue
        mq_runs_by_date[date_str][conclusion] += 1
        mq_runs_by_date[date_str]["total"] += 1

        if earliest and latest and latest > earliest:
            tat = (latest - earliest).total_seconds() / 60
            mq_tat_by_date[date_str].append(tat)

        if conclusion == "failure":
            branch = run_jobs[0].get("head_branch", "")
            pr_num = parse_merge_queue_pr_number(branch)

            # Find failing job names
            failing_jobs = [
                j.get("name", "") for j in run_jobs
                if j.get("conclusion") == "failure"
            ]
            mq_recent_failures.append({
                "date": date_str,
                "created_at": earliest.isoformat(),
                "run_id": run_id,
                "branch": branch,
                "pr_number": pr_num,
                "url": run_jobs[0].get("html_url", ""),
                "failing_jobs": failing_jobs[:5],
            })

    mq_recent_failures.sort(key=lambda x: x["created_at"], reverse=True)

    generated_at = datetime.datetime.now(datetime.timezone.utc).strftime(
        "%Y-%m-%d %H:%M UTC"
    )

    return {
        "all_jobs": jobs_data,
        "active_jobs": active_jobs,
        "jobs_by_date": dict(jobs_by_date),
        "jobs_by_month": dict(jobs_by_month),
        "turnaround_by_date": dict(turnaround_by_date),
        "ci_turnaround_by_date": dict(ci_turnaround_by_date),
        "ci_sol_by_date": dict(ci_sol_by_date),
        "build_wait_by_date": dict(build_wait_by_date),
        "test_wait_by_date": dict(test_wait_by_date),
        "mq_runs_by_date": dict(mq_runs_by_date),
        "mq_tat_by_date": dict(mq_tat_by_date),
        "mq_recent_failures": mq_recent_failures[:50],
        "dates": sorted(jobs_by_date.keys()),
        "months": sorted(jobs_by_month.keys()),
        "generated_at": generated_at,
    }


# --- Shared helpers ---


def _count_pr_merges_by_date(pr_merges):
    """Count PRs merged per date string from pr_collector data."""
    counts = defaultdict(int)
    for pr in pr_merges:
        merged_at = pr.get("merged_at")
        if not merged_at:
            continue
        try:
            dt = parse_dt(merged_at)
            counts[dt.strftime("%Y-%m-%d")] += 1
        except (ValueError, TypeError):
            continue
    return counts


# --- Index page ---


def _avg_last_n_days(by_date, dates, n):
    """Average of values across the last n dates."""
    recent = dates[-n:] if len(dates) >= n else dates
    all_vals = []
    for d in recent:
        all_vals.extend(by_date.get(d, []))
    return sum(all_vals) / len(all_vals) if all_vals else 0


def build_os_phase_dataset_js(os_list, os_phase_avg_by_date, dates, phase):
    datasets = []
    for i, os_name in enumerate(os_list):
        key = f"{os_name}_{phase}"
        if key not in os_phase_avg_by_date:
            continue
        series = os_phase_avg_by_date.get(key, [0] * len(dates))
        datasets.append(
            (
                "{"
                f"label:'{os_name}', "
                f"data:sliceData({json.dumps(series)},30), "
                f"_allData:{json.dumps(series)}, "
                f"borderColor:'{CHART_PALETTE[i % len(CHART_PALETTE)]}', "
                "fill:false, tension:0.1"
                "}"
            )
        )
    return ",".join(datasets)


def generate_index(data, output_dir):
    # Filter to CI workflow only
    ci_filter = lambda j: j.get("workflow_name") == "CI"
    active = [j for j in data["active_jobs"] if ci_filter(j)]
    dates = data["dates"]
    total = len(active)
    success = sum(1 for j in active if j.get("conclusion") == "success")
    success_rate = (success / total * 100) if total > 0 else 0

    # Compute metrics for a 3-day window
    def _compute_3d_metrics(window_dates):
        tat = 0
        ci_tat_data = data.get("ci_turnaround_by_date", {})
        tat_vals = []
        for d in window_dates:
            tat_vals.extend(ci_tat_data.get(d, []))
        tat = sum(tat_vals) / len(tat_vals) if tat_vals else 0

        pr_branches = set()
        for d in window_dates:
            for j in data["jobs_by_date"].get(d, []):
                if ci_filter(j) and j.get("event") == "pull_request" and j.get("head_branch"):
                    pr_branches.add(j["head_branch"])
        prs = len(pr_branches) / len(window_dates) if window_dates else 0

        s, f = 0, 0
        for d in window_dates:
            for j in data["jobs_by_date"].get(d, []):
                if not ci_filter(j):
                    continue
                c = j.get("conclusion")
                if c == "success":
                    s += 1
                elif c == "failure":
                    f += 1
        total_sf = s + f
        fr = (f / total_sf * 100) if total_sf > 0 else 0
        return tat, prs, fr

    recent_dates = dates[-3:] if len(dates) >= 3 else dates
    prev_dates = dates[-6:-3] if len(dates) >= 6 else []

    ci_tat_3d, prs_3d, failure_rate_3d = _compute_3d_metrics(recent_dates)
    ci_tat_prev, prs_prev, failure_rate_prev = _compute_3d_metrics(prev_dates)

    def _delta_str(current, previous, unit="", invert=False):
        """Format a delta value. invert=True means lower is better."""
        if not previous:
            return ""
        diff = current - previous
        if abs(diff) < 0.05:
            return '<span style="color:#6c757d;font-size:0.6em"> (flat)</span>'
        if invert:
            color = "#28a745" if diff < 0 else "#dc3545"
        else:
            color = "#28a745" if diff > 0 else "#dc3545"
        sign = "+" if diff > 0 else ""
        if unit == "%":
            txt = f"{sign}{diff:.1f}pp"
        elif unit == "m":
            txt = f"{sign}{diff:.0f}m"
        else:
            txt = f"{sign}{diff:.1f}"
        return f'<span style="color:{color};font-size:0.6em"> ({txt})</span>'

    tat_delta = _delta_str(ci_tat_3d, ci_tat_prev, "m", invert=True)
    prs_delta = _delta_str(prs_3d, prs_prev)
    fr_delta = _delta_str(failure_rate_3d, failure_rate_prev, "%", invert=True)

    # PRs merged per day (from pr_collector data)
    pr_merges = data.get("pr_merges", [])
    prs_merged_by_date = _count_pr_merges_by_date(pr_merges)

    def _avg_merged(window_dates):
        total = sum(prs_merged_by_date.get(d, 0) for d in window_dates)
        return total / len(window_dates) if window_dates else 0

    merged_3d = _avg_merged(recent_dates)
    merged_prev = _avg_merged(prev_dates)
    merged_delta = _delta_str(merged_3d, merged_prev)

    merged_card_html = ""
    if pr_merges:
        merged_card_html = f'  <div class="stat-card"><div class="value">{merged_3d:.1f}{merged_delta}</div><div class="label">PRs Merged / day</div></div>'

    months_html = ""
    for month in reversed(data["months"]):
        count = len(data["jobs_by_month"][month])
        months_html += f'<li><a href="month_{month}.html">{month}</a> ({count} jobs)</li>\n'

    body = f"""
<h1>Slang CI Analytics</h1>
<p style="color:#6c757d">Last updated: {data['generated_at']}. CI workflow only. Excludes skipped jobs. Data range: {dates[0] if dates else 'N/A'} to {dates[-1] if dates else 'N/A'}.</p>
<h2>Last 3 Days</h2>
<div>
  <div class="stat-card"><div class="value">{ci_tat_3d:.0f}m{tat_delta}</div><div class="label">CI Turnaround (avg)</div></div>
  <div class="stat-card"><div class="value">{prs_3d:.1f}{prs_delta}</div><div class="label">Active PRs / day</div></div>
  <div class="stat-card"><div class="value">{failure_rate_3d:.1f}%{fr_delta}</div><div class="label">Failure Rate</div></div>
{merged_card_html}
</div>

<h2>Pages</h2>
<ul>
  <li><a href="statistics.html">Statistics &amp; Trends</a></li>
</ul>

<h2>Monthly Timelines</h2>
<ul>
{months_html}
</ul>
"""
    with open(os.path.join(output_dir, "index.html"), "w") as f:
        f.write(page_template("Home", body, "Home"))


# --- Statistics page ---


def generate_statistics(data, config, output_dir):
    dates = data["dates"]

    # Filter everything to CI workflow only
    ci_filter = lambda j: j.get("workflow_name") == "CI"
    active = [j for j in data["active_jobs"] if ci_filter(j)]
    jobs_by_date = {
        d: [j for j in jobs if ci_filter(j)]
        for d, jobs in data["jobs_by_date"].items()
    }

    # Per-day stats
    labels_json = json.dumps(dates)

    success_per_day = []
    failure_per_day = []
    cancelled_per_day = []
    runs_per_day = []
    prs_per_day = []
    avg_duration_per_day = []
    avg_queue_per_day = []
    failure_rate_per_day = []

    for date in dates:
        djobs = jobs_by_date[date]
        s = sum(1 for j in djobs if j.get("conclusion") == "success")
        f = sum(1 for j in djobs if j.get("conclusion") == "failure")
        c = sum(1 for j in djobs if j.get("conclusion") == "cancelled")
        success_per_day.append(s)
        failure_per_day.append(f)
        cancelled_per_day.append(c)

        run_ids = set(j.get("run_id") for j in djobs if j.get("run_id"))
        runs_per_day.append(len(run_ids))

        pr_branches = set(
            j.get("head_branch") for j in djobs
            if j.get("event") == "pull_request" and j.get("head_branch")
        )
        prs_per_day.append(len(pr_branches))

        durs = [j["duration_seconds"] for j in djobs if j.get("duration_seconds") and j["duration_seconds"] > 0]
        avg_duration_per_day.append(round(sum(durs) / len(durs) / 60, 1) if durs else 0)

        queues = [
            j["queued_seconds"]
            for j in djobs
            if j.get("queued_seconds") is not None and j["queued_seconds"] >= 0
        ]
        avg_queue_per_day.append(round(sum(queues) / len(queues) / 60, 1) if queues else 0)

        total_day = s + f
        failure_rate_per_day.append(round(f / total_day * 100, 1) if total_day > 0 else 0)

    # 7-day moving average for duration
    ma_duration = []
    for i in range(len(avg_duration_per_day)):
        window = avg_duration_per_day[max(0, i - 6) : i + 1]
        ma_duration.append(round(sum(window) / len(window), 1))

    # CI turnaround time per day — main CI workflow only
    ci_turnaround_by_date = data.get("ci_turnaround_by_date", {})
    ci_avg_tat = []
    ci_median_tat = []
    ci_p95_tat = []
    for date in dates:
        tats = sorted(ci_turnaround_by_date.get(date, []))
        if tats:
            ci_avg_tat.append(round(sum(tats) / len(tats), 1))
            ci_median_tat.append(round(tats[len(tats) // 2], 1))
            ci_p95_tat.append(round(tats[int(len(tats) * 0.95)], 1))
        else:
            ci_avg_tat.append(0)
            ci_median_tat.append(0)
            ci_p95_tat.append(0)

    # Speed of light per day (average across CI runs)
    ci_sol_by_date = data.get("ci_sol_by_date", {})
    ci_sol_avg = []
    for date in dates:
        sols = ci_sol_by_date.get(date, [])
        ci_sol_avg.append(round(sum(sols) / len(sols), 1) if sols else 0)

    # Build and test duration breakdown per OS (CI workflow only)
    # Parse job names like "build-linux-debug-gcc-x86_64 / build"
    # and "test-windows-release-cl-x86_64-gpu / test-slang"
    os_phases = defaultdict(lambda: defaultdict(list))  # os -> phase -> [durations]
    os_phase_by_date = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for j in active:
        if j.get("workflow_name") != "CI":
            continue
        dur = j.get("duration_seconds")
        if not dur or dur <= 0:
            continue
        name = j.get("name", "")
        # Determine phase and OS from job name prefix
        if name.startswith("build-"):
            phase = "build"
        elif name.startswith("test-"):
            phase = "test"
        else:
            continue
        # Extract OS: build-{os}-... or test-{os}-...
        parts = name.split("-", 2)
        if len(parts) < 2:
            continue
        os_name = parts[1]
        if os_name not in VALID_OS:
            continue
        os_phases[os_name][phase].append(dur / 60)

        created = j.get("created_at")
        if created:
            try:
                dt = parse_dt(created)
                date_str = dt.strftime("%Y-%m-%d")
                os_phase_by_date[date_str][os_name][phase].append(dur / 60)
            except (ValueError, TypeError):
                pass

    # Build per-day average for each OS+phase combo
    os_list = sorted(os_phases.keys())
    os_phase_avg_by_date = {}
    for os_name in os_list:
        for phase in ["build", "test"]:
            key = f"{os_name}_{phase}"
            series = []
            for date in dates:
                vals = os_phase_by_date.get(date, {}).get(os_name, {}).get(phase, [])
                series.append(round(sum(vals) / len(vals), 1) if vals else 0)
            os_phase_avg_by_date[key] = series

    # Jobs by runner group
    group_counts = defaultdict(int)
    for j in active:
        group_counts[j.get("_group", "Other")] += 1
    group_names = sorted(group_counts.keys())
    group_values = [group_counts[g] for g in group_names]

    # Parallelization rate per runner group (from former capacity page)
    sh_groups = {}
    for g in config.get("label_groups", []):
        if g.get("self_hosted"):
            name = g["name"]
            if name not in sh_groups:
                sh_groups[name] = g.get("runner_count", 0)
    for p in config.get("runner_name_prefixes", []):
        if p.get("self_hosted"):
            name = p["name"]
            if name not in sh_groups:
                sh_groups[name] = p.get("runner_count", 0)

    group_parallel_per_day = defaultdict(list)
    cap_avg_queue = []
    cap_p50_queue = []
    cap_p90_queue = []
    cap_p95_queue = []

    for date in dates:
        djobs = jobs_by_date[date]
        queues = sorted(
            [
                j["queued_seconds"]
                for j in djobs
                if j.get("queued_seconds") is not None and j["queued_seconds"] >= 0
            ]
        )
        if queues:
            cap_avg_queue.append(round(sum(queues) / len(queues) / 60, 1))
            cap_p50_queue.append(round(queues[len(queues) // 2] / 60, 1))
            cap_p90_queue.append(round(queues[int(len(queues) * 0.9)] / 60, 1))
            cap_p95_queue.append(round(queues[int(len(queues) * 0.95)] / 60, 1))
        else:
            cap_avg_queue.append(0)
            cap_p50_queue.append(0)
            cap_p90_queue.append(0)
            cap_p95_queue.append(0)

        group_busy = defaultdict(float)
        for j in djobs:
            g = j.get("_group", "Other")
            if g not in sh_groups:
                continue
            dur = j.get("duration_seconds")
            if dur and dur > 0:
                group_busy[g] += dur
        for g in sorted(sh_groups):
            group_parallel_per_day[g].append(round(group_busy[g] / 86400, 2))

    parallel_datasets = []
    ci = 0
    for g in sorted(sh_groups):
        # Only include groups that have actual data
        if not any(v > 0 for v in group_parallel_per_day[g]):
            continue
        color = CHART_PALETTE[ci % len(CHART_PALETTE)]
        ci += 1
        parallel_datasets.append({
            "label": g,
            "data": group_parallel_per_day[g],
            "borderColor": color,
            "backgroundColor": color + "33",
            "fill": True,
            "tension": 0.1,
        })
    parallel_datasets_js = ",".join(
        (
            "{"
            f"label:{json.dumps(ds['label'])}, "
            f"data:sliceData({json.dumps(ds['data'])},30), "
            f"_allData:{json.dumps(ds['data'])}, "
            f"borderColor:{json.dumps(ds['borderColor'])}, "
            f"backgroundColor:{json.dumps(ds['backgroundColor'])}, "
            f"fill:{json.dumps(ds['fill'])}, "
            f"tension:{json.dumps(ds['tension'])}"
            "}"
        )
        for ds in parallel_datasets
    )

    # Build and test wait times per day
    build_wait_by_date = data.get("build_wait_by_date", {})
    test_wait_by_date = data.get("test_wait_by_date", {})
    avg_build_wait = []
    avg_test_wait = []
    for date in dates:
        bw = build_wait_by_date.get(date, [])
        avg_build_wait.append(round(sum(bw) / len(bw), 1) if bw else 0)
        tw = test_wait_by_date.get(date, [])
        avg_test_wait.append(round(sum(tw) / len(tw), 1) if tw else 0)

    build_os_datasets_js = build_os_phase_dataset_js(
        os_list, os_phase_avg_by_date, dates, "build"
    )
    test_os_datasets_js = build_os_phase_dataset_js(
        os_list, os_phase_avg_by_date, dates, "test"
    )

    # PRs merged per day (from pr_collector data)
    pr_merges = data.get("pr_merges", [])
    prs_merged_by_date = _count_pr_merges_by_date(pr_merges)
    prs_merged_per_day = [prs_merged_by_date.get(d, 0) for d in dates]

    if pr_merges:
        pr_merged_chart_html = chart_section(
            "prsMerged", "PRs Merged per Day",
            "Number of pull requests merged each day."
        )
    else:
        pr_merged_chart_html = ""

    # Merge queue stats per day
    mq_runs_by_date = data.get("mq_runs_by_date", {})
    mq_tat_by_date = data.get("mq_tat_by_date", {})
    mq_recent_failures = data.get("mq_recent_failures", [])
    mq_success_per_day = []
    mq_failure_per_day = []
    mq_cancelled_per_day = []
    mq_fail_rate_per_day = []
    mq_avg_tat_per_day = []
    has_mq_data = bool(mq_runs_by_date)
    for date in dates:
        mq = mq_runs_by_date.get(date, {})
        s = mq.get("success", 0)
        f = mq.get("failure", 0)
        c = mq.get("cancelled", 0)
        mq_success_per_day.append(s)
        mq_failure_per_day.append(f)
        mq_cancelled_per_day.append(c)
        total_sf = s + f
        mq_fail_rate_per_day.append(round(f / total_sf * 100, 1) if total_sf > 0 else 0)
        tats = mq_tat_by_date.get(date, [])
        mq_avg_tat_per_day.append(round(sum(tats) / len(tats), 1) if tats else 0)

    # Build merge queue failure table HTML
    mq_failures_html = ""
    if mq_recent_failures:
        mq_failures_html = '\n<h3>Recent Merge Queue Failures</h3>\n'
        mq_failures_html += '<table><tr><th>Date</th><th>PR</th><th>Run</th><th>Failing Jobs</th></tr>\n'
        for mf in mq_recent_failures[:20]:
            pr_num = mf.get("pr_number", "")
            url = mf.get("url", "")
            run_url = url.split("/jobs/")[0] if "/jobs/" in url else url
            if pr_num:
                pr_link = f'<a href="https://github.com/shader-slang/slang/pull/{html_mod.escape(pr_num)}" target="_blank">#{html_mod.escape(pr_num)}</a>'
            else:
                pr_link = "?"
            run_link = f'<a href="{html_mod.escape(run_url)}" target="_blank">logs</a>' if run_url else ""
            failing = ", ".join(mf.get("failing_jobs", [])[:3])
            if len(mf.get("failing_jobs", [])) > 3:
                failing += f" (+{len(mf['failing_jobs']) - 3} more)"
            mq_failures_html += f"<tr><td>{html_mod.escape(mf.get('date', ''))}</td><td>{pr_link}</td><td>{run_link}</td><td>{html_mod.escape(failing)}</td></tr>\n"
        mq_failures_html += "</table>\n"

    mq_chart_html = ""
    if has_mq_data:
        mq_chart_html = f"""
{chart_section("mqChecks", "Merge Queue Checks per Day",
    "Stacked by conclusion: success, failure, cancelled. Shows merge queue CI check runs triggered by GitHub merge queue.")}

{chart_section("mqFailRate", "Merge Queue Failure Rate (%)",
    "Percentage of merge queue CI checks that failed (excludes cancelled).")}

{chart_section("mqTurnaround", "Merge Queue Turnaround Time (minutes)",
    "Average time from merge queue CI check start to completion.")}

{mq_failures_html}
"""

    body = f"""
<h1>Statistics &amp; Trends</h1>
<p style="color:#6c757d">Last updated: {data['generated_at']}. CI workflow only. Excludes skipped jobs. Data range: {dates[0] if dates else 'N/A'} to {dates[-1] if dates else 'N/A'}.</p>

<div style="margin-bottom:15px">
  <label>Date range: </label>
  <select id="rangeSelect" onchange="updateRange()">
    <option value="7">Last 7 days</option>
    <option value="30" selected>Last 30 days</option>
    <option value="90">Last 90 days</option>
    <option value="0">All time</option>
  </select>
</div>

{chart_section("turnaround", "CI Turnaround Time (minutes)",
    "Time from workflow trigger to last job completed per run. Speed of light = max(build+test) across platforms, assuming full parallelization.")}

{chart_section("prsPerDay", "Active PRs per Day",
    "Unique PR branches with CI activity per day.")}

{pr_merged_chart_html}
{chart_section("buildTestWait", "Build and Test Wait Times (minutes)",
    "Build wait: run trigger to first build started. Test wait: last build completed to first test started (worst platform).")}

{chart_section("buildByOs", "Build Duration by OS (minutes)",
    "Average build job duration per day.")}

{chart_section("testByOs", "Test Duration by OS (minutes)",
    "Average test job duration per day.")}

{chart_section("jobsPerDay", "Jobs per Day",
    "Stacked by conclusion: success, failure, cancelled.")}

{chart_section("runsPerDay", "Workflow Runs per Day",
    "Number of distinct workflow runs per day.")}

{chart_section("avgDuration", "Average Job Duration (minutes)",
    "Mean duration across all jobs per day, with 7-day moving average.")}

{chart_section("avgQueue", "Average Queue Wait Time (minutes)",
    "Mean time jobs spent waiting for a runner before starting.")}

{chart_section("failureRate", "Failure Rate (%)",
    "Percentage of jobs that failed (excludes skipped and cancelled).")}

{chart_section("byGroup", "Jobs by Runner Group",
    "Total jobs per runner group over the full date range.", canvas_style="max-width:800px")}

{chart_section("parallelRate", "Average Concurrent Runners",
    "Average number of self-hosted runners busy at any moment, per group. Computed as total busy time / 24h.")}

{chart_section("queueWait", "Queue Wait Time Percentiles (minutes)",
    "Time each job spent waiting in the CI queue for a runner before execution started. Shows average, median (p50), p90, and p95 per day.")}

{mq_chart_html}

<script src="{CHARTJS_CDN}"></script>
<script>
const allLabels = {labels_json};
const allSuccess = {json.dumps(success_per_day)};
const allFailure = {json.dumps(failure_per_day)};
const allCancelled = {json.dumps(cancelled_per_day)};
const allRuns = {json.dumps(runs_per_day)};
const allPRs = {json.dumps(prs_per_day)};
const allDuration = {json.dumps(avg_duration_per_day)};
const allMaDuration = {json.dumps(ma_duration)};
const allQueue = {json.dumps(avg_queue_per_day)};
const allFailRate = {json.dumps(failure_rate_per_day)};
const allTurnAvg = {json.dumps(ci_avg_tat)};
const allTurnMedian = {json.dumps(ci_median_tat)};
const allTurnP95 = {json.dumps(ci_p95_tat)};
const allSoL = {json.dumps(ci_sol_avg)};
const allBuildWait = {json.dumps(avg_build_wait)};
const allTestWait = {json.dumps(avg_test_wait)};
const allPRsMerged = {json.dumps(prs_merged_per_day)};
const allMqSuccess = {json.dumps(mq_success_per_day)};
const allMqFailure = {json.dumps(mq_failure_per_day)};
const allMqCancelled = {json.dumps(mq_cancelled_per_day)};
const allMqFailRate = {json.dumps(mq_fail_rate_per_day)};
const allMqTat = {json.dumps(mq_avg_tat_per_day)};
const allQueueWaitAvg = {json.dumps(cap_avg_queue)};
const allQueueWaitP50 = {json.dumps(cap_p50_queue)};
const allQueueWaitP90 = {json.dumps(cap_p90_queue)};
const allQueueWaitP95 = {json.dumps(cap_p95_queue)};
const hasMqData = {json.dumps(has_mq_data)};

let charts = [];

{DOWNLOAD_JS}

function sliceData(arr, n) {{
  return n === 0 ? arr : arr.slice(-n);
}}

function makeChart(id, type, config) {{
  const ctx = document.getElementById(id).getContext('2d');
  const c = new Chart(ctx, {{type, ...config}});
  charts.push({{chart: c, id, type, config}});
  return c;
}}

function updateRange() {{
  const n = parseInt(document.getElementById('rangeSelect').value);
  const labs = sliceData(allLabels, n);
  charts.forEach(item => {{
    const c = item.chart;
    c.data.labels = labs;
    c.data.datasets.forEach((ds, i) => {{
      if (ds._allData) ds.data = sliceData(ds._allData, n);
    }});
    c.update();
  }});
}}

// CI Turnaround time
makeChart('turnaround_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [
      {{label:'Average', data:sliceData(allTurnAvg,30), _allData:allTurnAvg, borderColor:'#0d6efd', fill:false, tension:0.1}},
      {{label:'Median', data:sliceData(allTurnMedian,30), _allData:allTurnMedian, borderColor:'#28a745', fill:false, tension:0.1}},
      {{label:'p95', data:sliceData(allTurnP95,30), _allData:allTurnP95, borderColor:'#dc3545', borderDash:[5,5], fill:false, tension:0.1}},
      {{label:'Speed of Light', data:sliceData(allSoL,30), _allData:allSoL, borderColor:'#6c757d', borderDash:[2,4], fill:false, tension:0.1, pointStyle:'triangle'}},
    ]
  }},
  options: {{responsive:true, scales:{{y:{{title:{{display:true,text:'Minutes'}}}}}}}}
}});

// Build and test wait times
makeChart('buildTestWait_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [
      {{label:'Build Wait', data:sliceData(allBuildWait,30), _allData:allBuildWait, borderColor:'#0d6efd', fill:false, tension:0.1}},
      {{label:'Test Wait (after build)', data:sliceData(allTestWait,30), _allData:allTestWait, borderColor:'#dc3545', fill:false, tension:0.1}},
    ]
  }},
  options: {{responsive:true, scales:{{y:{{title:{{display:true,text:'Minutes'}}}}}}}}
}});

// Build duration by OS
makeChart('buildByOs_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [{build_os_datasets_js}]
  }},
  options: {{responsive:true, scales:{{y:{{title:{{display:true,text:'Minutes'}}}}}}}}
}});

// Test duration by OS
makeChart('testByOs_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [{test_os_datasets_js}]
  }},
  options: {{responsive:true, scales:{{y:{{title:{{display:true,text:'Minutes'}}}}}}}}
}});

// Jobs per day (stacked bar)
makeChart('jobsPerDay_canvas', 'bar', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [
      {{label:'Success', data:sliceData(allSuccess,30), _allData:allSuccess, backgroundColor:'{CONCLUSION_COLORS["success"]}'}},
      {{label:'Failure', data:sliceData(allFailure,30), _allData:allFailure, backgroundColor:'{CONCLUSION_COLORS["failure"]}'}},
      {{label:'Cancelled', data:sliceData(allCancelled,30), _allData:allCancelled, backgroundColor:'{CONCLUSION_COLORS["cancelled"]}'}},
    ]
  }},
  options: {{responsive:true, scales:{{x:{{stacked:true}},y:{{stacked:true}}}}}}
}});

// Active PRs per day
makeChart('prsPerDay_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [{{label:'Active PRs', data:sliceData(allPRs,30), _allData:allPRs, borderColor:'#28a745', fill:true, backgroundColor:'rgba(40,167,69,0.1)', tension:0.1}}]
  }},
  options: {{responsive:true}}
}});

// PRs merged per day
if (document.getElementById('prsMerged_canvas')) {{
  makeChart('prsMerged_canvas', 'bar', {{
    data: {{
      labels: sliceData(allLabels, 30),
      datasets: [{{label:'PRs Merged', data:sliceData(allPRsMerged,30), _allData:allPRsMerged, backgroundColor:'#6f42c1'}}]
    }},
    options: {{responsive:true, scales:{{y:{{beginAtZero:true, title:{{display:true,text:'PRs'}}}}}}}}
  }});
}}

// Runs per day
makeChart('runsPerDay_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [{{label:'Workflow Runs', data:sliceData(allRuns,30), _allData:allRuns, borderColor:'#0d6efd', fill:false, tension:0.1}}]
  }},
  options: {{responsive:true}}
}});

// Average duration
makeChart('avgDuration_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [
      {{label:'Avg Duration', data:sliceData(allDuration,30), _allData:allDuration, borderColor:'#0d6efd', fill:false, tension:0.1}},
      {{label:'7-day MA', data:sliceData(allMaDuration,30), _allData:allMaDuration, borderColor:'#fd7e14', borderDash:[5,5], fill:false, tension:0.1}},
    ]
  }},
  options: {{responsive:true}}
}});

// Queue wait time
makeChart('avgQueue_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [{{label:'Avg Queue (min)', data:sliceData(allQueue,30), _allData:allQueue, borderColor:'#6f42c1', fill:true, backgroundColor:'rgba(111,66,193,0.1)', tension:0.1}}]
  }},
  options: {{responsive:true}}
}});

// Failure rate
makeChart('failureRate_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [{{label:'Failure Rate %', data:sliceData(allFailRate,30), _allData:allFailRate, borderColor:'{CONCLUSION_COLORS["failure"]}', fill:true, backgroundColor:'rgba(220,53,69,0.1)', tension:0.1}}]
  }},
  options: {{responsive:true, scales:{{y:{{min:0,max:100}}}}}}
}});

// By runner group (static, no range filter)
new Chart(document.getElementById('byGroup_canvas').getContext('2d'), {{
  type: 'bar',
  data: {{
    labels: {json.dumps(group_names)},
    datasets: [{{label:'Jobs', data:{json.dumps(group_values)}, backgroundColor:'#0d6efd'}}]
  }},
  options: {{responsive:true, indexAxis:'y'}}
}});

// Parallelization rate
makeChart('parallelRate_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [
      {parallel_datasets_js}
    ]
  }},
  options: {{responsive:true, scales:{{y:{{stacked:true,min:0,title:{{display:true,text:'Avg Concurrent Runners'}}}}}}}}
}});

// Queue wait time percentiles
makeChart('queueWait_canvas', 'line', {{
  data: {{
    labels: sliceData(allLabels, 30),
    datasets: [
      {{label:'Avg', data:sliceData(allQueueWaitAvg,30), _allData:allQueueWaitAvg, borderColor:'#0d6efd', fill:false, tension:0.1}},
      {{label:'p50', data:sliceData(allQueueWaitP50,30), _allData:allQueueWaitP50, borderColor:'#28a745', borderDash:[5,5], fill:false, tension:0.1}},
      {{label:'p90', data:sliceData(allQueueWaitP90,30), _allData:allQueueWaitP90, borderColor:'#ffc107', borderDash:[5,5], fill:false, tension:0.1}},
      {{label:'p95', data:sliceData(allQueueWaitP95,30), _allData:allQueueWaitP95, borderColor:'#dc3545', borderDash:[5,5], fill:false, tension:0.1}},
    ]
  }},
  options: {{responsive:true, scales:{{y:{{title:{{display:true,text:'Minutes'}}}}}}}}
}});

// Merge queue charts (only if data exists)
if (hasMqData) {{
  // Merge queue checks per day (stacked bar)
  makeChart('mqChecks_canvas', 'bar', {{
    data: {{
      labels: sliceData(allLabels, 30),
      datasets: [
        {{label:'Success', data:sliceData(allMqSuccess,30), _allData:allMqSuccess, backgroundColor:'{CONCLUSION_COLORS["success"]}'}},
        {{label:'Failure', data:sliceData(allMqFailure,30), _allData:allMqFailure, backgroundColor:'{CONCLUSION_COLORS["failure"]}'}},
        {{label:'Cancelled', data:sliceData(allMqCancelled,30), _allData:allMqCancelled, backgroundColor:'{CONCLUSION_COLORS["cancelled"]}'}},
      ]
    }},
    options: {{responsive:true, scales:{{x:{{stacked:true}},y:{{stacked:true, title:{{display:true,text:'Merge Queue Checks'}}}}}}}}
  }});

  // Merge queue failure rate
  makeChart('mqFailRate_canvas', 'line', {{
    data: {{
      labels: sliceData(allLabels, 30),
      datasets: [{{label:'Failure Rate %', data:sliceData(allMqFailRate,30), _allData:allMqFailRate, borderColor:'#dc3545', fill:true, backgroundColor:'rgba(220,53,69,0.1)', tension:0.1}}]
    }},
    options: {{responsive:true, scales:{{y:{{min:0, max:100, title:{{display:true,text:'%'}}}}}}}}
  }});

  // Merge queue turnaround time
  makeChart('mqTurnaround_canvas', 'line', {{
    data: {{
      labels: sliceData(allLabels, 30),
      datasets: [{{label:'Avg Turnaround', data:sliceData(allMqTat,30), _allData:allMqTat, borderColor:'#0d6efd', fill:false, tension:0.1}}]
    }},
    options: {{responsive:true, scales:{{y:{{title:{{display:true,text:'Minutes'}}}}}}}}
  }});
}}
</script>
"""
    with open(os.path.join(output_dir, "statistics.html"), "w") as f:
        f.write(page_template("Statistics", body, "Statistics"))


# --- Monthly timeline pages ---


def generate_month_page(month, month_jobs, config, output_dir, generated_at=""):
    """Generate a monthly timeline page with daily Gantt views."""
    # Group by date, then by runner
    days = defaultdict(lambda: defaultdict(list))
    workflows = set()
    branches = set()

    for job in month_jobs:
        started = parse_dt(job.get("started_at"))
        completed = parse_dt(job.get("completed_at"))
        if not started or not completed:
            continue
        runner = job.get("runner_name") or "unknown"
        workflows.add(job.get("workflow_name", ""))
        branches.add(job.get("head_branch", ""))
        if completed <= started:
            continue

        # Split jobs into per-day segments to handle midnight spanning.
        day_start = datetime.datetime.combine(
            started.date(), datetime.time.min, tzinfo=started.tzinfo
        )
        while day_start < completed:
            next_day = day_start + datetime.timedelta(days=1)
            seg_start = max(started, day_start)
            seg_end = min(completed, next_day)
            if seg_end > seg_start:
                date_str = day_start.strftime("%Y-%m-%d")
                seg = dict(job)
                seg["_seg_started_at"] = seg_start.isoformat()
                seg["_seg_completed_at"] = seg_end.isoformat()
                days[date_str][runner].append(seg)
            day_start = next_day

    sorted_dates = sorted(days.keys())

    # Build HTML for each day
    days_html = []
    for date_str in sorted_dates:
        runners_data = days[date_str]
        sorted_runners = sorted(runners_data.keys())
        num_runners = len(sorted_runners)
        timeline_height = num_runners * ROW_HEIGHT + 30  # header

        # Runner rows with job blocks
        rows_html = []
        for ri, runner in enumerate(sorted_runners):
            top = 30 + ri * ROW_HEIGHT
            runner_esc = html_mod.escape(runner)
            # Runner label
            rows_html.append(
                f'<div style="position:absolute;left:0;top:{top}px;width:120px;height:{ROW_HEIGHT}px;'
                f'font-size:11px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;'
                f'line-height:{ROW_HEIGHT}px;padding:0 4px;background:#f8f9fa;border-bottom:1px solid #eee;z-index:1" '
                f'title="{runner_esc}">{runner_esc}</div>'
            )

            for job in runners_data[runner]:
                seg_start = job.get("_seg_started_at")
                seg_end = job.get("_seg_completed_at")
                started = parse_dt(seg_start) if seg_start else parse_dt(job["started_at"])
                completed = parse_dt(seg_end) if seg_end else parse_dt(job["completed_at"])
                # Position in pixels from midnight UTC
                start_hour = started.hour + started.minute / 60 + started.second / 3600
                dur_hours = (completed - started).total_seconds() / 3600
                left = 120 + int(start_hour * PIXELS_PER_HOUR)
                width = max(int(dur_hours * PIXELS_PER_HOUR), 3)

                conclusion = job.get("conclusion", "")
                color = CONCLUSION_COLORS.get(conclusion, "#6c757d")
                name = html_mod.escape(job.get("name", ""), quote=True)
                wf = html_mod.escape(job.get("workflow_name", ""), quote=True)
                branch = html_mod.escape(job.get("head_branch", ""), quote=True)
                dur = format_duration((completed - started).total_seconds())
                queue = format_duration(job.get("queued_seconds"))
                url = html_mod.escape(job.get("html_url", ""), quote=True)

                conclusion_esc = html_mod.escape(conclusion, quote=True)
                tooltip = f"{name}\\n{wf} / {branch}\\nDuration: {dur}, Queue: {queue}\\nConclusion: {conclusion_esc}"

                rows_html.append(
                    f'<a href="{url}" target="_blank" rel="noopener noreferrer" '
                    f'class="job-block" '
                    f'data-wf="{wf}" data-branch="{branch}" '
                    f'style="position:absolute;left:{left}px;top:{top + 2}px;'
                    f'width:{width}px;height:{ROW_HEIGHT - 4}px;'
                    f'background:{color};border-radius:3px;opacity:0.85;'
                    f'display:block;text-decoration:none;cursor:pointer;overflow:hidden;'
                    f'font-size:10px;color:white;line-height:{ROW_HEIGHT - 4}px;padding:0 2px;'
                    f'white-space:nowrap" title="{tooltip}">{name}</a>'
                )

        # Hour markers
        hour_markers = []
        for h in range(25):
            x = 120 + h * PIXELS_PER_HOUR
            hour_markers.append(
                f'<div style="position:absolute;left:{x}px;top:0;height:100%;'
                f'border-left:1px solid #eee;font-size:10px;color:#999;padding:2px 4px">'
                f'{h:02d}:00</div>'
            )

        total_w = 120 + TOTAL_WIDTH
        days_html.append(f"""
<h3>{date_str} ({num_runners} runners, {sum(len(v) for v in runners_data.values())} jobs)</h3>
<div style="overflow-x:auto;margin-bottom:20px">
<div style="position:relative;width:{total_w}px;height:{timeline_height}px;background:white;border:1px solid #dee2e6">
{''.join(hour_markers)}
{''.join(rows_html)}
</div>
</div>
""")

    # Filter controls
    wf_options = "".join(
        f'<option value="{html_mod.escape(w)}">{html_mod.escape(w)}</option>'
        for w in sorted(workflows) if w
    )
    br_options = "".join(
        f'<option value="{html_mod.escape(b)}">{html_mod.escape(b)}</option>'
        for b in sorted(branches) if b
    )

    updated_html = f'\n<p style="color:#6c757d">Last updated: {generated_at}.</p>' if generated_at else ""
    body = f"""
<h1>Timeline: {month}</h1>{updated_html}
<div style="margin-bottom:15px">
  <label>Workflow: </label>
  <select id="wfFilter" onchange="filterJobs()">
    <option value="">All</option>
    {wf_options}
  </select>
  &nbsp;
  <label>Branch: </label>
  <select id="brFilter" onchange="filterJobs()">
    <option value="">All</option>
    {br_options}
  </select>
</div>
{''.join(days_html)}
<script>
function filterJobs() {{
  const wf = document.getElementById('wfFilter').value;
  const br = document.getElementById('brFilter').value;
  document.querySelectorAll('.job-block').forEach(el => {{
    const matchWf = !wf || el.dataset.wf === wf;
    const matchBr = !br || el.dataset.branch === br;
    el.style.display = (matchWf && matchBr) ? 'block' : 'none';
  }});
}}
</script>
"""
    with open(os.path.join(output_dir, f"month_{month}.html"), "w") as f:
        f.write(page_template(f"Timeline {month}", body, ""))


# --- Health page ---


def generate_health(output_dir):
    """Generate placeholder health page only if it doesn't exist yet.

    The real health page is generated by ci_health.py on a 15-minute
    schedule. This only creates the initial placeholder.
    """
    path = os.path.join(output_dir, "health.html")
    if os.path.exists(path):
        return
    body = """
<h1>CI System Health</h1>
<p style="color:#6c757d">Live status of CI infrastructure. Updated every 15 minutes.</p>
<p>Waiting for first health update...</p>
"""
    with open(path, "w") as f:
        f.write(page_template("Health", body, "Health"))


def _load_monthly_jobs(input_dir):
    """Load all ci_jobs_YYYY-MM.json files from a directory into a flat list."""
    pattern = os.path.join(input_dir, "ci_jobs_*.json")
    files = sorted(glob.glob(pattern))
    # Filter to only YYYY-MM format files (exclude legacy ci_jobs.json if present)
    prefix = "ci_jobs_"
    suffix = ".json"
    files = [
        p for p in files
        if (m := os.path.basename(p)[len(prefix):-len(suffix)])
        and len(m) == 7
        and m[4] == "-"
    ]
    if not files:
        print(f"Error: no ci_jobs_*.json files found in {input_dir}", file=sys.stderr)
        sys.exit(2)
    all_jobs = []
    for path in files:
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, list):
                print(
                    f"Error: expected top-level array in {path}, got {type(data).__name__}",
                    file=sys.stderr,
                )
                sys.exit(2)
            all_jobs.extend(data)
        except (json.JSONDecodeError, OSError) as e:
            print(f"Error: failed reading {path}: {e}", file=sys.stderr)
            sys.exit(2)
    return all_jobs


# --- Main ---


def main():
    args = parse_args()
    config = load_config()

    # Load job data
    if args.input_dir:
        print(f"Loading job data from {args.input_dir}/...")
        jobs_data = _load_monthly_jobs(args.input_dir)
    else:
        print(f"Loading job data from {args.input}...")
        try:
            with open(args.input, encoding="utf-8") as f:
                jobs_data = json.load(f)
        except FileNotFoundError:
            print(f"Error: input JSON not found: {args.input}", file=sys.stderr)
            sys.exit(2)
        except json.JSONDecodeError as e:
            print(f"Error: invalid JSON in {args.input}: {e}", file=sys.stderr)
            sys.exit(2)
        except OSError as e:
            print(f"Error: failed reading {args.input}: {e}", file=sys.stderr)
            sys.exit(2)
        if not isinstance(jobs_data, list):
            print(
                f"Error: expected top-level array in {args.input}, got {type(jobs_data).__name__}",
                file=sys.stderr,
            )
            sys.exit(2)
    print(f"Loaded {len(jobs_data)} jobs")

    # Load PR merge data (optional)
    pr_data = []
    if os.path.exists(args.pr_input):
        try:
            with open(args.pr_input, encoding="utf-8") as f:
                pr_data = json.load(f)
            if not isinstance(pr_data, list):
                print(
                    f"Warning: PR data in {args.pr_input} is not a list; ignoring",
                    file=sys.stderr,
                )
                pr_data = []
            else:
                pr_data = [p for p in pr_data if isinstance(p, dict)]
            print(f"Loaded {len(pr_data)} merged PRs from {args.pr_input}")
        except (json.JSONDecodeError, OSError) as e:
            print(f"Warning: Could not load PR data: {e}", file=sys.stderr)
    else:
        print(f"No PR data at {args.pr_input} (skipping PRs merged chart)")

    # Process
    data = process_jobs(jobs_data, config)
    data["pr_merges"] = pr_data
    print(f"Active jobs (excluding skipped): {len(data['active_jobs'])}")
    print(f"Date range: {data['dates'][0] if data['dates'] else 'N/A'} to {data['dates'][-1] if data['dates'] else 'N/A'}")
    print(f"Months: {len(data['months'])}")

    # Generate output
    os.makedirs(args.output, exist_ok=True)

    print("Generating index.html...")
    generate_index(data, args.output)

    print("Generating statistics.html...")
    generate_statistics(data, config, args.output)

    print("Generating health.html...")
    generate_health(args.output)

    for month in data["months"]:
        print(f"Generating month_{month}.html...")
        generate_month_page(month, data["jobs_by_month"][month], config, args.output, data["generated_at"])

    print(f"\nDone! Output written to {args.output}/")
    print(f"Open {args.output}/index.html in a browser to view.")


if __name__ == "__main__":
    main()
