//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK):
// Test forward references in generic constraints

interface IFloat {}
interface IFoo<T : IFloat> {}
interface IBar<T, U> {}
interface IBaz<let V : int> {}

// Test case 1: Simple forward reference in interface constraint
void test1<Foo : IFoo<T>, T : IFloat>() {}
//CHECK:         ^^^^ forward reference in generic constraint
//CHECK:         ^^^^ generic constraint for parameter 'Foo' references parameter 'T' before it is declared

// Test case 2: Multiple forward references in a single constraint
void test2<A : IBar<B, C>, B : IFloat, C : IFloat>() {}
//CHECK:       ^^^^ forward reference in generic constraint
//CHECK:       ^^^^ generic constraint for parameter 'A' references parameter 'B' before it is declared
//CHECK:       ^^^^ forward reference in generic constraint
//CHECK:       ^^^^ generic constraint for parameter 'A' references parameter 'C' before it is declared

// Valid case that should NOT produce our error:
// Test case 3: Correct order - parameter declared before use
void test3<T : IFloat, Foo : IFoo<T>>() {}

// Test case 4: Forward reference to value parameter
void test4<A : IBaz<V>, let V : int>() {}
//CHECK:       ^^^^ forward reference in generic constraint
//CHECK:       ^^^^ generic constraint for parameter 'A' references parameter 'V' before it is declared
