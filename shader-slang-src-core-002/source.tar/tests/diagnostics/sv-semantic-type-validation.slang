//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK1): -target spirv -entry vsWrongVectorSize -stage vertex
//TEST:SIMPLE(filecheck=CHECK2): -target spirv -entry vsPositionFloat2 -stage vertex
//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK3): -target spirv -entry vsConditionalWrongType -stage vertex
//TEST:SIMPLE(filecheck=CHECK4): -target spirv -entry vsConditionalCorrectType -stage vertex
//TEST:SIMPLE(filecheck=CHECK5): -target spirv -entry vsConditionalOutputFloat2 -stage vertex
//TEST:SIMPLE(filecheck=CHECK6): -target spirv -entry vsConditionalOutputCorrectType -stage vertex
//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK7): -target spirv -entry vsConditionalOutputWrongType -stage vertex
//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK8): -target spirv -entry vsPositionScalar -stage vertex
//TEST:SIMPLE(filecheck=CHECK9): -target spirv -entry vsPositionFloat3 -stage vertex
//TEST:SIMPLE(filecheck=CHECK10): -target hlsl -entry vsPositionFloat2 -stage vertex
// Tests for cross-category coercion rejection (issue #6428):
//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK11): -target hlsl -entry vsBoolViewID -stage vertex
//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK12): -target hlsl -entry fsIntIsFrontFace -stage fragment
//TEST:SIMPLE(filecheck=CHECK13): -target hlsl -entry csInt3DispatchThreadID -stage compute
// Tests for unsized-array element-type path in isSemanticTypeCompatible:
//TEST:SIMPLE(filecheck=CHECK14): -target hlsl -entry vsClipDistanceFloat -stage vertex
//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK15): -target hlsl -entry vsClipDistanceInt -stage vertex
// The Metal SV_InstanceID rewrite relies on this front-end check admitting only scalars:
//DIAGNOSTIC_TEST:SIMPLE(diag=CHECK16): -target metal -entry vsVectorInstanceID -stage vertex

// Test type validation for system value semantics.
// Each SV_ semantic declares its accepted types. Shape mismatches (e.g., vector for a
// scalar semantic) produce errors, while scalar type coercions (e.g., int to uint) are allowed.

// Test 1: Wrong vector size for SV_VertexID
// SV_VertexID requires uint (scalar), not uint2 (vector)
float4 vsWrongVectorSize(uint2 vertexId : SV_VertexID) : SV_Position
//CHECK1:                      ^^^^^^^^ type 'vector<uint,2>' is not valid for system value semantic 'SV_VertexID'; expected 'uint'
{
    return float4(float(vertexId.x), 0, 0, 1);
}

// Test 2: float2 is an accepted type for SV_Position output (HLSL allows fewer components)
// CHECK2-NOT: error 30701
float2 vsPositionFloat2(uint vertexId : SV_VertexID) : SV_Position
{
    return float2(float(vertexId), 0);
}

// Test 3: Conditional<T, hasValue> should unwrap to T for type validation (input)
// Conditional<uint2, true> unwraps to uint2, which is wrong for SV_VertexID
// The error message shows the unwrapped type (what's actually validated)
float4 vsConditionalWrongType(Conditional<uint2, true> vertexId : SV_VertexID) : SV_Position
//CHECK3:                                              ^^^^^^^^ type 'vector<uint,2>' is not valid for system value semantic 'SV_VertexID'; expected 'uint'
{
    return float4(0, 0, 0, 1);
}

// Test 4: Conditional<uint, true> unwraps to uint, which is correct for SV_VertexID (input)
// CHECK4-NOT: error 30701
float4 vsConditionalCorrectType(Conditional<uint, true> vertexId : SV_VertexID) : SV_Position
{
    return float4(0, 0, 0, 1);
}

// Test 5: Conditional<float2, true> unwraps to float2, which is now accepted for SV_Position
// CHECK5-NOT: error 30701
Conditional<float2, true> vsConditionalOutputFloat2(uint vertexId : SV_VertexID) : SV_Position
{
    return float2(0, 0);
}

// Test 6: Conditional<float4, true> unwraps to float4, which is correct for SV_Position (output)
// CHECK6-NOT: error 30701
Conditional<float4, true> vsConditionalOutputCorrectType(uint vertexId : SV_VertexID) : SV_Position
{
    return float4(0, 0, 0, 1);
}

// Test 7: Conditional<float, true> unwraps to float (scalar), which is wrong for SV_Position
Conditional<float, true> vsConditionalOutputWrongType(uint vertexId : SV_VertexID) : SV_Position
//CHECK7:                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^ type 'float' is not valid for system value semantic 'SV_Position'; expected 'vector<float,4>' or 'vector<float,3>' or 'vector<float,2>'
{
    return float(vertexId);
}

// Test 8: Scalar type is rejected for SV_Position (only float2/float3/float4 accepted)
float vsPositionScalar(uint vertexId : SV_VertexID) : SV_Position
/*CHECK8:
      ^^^^^^^^^^^^^^^^ type 'float' is not valid for system value semantic 'SV_Position'; expected 'vector<float,4>' or 'vector<float,3>' or 'vector<float,2>'
*/
{
    return float(vertexId);
}

// Test 9: float3 is an accepted type for SV_Position
// CHECK9-NOT: error 30701
float3 vsPositionFloat3(uint vertexId : SV_VertexID) : SV_Position
{
    return float3(float(vertexId), 0, 0);
}

// Test 10: float2 for SV_Position works for HLSL target too
// CHECK10-NOT: error 30701
// (uses vsPositionFloat2 entry point from Test 2, targeting HLSL)

// Test 11: bool is rejected for SV_ViewID (uint semantic) — cross-category coercion (issue #6428)
[shader("vertex")]
float4 vsBoolViewID(bool id: SV_ViewID) : SV_Position
//CHECK11:               ^^ type 'bool' is not valid for system value semantic 'SV_ViewID'; expected 'uint'
{
    return float4(0, 0, 0, 1);
}

// Test 12: int is rejected for SV_IsFrontFace (bool semantic) — cross-category coercion (issue #6428)
[shader("fragment")]
float4 fsIntIsFrontFace(int isFront: SV_IsFrontFace) : SV_Target
//CHECK12:                  ^^^^^^^ type 'int' is not valid for system value semantic 'SV_IsFrontFace'; expected 'bool'
{
    return float4(0, 0, 0, 1);
}

// Test 13: int3 is accepted for SV_DispatchThreadID (uint3 semantic) — sign coercion is preserved
// CHECK13-NOT: E30701
[shader("compute")]
[numthreads(1, 1, 1)]
void csInt3DispatchThreadID(int3 tid: SV_DispatchThreadID) {}

// Test 14: float[N] for SV_ClipDistance (unsized-array accessor path) — positive case
// CHECK14-NOT: E30701
[shader("vertex")]
float4 vsClipDistanceFloat(uint id: SV_VertexID, out float cd[4]: SV_ClipDistance) : SV_Position
{
    for (int i = 0; i < 4; ++i)
        cd[i] = 0;
    return float4(0, 0, 0, 1);
}

// Test 15: int[N] for SV_ClipDistance — cross-category mismatch through the unsized-array element path
[shader("vertex")]
float4 vsClipDistanceInt(uint id: SV_VertexID, out int cd[4]: SV_ClipDistance) : SV_Position
//CHECK15: type 'int[4]' is not valid for system value semantic 'SV_ClipDistance'; expected 'float' or 'float[]'
{
    for (int i = 0; i < 4; ++i)
        cd[i] = 0;
    return float4(0, 0, 0, 1);
}

// Test 16: uint2 is rejected for SV_InstanceID on every target, before Metal's base_instance rewrite
[shader("vertex")]
float4 vsVectorInstanceID(uint2 id: SV_InstanceID) : SV_Position
//CHECK16:                      ^^ type 'vector<uint,2>' is not valid for system value semantic 'SV_InstanceID'; expected 'uint'
{
    return float4(0, 0, 0, 1);
}
