// Basic test for builtin neural "frontend" APIs (layers + activations).
//
//TEST(compute, vulkan):COMPARE_COMPUTE_EX(filecheck-buffer=BUFFER):-vk -compute -shaderobj -xslang -experimental-feature -output-using-type -emit-spirv-directly
//TEST(compute, vulkan):COMPARE_COMPUTE_EX(filecheck-buffer=BUFFER):-dx12 -compute -shaderobj -profile cs_6_6 -xslang -experimental-feature -output-using-type
//TEST(compute, vulkan):COMPARE_COMPUTE_EX(filecheck-buffer=BUFFER):-mtl -compute -shaderobj -output-using-type -xslang -experimental-feature
//TEST(compute, vulkan):COMPARE_COMPUTE_EX(filecheck-buffer=BUFFER):-cuda -compute -shaderobj -output-using-type -capability cuda_sm_7_0 -xslang -experimental-feature

import slang.neural;

// Parameters: FFLayer<float, 4, 2, ..., HasBias=true>
// weights = 2x4 matrix, bias = 2
//TEST_INPUT: set parametersFloat = ubuffer(data=[1.0 2.0 3.0 4.0  5.0 6.0 7.0 8.0  9.0 10.0], stride=4)
RWStructuredBuffer<float> parametersFloat;

//TEST_INPUT: set params = ubuffer(data=[0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0], stride=4)
uniform RWStructuredBuffer<float>.Handle params;

//TEST_INPUT: ubuffer(data=[0 0], stride=4):out,name=testResult
RWStructuredBuffer<uint> testResult;

typealias Address = BindlessAddress<float>;
typealias XVec = InlineVector<float, 4>;
typealias YVec = InlineVector<float, 2>;
typealias Act = ReLU<float>;
typealias Layer = FFLayer<float, XVec, YVec, LinearLayout, Act, true>;

// Test: evaluate layer through ILayer constraint
InlineVector<float, 2> evalAsLayer<L>(
    L layer,
    Address paramAddr,
    InlineVector<float, 4> input)
    where L : ILayer<float, InlineVector<float, 4>, InlineVector<float, 2>, LinearLayout, Act>
{
    return layer.eval<Address>(input, paramAddr);
}

bool forwardTest()
{
    // Copy parametersFloat -> params
    for(int i=0;i<10;i++) params[i] = parametersFloat[i];

    let baseAddr = Address(params);
    let layer = Layer();

    // Input x = [1,2,3,4]
    float[4] xArr = {1.0, 2.0, 3.0, 4.0};
    let x = InlineVector<float, 4>(xArr);

    // Layer: y = ReLU(W*x + b)
    let y = evalAsLayer<Layer>(layer, baseAddr, x);

    // Expected: W*x + b = [1*1+2*2+3*3+4*4 + 9, 5*1+6*2+7*3+8*4 + 10] = [39, 80]
    // ReLU([39, 80]) = [39, 80]
    return abs(y[0] - 39.0) < 0.001 && abs(y[1] - 80.0) < 0.001;
}

bool parameterCountTest()
{
    // FFLayer<float, 4->2, HasBias=true> should have 4*2 + 2 = 10 parameters
    return Layer.ParameterCount == 10;
}

[shader("compute")]
[numthreads(1, 1, 1)]
void computeMain()
{
    testResult[0] = forwardTest();
    testResult[1] = parameterCountTest();

    // BUFFER: 1
    // BUFFER-NEXT: 1
}
