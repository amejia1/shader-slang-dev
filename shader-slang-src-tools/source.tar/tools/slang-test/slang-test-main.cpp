// slang-test-main.cpp

#include "compiler-core/slang-artifact-desc-util.h"
#include "compiler-core/slang-artifact-helper.h"
#include "core/slang-byte-encode-util.h"
#include "core/slang-castable.h"
#include "core/slang-char-util.h"
#include "core/slang-hex-dump-util.h"
#include "core/slang-io.h"
#include "core/slang-memory-arena.h"
#include "core/slang-process-util.h"
#include "core/slang-render-api-util.h"
#include "core/slang-shared-library.h"
#include "core/slang-std-writers.h"
#include "core/slang-string-escape-util.h"
#include "core/slang-string-util.h"
#include "core/slang-test-tool-util.h"
#include "core/slang-token-reader.h"
#include "core/slang-type-text-util.h"
#include "slang-com-helper.h"
#include "unit-test/slang-unit-test.h"
#undef SLANG_UNIT_TEST

#include "compiler-core/slang-artifact-associated-impl.h"
#include "compiler-core/slang-downstream-compiler.h"
#include "compiler-core/slang-language-server-protocol.h"
#include "compiler-core/slang-nvrtc-compiler.h"
#include "diagnostic-annotation-util.h"
#include "directory-util.h"
#include "options.h"
#include "parse-diagnostic-util.h"
#include "render-test/slang-support.h"
#include "slang-test-optimization-options.h"
#include "slangc-tool.h"
#include "slangi-tool.h"
#include "test-context.h"
#include "test-output-path-util.h"
#include "test-reporter.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <math.h>
#include <random>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#define SLANG_PRELUDE_NAMESPACE CPPPrelude
#include "slang-cpp-types.h"

#include <atomic>
#include <thread>

#if SLANG_UNIX_FAMILY
#include <signal.h>
#endif

#if defined(_WIN32)
#include <slang-rhi/agility-sdk.h>
SLANG_RHI_EXPORT_AGILITY_SDK
#endif

using namespace Slang;

// Constants for slang-test specific options
static const char* kPreserveEmbeddedSourceOption = "-preserve-embedded-source";

// Options for a particular test
struct TestOptions
{
    enum Type
    {
        Normal,     ///< A regular test
        Diagnostic, ///< Diagnostic tests will always run (as form of failure is being tested)
    };

    void addCategory(TestCategory* category)
    {
        if (categories.indexOf(category) < 0)
        {
            categories.add(category);
        }
    }
    void addCategories(TestCategory* const* inCategories, Index count)
    {
        for (Index i = 0; i < count; ++i)
        {
            addCategory(inCategories[i]);
        }
    }

    // Small helper to help consistently interrogating for filecheck usage
    bool getFileCheckPrefix(String& prefix) const
    {
        return commandOptions.tryGetValue("filecheck", prefix);
    }
    bool getFileCheckBufferPrefix(String& prefix) const
    {
        return commandOptions.tryGetValue("filecheck-buffer", prefix);
    }
    bool getDiagTestPrefix(String& prefix) const
    {
        return commandOptions.tryGetValue("diag", prefix);
    }
    bool isNonExhaustiveDiagTest() const { return commandOptions.containsKey("non-exhaustive"); }

    Type type = Type::Normal;

    String command;
    List<String> args;

    Dictionary<String, String> commandOptions;

    // The categories that this test was assigned to
    List<TestCategory*> categories;

    bool isEnabled = true;
    bool isSynthesized = false;
};

struct FileTestInfoImpl : public FileTestInfo
{
    String testName;
    String filePath;
    String outputStem;
    TestOptions options;
};

struct TestDetails
{
    TestDetails() {}
    explicit TestDetails(const TestOptions& inOptions)
        : options(inOptions)
    {
    }

    TestOptions options;           ///< The options for the test
    TestRequirements requirements; ///< The requirements for the test to work
};

// Information on tests to run for a particular file
struct FileTestList
{
    List<TestDetails> tests;
};


struct TestInput
{
    // Path to the input file for the test
    String filePath;

    // Prefix for the path that test output should write to
    // (usually the same as `filePath`, but will differ when
    // we run multiple tests out of the same file)
    String outputStem;

    // Arguments for the test (usually to be interpreted
    // as command line args)
    TestOptions const* testOptions;

    // Determines how the test will be spawned
    SpawnType spawnType;
};

typedef TestResult (*TestCallback)(TestContext* context, TestInput& input);

// Globals

// Pre declare
static void _addRenderTestOptions(
    const Options& options,
    CommandLine& ioCmdLine,
    bool allowCacheRHI);

/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!! Functions !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */

// Tries to read in order
// - The file specific to this test:      input.outputStem + suffix
// - The general file for a set of tests: input.fileName + suffix;
static SlangResult _readTestFile(const TestInput& input, const String& suffix, String& out)
{
    StringBuilder buf;
    buf << input.outputStem << suffix;
    if (auto r = Slang::File::readAllText(buf, out); SLANG_SUCCEEDED(r))
    {
        return r;
    }

    buf.clear();
    buf << input.filePath << suffix;
    return Slang::File::readAllText(buf, out);
}


bool match(char const** ioCursor, char const* expected)
{
    char const* cursor = *ioCursor;
    while (*expected && *cursor == *expected)
    {
        cursor++;
        expected++;
    }
    if (*expected != 0)
        return false;

    *ioCursor = cursor;
    return true;
}

void skipHorizontalSpace(char const** ioCursor)
{
    char const* cursor = *ioCursor;
    for (;;)
    {
        switch (*cursor)
        {
        case ' ':
        case '\t':
            cursor++;
            continue;

        default:
            break;
        }

        break;
    }
    *ioCursor = cursor;
}

void skipToEndOfLine(char const** ioCursor)
{
    char const* cursor = *ioCursor;
    for (;;)
    {
        int c = *cursor;
        switch (c)
        {
        default:
            cursor++;
            continue;

        case '\r':
        case '\n':
            {
                cursor++;
                int d = *cursor;
                if ((c ^ d) == ('\r' ^ '\n'))
                {
                    cursor++;
                }
            }
            [[fallthrough]];
        case 0:
            *ioCursor = cursor;
            return;
        }
    }
}

String getString(char const* textBegin, char const* textEnd)
{
    StringBuilder sb;
    sb.append(textBegin, textEnd - textBegin);
    return sb.produceString();
}

String collectRestOfLine(char const** ioCursor)
{
    char const* cursor = *ioCursor;

    char const* textBegin = cursor;
    skipToEndOfLine(&cursor);
    char const* textEnd = cursor;

    *ioCursor = cursor;
    return getString(textBegin, textEnd);
}

static bool _isEndOfLineOrParens(char c)
{
    switch (c)
    {
    case '\n':
    case '\r':
    case 0:
    case ')':
        {
            return true;
        }
    default:
        return false;
    }
}

static SlangResult _parseCategories(
    TestCategorySet* categorySet,
    char const** ioCursor,
    TestOptions& out)
{
    char const* cursor = *ioCursor;

    // If don't have ( we don't have category list
    if (*cursor == '(')
    {
        cursor++;
        const char* const start = cursor;

        // Find the end
        for (; !_isEndOfLineOrParens(*cursor); ++cursor)
            ;
        if (*cursor != ')')
        {
            *ioCursor = cursor;
            return SLANG_FAIL;
        }
        cursor++;

        List<UnownedStringSlice> slices;
        StringUtil::split(UnownedStringSlice(start, cursor - 1), ',', slices);

        for (auto& slice : slices)
        {
            // Trim any whitespace
            auto categoryName = slice.trim();

            TestCategory* category = categorySet->find(categoryName);

            if (!category)
            {
                // Mark this test as disabled, as we don't have all of the categories
                out.isEnabled = false;
                break;
            }

            out.addCategory(category);
        }
    }

    *ioCursor = cursor;
    return SLANG_OK;
}

static SlangResult _parseCommandArguments(char const** ioCursor, TestOptions& out)
{
    char const* cursor = *ioCursor;

    // If don't have ( we don't have any additional options
    if (*cursor == '(')
    {
        cursor++;
        const char* const start = cursor;

        // Find the end
        for (; !_isEndOfLineOrParens(*cursor); ++cursor)
            ;
        if (*cursor != ')')
        {
            *ioCursor = cursor;
            return SLANG_FAIL;
        }
        cursor++;

        List<UnownedStringSlice> options;
        StringUtil::split(UnownedStringSlice(start, cursor - 1), ',', options);

        for (auto& option : options)
        {
            auto i = option.indexOf('=');
            if (i == -1)
            {
                out.commandOptions.add(option.trim(), "");
            }
            else
            {
                out.commandOptions.add(option.head(i).trim(), option.tail(i + 1).trim());
            }
        }
    }

    *ioCursor = cursor;
    return SLANG_OK;
}

static SlangResult _parseArg(const char** ioCursor, UnownedStringSlice& outArg)
{
    const char* cursor = *ioCursor;
    const char* const argBegin = cursor;

    // Let's try to read one option
    for (;;)
    {
        switch (*cursor)
        {
        default:
            {
                ++cursor;
                break;
            }
        case '"':
            {
                // If we have quotes let's just parse them as is and make output
                auto escapeHandler = StringEscapeUtil::getHandler(StringEscapeUtil::Style::Space);
                SLANG_RETURN_ON_FAIL(escapeHandler->lexQuoted(cursor, &cursor));
                break;
            }
        case 0:
        case '\r':
        case '\n':
        case ' ':
        case '\t':
            {
                char const* argEnd = cursor;
                SLANG_ASSERT(argBegin != argEnd);

                outArg = UnownedStringSlice(argBegin, argEnd);
                *ioCursor = cursor;
                return SLANG_OK;
            }
        }
    }
}

static SlangResult _gatherTestOptions(
    TestCategorySet* categorySet,
    char const** ioCursor,
    TestOptions& outOptions)
{
    SLANG_RETURN_ON_FAIL(_parseCategories(categorySet, ioCursor, outOptions));

    char const* cursor = *ioCursor;

    if (*cursor != ':')
    {
        return SLANG_FAIL;
    }
    cursor++;

    // Next scan for a sub-command name
    char const* commandStart = cursor;
    for (;;)
    {
        switch (*cursor)
        {
        default:
            cursor++;
            continue;

        case '(':
        case ':':
            break;

        case 0:
        case '\r':
        case '\n':
            return SLANG_FAIL;
        }

        break;
    }
    char const* commandEnd = cursor;

    outOptions.command = getString(commandStart, commandEnd);

    // Allow parameterizing the test command separately from the arguments, this
    // is because the arguments are often passed to the compiler verbatim, and
    // it's messy to have the test runner rifling through and picking things
    // out
    // Format is: (foo=bar, baz = 2)
    SLANG_RETURN_ON_FAIL(_parseCommandArguments(&cursor, outOptions));

    if (*cursor == ':')
        cursor++;
    else
    {
        return SLANG_FAIL;
    }

    // Now scan for arguments. For now we just assume that
    // any whitespace separation indicates a new argument
    for (;;)
    {
        skipHorizontalSpace(&cursor);

        // End of line? then no more options.
        switch (*cursor)
        {
        case 0:
        case '\r':
        case '\n':
            skipToEndOfLine(&cursor);

            *ioCursor = cursor;
            return SLANG_OK;

        default:
            break;
        }

        // Let's try to read one option
        UnownedStringSlice arg;
        SLANG_RETURN_ON_FAIL(_parseArg(&cursor, arg));

        outOptions.args.add(arg);
    }
}


static RenderApiFlags _getRequiredRenderApisByCommand(const UnownedStringSlice& name);

static void _combineOptions(
    TestCategorySet* categorySet,
    const TestOptions& fileOptions,
    TestOptions& ioOptions)
{
    // And the file categories
    ioOptions.addCategories(fileOptions.categories.getBuffer(), fileOptions.categories.getCount());

    // If no categories were specified, then add the default category
    if (ioOptions.categories.getCount() == 0)
    {
        ioOptions.categories.add(categorySet->defaultCategory);
    }
}

static SlangResult _extractCommand(const char** ioCursor, UnownedStringSlice& outCommand)
{
    const char* cursor = *ioCursor;
    const char* const start = cursor;

    while (true)
    {
        const char c = *cursor;

        if (CharUtil::isAlpha(c) || c == '_')
        {
            cursor++;
            continue;
        }

        if (c == ':' || c == '(' || c == 0 || c == '\n' || c == '\r')
        {
            *ioCursor = cursor;
            outCommand = UnownedStringSlice(start, cursor);
            return SLANG_OK;
        }

        return SLANG_FAIL;
    }
}

static void applyMacroSubstitution(String filePath, TestDetails& details)
{
    for (auto& arg : details.options.args)
    {
        arg = StringUtil::replaceAll(
            arg.getUnownedSlice(),
            toSlice("$dirname"),
            Path::getParentDirectory(filePath).getUnownedSlice());
    }
}

// Normalizes and validates the output-path arguments of a parsed test directive, reporting any
// rejection (an absolute `-o` / `-separate-debug-info-output` path) as a run error against
// `filePath` so the test fails rather than silently running with an unportable path.
static SlangResult _normalizeTestOutputPaths(
    const String& filePath,
    List<String>& args,
    TestContext* context)
{
    String error;
    const SlangResult res = normalizeTestOutputPathsForTestFile(filePath, args, error);
    if (SLANG_FAILED(res))
    {
        // Every path that reaches directive parsing installs a reporter first, so a missing one is
        // a programming error rather than a case to handle.
        SLANG_ASSERT(context && context->getTestReporter());
        context->getTestReporter()->messageFormat(
            TestMessageType::RunError,
            "Invalid test directive in file '%s': %s",
            filePath.getBuffer(),
            error.getBuffer());
    }
    return res;
}

// Try to read command-line options from the test file itself
static SlangResult _gatherTestsForFile(
    TestCategorySet* categorySet,
    String filePath,
    FileTestList* outTestList,
    TestContext* context = nullptr)
{
    outTestList->tests.clear();

    String fileContents;

    TestReporter* testReporter = nullptr;
    if (context)
        testReporter = context->getTestReporter();

    // Try reading the file with retries on failure to handle intermittent I/O errors
    // (commonly seen on macOS in CI environments)
    SlangResult readResult = SLANG_FAIL;
    for (int retryCount = 0; retryCount < 3 && SLANG_FAILED(readResult); ++retryCount)
    {
        if (retryCount)
        {
            if (testReporter)
            {
                testReporter->messageFormat(
                    TestMessageType::Info,
                    "Retrying to read test file '%s' (attempt %d)",
                    filePath.getBuffer(),
                    retryCount + 1);
            }
            else
            {
                fprintf(
                    stderr,
                    "Retrying to read test file '%s' (attempt %d)\n",
                    filePath.getBuffer(),
                    retryCount + 1);
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(retryCount * 100));
        }
        readResult = Slang::File::readAllText(filePath, fileContents);
    }
    if (SLANG_FAILED(readResult))
    {
        // Log file reading failure with details (thread-safe)
        if (testReporter)
        {
            testReporter->messageFormat(
                TestMessageType::RunError,
                "Failed to read test file '%s' (error: 0x%08X)",
                filePath.getBuffer(),
                (unsigned int)readResult);
        }
        else
        {
            // Fallback to stderr if no context available
            fprintf(
                stderr,
                "Failed to read test file '%s' (error: 0x%08X)\n",
                filePath.getBuffer(),
                (unsigned int)readResult);
        }
        return readResult;
    }

    // Walk through the lines of the file, looking for test commands
    char const* cursor = fileContents.begin();

    // Options that are specified across all tests in the file.
    TestOptions fileOptions;

    while (*cursor)
    {
        // We are at the start of a line of input.

        skipHorizontalSpace(&cursor);

        if (!match(&cursor, "//"))
        {
            skipToEndOfLine(&cursor);
            continue;
        }

        // Skip any extra slashes and spaces to handle malformed directives like ///TEST or // TEST
        while (*cursor == '/')
        {
            cursor++;
        }
        skipHorizontalSpace(&cursor);

        UnownedStringSlice command;

        if (SLANG_FAILED(_extractCommand(&cursor, command)))
        {
            // Couldn't find a command so skip
            skipToEndOfLine(&cursor);
            continue;
        }

        // Look for a pattern that matches what we want
        if (command == "TEST_IGNORE_FILE")
        {
            outTestList->tests.clear();
            return SLANG_OK;
        }

        const UnownedStringSlice disablePrefix = UnownedStringSlice::fromLiteral("DISABLE_");

        TestDetails testDetails;

        {
            if (command.startsWith(disablePrefix))
            {
                testDetails.options.isEnabled = false;
                command = command.tail(disablePrefix.getLength());
            }
        }

        if (command == "TEST_CATEGORY")
        {
            SlangResult res = _parseCategories(categorySet, &cursor, fileOptions);

            // If it failed we are done, unless it was just 'not available'
            if (SLANG_FAILED(res) && res != SLANG_E_NOT_AVAILABLE)
            {
                if (context && context->getTestReporter())
                {
                    context->getTestReporter()->messageFormat(
                        TestMessageType::RunError,
                        "Failed to parse TEST_CATEGORY in file '%s' (error: 0x%08X)",
                        filePath.getBuffer(),
                        (unsigned int)res);
                }
                else
                {
                    fprintf(
                        stderr,
                        "Failed to parse TEST_CATEGORY in file '%s' (error: 0x%08X)\n",
                        filePath.getBuffer(),
                        (unsigned int)res);
                }
                return res;
            }

            skipToEndOfLine(&cursor);
            continue;
        }

        if (command == "TEST")
        {
            SlangResult testRes = _gatherTestOptions(categorySet, &cursor, testDetails.options);
            if (SLANG_FAILED(testRes))
            {
                if (context && context->getTestReporter())
                {
                    context->getTestReporter()->messageFormat(
                        TestMessageType::RunError,
                        "Failed to parse TEST directive in file '%s' (error: 0x%08X)",
                        filePath.getBuffer(),
                        (unsigned int)testRes);
                }
                else
                {
                    fprintf(
                        stderr,
                        "Failed to parse TEST directive in file '%s' (error: 0x%08X)\n",
                        filePath.getBuffer(),
                        (unsigned int)testRes);
                }
                return testRes;
            }
            applyMacroSubstitution(filePath, testDetails);

            // See if the type of test needs certain APIs available
            const RenderApiFlags testRequiredApis =
                _getRequiredRenderApisByCommand(testDetails.options.command.getUnownedSlice());
            testDetails.requirements.addUsedRenderApis(testRequiredApis);

            // Apply the file wide options
            _combineOptions(categorySet, fileOptions, testDetails.options);
            SLANG_RETURN_ON_FAIL(
                _normalizeTestOutputPaths(filePath, testDetails.options.args, context));

            outTestList->tests.add(testDetails);
        }
        else if (command == "DIAGNOSTIC_TEST")
        {
            SlangResult diagRes = _gatherTestOptions(categorySet, &cursor, testDetails.options);
            if (SLANG_FAILED(diagRes))
            {
                if (context && context->getTestReporter())
                {
                    context->getTestReporter()->messageFormat(
                        TestMessageType::RunError,
                        "Failed to parse DIAGNOSTIC_TEST directive in file '%s' (error: 0x%08X)",
                        filePath.getBuffer(),
                        (unsigned int)diagRes);
                }
                else
                {
                    fprintf(
                        stderr,
                        "Failed to parse DIAGNOSTIC_TEST directive in file '%s' (error: 0x%08X)\n",
                        filePath.getBuffer(),
                        (unsigned int)diagRes);
                }
                return diagRes;
            }
            applyMacroSubstitution(filePath, testDetails);

            // Apply the file wide options
            _combineOptions(categorySet, fileOptions, testDetails.options);
            SLANG_RETURN_ON_FAIL(
                _normalizeTestOutputPaths(filePath, testDetails.options.args, context));

            // Mark that it is a diagnostic test
            testDetails.options.type = TestOptions::Type::Diagnostic;
            outTestList->tests.add(testDetails);
        }
        else
        {
            // Hmm we don't know what kind of test this actually is.
            // Assume that's ok and this *isn't* a test and ignore.
            skipToEndOfLine(&cursor);
        }
    }

    return SLANG_OK;
}

static void SLANG_STDCALL _fileCheckDiagnosticCallback(
    void* data,
    const TestMessageType messageType,
    const char* message) noexcept
{
    auto& testReporter = *reinterpret_cast<TestReporter*>(data);
    testReporter.message(messageType, message);
}
struct bool2
{
    bool x, y;
};
//
// Check some generated output with FileCheck
//
static TestResult _fileCheckTest(
    TestContext& context,
    const String& fileCheckRules,
    const String& fileCheckPrefix,
    const String& outputToCheck)
{
    auto& testReporter = *context.getTestReporter();

    IFileCheck* fc = context.getFileCheck();
    if (!fc)
    {
        // Ignore if FileCheck is not available.
        // We could report an error, but our ARM64 CI doesn't have FileCheck yet.
        testReporter.message(TestMessageType::Info, "FileCheck is not available");
        return TestResult::Ignored;
    }

    const bool coloredOutput = true;
    testReporter.message(TestMessageType::Info, outputToCheck.getBuffer());
    return fc->performTest(
        "slang-test",
        fileCheckRules.begin(),
        fileCheckPrefix.begin(),
        outputToCheck.begin(),
        "actual-output",
        _fileCheckDiagnosticCallback,
        &testReporter,
        coloredOutput);
}

//
// Check diagnostic annotations in the source file
//
static TestResult _diagnosticAnnotationTest(
    TestContext& context,
    const TestInput& input,
    const String& diagPrefix,
    const String& outputToCheck)
{
    auto& testReporter = *context.getTestReporter();

    // Read the source file to get annotations
    String sourceText;
    if (SLANG_FAILED(File::readAllText(input.filePath, sourceText)))
    {
        testReporter.messageFormat(
            TestMessageType::RunError,
            "Failed to read source file for diagnostic annotations: '%s'",
            input.filePath.getBuffer());
        return TestResult::Fail;
    }

    // Extract standard error from the formatted output
    // Format: "result code = X\nstandard error = {\n<content>\n}\n..."
    String standardError;
    {
        UnownedStringSlice output = outputToCheck.getUnownedSlice();
        Index stderrStart = output.indexOf(UnownedStringSlice::fromLiteral("standard error = {\n"));
        if (stderrStart != -1)
        {
            stderrStart += strlen("standard error = {\n");
            // Search for "\n}" after stderrStart
            UnownedStringSlice remaining = output.tail(stderrStart);
            Index stderrEnd = remaining.indexOf(UnownedStringSlice::fromLiteral("\n}"));
            if (stderrEnd != -1)
            {
                standardError = String(remaining.head(stderrEnd));
            }
        }
    }

    // Check if exhaustive mode (default) or non-exhaustive
    bool exhaustive = !input.testOptions->isNonExhaustiveDiagTest();

    // Check diagnostic annotations
    String errorMessage;
    if (!DiagnosticAnnotationUtil::checkDiagnosticAnnotations(
            sourceText.getUnownedSlice(),
            diagPrefix.getUnownedSlice(),
            standardError.getUnownedSlice(),
            exhaustive,
            errorMessage))
    {
        testReporter.message(TestMessageType::TestFailure, errorMessage.getBuffer());
        return TestResult::Fail;
    }

    return TestResult::Pass;
}

template<typename Compare>
static TestResult _fileComparisonTest(
    TestContext& context,
    const TestInput& input,
    const char* defaultExpectedContent,
    const char* expectedFileSuffix,
    const String& actualOutput,
    Compare compare)
{
    String expectedOutput;

    if (SLANG_FAILED(_readTestFile(input, expectedFileSuffix, expectedOutput)))
    {
        if (defaultExpectedContent)
        {
            expectedOutput = defaultExpectedContent;
        }
        else
        {
            context.getTestReporter()->messageFormat(
                TestMessageType::RunError,
                "Unable to read %s output for '%s'\n",
                expectedFileSuffix,
                input.outputStem.getBuffer());
            return TestResult::Fail;
        }
    }

    // Otherwise we compare to the expected output
    if (!compare(actualOutput, expectedOutput))
    {
        context.getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);
        return TestResult::Fail;
    }
    return TestResult::Pass;
}

static bool _areLinesEqual(const String& a, const String& e)
{
    return StringUtil::areLinesEqual(a.getUnownedSlice(), e.getUnownedSlice());
}

// Either run diagnostic annotation check, FileCheck, or compare with a .expected file
// On a comparison failure, dump the difference
// On any failure, write a .actual file.
template<typename Compare = decltype(_areLinesEqual)>
static TestResult _validateOutput(
    TestContext* const context,
    const TestInput& input,
    const String& actualOutput,
    const bool forceFailure = false,
    const char* defaultExpectedContent = nullptr,
    const Compare compare = _areLinesEqual)
{
    TestResult result = TestResult::Fail;

    // Check for diagnostic annotations first
    String diagPrefix;
    if (input.testOptions->getDiagTestPrefix(diagPrefix))
    {
        result = _diagnosticAnnotationTest(*context, input, diagPrefix, actualOutput);
    }
    else
    {
        // Fall back to filecheck or file comparison
        String fileCheckPrefix;
        result = input.testOptions->getFileCheckPrefix(fileCheckPrefix)
                     ? _fileCheckTest(*context, input.filePath, fileCheckPrefix, actualOutput)
                     : _fileComparisonTest(
                           *context,
                           input,
                           defaultExpectedContent,
                           ".expected",
                           actualOutput,
                           compare);
    }

    // If the test failed, then we write the actual output to a file
    // so that we can easily diff it from the command line and
    // diagnose the problem.
    if (result == TestResult::Fail || forceFailure)
    {
        String actualOutputPath = input.outputStem + ".actual";
        Slang::File::writeAllText(actualOutputPath, actualOutput);
        return TestResult::Fail;
    }
    else
    {
        return result;
    }
}

Result spawnAndWaitExe(
    TestContext* context,
    const String& testPath,
    const CommandLine& cmdLine,
    ExecuteResult& outRes)
{
    std::lock_guard<std::mutex> lock(context->mutex);

    const auto& options = context->options;

    if (options.verbosity == VerbosityLevel::Verbose)
    {
        String commandLine = cmdLine.toString();
        context->getTestReporter()->messageFormat(
            TestMessageType::Info,
            "%s\n",
            commandLine.begin());
    }

    Result res = ProcessUtil::execute(cmdLine, outRes);
    if (SLANG_FAILED(res))
    {
        //        fprintf(stderr, "failed to run test '%S'\n", testPath.ToWString());
        context->getTestReporter()->messageFormat(
            TestMessageType::RunError,
            "failed to run test '%S'",
            testPath.toWString().begin());
    }
    return res;
}


Result spawnAndWaitSharedLibrary(
    TestContext* context,
    const String& testPath,
    const CommandLine& cmdLine,
    ExecuteResult& outRes)
{
    std::lock_guard<std::mutex> lock(context->mutex);

    const auto& options = context->options;
    String exeName = Path::getFileNameWithoutExt(cmdLine.m_executableLocation.m_pathOrName);

    if (options.verbosity == VerbosityLevel::Verbose)
    {
        CommandLine testCmdLine;

        testCmdLine.setExecutableLocation(ExecutableLocation("slang-test"));

        if (options.binDir.getLength())
        {
            testCmdLine.addArg("-bindir");
            testCmdLine.addArg(options.binDir);
        }

        testCmdLine.addArg(exeName);
        testCmdLine.m_args.addRange(cmdLine.m_args);

        context->getTestReporter()->messageFormat(
            TestMessageType::Info,
            "%s\n",
            testCmdLine.toString().getBuffer());
    }

    auto func = context->getInnerMainFunc(context->options.binDir, exeName);
    if (func)
    {
        StringBuilder stdErrorString;
        StringBuilder stdOutString;
        renderer_test::CoreDebugCallback coreDebugCallback;
        renderer_test::CoreToRHIDebugBridge rhiDebugBridge;
        rhiDebugBridge.setCoreCallback(&coreDebugCallback);

        // Say static so not released
        StringWriter stdError(&stdErrorString, WriterFlag::IsStatic);
        // Use IsConsole on stdout because we have tests which output spirv
        // which we want to have disassembled
        StringWriter stdOut(&stdOutString, WriterFlag::IsConsole | WriterFlag::IsStatic);

        StdWriters* prevStdWriters = StdWriters::getSingleton();

        StdWriters stdWriters;
        stdWriters.setWriter(SLANG_WRITER_CHANNEL_STD_ERROR, &stdError);
        stdWriters.setWriter(SLANG_WRITER_CHANNEL_STD_OUTPUT, &stdOut);
        stdWriters.setDebugCallback(&coreDebugCallback);

        if (exeName == "slangc" || exeName == "slangi")
        {
            stdWriters.setWriter(SLANG_WRITER_CHANNEL_DIAGNOSTIC, &stdError);
        }

        String exePath = Path::combine(context->exeDirectoryPath, exeName);

        List<const char*> args;
        args.add(exePath.getBuffer());
        for (const auto& cmdArg : cmdLine.m_args)
        {
            args.add(cmdArg.getBuffer());
        }

        SlangResult res =
            func(&stdWriters, context->getSession(), int(args.getCount()), args.begin());

        StdWriters::setSingleton(prevStdWriters);

        outRes.standardError = stdErrorString;
        outRes.standardOutput = stdOutString;
        outRes.debugLayer = coreDebugCallback.getString();

        outRes.resultCode = (int)TestToolUtil::getReturnCode(res);

        return SLANG_OK;
    }

    return SLANG_FAIL;
}


Result spawnAndWaitProxy(
    TestContext* context,
    const String& testPath,
    const CommandLine& inCmdLine,
    ExecuteResult& outRes)
{
    std::lock_guard<std::mutex> lock(context->mutex);

    // Get the name of the thing to execute
    String exeName = Path::getFileNameWithoutExt(inCmdLine.m_executableLocation.m_pathOrName);

    if (exeName == "slangc" || exeName == "slangi")
    {
        // If the test is slangc there is a command line version we can just directly use
        // return spawnAndWaitExe(context, testPath, inCmdLine, outRes);
        return spawnAndWaitSharedLibrary(context, testPath, inCmdLine, outRes);
    }

    CommandLine cmdLine(inCmdLine);

    // Make the first arg the name of the tool to invoke
    cmdLine.m_args.insert(0, exeName);
    cmdLine.setExecutableLocation(ExecutableLocation(context->exeDirectoryPath, "test-proxy"));

    const auto& options = context->options;
    if (options.verbosity == VerbosityLevel::Verbose)
    {
        String commandLine = cmdLine.toString();
        context->getTestReporter()->messageFormat(
            TestMessageType::Info,
            "%s\n",
            commandLine.begin());
    }

    // Execute
    Result res = ProcessUtil::execute(cmdLine, outRes);
    if (SLANG_FAILED(res))
    {
        //        fprintf(stderr, "failed to run test '%S'\n", testPath.ToWString());
        context->getTestReporter()->messageFormat(
            TestMessageType::RunError,
            "failed to run test '%S'",
            testPath.toWString().begin());
    }

    return res;
}

/// Why an RPC attempt did not produce a result.
///
/// The distinction that matters is Lost vs TimedOut. A lost connection says nothing at all
/// about the test that was in flight -- the request never completed, so there is no verdict
/// to report -- whereas a timeout is a statement about this test: it ran and did not finish.
/// Collapsing the two, as this code used to, means a server that dies for its own reasons is
/// recorded as "this test failed", which is simply false.
enum class RPCAttemptOutcome
{
    Ok,            ///< A result came back (whatever the test's own verdict is).
    Lost,          ///< The connection closed or errored: a running server went away.
    StartFailed,   ///< No server could be spawned, so nothing ever ran.
    TimedOut,      ///< The server is alive but did not answer in connectionTimeOutInMs.
    ProtocolError, ///< A reply arrived but was not the expected result message.
    SendFailed     ///< The request could not even be written.
};

/// Describe the death of a test server as precisely as the OS will let us.
///
/// Everything here was previously discarded. The transport already distinguishes a closed
/// pipe from a read error from a timeout (HTTPPacketConnection::getReadState), and the
/// process object already knows the exit status -- but the only thing that reached the log
/// was the name of the function that failed, which is the one detail that cannot tell an
/// OOM kill from a segfault from a clean exit.
static void _reportServerLoss(
    TestContext* context,
    JSONRPCConnection* rpcConnection,
    RPCAttemptOutcome outcome,
    int requestOrdinal,
    const char* phase)
{
    StringBuilder detail;

    SLANG_RELEASE_ASSERT(rpcConnection);
    auto* connection = rpcConnection->getUnderlyingConnection();

    switch (outcome)
    {
    case RPCAttemptOutcome::SendFailed:
        detail << "the request could not be written, though the server is still running";
        break;
    case RPCAttemptOutcome::TimedOut:
        detail << "no reply within the timeout";
        break;
    case RPCAttemptOutcome::Lost:
        if (!connection)
        {
            detail << "no transport";
        }
        else if (connection->getReadState() == HTTPPacketConnection::ReadState::Closed)
        {
            detail << "the server closed the connection";
        }
        else if (connection->getReadState() == HTTPPacketConnection::ReadState::Error)
        {
            detail << "the connection errored";
        }
        else
        {
            // Header, Content or Done: the transport saw no failure, so the loss was
            // established by the process being gone rather than by the pipe. Header does
            // mean nothing was read on this connection, but Content and Done reach here too
            // (via the sendCall path, where an earlier packet was read), so this says only
            // what is certain -- not that the death fell between requests.
            detail << "the server is gone";
        }
        break;
    default:
        // Ok and ProtocolError are not losses. Reaching here means a caller labelled an
        // outcome wrongly, and the result would be a "test server lost" line for a server
        // that is fine -- the same misreporting this whole change exists to remove.
        SLANG_RELEASE_ASSERT(!"_reportServerLoss called with a non-loss outcome");
        break;
    }

    // How the server ended separates the leading explanations at a glance: killed by SIGKILL
    // is the OOM killer, SIGSEGV is a crash, and an ordinary exit status means it chose to
    // stop. Reported as a signal rather than as a shell-style 137/139 because that is what
    // the OS actually told us -- Unix exit statuses are narrowed to int8_t to round-trip
    // negative return codes, so 137 would surface as -119 and a signal death would surface
    // as nothing at all.
    if (auto* process = rpcConnection->getProcess())
    {
        if (!process->isTerminated())
        {
            detail << ", server process still running";
        }
        else if (const int32_t signalNumber = process->getTerminationSignal())
        {
            detail << ", server killed by signal " << signalNumber;
#if SLANG_UNIX_FAMILY
            // Named only where the constants exist: signal.h is Unix-guarded above, and the
            // MSVC CRT has no SIGKILL at all. The number is always printed, so a Windows
            // build loses nothing but the gloss -- and cannot report a signal anyway.
            if (signalNumber == SIGKILL)
            {
                detail << " (SIGKILL -- typically the OOM killer)";
            }
            else if (signalNumber == SIGSEGV)
            {
                detail << " (SIGSEGV -- a crash)";
            }
#endif
        }
        else
        {
            detail << ", server exited with status " << process->getReturnValue();
        }
    }

    // The lead phrase follows the OUTCOME. Hardcoding "lost" made a timeout claim the server
    // was gone when it is alive-but-slow, and made a send failure emit "test server lost ...
    // the request could not be written, though the server is still running" -- one line
    // asserting both halves of a contradiction, in a change whose whole point is that these
    // logs stop lying about what happened.
    const char* lead = "test server lost";
    switch (outcome)
    {
    case RPCAttemptOutcome::TimedOut:
        lead = "test server did not answer";
        break;
    case RPCAttemptOutcome::SendFailed:
        lead = "test server could not be sent to";
        break;
    default:
        break;
    }

    // "died ON request N", not "after serving N": advanceRPCRequestOrdinal() numbers the request
    // being sent, so the server had answered N-1 of them. Stated as the ordinal it died on
    // because that is the number worth comparing across runs -- if deaths cluster near a fixed
    // ordinal the server is accumulating something per request, and an off-by-one in the
    // instrument would misplace exactly that clustering.
    context->getTestReporter()->messageFormat(
        TestMessageType::RunError,
        "%s in %s on request #%d of this connection (it had answered %d): %s",
        lead,
        phase,
        requestOrdinal,
        requestOrdinal - 1,
        detail.produceString().getBuffer());
}

/// One RPC attempt.
///
/// Records no pass/fail VERDICT for the test -- the caller decides what a non-Ok outcome
/// means. Server-loss diagnostics are still emitted from here, which is the distinction the
/// old wording blurred. outRes is written only on Ok, so a failed attempt leaves whatever the
/// caller initialised it with rather than a half-populated result.
static RPCAttemptOutcome _executeRPCOnce(
    TestContext* context,
    SpawnType spawnType,
    const UnownedStringSlice& method,
    const RttiInfo* rttiInfo,
    const void* args,
    ExecuteResult& outRes)
{
    // If we are 'fully isolated', we cannot share a test server.
    // So tear down the RPC connection if there is one currently.
    if (spawnType == SpawnType::UseFullyIsolatedTestServer)
    {
        context->destroyRPCConnection();
    }

    JSONRPCConnection* rpcConnection = context->getOrCreateJSONRPCConnection();
    if (!rpcConnection)
    {
        // NOT Lost. Nothing was spawned, so no server closed a connection and no request
        // was ever sent -- attributing this to the test would let a missing test-server
        // binary or a fork failure be reported as "this test killed a freshly spawned test
        // server twice", which names an innocent input for a broken machine.
        context->getTestReporter()->messageFormat(
            TestMessageType::RunError,
            "JSON RPC failure: getOrCreateJSONRPCConnection() -- no test server could be "
            "spawned, so this test never ran");
        return RPCAttemptOutcome::StartFailed;
    }

    const int requestOrdinal = context->advanceRPCRequestOrdinal();

    // Execute
    if (SLANG_FAILED(rpcConnection->sendCall(method, rttiInfo, args)))
    {
        // A write that fails because the peer is GONE is a lost server, not a bad request.
        // A server that dies between requests leaves the next test writing into a closed
        // pipe, and that test has not run at all yet -- blaming it would be the same false
        // verdict this function exists to stop, just moved one step earlier. Asked of the
        // process rather than the transport because nothing has been read on this connection,
        // so the read state has no opinion to give.
        //
        // Give the OS a moment to answer, rather than asking once and believing a "no". The
        // write can fail before the peer's exit has been observed, and WinProcess's
        // isTerminated() is a zero-timeout wait that then reports a dead server as running --
        // which classified the loss as SendFailed, skipped the retry, and failed a test that
        // had not run. Only on the failure path, so a healthy run pays nothing.
        bool serverGone = !rpcConnection->isActive();
        if (!serverGone)
        {
            if (auto* process = rpcConnection->getProcess())
            {
                static const Int kServerExitGraceInMs = 250;
                serverGone = process->waitForTermination(kServerExitGraceInMs);
            }
        }
        const RPCAttemptOutcome outcome =
            serverGone ? RPCAttemptOutcome::Lost : RPCAttemptOutcome::SendFailed;

        _reportServerLoss(context, rpcConnection, outcome, requestOrdinal, "sendCall");

        context->destroyRPCConnection();
        return outcome;
    }

    // Wait for the result
    const bool waitFailed =
        SLANG_FAILED(rpcConnection->waitForResult(context->connectionTimeOutInMs));

    if (waitFailed || !rpcConnection->hasMessage())
    {
        // A malformed HTTP header or JSON value leaves the connection unusable just like EOF,
        // but starting a fresh server cannot repair a protocol disagreement. Keep it out of the
        // loss retry and attribution paths.
        const auto readError = rpcConnection->getReadError();
        if (readError == JSONRPCConnection::ReadError::Protocol)
        {
            context->getTestReporter()->message(
                TestMessageType::RunError,
                "JSON RPC protocol error: the test server returned a malformed HTTP or JSON "
                "response");
            context->destroyRPCConnection();
            return RPCAttemptOutcome::ProtocolError;
        }

        // A live-but-slow server has no read error and is a timeout (this test's problem), while
        // EOF or a transport failure is a lost connection (not this test's problem).
        const bool serverGone = readError == JSONRPCConnection::ReadError::ConnectionClosed ||
                                readError == JSONRPCConnection::ReadError::Transport;
        const RPCAttemptOutcome outcome =
            serverGone ? RPCAttemptOutcome::Lost : RPCAttemptOutcome::TimedOut;

        _reportServerLoss(context, rpcConnection, outcome, requestOrdinal, "waitForResult");

        // Either way the connection is unusable now: a timed-out request may still land later
        // and would then be read as the answer to the NEXT request.
        context->destroyRPCConnection();
        return outcome;
    }

    if (rpcConnection->getMessageType() != JSONRPCMessageType::Result)
    {
        context->getTestReporter()->messageFormat(
            TestMessageType::RunError,
            "JSON RPC failure: getMessageType() != JSONRPCMessageType::Result");

        context->destroyRPCConnection();
        return RPCAttemptOutcome::ProtocolError;
    }

    // Get the result
    TestServerProtocol::ExecutionResult exeRes;
    if (SLANG_FAILED(rpcConnection->getMessage(&exeRes)))
    {
        context->getTestReporter()->messageFormat(
            TestMessageType::RunError,
            "JSON RPC failure: getMessage()");

        context->destroyRPCConnection();
        return RPCAttemptOutcome::ProtocolError;
    }

    outRes.resultCode = exeRes.returnCode;
    outRes.standardError = exeRes.stdError;
    outRes.standardOutput = exeRes.stdOut;
    outRes.debugLayer = exeRes.debugLayer;

    return RPCAttemptOutcome::Ok;
}

static Result _executeRPC(
    TestContext* context,
    SpawnType spawnType,
    const UnownedStringSlice& method,
    const RttiInfo* rttiInfo,
    const void* args,
    ExecuteResult& outRes)
{
    const RPCAttemptOutcome first =
        _executeRPCOnce(context, spawnType, method, rttiInfo, args, outRes);

    if (first == RPCAttemptOutcome::Ok)
    {
        return SLANG_OK;
    }

    // Lost and StartFailed retry, kept distinct because only Lost can be charged to the test:
    // nothing ran on a server that never started.
    //
    // ProtocolError retries too. This used to reason that a wire-format disagreement would
    // repeat on a new process, but the errors seen are not that: ~7 per 6300-test run, on
    // different tests each time, each passing on other runs (#12534). They are replies
    // corrupted in flight, which a fresh server discriminates -- and a real disagreement
    // still repeats and is charged to the test below.
    //
    // The rest do not:
    // - TimedOut re-pays connectionTimeOutInMs plus a core-module recompile on the new server.
    // - SendFailed never got a reply to corrupt; the request was never written.
    const bool isRetryable = first == RPCAttemptOutcome::Lost ||
                             first == RPCAttemptOutcome::StartFailed ||
                             first == RPCAttemptOutcome::ProtocolError;
    if (!isRetryable)
    {
        return SLANG_FAIL;
    }

    // _executeRPCOnce already tore the connection down, so this attempt gets a server that
    // has served nothing else. That is what makes the retry a DISCRIMINATOR rather than a
    // mask: an ambient death (whatever the server had accumulated, or whatever the machine
    // was doing) does not reproduce on a virgin process, while an input that genuinely kills
    // the compiler kills this one too -- and then the failure is reported against the test,
    // where it belongs, instead of being retried until it looks green.
    //
    // One message per cause: only Lost and ProtocolError can be charged to the test, so the
    // spawn path must not promise that a second failure will be.
    const char* retryMessage = nullptr;
    switch (first)
    {
    case RPCAttemptOutcome::StartFailed:
        retryMessage =
            "no test server could be spawned; retrying once, and a second failure to spawn "
            "will fail this test without blaming its input";
        break;
    case RPCAttemptOutcome::ProtocolError:
        retryMessage =
            "retrying once on a freshly spawned test server; a second unreadable reply will "
            "be reported against this test";
        break;
    case RPCAttemptOutcome::Lost:
        retryMessage =
            "retrying once on a freshly spawned test server; a second loss will be reported "
            "against this test";
        break;
    default:
        // Unreachable: isRetryable above admits exactly the three cases handled here. Listed
        // rather than defaulted so that adding a fourth retryable outcome fails here instead
        // of silently inheriting one of these messages.
        SLANG_ASSERT(!"unhandled retryable outcome");
        retryMessage = "retrying once on a freshly spawned test server";
        break;
    }
    context->getTestReporter()->message(TestMessageType::RunError, retryMessage);

    // Straight into outRes, as the first attempt does: _executeRPCOnce writes it only on
    // success, so a second loss leaves the caller's own init() value intact rather than a
    // half-populated copy.
    const RPCAttemptOutcome second =
        _executeRPCOnce(context, spawnType, method, rttiInfo, args, outRes);

    if (second == RPCAttemptOutcome::Ok)
    {
        // The RPC is fine; if a server was actually lost, keep that loss countable. A recovered
        // StartFailed means no server existed, so recording it here would make the summary claim
        // that one died.
        if (first == RPCAttemptOutcome::Lost)
        {
            context->getTestReporter()->recordTestServerLoss();
        }
        else if (first == RPCAttemptOutcome::ProtocolError)
        {
            context->getTestReporter()->recordTestServerProtocolError();
        }
        return SLANG_OK;
    }

    // Only a genuine second LOSS implicates the input. A spawn failure repeating means the
    // machine still cannot start a server, which says nothing about the test.
    if (second == RPCAttemptOutcome::Lost && first == RPCAttemptOutcome::Lost)
    {
        context->getTestReporter()->messageFormat(
            TestMessageType::TestFailure,
            "this test killed a freshly spawned test server twice in a row; treating it as a "
            "crash caused by this input rather than as an unrelated server loss");
    }

    // Likewise a repeated PROTOCOL ERROR: two fresh servers failing to frame a reply to this
    // one request reproduces, so it is the test's to answer for.
    if (second == RPCAttemptOutcome::ProtocolError && first == RPCAttemptOutcome::ProtocolError)
    {
        context->getTestReporter()->messageFormat(
            TestMessageType::TestFailure,
            "this test drew an unreadable reply from a freshly spawned test server twice in a "
            "row; treating it as caused by this input rather than as an unrelated malformed "
            "response");
    }

    return SLANG_FAIL;
}

template<typename T>
static Result _executeRPC(
    TestContext* context,
    SpawnType spawnType,
    const UnownedStringSlice& method,
    const T* msg,
    ExecuteResult& outRes)
{
    return _executeRPC(context, spawnType, method, GetRttiInfo<T>::get(), (const void*)msg, outRes);
}

Result spawnAndWaitTestServer(
    TestContext* context,
    SpawnType spawnType,
    const String& testPath,
    const CommandLine& inCmdLine,
    ExecuteResult& outRes)
{
    String exeName = Path::getFileNameWithoutExt(inCmdLine.m_executableLocation.m_pathOrName);

    // This is a test tool execution
    TestServerProtocol::ExecuteToolTestArgs args;

    args.toolName = exeName;
    args.args = inCmdLine.m_args;

    return _executeRPC(
        context,
        spawnType,
        TestServerProtocol::ExecuteToolTestArgs::g_methodName,
        &args,
        outRes);
}

static SlangResult _extractArg(const CommandLine& cmdLine, const String& argName, String& outValue)
{
    SLANG_ASSERT(argName.getLength() > 0 && argName[0] == '-');
    Index index = cmdLine.findArgIndex(argName.getUnownedSlice());

    if (index >= 0 && index < cmdLine.getArgCount() - 1)
    {
        outValue = cmdLine.m_args[index + 1];
        return SLANG_OK;
    }
    return SLANG_FAIL;
}

static bool _hasOption(const List<String>& args, const String& argName)
{
    return args.indexOf(argName) != Index(-1);
}

static PassThroughFlags _getPassThroughFlagsForTarget(SlangCompileTarget target)
{
    switch (target)
    {
    case SLANG_TARGET_UNKNOWN:

    case SLANG_HLSL:
    case SLANG_GLSL:
    case SLANG_C_SOURCE:
    case SLANG_CPP_SOURCE:
    case SLANG_CPP_HEADER:
    case SLANG_CPP_PYTORCH_BINDING:
    case SLANG_HOST_CPP_SOURCE:
    case SLANG_CUDA_SOURCE:
    case SLANG_CUDA_HEADER:
    case SLANG_METAL:
    case SLANG_WGSL:
    case SLANG_HOST_VM:
    case SLANG_HOST_LLVM_IR:
    case SLANG_HOST_OBJECT_CODE:
    case SLANG_SHADER_LLVM_IR:
    case SLANG_OBJECT_CODE:
        {
            return 0;
        }
    case SLANG_WGSL_SPIRV:
    case SLANG_WGSL_SPIRV_ASM:
        {
            return PassThroughFlag::Tint;
        }
    case SLANG_DXBC:
    case SLANG_DXBC_ASM:
        {
            return PassThroughFlag::Fxc;
        }
    case SLANG_SPIRV:
    case SLANG_SPIRV_ASM:
        {
            return PassThroughFlag::Glslang;
        }
    case SLANG_DXIL:
    case SLANG_DXIL_ASM:
        {
            return PassThroughFlag::Dxc;
        }

    case SLANG_METAL_LIB:
    case SLANG_METAL_LIB_ASM:
        {
            return PassThroughFlag::Metal;
        }

    case SLANG_SHADER_HOST_CALLABLE:
    case SLANG_HOST_HOST_CALLABLE:

    case SLANG_HOST_EXECUTABLE:
    case SLANG_SHADER_SHARED_LIBRARY:
    case SLANG_HOST_SHARED_LIBRARY:
        {
            return PassThroughFlag::Generic_C_CPP;
        }
    case SLANG_PTX:
        {
            return PassThroughFlag::NVRTC;
        }

    default:
        {
            SLANG_ASSERT(!"Unknown type");
            return 0;
        }
    }
}

static SlangResult _extractRenderTestRequirements(
    const CommandLine& cmdLine,
    TestRequirements* ioRequirements)
{
    const auto& args = cmdLine.m_args;

    // TODO(JS):
    // This is rather convoluted in that it has to work out from the command line parameters passed
    // to render-test what renderer will be used.
    // That a similar logic has to be kept inside the implementation of render-test and both this
    // and render-test will have to be kept in sync.

    bool useDxbc = cmdLine.findArgIndex(UnownedStringSlice::fromLiteral("-use-dxbc")) >= 0;

    bool usePassthru = false;

    // Work out what kind of render will be used
    RenderApiType renderApiType;
    {
        RenderApiType foundRenderApiType = RenderApiType::Unknown;
        RenderApiType foundLanguageRenderType = RenderApiType::Unknown;

        for (const auto& arg : args)
        {
            Slang::UnownedStringSlice argSlice = arg.getUnownedSlice();
            if (argSlice.getLength() && argSlice[0] == '-')
            {
                // Look up the rendering API if set
                UnownedStringSlice argName =
                    UnownedStringSlice(argSlice.begin() + 1, argSlice.end());
                RenderApiType renderApiType = RenderApiUtil::findApiTypeByName(argName);

                if (renderApiType != RenderApiType::Unknown)
                {
                    foundRenderApiType = renderApiType;

                    // There should be only one explicit api
                    SLANG_ASSERT(
                        ioRequirements->explicitRenderApi == RenderApiType::Unknown ||
                        ioRequirements->explicitRenderApi == renderApiType);

                    // Set the explicitly set render api
                    ioRequirements->explicitRenderApi = renderApiType;
                    continue;
                }

                // Lookup the target language type
                RenderApiType languageRenderType =
                    RenderApiUtil::findImplicitLanguageRenderApiType(argName);
                if (languageRenderType != RenderApiType::Unknown)
                {
                    foundLanguageRenderType = languageRenderType;

                    // Use the pass thru compiler if these are the sources
                    usePassthru |= (argName == "hlsl" || argName == "glsl");

                    continue;
                }
            }
        }

        // If a render option isn't set use defaultRenderType
        renderApiType = (foundRenderApiType == RenderApiType::Unknown) ? foundLanguageRenderType
                                                                       : foundRenderApiType;
    }

    // The native language for the API
    SlangCompileTarget target = SLANG_TARGET_NONE;
    SlangPassThrough passThru = SLANG_PASS_THROUGH_NONE;

    switch (renderApiType)
    {
    case RenderApiType::D3D11:
        target = SLANG_DXBC;
        passThru = SLANG_PASS_THROUGH_FXC;
        break;
    case RenderApiType::D3D12:
        target = SLANG_DXIL;
        passThru = SLANG_PASS_THROUGH_DXC;
        if (useDxbc)
        {
            target = SLANG_DXBC;
            passThru = SLANG_PASS_THROUGH_FXC;
        }
        break;
    case RenderApiType::Vulkan:
        target = SLANG_SPIRV;
        passThru = SLANG_PASS_THROUGH_GLSLANG;
        break;
    case RenderApiType::Metal:
        target = SLANG_METAL_LIB;
        passThru = SLANG_PASS_THROUGH_METAL;
        break;
    case RenderApiType::CPU:
        target = SLANG_SHADER_HOST_CALLABLE;
        passThru = SLANG_PASS_THROUGH_GENERIC_C_CPP;
        break;
    case RenderApiType::CUDA:
        target = SLANG_PTX;
        passThru = SLANG_PASS_THROUGH_NVRTC;
        break;
    case RenderApiType::WebGPU:
        target = SLANG_WGSL;
        passThru = SLANG_PASS_THROUGH_TINT;
        break;
    case RenderApiType::LLVM:
        target = SLANG_SHADER_HOST_CALLABLE;
        passThru = SLANG_PASS_THROUGH_NONE;
        break;
    }

    if (!usePassthru)
    {
        passThru = SLANG_PASS_THROUGH_NONE;
    }

    // In compile-only mode, we need neither the GPU API nor downstream compilers.
    // render-test will use text output targets (HLSL, GLSL, MSL, CUDA source)
    // that only exercise Slang's own emit code.
    bool isCompileOnly =
        cmdLine.findArgIndex(UnownedStringSlice::fromLiteral("-compile-only")) >= 0;
    if (!isCompileOnly)
    {
        if (passThru == SLANG_PASS_THROUGH_NONE)
        {
            ioRequirements->addUsedBackends(_getPassThroughFlagsForTarget(target));
        }
        else
        {
            ioRequirements->addUsedBackEnd(passThru);
        }

        ioRequirements->addUsedRenderApi(renderApiType);
    }

    return SLANG_OK;
}

static SlangResult _extractSlangCTestRequirements(
    const CommandLine& cmdLine,
    TestRequirements* ioRequirements)
{
    // This determines what the requirements are for a slangc like command line
    // First check pass through
    {
        String passThrough;
        if (SLANG_SUCCEEDED(_extractArg(cmdLine, "-pass-through", passThrough)))
        {
            ioRequirements->addUsedBackEnd(
                TypeTextUtil::findPassThrough(passThrough.getUnownedSlice()));
        }
    }

    // The target if set will also imply a backend
    {
        String targetName;
        if (SLANG_SUCCEEDED(_extractArg(cmdLine, "-target", targetName)))
        {
            const SlangCompileTarget target =
                TypeTextUtil::findCompileTargetFromName(targetName.getUnownedSlice());
            ioRequirements->addUsedBackends(_getPassThroughFlagsForTarget(target));
        }
    }

    // `-emit-cpu-via-llvm` routes CPU/host-callable code generation through the slang-llvm
    // backend regardless of the `-target`, so a test using it depends on that backend.
    if (_hasOption(cmdLine.m_args, "-emit-cpu-via-llvm"))
    {
        ioRequirements->addUsedBackEnd(SLANG_PASS_THROUGH_LLVM);
    }

    return SLANG_OK;
}

static SlangResult _extractReflectionTestRequirements(
    const CommandLine& cmdLine,
    TestRequirements* ioRequirements)
{
    // There are no specialized constraints for a reflection test
    return SLANG_OK;
}

static SlangResult _extractTestRequirements(const CommandLine& cmdLine, TestRequirements* ioInfo)
{
    String exeName = Path::getFileNameWithoutExt(cmdLine.m_executableLocation.m_pathOrName);

    if (exeName == "render-test")
    {
        return _extractRenderTestRequirements(cmdLine, ioInfo);
    }
    else if (exeName == "slangc")
    {
        return _extractSlangCTestRequirements(cmdLine, ioInfo);
    }
    else if (exeName == "slangi" || exeName == "slang")
    {
        return SLANG_OK;
    }
    else if (exeName == "slang-reflection-test")
    {
        return _extractReflectionTestRequirements(cmdLine, ioInfo);
    }

    SLANG_ASSERT(!"Unknown tool type");
    return SLANG_FAIL;
}

static RenderApiFlags _getAvailableRenderApiFlags(TestContext* context)
{
    static std::mutex mutex;
    std::lock_guard<std::mutex> lock(mutex);
    // Only evaluate if it hasn't already been evaluated (the actual evaluation is slow...)
    if (!context->isAvailableRenderApiFlagsValid)
    {
        // Call the render-test tool asking it only to startup a specified render api
        // (taking into account adapter options)

        // Only the positive "Check <api>: Supported" lines are noise to hide below Info verbosity
        // (e.g. `-v failure`); the "Not Supported" lines and the accompanying startup-failure
        // stderr/stdout dump are always shown, since a missing backend explains why tests are
        // skipped and is exactly what someone running `-v failure` needs to see. CI runs at default
        // (Info) and greps this output, so gating only the positive line keeps CI detection
        // working.
        const bool showDiscovery = context->options.verbosity >= VerbosityLevel::Info;

        RenderApiFlags availableRenderApiFlags = 0;
        for (int i = 0; i < int(RenderApiType::CountOf); ++i)
        {
            const RenderApiType apiType = RenderApiType(i);

            if (apiType == RenderApiType::CPU)
            {
                if ((context->availableBackendFlags & PassThroughFlag::Generic_C_CPP) == 0)
                {
                    continue;
                }

                // Check that the session has the generic C/CPP compiler availability - which is all
                // we should need for CPU target
                if (SLANG_SUCCEEDED(context->getSession()->checkPassThroughSupport(
                        SLANG_PASS_THROUGH_GENERIC_C_CPP)))
                {
                    availableRenderApiFlags |= RenderApiFlags(1) << int(apiType);
                    if (showDiscovery)
                        StdWriters::getOut().print(
                            "Check %s: Supported\n",
                            RenderApiUtil::getApiName(apiType).begin());
                }
                else
                {
                    StdWriters::getOut().print(
                        "Check %s: Not Supported\n",
                        RenderApiUtil::getApiName(apiType).begin());
                }
                continue;
            }

            // See if it's possible the api is available
            if (RenderApiUtil::calcHasApi(apiType))
            {
                if (context->options.skipApiDetection)
                {
                    availableRenderApiFlags |= RenderApiFlags(1) << int(apiType);
                    continue;
                }
                // Try starting up the device
                CommandLine cmdLine;
                cmdLine.setExecutableLocation(
                    ExecutableLocation(context->options.binDir, "render-test"));
                // Don't cache startup devices: a cached non-experimental device would prevent
                // D3D12EnableExperimentalFeatures from succeeding in subsequent test runs.
                _addRenderTestOptions(context->options, cmdLine, false);
                // We just want to see if the device can be started up
                cmdLine.addArg("-only-startup");

                // Select what api to use
                StringBuilder builder;
                builder << "-" << RenderApiUtil::getApiName(apiType);
                cmdLine.addArg(builder);
                // Run the render-test tool and see if the device could startup
                ExecuteResult exeRes;
                if (SLANG_SUCCEEDED(
                        spawnAndWaitSharedLibrary(context, "device-startup", cmdLine, exeRes)) &&
                    TestToolUtil::getReturnCodeFromInt(exeRes.resultCode) ==
                        ToolReturnCode::Success)
                {
                    availableRenderApiFlags |= RenderApiFlags(1) << int(apiType);
                    if (showDiscovery)
                        StdWriters::getOut().print(
                            "Check %s: Supported\n",
                            RenderApiUtil::getApiName(apiType).begin());
                }
                else
                {
                    StdWriters::getOut().print(
                        "Check %s: Not Supported\n",
                        RenderApiUtil::getApiName(apiType).begin());
                    const auto out = exeRes.standardOutput;
                    const auto err = exeRes.standardError;
                    if (err.getLength())
                        StdWriters::getOut().print("%s\n", err.getBuffer());
                    if (out.getLength())
                        StdWriters::getOut().print("%s\n", out.getBuffer());
                }
            }
        }

        // After determining available APIs, print adapter info for each one
        if (context->options.showAdapterInfo && availableRenderApiFlags)
        {
            StdWriters::getOut().print("\nAdapter Information for Available APIs:\n");
            for (int i = 0; i < int(RenderApiType::CountOf); ++i)
            {
                const RenderApiType apiType = RenderApiType(i);
                const RenderApiFlags apiFlag = RenderApiFlags(1) << int(apiType);

                if (availableRenderApiFlags & apiFlag)
                {
                    // Create command line to query adapter info
                    CommandLine cmdLine;
                    cmdLine.setExecutableLocation(
                        ExecutableLocation(context->options.binDir, "render-test"));

                    // Add the API type
                    StringBuilder builder;
                    builder << "-" << RenderApiUtil::getApiName(apiType);
                    cmdLine.addArg(builder);

                    // Add flags to show adapter info and only startup
                    cmdLine.addArg("-show-adapter-info");
                    cmdLine.addArg("-only-startup");

                    // Run render-test to get adapter info
                    ExecuteResult exeRes;
                    if (SLANG_SUCCEEDED(
                            spawnAndWaitSharedLibrary(context, "adapter-info", cmdLine, exeRes)))
                    {
                        // Output the adapter info
                        StdWriters::getOut().print(
                            "\n%s:\n%s",
                            RenderApiUtil::getApiName(apiType).begin(),
                            exeRes.standardOutput.getBuffer());
                    }
                }
            }
            StdWriters::getOut().print("\n");
        }

        context->availableRenderApiFlags = availableRenderApiFlags;
        context->isAvailableRenderApiFlagsValid = true;
    }

    return context->availableRenderApiFlags;
}

ToolReturnCode getReturnCode(const ExecuteResult& exeRes)
{
    return TestToolUtil::getReturnCodeFromInt(exeRes.resultCode);
}

ToolReturnCode spawnAndWait(
    TestContext* context,
    const String& testPath,
    SpawnType spawnType,
    const CommandLine& cmdLine,
    ExecuteResult& outExeRes)
{
    if (context->isCollectingRequirements())
    {
        std::lock_guard<std::mutex> lock(context->mutex);
        // If we just want info... don't bother running anything
        const SlangResult res = _extractTestRequirements(cmdLine, context->getTestRequirements());
        // Keep compiler happy on release
        SLANG_UNUSED(res);
        SLANG_ASSERT(SLANG_SUCCEEDED(res));

        return ToolReturnCode::Success;
    }

    const auto& options = context->options;

    const auto finalSpawnType = context->getFinalSpawnType(spawnType);

    SlangResult spawnResult = SLANG_FAIL;
    switch (finalSpawnType)
    {
    case SpawnType::UseExe:
        {
            spawnResult = spawnAndWaitExe(context, testPath, cmdLine, outExeRes);
            break;
        }
    case SpawnType::Default:
    case SpawnType::UseSharedLibrary:
        {
            spawnResult = spawnAndWaitSharedLibrary(context, testPath, cmdLine, outExeRes);
            break;
        }
    case SpawnType::UseFullyIsolatedTestServer:
    case SpawnType::UseTestServer:
        {
            spawnResult =
                spawnAndWaitTestServer(context, finalSpawnType, testPath, cmdLine, outExeRes);
            break;
        }
    default:
        break;
    }

    if (SLANG_FAILED(spawnResult))
    {
        return ToolReturnCode::FailedToRun;
    }

    return getReturnCode(outExeRes);
}

// Remove embedded source code from SPIR-V assembly output to prevent filecheck from matching
// against embedded source instead of actual SPIR-V instructions
String removeEmbeddedSourceFromSPIRV(const String& spirvOutput)
{
    StringBuilder filteredOutput;
    List<UnownedStringSlice> lines;
    StringUtil::calcLines(spirvOutput.getUnownedSlice(), lines);

    if (spirvOutput.endsWith("\n"))
    {
        // The last empty line should be removed,
        // because `StringUtil::calcLines()` turns "A\nB\n" into three lines; not two.
        SLANG_ASSERT(lines[lines.getCount() - 1] == "");
        lines.setCount(lines.getCount() - 1);
    }

    // First pass: Find OpString IDs that are referenced by DebugSource
    List<String> sourceStringIds;
    for (const auto& line : lines)
    {
        UnownedStringSlice trimmedLine = line.trim();

        if (trimmedLine.indexOf(UnownedStringSlice(" DebugSource ")) == Index(-1))
            continue;

        // Extract the last parameter which is the source string ID
        // Pattern: %4 = OpExtInst %void %2 DebugSource %5 %1
        List<UnownedStringSlice> tokens;
        StringUtil::split(trimmedLine, ' ', tokens);

        // The last token should be the source string ID
        UnownedStringSlice lastToken = tokens.getLast();
        if (lastToken.startsWith(UnownedStringSlice("%")))
        {
            sourceStringIds.add(String(lastToken));
        }
    }

    // Second pass: Process embedded source strings to replace content with informative message
    bool insideSourceString = false;
    for (const auto& line : lines)
    {
        UnownedStringSlice trimmedLine = line.trim();

        if (!insideSourceString)
        {
            Index equalPos = trimmedLine.indexOf(UnownedStringSlice(" = OpString"));
            if (equalPos != Index(-1) && trimmedLine.startsWith(UnownedStringSlice("%")))
            {
                String currentStringId = String(trimmedLine.head(equalPos));
                if (sourceStringIds.contains(currentStringId))
                {
                    insideSourceString = true;
                    Index quotePos = line.indexOf('\"');
                    if (quotePos != Index(-1))
                    {
                        filteredOutput.append(String(line.head(quotePos + 1)));
                        filteredOutput.append("// slang-test removed the embedded source\n");
                        filteredOutput.append("// Use `");
                        filteredOutput.append(kPreserveEmbeddedSourceOption);
                        filteredOutput.append("` to keep it explicitly\n\"\n");
                    }
                    continue;
                }
            }
        }

        if (insideSourceString)
        {
            if (trimmedLine.endsWith("\"") &&
                (trimmedLine.getLength() < 2 || trimmedLine[trimmedLine.getLength() - 2] != '\\'))
            {
                insideSourceString = false;
            }

            // skip the embedded source lines
            continue;
        }

        // Add this line to the filtered output
        filteredOutput.append(line);
        filteredOutput.append("\n");
    }

    return filteredOutput.produceString();
}

String getOutput(const ExecuteResult& exeRes, bool removeEmbeddedSource = false)
{
    ExecuteResult::ResultCode resultCode = exeRes.resultCode;

    String standardOuptut = exeRes.standardOutput;
    String standardError = exeRes.standardError;
    String debugLayer = exeRes.debugLayer;

    // Apply embedded source removal to standard output if requested
    if (removeEmbeddedSource && standardOuptut.getLength() > 0)
    {
        standardOuptut = removeEmbeddedSourceFromSPIRV(standardOuptut);
    }

    // We construct a single output string that captures the results
    StringBuilder actualOutputBuilder;
    actualOutputBuilder.append("result code = ");
    actualOutputBuilder.append(resultCode);
    actualOutputBuilder.append("\nstandard error = {\n");
    actualOutputBuilder.append(standardError);
    actualOutputBuilder.append("}\nstandard output = {\n");
    actualOutputBuilder.append(standardOuptut);
    actualOutputBuilder.append("}\n");
    if (debugLayer.getLength() > 0)
    {
        actualOutputBuilder.append("debug layer = {\n");
        actualOutputBuilder.append(debugLayer);
        actualOutputBuilder.append("}\n");
    }

    return actualOutputBuilder.produceString();
}

// Finds the specialized or default path for expected data for a test.
// If neither are found, will return an empty string
String findExpectedPath(const TestInput& input, const char* postFix)
{
    StringBuilder specializedBuf;

    // Try the specialized name first
    specializedBuf << input.outputStem;
    if (postFix)
    {
        specializedBuf << postFix;
    }
    if (File::exists(specializedBuf))
    {
        return specializedBuf;
    }


    // Try the default name
    StringBuilder defaultBuf;
    defaultBuf.clear();
    defaultBuf << input.filePath;
    if (postFix)
    {
        defaultBuf << postFix;
    }

    if (File::exists(defaultBuf))
    {
        return defaultBuf;
    }

    // Couldn't find either
    fprintf(
        stderr,
        "referenceOutput '%s' or '%s' not found.\n",
        defaultBuf.getBuffer(),
        specializedBuf.getBuffer());

    return "";
}

static SlangResult _initSlangInterpreter(TestContext* context, CommandLine& ioCmdLine)
{
    ioCmdLine.setExecutableLocation(ExecutableLocation(context->options.binDir, "slangi"));
    return SLANG_OK;
}

static SlangResult _initSlangDispatcher(TestContext* context, CommandLine& ioCmdLine)
{
    ioCmdLine.setExecutableLocation(ExecutableLocation(context->options.binDir, "slang"));
    return SLANG_OK;
}

static SlangResult _initSlangCompiler(TestContext* context, CommandLine& ioCmdLine)
{
    ioCmdLine.setExecutableLocation(ExecutableLocation(context->options.binDir, "slangc"));

    if (context->options.verbosePaths)
    {
        ioCmdLine.addArgIfNotFound("-verbose-paths");
    }

    for (auto& capability : context->options.capabilities)
    {
        ioCmdLine.addArg("-capability");
        ioCmdLine.addArg(capability.getBuffer());
    }

    // Look for definition of a slot

    {
        const auto prefix = toSlice("-DNV_SHADER_EXTN_SLOT=");

        bool usesNVAPI = false;

        for (auto& arg : ioCmdLine.m_args)
        {
            if (arg.startsWith(prefix))
            {
                // Has NVAPI prefix, meaning
                usesNVAPI = true;
                break;
            }
        }

        // This is necessary because the session can be shared, and the prelude overwritten by the
        // renderer.
        if (usesNVAPI)
        {
            // We want to set the path to NVAPI
            String rootPath;
            SLANG_RETURN_ON_FAIL(TestToolUtil::getRootPath(context->exePath.getBuffer(), rootPath));
            String includePath;
            SLANG_RETURN_ON_FAIL(
                TestToolUtil::getIncludePath(rootPath, "external/nvapi/nvHLSLExtns.h", includePath))

            StringBuilder buf;

            // Include the NVAPI header
            buf << "#include ";

            StringEscapeUtil::appendQuoted(
                StringEscapeUtil::getHandler(StringEscapeUtil::Style::Cpp),
                includePath.getUnownedSlice(),
                buf);
            buf << "\n\n";

            context->getSession()->setLanguagePrelude(SLANG_SOURCE_LANGUAGE_HLSL, buf.getBuffer());
        }
    }

    return SLANG_OK;
}

TestResult asTestResult(ToolReturnCode code)
{
    switch (code)
    {
    case ToolReturnCode::Success:
        return TestResult::Pass;
    case ToolReturnCode::Ignored:
        return TestResult::Ignored;
    default:
        return TestResult::Fail;
    }
}

#define TEST_RETURN_ON_DONE(x)              \
    {                                       \
        const ToolReturnCode toolRet_ = x;  \
        if (TestToolUtil::isDone(toolRet_)) \
        {                                   \
            return asTestResult(toolRet_);  \
        }                                   \
    }

static SlangResult _createArtifactFromHexDump(
    const UnownedStringSlice& hexDump,
    const ArtifactDesc& desc,
    ComPtr<IArtifact>& outArtifact)
{
    // We need to extract the binary
    List<uint8_t> data;
    SLANG_RETURN_ON_FAIL(HexDumpUtil::parseWithMarkers(hexDump, data));

    auto blob = ListBlob::moveCreate(data);
    auto artifact = ArtifactUtil::createArtifact(desc);
    artifact->addRepresentationUnknown(blob);

    outArtifact.swap(artifact);
    return SLANG_OK;
}

static SlangResult _executeBinaryFile(const UnownedStringSlice& fileName, ExecuteResult& outExeRes)
{
    CommandLine cmdLine;

#if SLANG_LINUX_FAMILY
    // Consider a //TEST:EXECUTABLE: case in sanitizer CI. slangc first invokes an
    // uninstrumented host compiler to produce the binary, and slang-test then runs it.
    // Applying LD_PRELOAD to slang-test would also inject the sanitizer into the compiler
    // and linker. Keep the requested value inert until this exact execution boundary instead.
    StringBuilder preloadValue;
    if (SLANG_SUCCEEDED(PlatformUtil::getEnvironmentVariable(
            UnownedStringSlice("SLANG_TEST_EXECUTABLE_LD_PRELOAD"),
            preloadValue)) &&
        preloadValue.getLength())
    {
        cmdLine.setExecutableLocation(ExecutableLocation("env"));

        StringBuilder preloadAssignment;
        preloadAssignment << "LD_PRELOAD=" << preloadValue;
        cmdLine.addArg(preloadAssignment.produceString());
        cmdLine.addArg(fileName);

        return ProcessUtil::execute(cmdLine, outExeRes);
    }
#endif

    ExecutableLocation exe;
    exe.setPath(fileName);
    cmdLine.setExecutableLocation(exe);

    return ProcessUtil::execute(cmdLine, outExeRes);
}

static SlangResult _executeBinary(const UnownedStringSlice& hexDump, ExecuteResult& outExeRes)
{
    ComPtr<IArtifact> artifact;
    SLANG_RETURN_ON_FAIL(_createArtifactFromHexDump(
        hexDump,
        ArtifactDesc::make(
            ArtifactKind::Executable,
            ArtifactPayload::HostCPU,
            ArtifactStyle::Unknown),
        artifact));

    ComPtr<IOSFileArtifactRepresentation> fileRep;
    SLANG_RETURN_ON_FAIL(artifact->requireFile(ArtifactKeep::Yes, fileRep.writeRef()));

    const auto fileName = fileRep->getPath();
    return _executeBinaryFile(UnownedStringSlice(fileName), outExeRes);
}

static bool _areDiagnosticsEqual(const UnownedStringSlice& a, const UnownedStringSlice& b)
{
    ParseDiagnosticUtil::OutputInfo outA, outB;

    // If we can't parse, we can't match, so fail.
    if (SLANG_FAILED(ParseDiagnosticUtil::parseOutputInfo(a, outA)) ||
        SLANG_FAILED(ParseDiagnosticUtil::parseOutputInfo(b, outB)))
    {
        fprintf(stderr, "Error: Unable to parse diagnostics for diagnostic test\n");
        return false;
    }

    // The result codes must match, and std out
    if (outA.resultCode != outB.resultCode ||
        !StringUtil::areLinesEqual(outA.stdOut.getUnownedSlice(), outB.stdOut.getUnownedSlice()))
    {
        return false;
    }

    // Parse the compiler diagnostics and make sure they are the same.
    // Ignores line number differences
    return ParseDiagnosticUtil::areEqual(
        outA.stdError.getUnownedSlice(),
        outB.stdError.getUnownedSlice(),
        ParseDiagnosticUtil::EqualityFlag::IgnoreLineNos);
}

static bool _areResultsEqual(TestOptions::Type type, const String& a, const String& b)
{
    switch (type)
    {
    case TestOptions::Type::Diagnostic:
        return _areDiagnosticsEqual(a.getUnownedSlice(), b.getUnownedSlice());
    case TestOptions::Type::Normal:
        return a == b;
    default:
        {
            SLANG_ASSERT(!"Unknown test type");
            return false;
        }
    }
}

static String _calcModulePath(const TestInput& input)
{
    // Make the module name the same as the source file
    auto filePath = input.filePath;
    String directory = Path::getParentDirectory(input.outputStem);
    String moduleName = Path::getFileNameWithoutExt(filePath);
    return Path::combine(directory, moduleName);
}

TestResult runDocTest(TestContext* context, TestInput& input)
{
    // need to execute the stand-alone Slang compiler on the file, and compare its output to what we
    // expect
    auto outputStem = input.outputStem;

    CommandLine cmdLine;


    cmdLine.addArg(input.filePath);

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }

    _initSlangCompiler(context, cmdLine);
    SlangTest::addDefaultSlangOptimization(cmdLine, context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    String actualOutput = getOutput(exeRes);

    String expectedOutputPath = outputStem + ".expected";
    String expectedOutput;

    // TODO(JS): Might want to check the result code..
    Slang::File::readAllText(expectedOutputPath, expectedOutput);

    // If no expected output file was found, then we
    // expect everything to be empty
    if (expectedOutput.getLength() == 0)
    {
        expectedOutput = "result code = 0\nstandard error = {\n}\nstandard output = {\n}\n";
    }

    TestResult result = TestResult::Pass;

    // Otherwise we compare to the expected output
    if (!_areResultsEqual(input.testOptions->type, expectedOutput, actualOutput))
    {
        context->getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);
        result = TestResult::Fail;
    }

    // If the test failed, then we write the actual output to a file
    // so that we can easily diff it from the command line and
    // diagnose the problem.
    if (result == TestResult::Fail)
    {
        String actualOutputPath = outputStem + ".actual";
        Slang::File::writeAllText(actualOutputPath, actualOutput);

        context->getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);
    }

    return result;
}

TestResult runExecutableTest(TestContext* context, TestInput& input)
{
    IDownstreamCompiler* compiler = context->getDefaultCompiler(SLANG_SOURCE_LANGUAGE_CPP);
    if (!compiler)
    {
        return TestResult::Ignored;
    }

    // If we are just collecting requirements, say it passed
    if (context->isCollectingRequirements())
    {
        std::lock_guard<std::mutex> lock(context->mutex);
        context->getTestRequirements()->addUsedBackEnd(SLANG_PASS_THROUGH_GENERIC_C_CPP);
        return TestResult::Pass;
    }

    auto filePath = input.filePath;
    auto outputStem = input.outputStem;

    String actualOutputPath = outputStem + ".actual";
    File::remove(actualOutputPath);

    // Make the module name the same as the current executable path, so it can discover
    // the slang-rt library if needed.
    String modulePath = Path::combine(
        Path::getParentDirectory(Path::getExecutablePath()),
        Path::getFileNameWithoutExt(filePath));

    // String testRoot
    // for(;;)
    // {
    //     String testRoot = Path::getParentDirectory(filePath);
    //     if (testRoot == "")
    //     {
    //         break;
    //     }
    // }
    // printf("test folder = %s\n", testRoot.begin());

    String moduleExePath;
    {
        StringBuilder buf;
        buf << modulePath;
        buf << Process::getExecutableSuffix();
        moduleExePath = buf;
    }

    // Remove the exe if it exists
    File::remove(moduleExePath);

    CommandLine cmdLine;
    _initSlangCompiler(context, cmdLine);

    StringEscapeHandler* escapeHandler =
        StringEscapeUtil::getHandler(StringEscapeUtil::Style::Space);

    List<String> args;
    args.add(filePath);
    args.add("-o");
    args.add(moduleExePath);
    args.add("-target");
    args.add("exe");
    args.add("-Xgenericcpp");
    args.add("-I./include");
    args.add("-Xgenericcpp");
    args.add("-I./external/unordered_dense/include");
    for (auto arg : args)
    {
        // If unescaping is needed, do it
        if (StringEscapeUtil::isUnescapeShellLikeNeeded(escapeHandler, arg.getUnownedSlice()))
        {
            StringBuilder buf;
            StringEscapeUtil::unescapeShellLike(escapeHandler, arg.getUnownedSlice(), buf);
            cmdLine.addArg(buf.produceString());
        }
        else
        {
            cmdLine.addArg(arg);
        }
    }
    SlangTest::addDefaultSlangOptimization(cmdLine, context->options.defaultOptimizationLevel);
    ExecuteResult exeRes;

    // TODO(Yong) HACK:
    // Just use shared library now, TestServer spawn mode seems to cause slangc to fail to find its
    // own executable path, and thus failed to find the `gfx.slang` file sitting along side
    // `slangc.exe`. We need to figure out what happened to `Path::getExecutablePath()` inside
    // test-server.
    SpawnType slangcSpawnType = input.spawnType;
    if (slangcSpawnType == SpawnType::UseTestServer)
        slangcSpawnType = SpawnType::UseExe;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, slangcSpawnType, cmdLine, exeRes));

    String actualOutput;

    // If the actual compilation failed, then the output will be the summary
    if (exeRes.resultCode != 0)
    {
        actualOutput = getOutput(exeRes);
    }
    else
    {
        // Execute the binary and see what we get
        ExecuteResult exeRes;
        if (SLANG_FAILED(_executeBinaryFile(moduleExePath.getUnownedSlice(), exeRes)))
        {
            return TestResult::Fail;
        }

        // Write the output, and compare to expected
        actualOutput = getOutput(exeRes);
    }

    // Write the output
    Slang::File::writeAllText(actualOutputPath, actualOutput);

    // Check that they are the same
    {
        // Read the expected
        String expectedOutput;

        String expectedOutputPath = outputStem + ".expected";
        Slang::File::readAllText(expectedOutputPath, expectedOutput);

        // Compare if they are the same
        if (!StringUtil::areLinesEqual(
                actualOutput.getUnownedSlice(),
                expectedOutput.getUnownedSlice()))
        {
            context->getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);
            return TestResult::Fail;
        }
    }

    return TestResult::Pass;
}

// Inspect the raw result kind: deserializing into a zero-field struct via getMessage() accepts `{}`
// but rejects JSON `null`, so it cannot detect a null result.
static bool receivedNullResult(JSONRPCConnection* connection)
{
    JSONResultResponse resultResponse;
    return SLANG_SUCCEEDED(connection->getRPC(&resultResponse)) &&
           resultResponse.result.getKind() == JSONValue::Kind::Null;
}

TestResult runLanguageServerTest(TestContext* context, TestInput& input)
{
    // We don't support running language server tests in parallel yet.
    std::lock_guard lock(context->mutex);

    if (!context->m_languageServerConnection)
    {
        if (SLANG_FAILED(context->createLanguageServerJSONRPCConnection(
                context->m_languageServerConnection)))
        {
            return TestResult::Fail;
        }
    }
    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }
    auto connection = context->m_languageServerConnection.Ptr();
    LanguageServerProtocol::InitializeParams initParams;
    LanguageServerProtocol::WorkspaceFolder wsFolder;
    wsFolder.name = "test";
    String fullPath;
    Path::getCanonical(input.filePath, fullPath);
    wsFolder.uri = URI::fromLocalFilePath(Path::getParentDirectory(fullPath).getUnownedSlice()).uri;
    if (input.testOptions->commandOptions.containsKey("workspace-search-path-order"))
    {
        // Keep the fixture roots outside the opened document's directory. Opening a document adds
        // that directory as a search path, and putting the roots below it verifies their explicit
        // workspaceFolders order without relying on recursive directory enumeration order.
        auto fixtureDir = Path::getParentDirectory(fullPath);
        wsFolder.name = "first";
        wsFolder.uri =
            URI::fromLocalFilePath(Path::combine(fixtureDir, "first-root").getUnownedSlice()).uri;
        initParams.workspaceFolders.add(wsFolder);
        wsFolder.name = "second";
        wsFolder.uri =
            URI::fromLocalFilePath(Path::combine(fixtureDir, "second-root").getUnownedSlice()).uri;
        initParams.workspaceFolders.add(wsFolder);
    }
    else if (
        input.testOptions->commandOptions.containsKey("additional-search-path-order") ||
        input.testOptions->commandOptions.containsKey("workspace-search-toggle"))
    {
        auto fixtureDir = Path::getParentDirectory(fullPath);
        wsFolder.name = "workspace";
        wsFolder.uri =
            URI::fromLocalFilePath(Path::combine(fixtureDir, "workspace-root").getUnownedSlice())
                .uri;
        initParams.workspaceFolders.add(wsFolder);
    }
    else if (input.testOptions->commandOptions.containsKey("root-uri-only"))
        initParams.rootUri = wsFolder.uri;
    else if (input.testOptions->commandOptions.containsKey("root-path-only"))
        initParams.rootPath = Path::getParentDirectory(fullPath);
    else
    {
        initParams.workspaceFolders.add(wsFolder);
        if (input.testOptions->commandOptions.containsKey("multi-root"))
        {
            // Put an empty root last so the test detects implementations that retain only the
            // final workspace folder's search paths.
            LanguageServerProtocol::WorkspaceFolder emptyFolder;
            emptyFolder.name = "empty";
            emptyFolder.uri =
                URI::fromLocalFilePath(
                    Path::combine(Path::getParentDirectory(fullPath), "__empty_workspace_root__")
                        .getUnownedSlice())
                    .uri;
            initParams.workspaceFolders.add(emptyFolder);
        }
    }
    if (SLANG_FAILED(connection->sendCall(
            LanguageServerProtocol::InitializeParams::methodName,
            &initParams,
            JSONValue::makeInt(0))))
    {
        return TestResult::Fail;
    }
    if (SLANG_FAILED(connection->waitForResult(-1)))
    {
        return TestResult::Fail;
    }

    LanguageServerProtocol::InitializeResult initResult;
    if (SLANG_FAILED(connection->getMessage(&initResult)))
    {
        return TestResult::Fail;
    }

    // Configuration changes ask the client to refresh semantic tokens and inlay hints. Drain
    // those requests before reading the response to a subsequent completion request.
    auto sendConfig = [&](const char* key, JSONValue value) -> SlangResult
    {
        auto container = connection->getContainer();
        JSONValue settingsValue = container->createObject(nullptr, 0);
        container->setKeyValue(settingsValue, container->getKey(UnownedStringSlice(key)), value);

        LanguageServerProtocol::DidChangeConfigurationParams configParams;
        configParams.settings = settingsValue;
        SLANG_RETURN_ON_FAIL(connection->sendCall(
            LanguageServerProtocol::DidChangeConfigurationParams::methodName,
            &configParams));

        for (Index i = 0; i < 2; ++i)
        {
            SLANG_RETURN_ON_FAIL(connection->waitForResult(-1));
            JSONRPCCall refreshCall;
            SLANG_RETURN_ON_FAIL(connection->getRPC(&refreshCall));
        }
        return SLANG_OK;
    };

    String testFileContent;

    if (SLANG_FAILED(File::readAllText(input.filePath, testFileContent)))
    {
        return TestResult::Fail;
    }

    List<UnownedStringSlice> lines;
    StringUtil::calcLines(testFileContent.getUnownedSlice(), lines);

    // A `//CONFIG_REPLY:<section>=<json>` or `//CONFIG:<key>=<json>` directive holds a JSON value.
    // It is parsed into the connection's container right before use, because the container is
    // reset whenever a message is read.
    auto parseConfigValue = [&](UnownedStringSlice text, JSONValue& outValue) -> SlangResult
    {
        return JSONRPCUtil::parseJSON(
            text.trim(),
            connection->getContainer(),
            connection->getSink(),
            outValue);
    };

    auto reportDirectiveError = [&](UnownedStringSlice line, const char* problem)
    {
        StringBuilder lineText;
        lineText << line;
        context->getTestReporter()->messageFormat(
            TestMessageType::RunError,
            "Invalid LANG_SERVER directive in '%s': %s: %s",
            input.filePath.getBuffer(),
            problem,
            lineText.getBuffer());
        return TestResult::Fail;
    };

    Dictionary<String, UnownedStringSlice> configReplies;
    for (auto line : lines)
    {
        line = line.trimStart();
        if (!line.startsWith("//"))
            continue;
        line = line.tail(2).trimStart();
        if (!line.startsWith("CONFIG_REPLY:"))
            continue;
        if (!input.testOptions->commandOptions.containsKey("config-pull"))
            return reportDirectiveError(line, "CONFIG_REPLY requires the config-pull option");
        auto reply = line.tail(UnownedStringSlice("CONFIG_REPLY:").getLength());
        Index eqIndex = reply.indexOf('=');
        if (eqIndex < 0)
            return reportDirectiveError(line, "expected <section>=<json>");
        String section = reply.head(eqIndex).trim();
        if (configReplies.containsKey(section))
            return reportDirectiveError(line, "duplicate section");
        configReplies[section] = reply.tail(eqIndex + 1);
    }

    List<LanguageServerProtocol::PublishDiagnosticsParams> diagnostics;
    bool diagnosticsReceived = false;
    // Every LANG_SERVER test shares one language server process, so a call the server sends must
    // be read before the test ends or the next test reads it in place of its own response. A
    // configuration message makes the server send zero or more refresh requests, depending on the
    // setting and whether it changed. We set this flag whenever one is sent, and `waitForResponse`
    // clears it, because the server sends those requests before it answers any later request.
    bool mayHaveUnreadServerCalls = false;
    // Record a `textDocument/publishDiagnostics` notification, or skip any other server-to-client
    // call. The server never blocks on a reply to the calls it sends, so skipping is safe.
    auto handleServerCall = [&](const JSONRPCCall& call) -> SlangResult
    {
        if (call.method != "textDocument/publishDiagnostics")
            return SLANG_OK;
        diagnosticsReceived = true;
        LanguageServerProtocol::PublishDiagnosticsParams arg;
        SLANG_RETURN_ON_FAIL(connection->getMessage(&arg));
        diagnostics.add(arg);
        return SLANG_OK;
    };

    // The harness answers the server's `workspace/configuration` request with one value per
    // requested section, taken from `//CONFIG_REPLY:` lines, and JSON null for every other section.
    // LSP requires null for a setting the client cannot provide, so this is the reply an editor
    // without Slang-specific defaults (such as Zed) sends. Other server calls that arrive first are
    // handled as `handleServerCall` does, and a request among them, such as
    // `client/registerCapability`, is answered with a null result.
    auto answerConfigRequest = [&]() -> SlangResult
    {
        for (;;)
        {
            SLANG_RETURN_ON_FAIL(connection->waitForResult(-1));
            JSONRPCCall call;
            SLANG_RETURN_ON_FAIL(connection->getRPC(&call));
            if (call.method != LanguageServerProtocol::ConfigurationParams::methodName)
            {
                SLANG_RETURN_ON_FAIL(handleServerCall(call));
                if (call.id.isValid())
                    SLANG_RETURN_ON_FAIL(connection->sendNullResult(call.id));
                continue;
            }

            LanguageServerProtocol::ConfigurationParams configParams;
            SLANG_RETURN_ON_FAIL(
                connection->toNativeArgsOrSendError(call.params, &configParams, call.id));
            List<JSONValue> values;
            for (auto& item : configParams.items)
            {
                JSONValue value = JSONValue::makeNull();
                UnownedStringSlice replyText;
                if (configReplies.tryGetValue(item.section, replyText))
                    SLANG_RETURN_ON_FAIL(parseConfigValue(replyText, value));
                values.add(value);
            }
            JSONResultResponse response;
            response.id = call.id;
            response.result =
                connection->getContainer()->createArray(values.getBuffer(), values.getCount());
            mayHaveUnreadServerCalls = true;
            return connection->sendRPC(&response);
        }
    };

    if (input.testOptions->commandOptions.containsKey("config-pull"))
    {
        if (SLANG_FAILED(connection->sendCall(UnownedStringSlice("initialized"))) ||
            SLANG_FAILED(answerConfigRequest()))
            return TestResult::Fail;
    }

    if (input.testOptions->commandOptions.containsKey("additional-search-path-order"))
    {
        // Configured search paths intentionally precede auto-discovered workspace paths. Exercise
        // that contract through the same notification a real editor sends.
        auto container = connection->getContainer();
        auto fixtureDir = Path::getParentDirectory(fullPath);
        auto additionalPath = Path::combine(fixtureDir, "additional-root");
        JSONValue pathValue = container->createString(additionalPath.getUnownedSlice());
        JSONValue pathsValue = container->createArray(&pathValue, 1);
        if (SLANG_FAILED(sendConfig("slang.additionalSearchPaths", pathsValue)))
            return TestResult::Fail;
    }

    // Send open document call.
    LanguageServerProtocol::DidOpenTextDocumentParams openDocParams;
    openDocParams.textDocument.version = 0;
    openDocParams.textDocument.uri = URI::fromLocalFilePath(fullPath.getUnownedSlice()).uri;
    openDocParams.textDocument.text = testFileContent;
    connection->sendCall(
        LanguageServerProtocol::DidOpenTextDocumentParams::methodName,
        &openDocParams,
        JSONValue::makeInt(1));
    auto waitForResponse = [&]() -> SlangResult
    {
        for (;;)
        {
            SLANG_RETURN_ON_FAIL(connection->waitForResult(-1));
            if (connection->getMessageType() != JSONRPCMessageType::Call)
            {
                mayHaveUnreadServerCalls = false;
                return SLANG_OK;
            }
            JSONRPCCall call;
            SLANG_RETURN_ON_FAIL(connection->getRPC(&call));
            SLANG_RETURN_ON_FAIL(handleServerCall(call));
        }
    };

    // Send a `//CONFIG:<key>=<json>` directive as a `workspace/didChangeConfiguration`
    // notification. Any refresh requests it causes are read by the next `waitForResponse`. The
    // server keeps formatting, inlay-hint, commit-character and trace options across `initialize`,
    // so a test that changes one of them sets it back to its default before the test ends.
    auto sendConfigNotification = [&](UnownedStringSlice directive) -> SlangResult
    {
        Index eqIndex = directive.indexOf('=');
        if (eqIndex < 0)
        {
            reportDirectiveError(directive, "expected CONFIG:<key>=<json>");
            return SLANG_FAIL;
        }
        JSONValue value;
        SLANG_RETURN_ON_FAIL(parseConfigValue(directive.tail(eqIndex + 1), value));
        auto container = connection->getContainer();
        JSONValue settingsValue = container->createObject(nullptr, 0);
        container->setKeyValue(
            settingsValue,
            container->getKey(directive.head(eqIndex).trim()),
            value);

        LanguageServerProtocol::DidChangeConfigurationParams configParams;
        configParams.settings = settingsValue;
        mayHaveUnreadServerCalls = true;
        return connection->sendCall(
            LanguageServerProtocol::DidChangeConfigurationParams::methodName,
            &configParams);
    };

    StringBuilder actualOutputSB;
    auto parseLocation = [&](UnownedStringSlice text, Index startPos, Int& linePos, Int& colPos)
    {
        linePos = StringUtil::parseIntAndAdvancePos(text.trimStart(), startPos);
        startPos++;
        colPos = StringUtil::parseIntAndAdvancePos(text.trimStart(), startPos);
        return startPos;
    };
    int callId = 2;
    // Items of the most recent COMPLETE (empty if it returned null or nothing), and the item picked
    // by SAVE_COMPLETION_ITEM, so that a later RESOLVE_SAVED_ITEM can resolve an item that belongs
    // to an earlier completion request. SAVE_COMPLETION_ITEM fails the test if the most recent
    // COMPLETE has no item with that label, and RESOLVE_SAVED_ITEM fails it if no item was saved.
    List<LanguageServerProtocol::CompletionItem> lastCompletionItems;
    LanguageServerProtocol::CompletionItem savedCompletionItem;
    bool hasSavedCompletionItem = false;
    for (auto line : lines)
    {
        line = line.trimStart();
        if (!line.startsWith("//"))
            continue;
        line = line.tail(2).trimStart();
        if (line.startsWith("COMPLETE:"))
        {
            auto arg = line.tail(UnownedStringSlice("COMPLETE:").getLength());
            Int linePos, colPos;
            parseLocation(arg, 0, linePos, colPos);

            LanguageServerProtocol::CompletionParams params;
            params.position.line = int(linePos - 1);
            params.position.character = int(colPos - 1);
            params.textDocument.uri = openDocParams.textDocument.uri;
            lastCompletionItems.clear();
            if (SLANG_FAILED(connection->sendCall(
                    LanguageServerProtocol::CompletionParams::methodName,
                    &params,
                    JSONValue::makeInt(callId++))))
            {
                return TestResult::Fail;
            }
            if (SLANG_FAILED(waitForResponse()))
                return TestResult::Fail;
            actualOutputSB << "--------\n";
            List<LanguageServerProtocol::CompletionItem> completionItems;
            if (receivedNullResult(connection))
            {
                actualOutputSB << "null\n";
            }
            else if (SLANG_SUCCEEDED(connection->getMessage(&completionItems)))
            {
                lastCompletionItems = completionItems;
                for (auto item : completionItems)
                {
                    actualOutputSB << item.label << ": " << item.kind << " " << item.detail << " ";
                    for (auto ch : item.commitCharacters)
                    {
                        if (ch == " ")
                            actualOutputSB << "<space>";
                        else
                            actualOutputSB << ch;
                    }
                    if (item.sortText.hasValue)
                        actualOutputSB << " sort(" << item.sortText.value << ")";
                    actualOutputSB << "\n";
                }
            }
        }
        else if (line.startsWith("SAVE_COMPLETION_ITEM:"))
        {
            auto label = line.tail(UnownedStringSlice("SAVE_COMPLETION_ITEM:").getLength()).trim();
            bool found = false;
            for (auto item : lastCompletionItems)
            {
                if (item.label.getUnownedSlice() == label)
                {
                    savedCompletionItem = item;
                    hasSavedCompletionItem = true;
                    found = true;
                    break;
                }
            }
            if (!found)
                return TestResult::Fail;
        }
        else if (line.startsWith("RESOLVE_SAVED_ITEM:"))
        {
            // This resolves the item saved by SAVE_COMPLETION_ITEM, which may come from an earlier
            // completion request than the most recent one. The directive is matched with its
            // trailing colon like the other directives, so that it cannot collide with a
            // directive that merely shares a prefix; it takes no argument.
            if (!hasSavedCompletionItem)
                return TestResult::Fail;
            if (SLANG_FAILED(connection->sendCall(
                    UnownedStringSlice("completionItem/resolve"),
                    &savedCompletionItem,
                    JSONValue::makeInt(callId++))))
            {
                return TestResult::Fail;
            }
            if (SLANG_FAILED(waitForResponse()))
                return TestResult::Fail;
            actualOutputSB << "--------\n";
            LanguageServerProtocol::CompletionItem resolved;
            if (receivedNullResult(connection))
            {
                actualOutputSB << "null\n";
            }
            else if (SLANG_SUCCEEDED(connection->getMessage(&resolved)))
            {
                actualOutputSB << "label: " << resolved.label << "\n";
                actualOutputSB << "detail: " << resolved.detail << "\n";
            }
        }
        else if (line.startsWith("DISABLE_WORKSPACE_SEARCH"))
        {
            if (SLANG_FAILED(sendConfig(
                    "slang.searchInAllWorkspaceDirectories",
                    JSONValue::makeBool(false))))
                return TestResult::Fail;
            actualOutputSB << "--------\nsearchInAllWorkspaceDirectories: false\n";
        }
        else if (line.startsWith("CONFIG:"))
        {
            auto arg = line.tail(UnownedStringSlice("CONFIG:").getLength());
            if (SLANG_FAILED(sendConfigNotification(arg)))
                return TestResult::Fail;
            actualOutputSB << "--------\nconfig: " << arg.trim() << "\n";
        }
        else if (line.trim() == "CONFIG_REPULL")
        {
            if (!input.testOptions->commandOptions.containsKey("config-pull"))
                return reportDirectiveError(line, "CONFIG_REPULL requires the config-pull option");
            // A `settings: null` notification asks the server to pull every setting again.
            LanguageServerProtocol::DidChangeConfigurationParams configParams;
            configParams.settings = JSONValue::makeNull();
            if (SLANG_FAILED(connection->sendCall(
                    LanguageServerProtocol::DidChangeConfigurationParams::methodName,
                    &configParams)) ||
                SLANG_FAILED(answerConfigRequest()))
                return TestResult::Fail;
            mayHaveUnreadServerCalls = true;
            actualOutputSB << "--------\nconfig: re-pulled\n";
        }
        else if (line.startsWith("ON_TYPE_FORMAT:"))
        {
            // Only whether on-type formatting is enabled is reported: a disabled server answers
            // null, and an enabled one answers a list of edits, which is empty when clang-format
            // is unavailable.
            auto arg = line.tail(UnownedStringSlice("ON_TYPE_FORMAT:").getLength());
            Int linePos, colPos;
            parseLocation(arg, 0, linePos, colPos);

            LanguageServerProtocol::DocumentOnTypeFormattingParams params;
            params.textDocument.uri = openDocParams.textDocument.uri;
            params.position.line = int(linePos - 1);
            params.position.character = int(colPos - 1);
            params.ch = "}";
            if (SLANG_FAILED(connection->sendCall(
                    LanguageServerProtocol::DocumentOnTypeFormattingParams::methodName,
                    &params,
                    JSONValue::makeInt(callId++))))
            {
                return TestResult::Fail;
            }
            if (SLANG_FAILED(waitForResponse()))
                return TestResult::Fail;
            actualOutputSB << "--------\non-type formatting: "
                           << (receivedNullResult(connection) ? "disabled" : "enabled") << "\n";
        }
        else if (line.trim() == "INLAY")
        {
            LanguageServerProtocol::InlayHintParams params;
            params.textDocument.uri = openDocParams.textDocument.uri;
            params.range.start.line = 0;
            params.range.start.character = 0;
            params.range.end.line = int(lines.getCount());
            params.range.end.character = 0;
            if (SLANG_FAILED(connection->sendCall(
                    LanguageServerProtocol::InlayHintParams::methodName,
                    &params,
                    JSONValue::makeInt(callId++))))
            {
                return TestResult::Fail;
            }
            if (SLANG_FAILED(waitForResponse()))
                return TestResult::Fail;
            actualOutputSB << "--------\ninlay hints:\n";
            List<LanguageServerProtocol::InlayHint> hints;
            if (!receivedNullResult(connection) && SLANG_FAILED(connection->getMessage(&hints)))
                return TestResult::Fail;
            for (auto& hint : hints)
            {
                actualOutputSB << hint.position.line << "," << hint.position.character << " "
                               << hint.label << "\n";
            }
        }
        else if (line.startsWith("SIGNATURE:"))
        {
            auto arg = line.tail(UnownedStringSlice("SIGNATURE:").getLength());
            Int linePos, colPos;
            parseLocation(arg, 0, linePos, colPos);

            LanguageServerProtocol::SignatureHelpParams params;
            params.position.line = int(linePos - 1);
            params.position.character = int(colPos - 1);
            params.textDocument.uri = openDocParams.textDocument.uri;
            if (SLANG_FAILED(connection->sendCall(
                    LanguageServerProtocol::SignatureHelpParams::methodName,
                    &params,
                    JSONValue::makeInt(callId++))))
            {
                return TestResult::Fail;
            }
            if (SLANG_FAILED(waitForResponse()))
                return TestResult::Fail;
            actualOutputSB << "--------\n";
            LanguageServerProtocol::SignatureHelp sigInfo;
            if (receivedNullResult(connection))
            {
                actualOutputSB << "null\n";
            }
            else if (SLANG_SUCCEEDED(connection->getMessage(&sigInfo)))
            {
                actualOutputSB << "activeParameter: " << sigInfo.activeParameter << "\n";
                actualOutputSB << "activeSignature: " << sigInfo.activeSignature << "\n";
                for (Index i = 0; i < sigInfo.signatures.getCount(); ++i)
                {
                    auto& item = sigInfo.signatures[i];
                    if (i == sigInfo.activeSignature)
                    {
                        actualOutputSB << "(selected) ";
                    }
                    actualOutputSB << item.label << ":";
                    for (auto param : item.parameters)
                    {
                        actualOutputSB << " (" << param.label[0] << "," << param.label[1] << ")";
                    }
                    actualOutputSB << "\n";
                    actualOutputSB << item.documentation.value << "\n";
                }
            }
        }
        else if (line.startsWith("HOVER:"))
        {
            auto arg = line.tail(UnownedStringSlice("HOVER:").getLength());
            Int linePos, colPos;
            parseLocation(arg, 0, linePos, colPos);

            LanguageServerProtocol::HoverParams params;
            params.position.line = int(linePos - 1);
            params.position.character = int(colPos - 1);
            params.textDocument.uri = openDocParams.textDocument.uri;
            if (SLANG_FAILED(connection->sendCall(
                    LanguageServerProtocol::HoverParams::methodName,
                    &params,
                    JSONValue::makeInt(callId++))))
            {
                return TestResult::Fail;
            }
            if (SLANG_FAILED(waitForResponse()))
                return TestResult::Fail;
            actualOutputSB << "--------\n";
            LanguageServerProtocol::Hover hover;
            if (receivedNullResult(connection))
            {
                actualOutputSB << "null\n";
            }
            else if (SLANG_SUCCEEDED(connection->getMessage(&hover)))
            {
                actualOutputSB << "range: " << hover.range.start.line << ","
                               << hover.range.start.character << " - " << hover.range.end.line
                               << "," << hover.range.end.character;
                actualOutputSB << "\ncontent:\n" << hover.contents.value << "\n";
            }
        }
        else if (line.startsWith("RESOLVE"))
        {
            // Drive completionItem/resolve for an item that carries a textEdit but no `data`
            // (the file/import completion shape). LSP requires resolve to answer with the item,
            // never null, so the server must echo it back with its textEdit preserved.
            LanguageServerProtocol::TextEditCompletionItem item;
            item.label = "resolveItem";
            item.textEdit.newText = "resolveItem";
            item.textEdit.range.start.line = 5;
            item.textEdit.range.start.character = 0;
            item.textEdit.range.end.line = 5;
            item.textEdit.range.end.character = 3;
            if (SLANG_FAILED(connection->sendCall(
                    UnownedStringSlice("completionItem/resolve"),
                    &item,
                    JSONValue::makeInt(callId++))))
            {
                return TestResult::Fail;
            }
            if (SLANG_FAILED(waitForResponse()))
                return TestResult::Fail;
            actualOutputSB << "--------\n";
            LanguageServerProtocol::TextEditCompletionItem resolved;
            if (receivedNullResult(connection))
            {
                actualOutputSB << "null\n";
            }
            else if (SLANG_SUCCEEDED(connection->getMessage(&resolved)))
            {
                actualOutputSB << "label: " << resolved.label << "\n";
                actualOutputSB << "textEdit: " << resolved.textEdit.newText << "\n";
                actualOutputSB << "range: " << resolved.textEdit.range.start.line << ","
                               << resolved.textEdit.range.start.character << " - "
                               << resolved.textEdit.range.end.line << ","
                               << resolved.textEdit.range.end.character << "\n";
            }
        }
        else if (line.startsWith("DIAGNOSTICS"))
        {
            if (!diagnosticsReceived)
            {
                waitForResponse();
            }
            actualOutputSB << "--------\n";
            for (auto item : diagnostics)
            {
                actualOutputSB << item.uri << "\n";
                for (auto msg : item.diagnostics)
                {
                    actualOutputSB << msg.range.start.line << "," << msg.range.start.character
                                   << "-" << msg.range.end.line << "," << msg.range.end.character
                                   << " " << msg.message;
                }
            }
        }
    }
    // A configuration message sent after the last request may have left server calls unread (see
    // `mayHaveUnreadServerCalls`). A document symbol request has no side effects, and the server
    // answers it only after handling every message sent before it.
    if (mayHaveUnreadServerCalls)
    {
        LanguageServerProtocol::DocumentSymbolParams params;
        params.textDocument.uri = openDocParams.textDocument.uri;
        if (SLANG_FAILED(connection->sendCall(
                LanguageServerProtocol::DocumentSymbolParams::methodName,
                &params,
                JSONValue::makeInt(callId++))) ||
            SLANG_FAILED(waitForResponse()))
            return TestResult::Fail;
    }

    LanguageServerProtocol::DidCloseTextDocumentParams closeDocParams;
    closeDocParams.textDocument.uri = URI::fromLocalFilePath(fullPath.getUnownedSlice()).uri;
    connection->sendCall(
        LanguageServerProtocol::DidCloseTextDocumentParams::methodName,
        &closeDocParams,
        JSONValue::makeInt(1));

    auto outputStem = input.outputStem;
    String expectedOutputPath = outputStem + ".expected.txt";
    String expectedOutput;

    Slang::File::readAllText(expectedOutputPath, expectedOutput);
    expectedOutput = expectedOutput.trim();

    TestResult result = TestResult::Pass;

    auto actualOutput = actualOutputSB.produceString();

    // Redact absolute file names from actualOutput
    List<UnownedStringSlice> outputLines;
    StringUtil::calcLines(actualOutput.getUnownedSlice(), outputLines);
    StringBuilder redactedSB;
    for (auto line : outputLines)
    {
        Index extIdx = line.indexOf(UnownedStringSlice(".slang"));
        if (extIdx == -1)
        {
            redactedSB << line << "\n";
            continue;
        }
        redactedSB << "{REDACTED}" << line.tail(extIdx) << "\n";
    }

    actualOutput = redactedSB.produceString().trim();

    String fileCheckPrefix;
    const bool isFileCheckTest = input.testOptions->getFileCheckPrefix(fileCheckPrefix);
    if (isFileCheckTest)
    {
        result = _fileCheckTest(*context, input.filePath, fileCheckPrefix, actualOutput);
    }
    else
    {
        if (!_areResultsEqual(input.testOptions->type, expectedOutput, actualOutput))
        {
            if (expectedOutput.startsWith("CONTAINS"))
            {
                List<UnownedStringSlice> words;
                List<UnownedStringSlice> expectedLines;
                StringUtil::calcLines(expectedOutput.getUnownedSlice(), expectedLines);
                if (expectedLines.getCount() >= 1)
                {
                    StringUtil::split(expectedLines[0], ' ', words);
                    if (words.getCount() >= 2)
                    {
                        if (actualOutput.contains(words[1].trim()))
                        {
                            return result;
                        }
                    }
                }
            }
            context->getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);
            result = TestResult::Fail;
        }
    }

    // If the test failed, then we write the actual output to a file
    // so that we can easily diff it from the command line and
    // diagnose the problem.
    if (result == TestResult::Fail)
    {
        String actualOutputPath = outputStem + ".actual";
        Slang::File::writeAllText(actualOutputPath, actualOutput);

        context->getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);
    }
    return result;
}

TestResult runSimpleTest(TestContext* context, TestInput& input)
{
    // need to execute the stand-alone Slang compiler on the file, and compare its output to what we
    // expect
    auto outputStem = input.outputStem;

    CommandLine cmdLine;

    if (input.testOptions->command != "SIMPLE_EX")
    {
        cmdLine.addArg(input.filePath);
    }

    // Enable machine-readable diagnostics if diag option is specified
    // This must come BEFORE other test options so that diagnostics emitted
    // during option parsing are properly formatted
    String diagPrefix;
    if (input.testOptions->getDiagTestPrefix(diagPrefix))
    {
        cmdLine.addArg("-enable-machine-readable-diagnostics");
    }

    for (auto arg : input.testOptions->args)
    {
        // Filter out slang-test specific options that shouldn't be passed to slangc
        if (arg == kPreserveEmbeddedSourceOption)
            continue;
        cmdLine.addArg(arg);
    }

    // If we can't set up for simple compilation, it's because some external resource isn't
    // available such as NVAPI headers. In that case we just ignore the test.
    if (SLANG_FAILED(_initSlangCompiler(context, cmdLine)))
    {
        return TestResult::Ignored;
    }
    // Keep compiler-based tests on the default optimization level unless a test opts out.
    SlangTest::addDefaultSlangOptimization(cmdLine, context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    // See what kind of target it is
    SlangCompileTarget target = SLANG_TARGET_UNKNOWN;
    {
        const auto& args = input.testOptions->args;
        const Index targetIndex = args.indexOf("-target");
        if (targetIndex != Index(-1) && targetIndex + 1 < args.getCount())
        {
            target =
                TypeTextUtil::findCompileTargetFromName(args[targetIndex + 1].getUnownedSlice());
        }
    }

    // If it's executable we run it and use it's output
    if (target == SLANG_HOST_EXECUTABLE)
    {
        ExecuteResult runExeRes;
        if (SLANG_FAILED(_executeBinary(exeRes.standardOutput.getUnownedSlice(), runExeRes)))
        {
            return TestResult::Fail;
        }
        exeRes = runExeRes;
    }

    bool needToRemoveEmbeddedSource =
        ((target == SLANG_SPIRV || target == SLANG_SPIRV_ASM) &&
         input.testOptions->args.indexOf(kPreserveEmbeddedSourceOption) == Index(-1));

    String actualOutput = getOutput(exeRes, needToRemoveEmbeddedSource);

    return _validateOutput(
        context,
        input,
        actualOutput,
        false,
        "result code = 0\nstandard error = {\n}\nstandard output = {\n}\n",
        [&input](auto e, auto a) { return _areResultsEqual(input.testOptions->type, e, a); });
}

TestResult runSimpleLineTest(TestContext* context, TestInput& input)
{
    // need to execute the stand-alone Slang compiler on the file, and compare its output to what we
    // expect
    auto outputStem = input.outputStem;

    CommandLine cmdLine;
    _initSlangCompiler(context, cmdLine);

    cmdLine.addArg(input.filePath);

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }
    SlangTest::addDefaultSlangOptimization(cmdLine, context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    // Parse all the diagnostics so we can extract line numbers
    auto diagnostics = ArtifactDiagnostics::create();
    if (SLANG_FAILED(ParseDiagnosticUtil::parseDiagnostics(
            exeRes.standardError.getUnownedSlice(),
            diagnostics)) ||
        diagnostics->getCount() <= 0)
    {
        // Write out the diagnostics which couldn't be parsed.

        String actualOutputPath = outputStem + ".actual";
        Slang::File::writeAllText(actualOutputPath, exeRes.standardError);

        return TestResult::Fail;
    }

    StringBuilder actualOutput;

    if (diagnostics->getCount() > 0)
    {
        actualOutput << diagnostics->getAt(0)->location.line << "\n";
    }
    else
    {
        actualOutput << "No output diagnostics\n";
    }

    return _validateOutput(context, input, actualOutput, false);
}

TestResult runInterpreterTest(TestContext* context, TestInput& input)
{
    // need to execute the stand-alone Slang compiler on the file, and compare its output to what we
    // expect
    auto outputStem = input.outputStem;

    CommandLine cmdLine;

    List<String> args;

    for (Index i = 0; i < input.testOptions->args.getCount(); i++)
    {
        auto& arg = input.testOptions->args[i];
        if (arg == "-disasm")
            cmdLine.addArg(arg);
        else if (arg == "-entry")
        {
            cmdLine.addArg(arg);
            i++;
            if (i < input.testOptions->args.getCount())
            {
                cmdLine.addArg(input.testOptions->args[i]);
            }
        }
        else
        {
            args.add(arg);
        }
    }

    cmdLine.addArg(input.filePath);

    for (auto arg : args)
    {
        cmdLine.addArg(arg);
    }

    if (SLANG_FAILED(_initSlangInterpreter(context, cmdLine)))
    {
        return TestResult::Ignored;
    }

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    String actualOutput = getOutput(exeRes);

    return _validateOutput(
        context,
        input,
        actualOutput,
        false,
        "result code = 0\nstandard error = {\n}\nstandard output = {\n}\n",
        [&input](auto e, auto a) { return _areResultsEqual(input.testOptions->type, e, a); });
}

TestResult runDispatcherTest(TestContext* context, TestInput& input)
{
    auto outputStem = input.outputStem;

    CommandLine cmdLine;

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }

    if (SLANG_FAILED(_initSlangDispatcher(context, cmdLine)))
    {
        return TestResult::Ignored;
    }

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, SpawnType::UseExe, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    String actualOutput = getOutput(exeRes);

    return _validateOutput(
        context,
        input,
        actualOutput,
        false,
        "result code = 0\nstandard error = {\n}\nstandard output = {\n}\n",
        [&input](auto e, auto a) { return _areResultsEqual(input.testOptions->type, e, a); });
}

TestResult runCompile(TestContext* context, TestInput& input)
{
    auto outputStem = input.outputStem;

    CommandLine cmdLine;
    _initSlangCompiler(context, cmdLine);

    StringEscapeHandler* escapeHandler =
        StringEscapeUtil::getHandler(StringEscapeUtil::Style::Space);

    for (auto arg : input.testOptions->args)
    {
        // If unescaping is needed, do it
        if (StringEscapeUtil::isUnescapeShellLikeNeeded(escapeHandler, arg.getUnownedSlice()))
        {
            StringBuilder buf;
            StringEscapeUtil::unescapeShellLike(escapeHandler, arg.getUnownedSlice(), buf);
            cmdLine.addArg(buf.produceString());
        }
        else
        {
            cmdLine.addArg(arg);
        }
    }
    SlangTest::addDefaultSlangOptimization(cmdLine, context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));
    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    if (exeRes.resultCode != 0)
    {
        auto reporter = context->getTestReporter();
        if (reporter)
        {
            auto output = getOutput(exeRes);
            reporter->message(TestMessageType::TestFailure, output);
        }

        return TestResult::Fail;
    }

    return TestResult::Pass;
}

TestResult runCompileTarget(TestContext* context, TestInput& input)
{
    auto outputStem = input.outputStem;

    CommandLine cmdLine;
    cmdLine.setExecutableLocation(ExecutableLocation(context->options.binDir, "render-test"));
    cmdLine.addArg(input.filePath);
    _addRenderTestOptions(context->options, cmdLine, true);

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }

    cmdLine.addArg("-compile-only");
    SlangTest::addDefaultRenderTestSlangOptimization(
        cmdLine,
        context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));
    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    if (exeRes.resultCode != 0)
    {
        auto reporter = context->getTestReporter();
        if (reporter)
        {
            auto output = getOutput(exeRes);
            reporter->message(TestMessageType::TestFailure, output);
        }

        return TestResult::Fail;
    }

    return TestResult::Pass;
}

TestResult runSimpleCompareCommandLineTest(TestContext* context, TestInput& input)
{
    TestInput workInput(input);
    // Use the original files input to compare with
    workInput.outputStem = input.filePath;
    // Force to using exes
    workInput.spawnType = SpawnType::UseExe;

    return runSimpleTest(context, workInput);
}

static SlangResult _parseJSON(
    const UnownedStringSlice& slice,
    DiagnosticSink* sink,
    JSONContainer* container,
    JSONValue& outValue)
{
    SourceManager* sourceManager = sink->getSourceManager();

    SourceFile* sourceFile =
        sourceManager->createSourceFileWithString(PathInfo::makeUnknown(), slice);
    SourceView* sourceView = sourceManager->createSourceView(sourceFile, nullptr, SourceLoc());

    JSONLexer lexer;
    lexer.init(sourceView, sink);

    JSONBuilder builder(container);

    JSONParser parser;
    SLANG_RETURN_ON_FAIL(parser.parse(&lexer, sourceView, &builder, sink));

    outValue = builder.getRootValue();
    return SLANG_OK;
}

TestResult runReflectionTest(TestContext* context, TestInput& input)
{
    const auto& options = context->options;
    const auto& filePath = input.filePath;
    auto& outputStem = input.outputStem;

    bool isCPUTest = input.testOptions->command.startsWith("CPU_");

    CommandLine cmdLine;

    cmdLine.setExecutableLocation(ExecutableLocation(options.binDir, "slang-reflection-test"));
    cmdLine.addArg(filePath);

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }
    SlangTest::addDefaultSlangOptimization(cmdLine, context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    String actualOutput = getOutput(exeRes);

    if (isCPUTest)
    {
#if SLANG_PTR_IS_32
        outputStem.append(".32");
#else
        outputStem.append(".64");
#endif
    }

    // Extrac the stand
    ParseDiagnosticUtil::OutputInfo outputInfo;
    if (SLANG_SUCCEEDED(
            ParseDiagnosticUtil::parseOutputInfo(actualOutput.getUnownedSlice(), outputInfo)))
    {
        const auto toolReturnCode = ToolReturnCode(outputInfo.resultCode);

        // The output should be JSON.
        // Parse it to check that it is valid json
        if (toolReturnCode == ToolReturnCode::Success)
        {
            SourceManager sourceManager;
            sourceManager.initialize(nullptr, nullptr);

            JSONContainer container(&sourceManager);

            DiagnosticSink sink;
            sink.init(&sourceManager, nullptr);

            JSONValue value;
            if (SLANG_FAILED(
                    _parseJSON(outputInfo.stdOut.getUnownedSlice(), &sink, &container, value)))
            {
                // Unable to parse as JSON

                context->getTestReporter()->messageFormat(
                    TestMessageType::RunError,
                    "Unable to parse reflection JSON '%s'\n",
                    input.outputStem.getBuffer());

                String actualOutputPath = input.outputStem + ".actual";
                Slang::File::writeAllText(actualOutputPath, actualOutput);
                return TestResult::Fail;
            }
        }
    }

    return _validateOutput(context, input, actualOutput);
}

static String _calcSummary(IArtifactDiagnostics* inDiagnostics)
{
    auto diagnostics = cloneInterface(inDiagnostics);

    // We only want to analyze errors for now
    diagnostics->removeBySeverity(ArtifactDiagnostic::Severity::Info);
    diagnostics->removeBySeverity(ArtifactDiagnostic::Severity::Warning);

    ComPtr<ISlangBlob> summary;
    diagnostics->calcSimplifiedSummary(summary.writeRef());

    return StringUtil::getString(summary);
}

static TestResult runCPPCompilerCompile(TestContext* context, TestInput& input)
{
    IDownstreamCompiler* compiler = context->getDefaultCompiler(SLANG_SOURCE_LANGUAGE_CPP);
    if (!compiler)
    {
        return TestResult::Ignored;
    }

    // need to execute the stand-alone Slang compiler on the file, and compare its output to what we
    // expect

    auto outputStem = input.outputStem;

    CommandLine cmdLine;
    _initSlangCompiler(context, cmdLine);

    cmdLine.addArg(input.filePath);
    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }
    SlangTest::addDefaultSlangOptimization(cmdLine, context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));
    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    // Dump out what happened
    {
        String actualOutputPath = outputStem + ".actual";
        Slang::File::writeAllText(actualOutputPath, getOutput(exeRes));
    }

    if (exeRes.resultCode != 0)
    {
        return TestResult::Fail;
    }

    return TestResult::Pass;
}

static TestResult runCPPCompilerSharedLibrary(TestContext* context, TestInput& input)
{
    IDownstreamCompiler* compiler = context->getDefaultCompiler(SLANG_SOURCE_LANGUAGE_CPP);
    if (!compiler)
    {
        std::lock_guard<std::mutex> lock(context->mutex);
        return TestResult::Ignored;
    }

    // If we are just collecting requirements, say it passed
    if (context->isCollectingRequirements())
    {
        context->getTestRequirements()->addUsedBackEnd(SLANG_PASS_THROUGH_GENERIC_C_CPP);
        return TestResult::Pass;
    }

    auto outputStem = input.outputStem;
    auto filePath = input.filePath;

    String actualOutputPath = outputStem + ".actual";
    File::remove(actualOutputPath);

    // Make the module name the same as the source file
    String modulePath = _calcModulePath(input);
    String ext = Path::getPathExt(filePath);

    // Remove the binary..
    String sharedLibraryPath = SharedLibrary::calcPlatformPath(modulePath.getUnownedSlice());
    File::remove(sharedLibraryPath);

    // Set up the compilation options
    DownstreamCompileOptions options;

    options.sourceLanguage = (ext == "c") ? SLANG_SOURCE_LANGUAGE_C : SLANG_SOURCE_LANGUAGE_CPP;

    // Build a shared library
    options.targetType = SLANG_SHADER_SHARED_LIBRARY;

    auto helper = DefaultArtifactHelper::getSingleton();

    // Compile this source
    ComPtr<IArtifact> sourceArtifact;

    // If set, we store the artifact in memory without a name.
    bool checkMemory = false;
    if (checkMemory)
    {
        helper->createArtifact(
            ArtifactDescUtil::makeDescForSourceLanguage(options.sourceLanguage),
            "",
            sourceArtifact.writeRef());

        ComPtr<IOSFileArtifactRepresentation> fileRep;
        // Let's just add a blob with the contents
        helper->createOSFileArtifactRepresentation(
            IOSFileArtifactRepresentation::Kind::Reference,
            asCharSlice(filePath.getUnownedSlice()),
            nullptr,
            fileRep.writeRef());

        ComPtr<ICastable> castable;
        fileRep->createRepresentation(ISlangBlob::getTypeGuid(), castable.writeRef());

        sourceArtifact->addRepresentation(castable);
    }
    else
    {
        helper->createOSFileArtifact(
            ArtifactDescUtil::makeDescForSourceLanguage(options.sourceLanguage),
            asCharSlice(filePath.getUnownedSlice()),
            sourceArtifact.writeRef());
    }

    TerminatedCharSlice includePaths[] = {TerminatedCharSlice(".")};

    options.sourceArtifacts = makeSlice(sourceArtifact.readRef(), 1);
    options.includePaths = makeSlice(includePaths, SLANG_COUNT_OF(includePaths));
    options.modulePath = SliceUtil::asTerminatedCharSlice(modulePath);

    ComPtr<IArtifact> artifact;
    const SlangResult compileRes = compiler->compile(options, artifact.writeRef());

    auto diagnostics =
        artifact ? findAssociatedRepresentation<IArtifactDiagnostics>(artifact) : nullptr;

    if (SLANG_FAILED(compileRes) || (diagnostics && SLANG_FAILED(diagnostics->getResult())))
    {
        // Compilation failed
        String actualOutput = diagnostics ? _calcSummary(diagnostics) : String("Compile: Error\n");

        // Write the output
        Slang::File::writeAllText(actualOutputPath, actualOutput);

        // Check that they are the same
        {
            // Read the expected
            String expectedOutput;

            String expectedOutputPath = outputStem + ".expected";
            Slang::File::readAllText(expectedOutputPath, expectedOutput);

            // Compare if they are the same
            if (!StringUtil::areLinesEqual(
                    actualOutput.getUnownedSlice(),
                    expectedOutput.getUnownedSlice()))
            {
                context->getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);
                return TestResult::Fail;
            }
        }
    }
    else
    {
        SharedLibrary::Handle handle;
        if (SLANG_FAILED(
                SharedLibrary::loadWithPlatformPath(sharedLibraryPath.getBuffer(), handle)))
        {
            return TestResult::Fail;
        }

        const int inValue = 10;
        const char inBuffer[] = "Hello World!";

        char buffer[128] = "";
        int value = 0;

        typedef int (*TestFunc)(int intValue, const char* textValue, char* outTextValue);

        // We could capture output if we passed in a ISlangWriter - but for that to work we'd need a
        TestFunc testFunc = (TestFunc)SharedLibrary::findSymbolAddressByName(handle, "test");
        if (testFunc)
        {
            value = testFunc(inValue, inBuffer, buffer);
        }
        else
        {
            printf("Unable to access 'test' function\n");
        }

        SharedLibrary::unload(handle);

        if (!(inValue == value && strcmp(inBuffer, buffer) == 0))
        {
            return TestResult::Fail;
        }
    }

    return TestResult::Pass;
}

static TestResult runCPPCompilerExecute(TestContext* context, TestInput& input)
{
    IDownstreamCompiler* compiler = context->getDefaultCompiler(SLANG_SOURCE_LANGUAGE_CPP);
    if (!compiler)
    {
        return TestResult::Ignored;
    }

    // If we are just collecting requirements, say it passed
    if (context->isCollectingRequirements())
    {
        std::lock_guard<std::mutex> lock(context->mutex);
        context->getTestRequirements()->addUsedBackEnd(SLANG_PASS_THROUGH_GENERIC_C_CPP);
        return TestResult::Pass;
    }

    auto filePath = input.filePath;
    auto outputStem = input.outputStem;

    String actualOutputPath = outputStem + ".actual";
    File::remove(actualOutputPath);

    // Make the module name the same as the source file
    String ext = Path::getPathExt(filePath);
    String modulePath = _calcModulePath(input);

    // Remove the binary..
    String moduleExePath;
    {
        StringBuilder buf;
        buf << modulePath;
        buf << Process::getExecutableSuffix();
        moduleExePath = buf;
    }

    // Remove the exe if it exists
    File::remove(moduleExePath);

    // Set up the compilation options
    DownstreamCompileOptions options;

    options.sourceLanguage = (ext == "c") ? SLANG_SOURCE_LANGUAGE_C : SLANG_SOURCE_LANGUAGE_CPP;

    TerminatedCharSlice filePaths[] = {SliceUtil::asTerminatedCharSlice(filePath)};

    auto helper = DefaultArtifactHelper::getSingleton();

    ComPtr<IArtifact> sourceArtifact;
    helper->createOSFileArtifact(
        ArtifactDescUtil::makeDescForSourceLanguage(options.sourceLanguage),
        asCharSlice(filePath.getUnownedSlice()),
        sourceArtifact.writeRef());

    // Compile this source
    options.sourceArtifacts = makeSlice(sourceArtifact.readRef(), 1);
    options.modulePath = SliceUtil::asTerminatedCharSlice(modulePath);

    ComPtr<IArtifact> artifact;
    SlangResult compileResult = compiler->compile(options, artifact.writeRef());

    String actualOutput;

    // Check if artifact is valid before trying to find diagnostics
    auto diagnostics =
        artifact ? findAssociatedRepresentation<IArtifactDiagnostics>(artifact) : nullptr;

    // If the actual compilation failed, then the output will be the summary
    if (SLANG_FAILED(compileResult) || (diagnostics && SLANG_FAILED(diagnostics->getResult())))
    {
        // Generate summary from diagnostics if available
        if (diagnostics)
        {
            actualOutput = _calcSummary(diagnostics);
        }
        else
        {
            // No diagnostics available, but compile failed
            actualOutput = "Compile: Error\n";
        }
    }
    else
    {
        // Execute the binary and see what we get
        CommandLine cmdLine;

        ExecutableLocation exe;
        exe.setPath(moduleExePath);

        cmdLine.setExecutableLocation(exe);

        ExecuteResult exeRes;
        if (SLANG_FAILED(ProcessUtil::execute(cmdLine, exeRes)))
        {
            return TestResult::Fail;
        }

        // Write the output, and compare to expected
        actualOutput = getOutput(exeRes);
    }

    // Write the output
    Slang::File::writeAllText(actualOutputPath, actualOutput);

    // Check that they are the same
    {
        // Read the expected
        String expectedOutput;

        String expectedOutputPath = outputStem + ".expected";
        Slang::File::readAllText(expectedOutputPath, expectedOutput);

        // Compare if they are the same
        if (!StringUtil::areLinesEqual(
                actualOutput.getUnownedSlice(),
                expectedOutput.getUnownedSlice()))
        {
            context->getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);
            return TestResult::Fail;
        }
    }

    return TestResult::Pass;
}

// Returns TestResult::Ignored if we don't have the capability to run the passthrough compiler
// Returns TestResult::Fail if we can't write the expected output debug file
// Otherwise return TestResult::Pass and if we are not just collecting
// requirements, writes the output into the `expectedOutput` parameter
static TestResult generateExpectedOutput(
    TestContext* const context,
    const TestInput& input,
    String& expectedOutput)
{
    auto filePath = input.filePath;
    auto outputStem = input.outputStem;

    CommandLine expectedCmdLine;

    _initSlangCompiler(context, expectedCmdLine);

    const auto& args = input.testOptions->args;

    const Index targetIndex = args.indexOf("-target");
    if (targetIndex != Index(-1) && targetIndex + 1 < args.getCount())
    {
        const SlangCompileTarget target =
            TypeTextUtil::findCompileTargetFromName(args[targetIndex + 1].getUnownedSlice());

        // Check the session supports it. If not we ignore it
        if (SLANG_FAILED(context->getSession()->checkCompileTargetSupport(target)))
        {
            return TestResult::Ignored;
        }

        switch (target)
        {
        case SLANG_DXIL:
        case SLANG_DXIL_ASM:
            {
                expectedCmdLine.addArg(filePath + ".hlsl");
                expectedCmdLine.addArg("-pass-through");
                expectedCmdLine.addArg("dxc");
                break;
            }
        case SLANG_DXBC:
        case SLANG_DXBC_ASM:
            {
                expectedCmdLine.addArg(filePath + ".hlsl");
                expectedCmdLine.addArg("-pass-through");
                expectedCmdLine.addArg("fxc");
                break;
            }
        default:
            {
                expectedCmdLine.addArg(filePath + ".glsl");
                expectedCmdLine.addArg("-emit-spirv-via-glsl");
                expectedCmdLine.addArg("-pass-through");
                expectedCmdLine.addArg("glslang");
                break;
            }
        }
    }

    for (auto arg : args)
    {
        expectedCmdLine.addArg(arg);
    }
    SlangTest::addDefaultSlangOptimization(
        expectedCmdLine,
        context->options.defaultOptimizationLevel);

    ExecuteResult expectedExeRes;
    TEST_RETURN_ON_DONE(
        spawnAndWait(context, outputStem, input.spawnType, expectedCmdLine, expectedExeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    expectedOutput = getOutput(expectedExeRes);
    String expectedOutputPath = outputStem + ".expected";

    if (SLANG_FAILED(Slang::File::writeAllText(expectedOutputPath, expectedOutput)))
    {
        context->getTestReporter()->messageFormat(
            TestMessageType::TestFailure,
            "Failed to write test expected output to %s",
            expectedOutputPath.getBuffer());
        return TestResult::Fail;
    }

    return TestResult::Pass;
}

// Returns TestResult::Fail if compilation fails
// Otherwise return TestResult::Pass and if we are not just collecting
// requirements, writes the output into the `expectedOutput` parameter
TestResult generateActualOutput(
    TestContext* const context,
    const TestInput& input,
    String& actualOutput)
{
    auto filePath = input.filePath;

    CommandLine actualCmdLine;
    _initSlangCompiler(context, actualCmdLine);
    actualCmdLine.addArg(filePath);
    actualCmdLine.addArg("-emit-spirv-via-glsl");

    const auto& args = input.testOptions->args;

    for (auto arg : input.testOptions->args)
    {
        actualCmdLine.addArg(arg);
    }
    SlangTest::addDefaultSlangOptimization(
        actualCmdLine,
        context->options.defaultOptimizationLevel);

    ExecuteResult actualExeRes;
    TEST_RETURN_ON_DONE(
        spawnAndWait(context, input.outputStem, input.spawnType, actualCmdLine, actualExeRes));

    // Early out if we're just collecting requirements
    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    actualOutput = getOutput(actualExeRes);

    // Always fail if the compilation produced a failure, just
    // to catch situations where, e.g., command-line options parsing
    // caused the same error in both the Slang and glslang cases.
    //
    if (actualExeRes.resultCode != 0)
    {
        return TestResult::Fail;
    }

    return TestResult::Pass;
}

TestResult runCrossCompilerTest(TestContext* context, TestInput& input)
{
    // Need to execute the stand-alone Slang compiler on the file
    // then on the same file + `.glsl` and compare output
    //
    // Or, in the case of a filecheck test, instead of comparing against the
    // +".glsl" version, we run some filecheck rules on it

    String fileCheckPrefix;
    const bool isFileCheckTest = input.testOptions->getFileCheckPrefix(fileCheckPrefix);

    String actualOutput;
    if (TestResult r = generateActualOutput(context, input, actualOutput); r != TestResult::Pass)
    {
        return r;
    }

    // Only generate the expected output if this is a comparison against some
    // known-good glsl/hlsl input
    String expectedOutput;
    if (!isFileCheckTest)
    {
        if (TestResult r = generateExpectedOutput(context, input, expectedOutput);
            r != TestResult::Pass)
        {
            return r;
        }
    }

    // Early out if we're just collecting requirements
    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    TestResult result = TestResult::Pass;

    if (isFileCheckTest)
    {
        result = _fileCheckTest(*context, input.filePath, fileCheckPrefix, actualOutput);
        // TODO: It might be a good idea to sanity check any expected output
        // source files against the filecheck rules if they're applicable.
        //
        // Something like:
        // fileCheckTest(context, prefix="HLSL", input, filePath + ".hlsl");
    }
    else
    {
        if (!StringUtil::areLinesEqual(
                actualOutput.getUnownedSlice(),
                expectedOutput.getUnownedSlice()))
        {
            result = TestResult::Fail;
            context->getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);
        }
    }

    // If the test failed, then we write the actual output to a file
    // so that we can easily inspect it from the command line and
    // diagnose the problem.
    if (result == TestResult::Fail)
    {
        String actualOutputPath = input.outputStem + ".actual";
        Slang::File::writeAllText(actualOutputPath, actualOutput);
    }

    return result;
}

TestResult generateHLSLBaseline(
    TestContext* context,
    TestInput& input,
    char const* targetFormat,
    char const* passThroughName)
{
    auto filePath999 = input.filePath;
    auto outputStem = input.outputStem;

    CommandLine cmdLine;
    _initSlangCompiler(context, cmdLine);

    cmdLine.addArg(filePath999);

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }

    cmdLine.addArg("-target");
    cmdLine.addArg(targetFormat);
    cmdLine.addArg("-pass-through");
    cmdLine.addArg(passThroughName);
    SlangTest::addDefaultSlangOptimization(cmdLine, context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    String expectedOutput = getOutput(exeRes);
    String expectedOutputPath = outputStem + ".expected";

    if (SLANG_FAILED(Slang::File::writeAllText(expectedOutputPath, expectedOutput)))
    {
        return TestResult::Fail;
    }

    return TestResult::Pass;
}

TestResult generateHLSLBaseline(TestContext* context, TestInput& input)
{
    return generateHLSLBaseline(context, input, "dxbc-assembly", "fxc");
}

static TestResult _runHLSLComparisonTest(
    TestContext* context,
    TestInput& input,
    char const* targetFormat,
    char const* passThroughName)
{
    auto filePath999 = input.filePath;
    auto outputStem = input.outputStem;

    // We will use the Microsoft compiler to generate out expected output here
    String expectedOutputPath = outputStem + ".expected";

    // Generate the expected output using standard HLSL compiler
    generateHLSLBaseline(context, input, targetFormat, passThroughName);

    // need to execute the stand-alone Slang compiler on the file, and compare its output to what we
    // expect

    CommandLine cmdLine;
    _initSlangCompiler(context, cmdLine);

    cmdLine.addArg(filePath999);

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }

    // TODO: The compiler should probably define this automatically...
    cmdLine.addArg("-D");
    cmdLine.addArg("__SLANG__");

    cmdLine.addArg("-target");
    cmdLine.addArg(targetFormat);
    SlangTest::addDefaultSlangOptimization(cmdLine, context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    // We ignore output to stdout, and only worry about what the compiler
    // wrote to stderr.

    ExecuteResult::ResultCode resultCode = exeRes.resultCode;

    String standardOutput = exeRes.standardOutput;
    String standardError = exeRes.standardError;
    String debugLayer = exeRes.debugLayer;

    // We construct a single output string that captures the results
    StringBuilder actualOutputBuilder;
    actualOutputBuilder.append("result code = ");
    actualOutputBuilder.append(resultCode);
    actualOutputBuilder.append("\nstandard error = {\n");
    actualOutputBuilder.append(standardError);
    actualOutputBuilder.append("}\nstandard output = {\n");
    actualOutputBuilder.append(standardOutput);
    actualOutputBuilder.append("}\n");
    if (debugLayer.getLength() > 0)
    {
        actualOutputBuilder.append("debug layer = {\n");
        actualOutputBuilder.append(debugLayer);
        actualOutputBuilder.append("}\n");
    }

    String actualOutput = actualOutputBuilder.produceString();

    // Always fail if the compilation produced a failure, just
    // to catch situations where, e.g., command-line options parsing
    // caused the same error in both the Slang and fxc cases.
    return _validateOutput(context, input, actualOutput, resultCode != 0);
}

static TestResult runDXBCComparisonTest(TestContext* context, TestInput& input)
{
    return _runHLSLComparisonTest(context, input, "dxbc-assembly", "fxc");
}

static TestResult runDXILComparisonTest(TestContext* context, TestInput& input)
{
    return _runHLSLComparisonTest(context, input, "dxil-assembly", "dxc");
}

TestResult doGLSLComparisonTestRun(
    TestContext* context,
    TestInput& input,
    char const* langDefine,
    char const* passThrough,
    char const* outputKind,
    String* outOutput)
{
    auto filePath999 = input.filePath;
    auto outputStem = input.outputStem;

    CommandLine cmdLine;
    _initSlangCompiler(context, cmdLine);

    cmdLine.addArg(filePath999);

    if (langDefine)
    {
        cmdLine.addArg("-D");
        cmdLine.addArg(langDefine);
    }

    if (passThrough)
    {
        cmdLine.addArg("-pass-through");
        cmdLine.addArg(passThrough);
    }

    cmdLine.addArg("-target");
    cmdLine.addArg("spirv-assembly");

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }
    SlangTest::addDefaultSlangOptimization(cmdLine, context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    ExecuteResult::ResultCode resultCode = exeRes.resultCode;

    String standardOuptut = exeRes.standardOutput;
    String standardError = exeRes.standardError;
    String debugLayer = exeRes.debugLayer;

    // We construct a single output string that captures the results
    StringBuilder outputBuilder;
    outputBuilder.append("result code = ");
    outputBuilder.append(resultCode);
    outputBuilder.append("\nstandard error = {\n");
    outputBuilder.append(standardError);
    outputBuilder.append("}\nstandard output = {\n");
    outputBuilder.append(standardOuptut);
    outputBuilder.append("}\n");
    if (debugLayer.getLength() > 0)
    {
        outputBuilder.append("debug layer = {\n");
        outputBuilder.append(debugLayer);
        outputBuilder.append("}\n");
    }

    String outputPath = outputStem + outputKind;
    String output = outputBuilder.produceString();

    *outOutput = output;

    return TestResult::Pass;
}

TestResult runGLSLComparisonTest(TestContext* context, TestInput& input)
{
    auto filePath999 = input.filePath;
    auto outputStem = input.outputStem;

    String expectedOutput;
    String actualOutput;

    TestResult hlslResult = doGLSLComparisonTestRun(
        context,
        input,
        "__GLSL__",
        "glslang",
        ".expected",
        &expectedOutput);
    TestResult slangResult =
        doGLSLComparisonTestRun(context, input, "__SLANG__", nullptr, ".actual", &actualOutput);

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    // If either is ignored, the whole test is
    if (hlslResult == TestResult::Ignored || slangResult == TestResult::Ignored)
    {
        return TestResult::Ignored;
    }

    Slang::File::writeAllText(outputStem + ".expected", expectedOutput);
    Slang::File::writeAllText(outputStem + ".actual", actualOutput);

    if (hlslResult == TestResult::Fail)
        return TestResult::Fail;
    if (slangResult == TestResult::Fail)
        return TestResult::Fail;

    if (!StringUtil::areLinesEqual(
            actualOutput.getUnownedSlice(),
            expectedOutput.getUnownedSlice()))
    {
        context->getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);

        return TestResult::Fail;
    }

    return TestResult::Pass;
}

static void _addRenderTestOptions(
    const Options& options,
    CommandLine& ioCmdLine,
    bool allowCacheRHI)
{
    if (!options.emitSPIRVDirectly)
    {
        ioCmdLine.addArg("-emit-spirv-via-glsl");
    }

    for (auto capability : options.capabilities)
    {
        ioCmdLine.addArg("-capability");
        ioCmdLine.addArg(capability);
    }

    if (options.enableDebugLayers)
    {
        ioCmdLine.addArg("-enable-debug-layers");
    }

    if (allowCacheRHI && options.cacheRhiDevice)
    {
        ioCmdLine.addArg("-cache-rhi-device");
    }
}

static SlangResult _extractProfileTime(const UnownedStringSlice& text, double& timeOut)
{
    // Need to find the profile figure..
    LineParser parser(text);

    const auto lineStart = UnownedStringSlice::fromLiteral("profile-time=");
    for (auto line : parser)
    {
        if (line.startsWith(lineStart))
        {
            UnownedStringSlice remaining(line.begin() + lineStart.getLength(), line.end());
            remaining.trim();

            timeOut = stringToDouble(String(remaining));
            return SLANG_OK;
        }
    }

    return SLANG_FAIL;
}

TestResult runPerformanceProfile(TestContext* context, TestInput& input)
{
    auto outputStem = input.outputStem;

    CommandLine cmdLine;

    cmdLine.setExecutableLocation(ExecutableLocation(context->options.binDir, "render-test"));

    cmdLine.addArg(input.filePath);
    cmdLine.addArg("-performance-profile");

    _addRenderTestOptions(context->options, cmdLine, true);

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }
    SlangTest::addDefaultRenderTestSlangOptimization(
        cmdLine,
        context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));
    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    auto actualOutput = getOutput(exeRes);

    double time;
    if (SLANG_FAILED(_extractProfileTime(actualOutput.getUnownedSlice(), time)))
    {
        return TestResult::Fail;
    }

    context->getTestReporter()->addExecutionTime(time);

    return TestResult::Pass;
}


static double _textToDouble(const UnownedStringSlice& slice)
{
    Index size = Index(slice.getLength());
    // We have to zero terminate to be able to use atof
    const Index maxSize = 80;
    char buffer[maxSize + 1];

    size = (size > maxSize) ? maxSize : size;

    memcpy(buffer, slice.begin(), size);
    buffer[size] = 0;

    return atof(buffer);
}

static void _calcLines(const UnownedStringSlice& slice, List<UnownedStringSlice>& outLines)
{
    StringUtil::calcLines(slice, outLines);

    // Remove any trailing empty lines
    while (outLines.getCount())
    {
        if (outLines.getLast().trim() == UnownedStringSlice())
        {
            outLines.removeLast();
        }
        else
        {
            break;
        }
    }
}

static SlangResult _compareWithType(
    const UnownedStringSlice& actual,
    const UnownedStringSlice& ref,
    double differenceThreshold = 0.0001)
{
    typedef slang::TypeReflection::ScalarType ScalarType;

    ScalarType scalarType = ScalarType::None;

    // We just do straight comparison if there is no type

    List<UnownedStringSlice> linesActual, linesRef;

    _calcLines(actual, linesActual);
    _calcLines(ref, linesRef);

    // If there are more lines in actual, we just ignore them, to keep same behavior as before
    if (linesRef.getCount() < linesActual.getCount())
    {
        linesActual.setCount(linesRef.getCount());
    }

    if (linesActual.getCount() != linesRef.getCount())
    {
        return SLANG_FAIL;
    }

    for (Index i = 0; i < linesActual.getCount(); ++i)
    {
        const UnownedStringSlice lineActual = linesActual[i];
        const UnownedStringSlice lineRef = linesRef[i];

        if (lineActual.startsWith(UnownedStringSlice::fromLiteral("type:")))
        {
            if (lineActual != lineRef)
            {
                return SLANG_FAIL;
            }
            // Get the type
            List<UnownedStringSlice> split;
            StringUtil::split(lineActual, ':', split);

            if (split.getCount() != 2)
            {
                return SLANG_FAIL;
            }

            scalarType = TypeTextUtil::findScalarType(split[1].trim());
            continue;
        }

        switch (scalarType)
        {
        default:
            {
                if (lineActual.trim() != lineRef.trim())
                {
                    return SLANG_FAIL;
                }
                break;
            }
        case ScalarType::Float16:
        case ScalarType::Float32:
        case ScalarType::Float64:
        case ScalarType::BFloat16:
        case ScalarType::FloatE4M3:
        case ScalarType::FloatE5M2:
            {

                // Compare as double
                double valueA = _textToDouble(lineActual);
                double valueB = _textToDouble(lineRef);

                if (!Math::AreNearlyEqual(valueA, valueB, differenceThreshold))
                {
                    return SLANG_FAIL;
                }
                break;
            }
        }
    }

    return SLANG_OK;
}

TestResult runComputeComparisonImpl(
    TestContext* context,
    TestInput& input,
    const char* const* langOpts,
    size_t numLangOpts)
{
    // TODO: delete any existing files at the output path(s) to avoid stale outputs leading to a
    // false pass
    auto filePath999 = input.filePath;
    auto outputStem = input.outputStem;

    CommandLine cmdLine;

    cmdLine.setExecutableLocation(ExecutableLocation(context->options.binDir, "render-test"));
    cmdLine.addArg(filePath999);

    _addRenderTestOptions(context->options, cmdLine, true);

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }

    for (int i = 0; i < int(numLangOpts); ++i)
    {
        cmdLine.addArg(langOpts[i]);
    }
    cmdLine.addArg("-o");
    auto actualOutputFile = outputStem + ".actual.txt";
    cmdLine.addArg(actualOutputFile);
    SlangTest::addDefaultRenderTestSlangOptimization(
        cmdLine,
        context->options.defaultOptimizationLevel);

    if (context->isExecuting())
    {
        // clear the stale actual output file first. This will allow us to detect error if
        // render-test fails and outputs nothing.
        File::writeAllText(actualOutputFile, "");
    }

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    // Check the stdout/stderr from the compiler process
    auto actualOutput = getOutput(exeRes);
    auto compileResult = _validateOutput(
        context,
        input,
        actualOutput,
        false,
        "result code = 0\nstandard error = {\n}\nstandard output = {\n}\n");

    // check against reference output
    String actualOutputContent;
    if (SLANG_FAILED(File::readAllText(actualOutputFile, actualOutputContent)))
    {
        context->getTestReporter()->messageFormat(
            TestMessageType::RunError,
            "Unable to read render-test output: %s\n",
            actualOutput.getBuffer());
        return TestResult::Fail;
    }

    String fileCheckPrefix;
    auto bufferResult =
        input.testOptions->getFileCheckBufferPrefix(fileCheckPrefix)
            ? _fileCheckTest(*context, input.filePath, fileCheckPrefix, actualOutputContent)
            : _fileComparisonTest(
                  *context,
                  input,
                  nullptr,
                  ".expected.txt",
                  actualOutputContent,
                  [](const auto& a, const auto& e) {
                      return SLANG_SUCCEEDED(
                          _compareWithType(a.getUnownedSlice(), e.getUnownedSlice()));
                  });
    return TestReporter::combine(compileResult, bufferResult);
}

TestResult runSlangComputeComparisonTest(TestContext* context, TestInput& input)
{
    const char* langOpts[] = {"-slang", "-compute"};
    return runComputeComparisonImpl(context, input, langOpts, SLANG_COUNT_OF(langOpts));
}

TestResult runSlangComputeComparisonTestEx(TestContext* context, TestInput& input)
{
    return runComputeComparisonImpl(context, input, nullptr, 0);
}

TestResult runHLSLComputeTest(TestContext* context, TestInput& input)
{
    const char* langOpts[] = {"--hlsl-rewrite", "-compute"};
    return runComputeComparisonImpl(context, input, langOpts, SLANG_COUNT_OF(langOpts));
}

TestResult runSlangRenderComputeComparisonTest(TestContext* context, TestInput& input)
{
    const char* langOpts[] = {"-slang", "-gcompute"};
    return runComputeComparisonImpl(context, input, langOpts, SLANG_COUNT_OF(langOpts));
}

TestResult doRenderComparisonTestRun(
    TestContext* context,
    TestInput& input,
    char const* langOption,
    char const* outputKind,
    String* outOutput)
{
    // TODO: delete any existing files at the output path(s) to avoid stale outputs leading to a
    // false pass

    auto filePath = input.filePath;
    auto outputStem = input.outputStem;

    CommandLine cmdLine;

    cmdLine.setExecutableLocation(ExecutableLocation(context->options.binDir, "render-test"));
    cmdLine.addArg(filePath);

    _addRenderTestOptions(context->options, cmdLine, true);

    for (auto arg : input.testOptions->args)
    {
        cmdLine.addArg(arg);
    }

    cmdLine.addArg(langOption);
    cmdLine.addArg("-o");
    cmdLine.addArg(outputStem + outputKind + ".png");
    SlangTest::addDefaultRenderTestSlangOptimization(
        cmdLine,
        context->options.defaultOptimizationLevel);

    ExecuteResult exeRes;
    TEST_RETURN_ON_DONE(spawnAndWait(context, outputStem, input.spawnType, cmdLine, exeRes));

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    ExecuteResult::ResultCode resultCode = exeRes.resultCode;

    String standardOutput = exeRes.standardOutput;
    String standardError = exeRes.standardError;
    String debugLayer = exeRes.debugLayer;

    // We construct a single output string that captures the results
    StringBuilder outputBuilder;
    outputBuilder.append("result code = ");
    outputBuilder.append(resultCode);
    outputBuilder.append("\nstandard error = {\n");
    outputBuilder.append(standardError);
    outputBuilder.append("}\nstandard output = {\n");
    outputBuilder.append(standardOutput);
    outputBuilder.append("}\n");
    if (debugLayer.getLength() > 0)
    {
        outputBuilder.append("debug layer = {\n");
        outputBuilder.append(debugLayer);
        outputBuilder.append("}\n");
    }

    String outputPath = outputStem + outputKind;
    String output = outputBuilder.produceString();

    *outOutput = output;

    // Always fail if the compilation produced a failure.
    if (exeRes.resultCode != 0)
    {
        return TestResult::Fail;
    }
    return TestResult::Pass;
}

class STBImage
{
public:
    typedef STBImage ThisType;

    /// Reset back to default initialized state (frees any image set)
    void reset();
    /// True if rhs has same size and amount of channels
    bool isComparable(const ThisType& rhs) const;

    /// The width in pixels
    int getWidth() const { return m_width; }
    /// The height in pixels
    int getHeight() const { return m_height; }
    /// The number of channels (typically held as bytes in order)
    int getNumChannels() const { return m_numChannels; }

    /// Get the contained pixels, nullptr if nothing loaded
    const unsigned char* getPixels() const { return m_pixels; }
    unsigned char* getPixels() { return m_pixels; }

    /// Read an image with filename. SLANG_OK on success
    SlangResult read(const char* filename);

    ~STBImage() { reset(); }

    int m_width = 0;
    int m_height = 0;
    int m_numChannels = 0;
    unsigned char* m_pixels = nullptr;
};

void STBImage::reset()
{
    if (m_pixels)
    {
        stbi_image_free(m_pixels);
        m_pixels = nullptr;
    }
    m_width = 0;
    m_height = 0;
    m_numChannels = 0;
}

SlangResult STBImage::read(const char* filename)
{
    reset();

    m_pixels = stbi_load(filename, &m_width, &m_height, &m_numChannels, 0);
    if (!m_pixels)
    {
        return SLANG_FAIL;
    }
    return SLANG_OK;
}

bool STBImage::isComparable(const ThisType& rhs) const
{
    return (this == &rhs) || (m_width == rhs.m_width && m_height == rhs.m_height &&
                              m_numChannels == rhs.m_numChannels);
}


TestResult doImageComparison(TestContext* context, String const& filePath)
{
    auto reporter = context->getTestReporter();

    // Allow a difference in the low bits of the 8-bit result, just to play it safe
    static const int kAbsoluteDiffCutoff = 2;

    // Allow a relative 1% difference
    static const float kRelativeDiffCutoff = 0.01f;

    String expectedPath = filePath + ".expected.png";
    String actualPath = filePath + ".actual.png";

    STBImage expectedImage;
    if (SLANG_FAILED(expectedImage.read(expectedPath.getBuffer())))
    {
        reporter->messageFormat(
            TestMessageType::RunError,
            "Unable to load image ;%s'",
            expectedPath.getBuffer());
        return TestResult::Fail;
    }

    STBImage actualImage;
    if (SLANG_FAILED(actualImage.read(actualPath.getBuffer())))
    {
        reporter->messageFormat(
            TestMessageType::RunError,
            "Unable to load image ;%s'",
            actualPath.getBuffer());
        return TestResult::Fail;
    }

    if (!expectedImage.isComparable(actualImage))
    {
        reporter->messageFormat(
            TestMessageType::TestFailure,
            "Images are different sizes '%s' '%s'",
            actualPath.getBuffer(),
            expectedPath.getBuffer());
        return TestResult::Fail;
    }

    {
        const unsigned char* expectedPixels = expectedImage.getPixels();
        const unsigned char* actualPixels = actualImage.getPixels();

        const int height = actualImage.getHeight();
        const int width = actualImage.getWidth();
        const int numChannels = actualImage.getNumChannels();
        const int rowSize = width * numChannels;

        for (int y = 0; y < height; ++y)
        {
            for (int i = 0; i < rowSize; ++i)
            {
                int expectedVal = expectedPixels[i];
                int actualVal = actualPixels[i];

                int absoluteDiff = actualVal - expectedVal;
                if (absoluteDiff < 0)
                    absoluteDiff = -absoluteDiff;

                if (absoluteDiff < kAbsoluteDiffCutoff)
                {
                    // There might be a difference, but we'll consider it to be inside tolerance
                    continue;
                }

                float relativeDiff = 0.0f;
                if (expectedVal != 0)
                {
                    relativeDiff =
                        fabsf(float(actualVal) - float(expectedVal)) / float(expectedVal);

                    if (relativeDiff < kRelativeDiffCutoff)
                    {
                        // relative difference was small enough
                        continue;
                    }
                }

                // TODO: may need to do some local search sorts of things, to deal with
                // cases where vertex shader results lead to rendering that is off
                // by one pixel...

                const int x = i / numChannels;
                const int channelIndex = i % numChannels;

                reporter->messageFormat(
                    TestMessageType::TestFailure,
                    "image compare failure at (%d,%d) channel %d. expected %d got %d (absolute "
                    "error: %d, relative error: %f)\n",
                    x,
                    y,
                    channelIndex,
                    expectedVal,
                    actualVal,
                    absoluteDiff,
                    relativeDiff);

                // There was a difference we couldn't excuse!
                return TestResult::Fail;
            }

            expectedPixels += rowSize;
            actualPixels += rowSize;
        }
    }

    return TestResult::Pass;
}

TestResult runHLSLRenderComparisonTestImpl(
    TestContext* context,
    TestInput& input,
    char const* expectedArg,
    char const* actualArg)
{
    String _fileCheckPrefix;
    if (input.testOptions->getFileCheckPrefix(_fileCheckPrefix))
    {
        context->getTestReporter()->message(
            TestMessageType::RunError,
            "FileCheck testing isn't supported for HLSL render tests");
        return TestResult::Fail;
    }

    auto filePath = input.filePath;
    auto outputStem = input.outputStem;

    String expectedOutput;
    String actualOutput;

    // Run the expected test case only if we're not skipping reference image generation
    TestResult hlslResult = TestResult::Pass;
    if (!context->options.skipReferenceImageGeneration)
    {
        hlslResult =
            doRenderComparisonTestRun(context, input, expectedArg, ".expected", &expectedOutput);
        if (hlslResult != TestResult::Pass)
        {
            return hlslResult;
        }
    }

    // Always run the actual test case
    TestResult slangResult =
        doRenderComparisonTestRun(context, input, actualArg, ".actual", &actualOutput);
    if (slangResult != TestResult::Pass)
    {
        return slangResult;
    }

    if (context->isCollectingRequirements())
    {
        return TestResult::Pass;
    }

    // Save the expected output if we generated it
    if (!context->options.skipReferenceImageGeneration)
    {
        Slang::File::writeAllText(outputStem + ".expected", expectedOutput);
    }

    Slang::File::writeAllText(outputStem + ".actual", actualOutput);

    if (hlslResult == TestResult::Fail)
        return TestResult::Fail;
    if (slangResult == TestResult::Fail)
        return TestResult::Fail;

    // Compare text output only if we generated the expected output
    if (!context->options.skipReferenceImageGeneration && !StringUtil::areLinesEqual(
                                                              actualOutput.getUnownedSlice(),
                                                              expectedOutput.getUnownedSlice()))
    {
        context->getTestReporter()->dumpOutputDifference(expectedOutput, actualOutput);

        return TestResult::Fail;
    }

    // Next do an image comparison on the expected output images!

    TestResult imageCompareResult = doImageComparison(context, outputStem);
    if (imageCompareResult != TestResult::Pass)
        return imageCompareResult;

    return TestResult::Pass;
}

TestResult runHLSLRenderComparisonTest(TestContext* context, TestInput& input)
{
    return runHLSLRenderComparisonTestImpl(context, input, "-hlsl", "-slang");
}

TestResult runHLSLCrossCompileRenderComparisonTest(TestContext* context, TestInput& input)
{
    return runHLSLRenderComparisonTestImpl(context, input, "-slang", "-glsl-cross");
}

TestResult runHLSLAndGLSLRenderComparisonTest(TestContext* context, TestInput& input)
{
    return runHLSLRenderComparisonTestImpl(context, input, "-hlsl-rewrite", "-glsl-rewrite");
}

TestResult skipTest(TestContext* /* context */, TestInput& /*input*/)
{
    return TestResult::Ignored;
}

// ---------------------------------------------------------------------------
// SPVDB_DEBUGGER: compile a .slang file to SPIR-V, then execute debugger
// commands embedded in the source file as "// SPVDB-CMD: ..." comments
// in-process via libspvdb, and validate the output with FileCheck.
//
// Test directive syntax:
//   //TEST:SPVDB_DEBUGGER(filecheck=SPVDB): -entry main -stage compute
//
// The args are forwarded to slangc (after -target spirv -g2 -o <stem>.spv).
// libspvdb is vendored at tests/spvdb and is always linked in when slang-test
// is built (see the SLANG_ENABLE_SPVDB block in tools/CMakeLists.txt).
// ---------------------------------------------------------------------------

#ifdef SLANG_ENABLE_SPVDB
#include "api/spvdb.h"
#include "api/spvdb_session.h"

#include <cstring>
#include <fstream>
#include <sstream>
#include <vector>

// Format a spvdb Value as a human-readable string.
static std::string spvdb_value_str(const spvdb::Value& v)
{
    using Kind = spvdb::Value::Kind;
    switch (v.kind)
    {
    case Kind::Bool:
        return v.scalar.b ? "true" : "false";
    case Kind::Int32:
        return std::to_string(v.scalar.i32);
    case Kind::UInt32:
        return std::to_string(v.scalar.u32);
    case Kind::Int64:
        return std::to_string(v.scalar.i64);
    case Kind::UInt64:
        return std::to_string(v.scalar.u64);
    case Kind::Float32:
        {
            std::ostringstream os;
            os << v.scalar.f32;
            return os.str();
        }
    case Kind::Float64:
        {
            std::ostringstream os;
            os << v.scalar.f64;
            return os.str();
        }
    case Kind::Composite:
        {
            bool named = !v.member_names.empty() && v.member_names.size() == v.elements.size();
            std::string s = named ? "{" : "(";
            for (size_t i = 0; i < v.elements.size(); ++i)
            {
                if (i)
                    s += ", ";
                if (named && !v.member_names[i].empty())
                    s += v.member_names[i] + "=";
                s += spvdb_value_str(v.elements[i]);
            }
            return s + (named ? "}" : ")");
        }
    default:
        return "<complex>";
    }
}

static std::string spvdb_stop_reason_str(spvdb::StopReason r)
{
    using SR = spvdb::StopReason;
    switch (r)
    {
    case SR::Breakpoint:
        return "Breakpoint";
    case SR::Step:
        return "Step";
    case SR::EntryReached:
        return "EntryReached";
    case SR::EntryFinished:
        return "EntryFinished";
    case SR::Panic:
        return "Panic";
    }
    return "Unknown";
}

// Split a line into whitespace-separated tokens.
static std::vector<std::string> spvdb_tokenize(const std::string& line)
{
    std::vector<std::string> tokens;
    std::istringstream ss(line);
    std::string tok;
    while (ss >> tok)
        tokens.push_back(tok);
    return tokens;
}

// Scan a source file for "// SPVDB-CMD: <command>" directives.
static std::vector<std::string> spvdb_extract_commands(const std::string& path)
{
    std::vector<std::string> cmds;
    std::ifstream f(path);
    if (!f.is_open())
        return cmds;
    std::string line;
    while (std::getline(f, line))
    {
        // Strip leading whitespace.
        size_t start = line.find_first_not_of(" \t");
        if (start == std::string::npos)
            continue;
        std::string trimmed = line.substr(start);

        const std::string prefix = "// SPVDB-CMD:";
        if (trimmed.size() < prefix.size())
            continue;
        if (trimmed.compare(0, prefix.size(), prefix) != 0)
            continue;

        std::string cmd = trimmed.substr(prefix.size());
        // Strip leading whitespace from the command itself.
        size_t cs = cmd.find_first_not_of(" \t");
        if (cs != std::string::npos)
            cmds.push_back(cmd.substr(cs));
    }
    return cmds;
}

// Parse `str` as an unsigned 32-bit integer, returning false instead of throwing on
// invalid input (empty string, non-numeric text, or a value that overflows). Directive
// tokens come from `// SPVDB-CMD:` lines in user-authored .slang test files, so a typo
// there must fail that one test gracefully rather than let std::stoul's
// std::invalid_argument/std::out_of_range propagate uncaught and abort the whole
// slang-test process.
static bool spvdb_parse_uint32(const std::string& str, uint32_t* out)
{
    try
    {
        size_t pos = 0;
        unsigned long val = std::stoul(str, &pos);
        if (pos != str.size())
            return false;
        *out = static_cast<uint32_t>(val);
        return true;
    }
    catch (const std::exception&)
    {
        return false;
    }
}

// Parse `str` as a float, returning false instead of throwing on invalid input. See
// spvdb_parse_uint32 for why this must not throw.
static bool spvdb_parse_float(const std::string& str, float* out)
{
    try
    {
        size_t pos = 0;
        float val = std::stof(str, &pos);
        if (pos != str.size())
            return false;
        *out = val;
        return true;
    }
    catch (const std::exception&)
    {
        return false;
    }
}

// Execute a list of SPVDB-CMD directives against a loaded SPIR-V module.
// Returns the collected output as a string suitable for FileCheck validation.
// On error, sets *error_out and returns "".
static std::string spvdb_run_commands(
    const std::string& spv_path,
    const std::vector<std::string>& commands,
    std::string* error_out)
{
    auto mod_result = spvdb::load_module_from_file(spv_path);
    if (!mod_result)
    {
        *error_out = std::string("spvdb: failed to load SPIR-V: ") + spv_path;
        return "";
    }
    auto mod = *mod_result;

    std::string entry_name = "main";
    std::unique_ptr<spvdb::Session> sess;
    std::ostringstream out;

    auto ensure_session = [&]() -> bool
    {
        if (!sess)
        {
            auto r = spvdb::create_session(mod, entry_name);
            if (!r)
            {
                *error_out = std::string("spvdb: create_session failed: ") + r.error().message;
                return false;
            }
            sess = std::move(*r);
        }
        return true;
    };

    for (const auto& cmd_line : commands)
    {
        auto tokens = spvdb_tokenize(cmd_line);
        if (tokens.empty())
            continue;
        const std::string& cmd = tokens[0];

        if (cmd == "entry")
        {
            if (tokens.size() < 2)
            {
                *error_out = "spvdb: entry requires <name>";
                return "";
            }
            entry_name = tokens[1];
            sess.reset();
        }
        else if (cmd == "descriptor")
        {
            if (tokens.size() < 4)
            {
                *error_out = "spvdb: descriptor requires <set> <binding> <json>";
                return "";
            }
            if (!ensure_session())
                return "";
            uint32_t set = 0, binding = 0;
            if (!spvdb_parse_uint32(tokens[1], &set) || !spvdb_parse_uint32(tokens[2], &binding))
            {
                *error_out =
                    "spvdb: descriptor: invalid <set>/<binding>: " + tokens[1] + " " + tokens[2];
                return "";
            }
            std::string json;
            for (size_t i = 3; i < tokens.size(); ++i)
            {
                if (i > 3)
                    json += " ";
                json += tokens[i];
            }
            auto r = spvdb::set_descriptor_json(*sess, set, binding, json);
            if (!r)
            {
                *error_out = std::string("spvdb: set_descriptor_json failed: ") + r.error().message;
                return "";
            }
        }
        else if (cmd == "inputloc")
        {
            // inputloc <location> <json>  — bind a vertex/fragment Input variable by Location.
            if (tokens.size() < 3)
            {
                *error_out = "spvdb: inputloc requires <location> <json>";
                return "";
            }
            if (!ensure_session())
                return "";
            uint32_t loc = 0;
            if (!spvdb_parse_uint32(tokens[1], &loc))
            {
                *error_out = "spvdb: inputloc: invalid <location>: " + tokens[1];
                return "";
            }
            std::string json;
            for (size_t i = 2; i < tokens.size(); ++i)
            {
                if (i > 2)
                    json += " ";
                json += tokens[i];
            }
            auto r = spvdb::set_input_location_json(*sess, loc, json);
            if (!r)
            {
                *error_out =
                    std::string("spvdb: set_input_location_json failed: ") + r.error().message;
                return "";
            }
        }
        else if (cmd == "outputs")
        {
            if (!ensure_session())
                return "";
            auto vars = spvdb::output_variables(*sess);
            for (const auto& lv : vars)
                out << "output: " << lv.name << " = " << spvdb_value_str(lv.value) << "\n";
            if (vars.empty())
                out << "outputs: (none)\n";
        }
        else if (cmd == "break")
        {
            if (tokens.size() < 3)
            {
                *error_out = "spvdb: break requires <file_suffix> <line>";
                return "";
            }
            if (!ensure_session())
                return "";
            std::string file = tokens[1];
            uint32_t line = 0;
            if (!spvdb_parse_uint32(tokens[2], &line))
            {
                *error_out = "spvdb: break: invalid <line>: " + tokens[2];
                return "";
            }
            auto r = spvdb::set_breakpoint(*sess, file, line);
            if (!r)
            {
                *error_out = std::string("spvdb: set_breakpoint failed: ") + r.error().message;
                return "";
            }
        }
        else if (cmd == "run" || cmd == "continue")
        {
            if (!ensure_session())
                return "";
            spvdb::StopReason reason = spvdb::run(*sess);
            out << "stopped: " << spvdb_stop_reason_str(reason);
            if (reason == spvdb::StopReason::Panic)
                out << ": " << spvdb::panic_message(*sess);
            out << "\n";
        }
        else if (cmd == "step")
        {
            if (!ensure_session())
                return "";
            spvdb::StopReason reason = spvdb::step(*sess);
            out << "stopped: " << spvdb_stop_reason_str(reason);
            if (reason == spvdb::StopReason::Panic)
                out << ": " << spvdb::panic_message(*sess);
            out << "\n";
        }
        else if (cmd == "stepi")
        {
            if (!ensure_session())
                return "";
            spvdb::StopReason reason = spvdb::step_instruction(*sess);
            out << "stopped: " << spvdb_stop_reason_str(reason);
            if (reason == spvdb::StopReason::Panic)
                out << ": " << spvdb::panic_message(*sess);
            out << "\n";
        }
        else if (cmd == "next")
        {
            if (!ensure_session())
                return "";
            spvdb::StopReason reason = spvdb::step_over(*sess);
            out << "stopped: " << spvdb_stop_reason_str(reason);
            if (reason == spvdb::StopReason::Panic)
                out << ": " << spvdb::panic_message(*sess);
            out << "\n";
        }
        else if (cmd == "finish")
        {
            if (!ensure_session())
                return "";
            spvdb::StopReason reason = spvdb::step_out(*sess);
            out << "stopped: " << spvdb_stop_reason_str(reason);
            if (reason == spvdb::StopReason::Panic)
                out << ": " << spvdb::panic_message(*sess);
            out << "\n";
        }
        else if (cmd == "print")
        {
            if (tokens.size() < 2)
            {
                *error_out = "spvdb: print requires <name>";
                return "";
            }
            if (!ensure_session())
                return "";
            auto r = spvdb::evaluate_variable(*sess, tokens[1]);
            if (!r)
            {
                *error_out = std::string("spvdb: evaluate_variable failed: ") + r.error().message;
                return "";
            }
            out << "print: " << r->name << " = " << spvdb_value_str(r->value) << "\n";
        }
        else if (cmd == "builtin")
        {
            // builtin <name> <val0> [val1] [val2] [val3]
            if (tokens.size() < 3)
            {
                *error_out = "spvdb: builtin requires <name> <val...>";
                return "";
            }
            if (!ensure_session())
                return "";

            // Map common builtin names to SpvBuiltIn enum values.
            static const struct
            {
                const char* name;
                uint32_t id;
            } kBuiltins[] = {
                {"GlobalInvocationID", SpvBuiltInGlobalInvocationId},
                {"LocalInvocationID", SpvBuiltInLocalInvocationId},
                {"WorkgroupID", SpvBuiltInWorkgroupId},
                {"LocalInvocationIndex", SpvBuiltInLocalInvocationIndex},
                {"VertexIndex", SpvBuiltInVertexIndex},
                {"InstanceIndex", SpvBuiltInInstanceIndex},
                {"Position", SpvBuiltInPosition},
                {"PointSize", SpvBuiltInPointSize},
                {"FragCoord", SpvBuiltInFragCoord},
                {"FrontFacing", SpvBuiltInFrontFacing},
                {"FragDepth", SpvBuiltInFragDepth},
                {"NumWorkgroups", SpvBuiltInNumWorkgroups},
                {"SubgroupSize", SpvBuiltInSubgroupSize},
            };
            uint32_t bi = 0;
            bool found = false;
            for (const auto& kb : kBuiltins)
            {
                if (tokens[1] == kb.name)
                {
                    bi = kb.id;
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                *error_out = std::string("spvdb: unknown builtin: ") + tokens[1];
                return "";
            }

            spvdb::Value bval;
            size_t nvals = tokens.size() - 2; // number of value tokens
            bool parseOk = true;
            if (nvals >= 2)
            {
                // Two, three, or four components — build a composite. (A genuinely
                // scalar builtin only ever supplies one value token; anything with
                // 2+ must be kept as a composite so no component is silently
                // dropped.)
                std::vector<spvdb::Value> elems;
                bool as_float = false;
                for (size_t i = 2; i < tokens.size(); ++i)
                {
                    if (tokens[i].find('.') != std::string::npos)
                    {
                        as_float = true;
                        break;
                    }
                }
                for (size_t i = 2; i < tokens.size() && parseOk; ++i)
                {
                    if (as_float)
                    {
                        float fv = 0.0f;
                        parseOk = spvdb_parse_float(tokens[i], &fv);
                        if (parseOk)
                            elems.push_back(spvdb::Value::make_f32(fv));
                    }
                    else
                    {
                        uint32_t uv = 0;
                        parseOk = spvdb_parse_uint32(tokens[i], &uv);
                        if (parseOk)
                            elems.push_back(spvdb::Value::make_u32(uv));
                    }
                }
                if (parseOk)
                    bval = spvdb::Value::make_composite(std::move(elems));
            }
            else
            {
                // Single scalar — try uint first, then float.
                const std::string& sv = tokens[2];
                if (sv.find('.') != std::string::npos)
                {
                    float fv = 0.0f;
                    parseOk = spvdb_parse_float(sv, &fv);
                    if (parseOk)
                        bval = spvdb::Value::make_f32(fv);
                }
                else
                {
                    uint32_t uv = 0;
                    parseOk = spvdb_parse_uint32(sv, &uv);
                    if (parseOk)
                        bval = spvdb::Value::make_u32(uv);
                }
            }
            if (!parseOk)
            {
                *error_out = "spvdb: builtin: invalid numeric value in: " + cmd_line;
                return "";
            }

            auto r = spvdb::set_builtin(*sess, bi, bval);
            if (!r)
            {
                *error_out = std::string("spvdb: set_builtin failed: ") + r.error().message;
                return "";
            }
        }
        else if (cmd == "location")
        {
            if (!ensure_session())
                return "";
            auto loc = spvdb::current_location(*sess);
            out << "location: " << loc.file << ":" << loc.line << "\n";
        }
        else if (cmd == "locals")
        {
            if (!ensure_session())
                return "";
            auto vars = spvdb::local_variables(*sess);
            for (const auto& lv : vars)
                out << "local: " << lv.name << " = " << spvdb_value_str(lv.value) << "\n";
            if (vars.empty())
                out << "locals: (none)\n";
        }
        else if (cmd == "backtrace")
        {
            if (!ensure_session())
                return "";
            auto bt = spvdb::backtrace(*sess);
            for (size_t i = 0; i < bt.size(); ++i)
            {
                out << "frame[" << i << "]: " << bt[i].function_name << " at " << bt[i].loc.file
                    << ":" << bt[i].loc.line << "\n";
            }
            if (bt.empty())
                out << "backtrace: (empty)\n";
        }
        else if (cmd == "read")
        {
            if (tokens.size() < 3)
            {
                *error_out = "spvdb: read requires <set> <binding>";
                return "";
            }
            if (!ensure_session())
                return "";
            uint32_t set = 0, binding = 0;
            if (!spvdb_parse_uint32(tokens[1], &set) || !spvdb_parse_uint32(tokens[2], &binding))
            {
                *error_out = "spvdb: read: invalid <set>/<binding>: " + tokens[1] + " " + tokens[2];
                return "";
            }
            auto r = spvdb::read_descriptor(*sess, set, binding);
            if (!r)
            {
                *error_out = std::string("spvdb: read_descriptor failed: ") + r.error().message;
                return "";
            }
            const auto& bytes = *r;
            size_t n_u32 = bytes.size() / sizeof(uint32_t);
            out << "read[" << set << "][" << binding << "]: [";
            for (size_t i = 0; i < n_u32; ++i)
            {
                if (i)
                    out << ", ";
                uint32_t val;
                std::memcpy(&val, bytes.data() + i * sizeof(uint32_t), sizeof(uint32_t));
                out << val;
            }
            out << "]\n";
        }
        else
        {
            *error_out = std::string("spvdb: unknown command: ") + cmd;
            return "";
        }
    }

    return out.str();
}
#endif // SLANG_ENABLE_SPVDB

TestResult runSpvdbDebuggerTest(TestContext* context, TestInput& input)
{
    if (context->isCollectingRequirements())
        return TestResult::Pass;

#ifndef SLANG_ENABLE_SPVDB
    // libspvdb not linked in this build of slang-test (see the
    // SLANG_ENABLE_SPVDB block in tools/CMakeLists.txt).
    auto reporter = context->getTestReporter();
    if (reporter)
        reporter->message(
            TestMessageType::Info,
            "SPVDB_DEBUGGER test skipped: spvdb not available in this slang-test build");
    return TestResult::Ignored;
#else
    auto outputStem = input.outputStem;
    String spvPath = outputStem + ".spvdb.spv";

    // --- Step 1: compile the source file to SPIR-V with debug info ---
    {
        CommandLine slangcCmdLine;
        slangcCmdLine.setExecutableLocation(ExecutableLocation(context->options.binDir, "slangc"));
        slangcCmdLine.addArg(input.filePath);
        slangcCmdLine.addArg("-target");
        slangcCmdLine.addArg("spirv");
        slangcCmdLine.addArg("-g2");
        slangcCmdLine.addArg("-o");
        slangcCmdLine.addArg(spvPath);

        for (auto arg : input.testOptions->args)
            slangcCmdLine.addArg(arg);

        SlangTest::addDefaultSlangOptimization(
            slangcCmdLine,
            context->options.defaultOptimizationLevel);

        ExecuteResult slangcRes;
        TEST_RETURN_ON_DONE(
            spawnAndWait(context, outputStem, SpawnType::UseExe, slangcCmdLine, slangcRes));

        if (slangcRes.resultCode != 0)
        {
            auto reporter = context->getTestReporter();
            if (reporter)
                reporter->message(
                    TestMessageType::TestFailure,
                    String("slangc failed:\n") + getOutput(slangcRes));
            return TestResult::Fail;
        }
    }

    // --- Step 2: run SPVDB-CMD directives in-process via libspvdb ---
    String actualOutput;
    {
        std::string sourcePath(input.filePath.getBuffer());
        std::string spvPathStd(spvPath.getBuffer());

        auto commands = spvdb_extract_commands(sourcePath);
        if (commands.empty())
        {
            auto reporter = context->getTestReporter();
            if (reporter)
                reporter->message(
                    TestMessageType::TestFailure,
                    String("spvdb: no SPVDB-CMD directives found in: ") + input.filePath);
            return TestResult::Fail;
        }

        std::string error;
        std::string output = spvdb_run_commands(spvPathStd, commands, &error);
        if (!error.empty())
        {
            auto reporter = context->getTestReporter();
            if (reporter)
                reporter->message(TestMessageType::TestFailure, error.c_str());
            return TestResult::Fail;
        }
        actualOutput = output.c_str();
    }

    // --- Step 3: validate output via FileCheck / comparison ---
    return _validateOutput(context, input, actualOutput);
#endif // SLANG_ENABLE_SPVDB
}

// based on command name, dispatch to an appropriate callback
struct TestCommandInfo
{
    char const* name;
    TestCallback callback;
    RenderApiFlags requiredRenderApiFlags; ///< An RenderApi types that are needed to run the tests
};

static const TestCommandInfo s_testCommandInfos[] = {
    {"SIMPLE", &runSimpleTest, 0},
    {"SIMPLE_EX", &runSimpleTest, 0},
    {"SIMPLE_LINE", &runSimpleLineTest, 0},
    {"INTERPRET", &runInterpreterTest, 0},
    {"DISPATCHER", &runDispatcherTest, 0},
    {"REFLECTION", &runReflectionTest, 0},
    {"CPU_REFLECTION", &runReflectionTest, 0},
    {"COMMAND_LINE_SIMPLE", &runSimpleCompareCommandLineTest, 0},
    {"COMPARE_HLSL", &runDXBCComparisonTest, 0},
    {"COMPARE_DXIL", &runDXILComparisonTest, 0},
    {"COMPARE_HLSL_RENDER", &runHLSLRenderComparisonTest, 0},
    {"COMPARE_HLSL_CROSS_COMPILE_RENDER", &runHLSLCrossCompileRenderComparisonTest, 0},
    {"COMPARE_HLSL_GLSL_RENDER", &runHLSLAndGLSLRenderComparisonTest, 0},
    {"COMPARE_COMPUTE", &runSlangComputeComparisonTest, 0},
    {"COMPARE_COMPUTE_EX", &runSlangComputeComparisonTestEx, 0},
    {"HLSL_COMPUTE", &runHLSLComputeTest, 0},
    {"COMPARE_RENDER_COMPUTE", &runSlangRenderComputeComparisonTest, 0},
    {"COMPARE_GLSL", &runGLSLComparisonTest, 0},
    {"CROSS_COMPILE", &runCrossCompilerTest, 0},
    {"CPP_COMPILER_EXECUTE", &runCPPCompilerExecute, RenderApiFlag::CPU},
    {"CPP_COMPILER_SHARED_LIBRARY", &runCPPCompilerSharedLibrary, RenderApiFlag::CPU},
    {"CPP_COMPILER_COMPILE", &runCPPCompilerCompile, RenderApiFlag::CPU},
    {"PERFORMANCE_PROFILE", &runPerformanceProfile, 0},
    {"COMPILE", &runCompile, 0},
    {"COMPILE_TARGET", &runCompileTarget, 0},
    {"DOC", &runDocTest, 0},
    {"LANG_SERVER", &runLanguageServerTest, 0},
    {"EXECUTABLE", &runExecutableTest, RenderApiFlag::CPU},
    {"SPVDB_DEBUGGER", &runSpvdbDebuggerTest, 0}};

const TestCommandInfo* _findTestCommandInfoByCommand(const UnownedStringSlice& name)
{
    for (const auto& command : s_testCommandInfos)
    {
        if (name == command.name)
        {
            return &command;
        }
    }
    return nullptr;
}

static RenderApiFlags _getRequiredRenderApisByCommand(const UnownedStringSlice& name)
{
    auto info = _findTestCommandInfoByCommand(name);
    return info ? info->requiredRenderApiFlags : 0;
}

TestResult runTest(
    TestContext* context,
    String const& filePath,
    String const& outputStem,
    String const& testName,
    TestOptions const& testOptions)
{
    // Diagnostic tests validate front-end diagnostics that slangc emits before any backend
    // runs, so they normally need no backend and run everywhere. The exception is
    // `-emit-cpu-via-llvm`, which forces the slang-llvm backend before the diagnostic is
    // reached; capture that here too. This branch returns before the general
    // `_extractSlangCTestRequirements` path runs, so the two checks stay disjoint.
    if (context->isCollectingRequirements() && testOptions.type == TestOptions::Diagnostic)
    {
        if (_hasOption(testOptions.args, "-emit-cpu-via-llvm"))
        {
            context->getTestRequirements()->addUsedBackEnd(SLANG_PASS_THROUGH_LLVM);
        }
        return TestResult::Pass;
    }

    auto testInfo = _findTestCommandInfoByCommand(testOptions.command.getUnownedSlice());

    if (testInfo)
    {
        TestInput testInput;
        testInput.filePath = filePath;
        testInput.outputStem = outputStem;
        testInput.testOptions = &testOptions;
        testInput.spawnType = context->options.defaultSpawnType;

        return testInfo->callback(context, testInput);
    }

    // No actual test runner found!
    return TestResult::Fail;
}

bool testCategoryMatches(TestCategory* sub, TestCategory* sup)
{
    auto ss = sub;
    while (ss)
    {
        if (ss == sup)
            return true;

        ss = ss->parent;
    }
    return false;
}

bool testCategoryMatches(
    TestCategory* categoryToMatch,
    const Dictionary<TestCategory*, TestCategory*>& categorySet)
{
    for (const auto& [_, category] : categorySet)
    {
        if (testCategoryMatches(categoryToMatch, category))
            return true;
    }
    return false;
}

bool testPassesCategoryMask(TestContext* context, TestOptions const& test)
{
    // Don't include a test we should filter out
    for (auto testCategory : test.categories)
    {
        if (testCategoryMatches(testCategory, context->options.excludeCategories))
            return false;
    }

    // Otherwise include any test the user asked for
    for (auto testCategory : test.categories)
    {
        if (testCategoryMatches(testCategory, context->options.includeCategories))
            return true;
    }

    // skip by default
    return false;
}

static void _calcSynthesizedTests(
    TestContext* context,
    RenderApiType synthRenderApiType,
    const List<TestDetails>& srcTests,
    List<TestDetails>& ioSynthTests)
{
    // Add the explicit parameter
    for (const auto& srcTest : srcTests)
    {
        const auto& requirements = srcTest.requirements;

        // Render tests use renderApis...
        // If it's an explicit test, we don't synth from it now

        // In the case of CUDA, we can only synth from a CPU source
        if (synthRenderApiType == RenderApiType::CUDA)
        {
            if (requirements.explicitRenderApi != RenderApiType::CPU)
            {
                continue;
            }

            // If the source language is defined, and it's

            const Index index = srcTest.options.args.indexOf("-source-language");
            if (index >= 0)
            {
                //
                const auto& language = srcTest.options.args[index + 1];
                SlangSourceLanguage sourceLanguage =
                    TypeTextUtil::findSourceLanguage(language.getUnownedSlice());

                bool isCrossCompile = true;

                switch (sourceLanguage)
                {
                case SLANG_SOURCE_LANGUAGE_GLSL:
                case SLANG_SOURCE_LANGUAGE_C:
                case SLANG_SOURCE_LANGUAGE_CPP:
                    {
                        isCrossCompile = false;
                    }
                default:
                    break;
                }

                if (!isCrossCompile)
                {
                    continue;
                }
            }
        }
        else
        {
            // TODO(JS): Arguably we should synthesize from explicit tests. In principal we can
            // remove the explicit api apply another although that may not always work. If it
            // doesn't use any render API or only uses CPU, we don't synthesize
            if (requirements.usedRenderApiFlags == 0 ||
                requirements.usedRenderApiFlags == RenderApiFlag::CPU ||
                requirements.explicitRenderApi != RenderApiType::Unknown)
            {
                continue;
            }
        }

        TestDetails synthTestDetails(srcTest.options);
        TestOptions& synthOptions = synthTestDetails.options;

        // If there's a category associated with this render api, add it to the synthesized test
        if (auto c = context->categorySet.find(RenderApiUtil::getApiName(synthRenderApiType)))
        {
            synthOptions.categories.add(c);
        }

        // Mark as synthesized
        synthOptions.isSynthesized = true;

        StringBuilder builder;
        builder << "-";
        builder << RenderApiUtil::getApiName(synthRenderApiType);

        synthOptions.args.add(builder);

        // If the target is vulkan remove the -hlsl option
        if (synthRenderApiType == RenderApiType::Vulkan)
        {
            const Index index = synthOptions.args.indexOf("-hlsl");
            if (index >= 0)
            {
                synthOptions.args.removeAt(index);
            }
        }
        else if (synthRenderApiType == RenderApiType::CUDA)
        {
            const Index index = synthOptions.args.indexOf("-cpu");
            if (index >= 0)
            {
                synthOptions.args.removeAt(index);
            }
        }

        // Work out the info about this tests
        context->setTestRequirements(&synthTestDetails.requirements);
        runTest(context, "", "", "", synthOptions);
        context->setTestRequirements(nullptr);

        // It does set the explicit render target
        SLANG_ASSERT(synthTestDetails.requirements.explicitRenderApi == synthRenderApiType);
        // Add to the tests
        ioSynthTests.add(synthTestDetails);
    }
}

static bool _isGpuComputeCommand(const String& command)
{
    return command == "COMPARE_COMPUTE" || command == "COMPARE_COMPUTE_EX" ||
           command == "COMPARE_RENDER_COMPUTE" || command == "HLSL_COMPUTE";
}

static RenderApiType _getRenderApiFromArgs(const List<String>& args)
{
    for (const auto& arg : args)
    {
        if (arg.getLength() > 1 && arg[0] == '-')
        {
            UnownedStringSlice name(arg.getUnownedSlice().begin() + 1, arg.getUnownedSlice().end());
            RenderApiType apiType = RenderApiUtil::findApiTypeByName(name);
            if (apiType != RenderApiType::Unknown)
                return apiType;
        }
    }
    return RenderApiType::Unknown;
}

static void _calcSynthesizedCompileTargetTests(
    TestContext* context,
    const String& filePath,
    const List<TestDetails>& srcTests,
    List<TestDetails>& ioSynthTests)
{
    SLANG_UNUSED(filePath);

    HashSet<String> synthesizedKeys;

    for (const auto& srcTest : srcTests)
    {
        if (!srcTest.options.isEnabled || srcTest.options.isSynthesized ||
            !_isGpuComputeCommand(srcTest.options.command))
            continue;

        RenderApiType renderApi = _getRenderApiFromArgs(srcTest.options.args);
        if (renderApi == RenderApiType::Unknown)
            continue;

        StringBuilder keyBuilder;
        keyBuilder << RenderApiUtil::getApiName(renderApi) << "|" << srcTest.options.command;
        String synthKey = keyBuilder.produceString();
        if (synthesizedKeys.contains(synthKey))
            continue;

        TestDetails synthDetails;
        TestOptions& synthOptions = synthDetails.options;
        synthOptions.command = "COMPILE_TARGET";
        synthOptions.isSynthesized = true;

        if (auto c = context->categorySet.find("compile-target"))
        {
            synthOptions.categories.add(c);
        }

        synthOptions.args = srcTest.options.args;

        // Add the implicit args that each command handler normally appends.
        // COMPARE_COMPUTE_EX adds no implicit args (passes nullptr, 0 to
        // runComputeComparisonImpl), so no branch is needed for it.
        if (srcTest.options.command == "COMPARE_COMPUTE")
        {
            synthOptions.args.add("-slang");
            synthOptions.args.add("-compute");
        }
        else if (srcTest.options.command == "COMPARE_RENDER_COMPUTE")
        {
            synthOptions.args.add("-slang");
            synthOptions.args.add("-gcompute");
        }
        else if (srcTest.options.command == "HLSL_COMPUTE")
        {
            synthOptions.args.add("--hlsl-rewrite");
            synthOptions.args.add("-compute");
        }

        context->setTestRequirements(&synthDetails.requirements);
        runTest(context, "", "", "", synthOptions);
        context->setTestRequirements(nullptr);

        ioSynthTests.add(synthDetails);
        synthesizedKeys.add(synthKey);
    }
}

static bool _canIgnore(TestContext* context, const TestDetails& details)
{
    if (details.options.isEnabled == false)
    {
        return true;
    }

    const auto& requirements = details.requirements;

    // Check if it's possible in principal to run this test with the render api flags used by this
    // test
    if (!context->canRunTestWithRenderApiFlags(requirements.usedRenderApiFlags))
    {
        return true;
    }

    // Are all the required backends available?
    if (((requirements.usedBackendFlags & context->availableBackendFlags) !=
         requirements.usedBackendFlags))
    {
        return true;
    }

    // If there are no render API requirements, then we don't need to ignore.
    if (requirements.usedRenderApiFlags == 0)
    {
        return false;
    }

    // Work out what render api flags are actually available, lazily
    const RenderApiFlags availableRenderApiFlags =
        requirements.usedRenderApiFlags ? _getAvailableRenderApiFlags(context) : 0;

    // Are all the required rendering apis available?
    if ((requirements.usedRenderApiFlags & availableRenderApiFlags) !=
        requirements.usedRenderApiFlags)
    {
        return true;
    }

    return false;
}

// Insert a subtest index into a test name, after the file path but before any suffix.
// e.g., "foo.slang (vk)" with index 0 -> "foo.slang.0 (vk)"
static String insertSubtestIndex(const String& testName, int index)
{
    Index spacePos = testName.indexOf(' ');
    StringBuilder result;
    if (spacePos >= 0)
    {
        result << testName.subString(0, spacePos) << "." << index
               << testName.subString(spacePos, testName.getLength() - spacePos);
    }
    else
    {
        result << testName << "." << index;
    }
    return result.produceString();
}

// Check if a prefix specifies a subtest index (e.g., "foo.slang.1" or "foo.slang.0")
// Returns the subtest index if found, or -1 if not a subtest prefix.
static SlangResult _runTestsOnFile(TestContext* context, String filePath)
{
    // Gather a list of tests to run
    FileTestList testList;

    SLANG_RETURN_ON_FAIL(_gatherTestsForFile(&context->categorySet, filePath, &testList, context));

    if (testList.tests.getCount() == 0)
    {
        // Test was explicitly ignored
        return SLANG_OK;
    }

    // Note cases where a test file exists, but we found nothing to run
    if (testList.tests.getCount() == 0)
    {
        context->getTestReporter()->addTest(filePath, TestResult::Ignored);
        return SLANG_OK;
    }

    RenderApiFlags apiUsedFlags = 0;
    RenderApiFlags explictUsedApiFlags = 0;

    {
        // We can get the test info for each of them
        for (auto& testDetails : testList.tests)
        {
            auto& requirements = testDetails.requirements;

            // Collect what the test needs (by setting restRequirements the test isn't actually run)
            context->setTestRequirements(&requirements);
            runTest(context, filePath, filePath, filePath, testDetails.options);


            apiUsedFlags |= requirements.usedRenderApiFlags;
            explictUsedApiFlags |= (requirements.explicitRenderApi != RenderApiType::Unknown)
                                       ? (RenderApiFlags(1) << int(requirements.explicitRenderApi))
                                       : 0;
        }
        context->setTestRequirements(nullptr);
    }

    SLANG_ASSERT((apiUsedFlags & explictUsedApiFlags) == explictUsedApiFlags);

    // If synthesized tests are wanted look into adding them
    // We synthesize for all configured APIs, not just available ones - _canIgnore will
    // report unavailable ones as "Ignored" so users see why a test didn't run.
    if (context->options.synthesizedTestApis)
    {
        List<TestDetails> synthesizedTests;

        // What render options do we want to synthesize
        RenderApiFlags missingApis = (~apiUsedFlags) & context->options.synthesizedTestApis;

        // const Index numInitialTests = testList.tests.getCount();

        while (missingApis)
        {
            const int index = ByteEncodeUtil::calcMsb8(missingApis);
            SLANG_ASSERT(index >= 0 && index <= int(RenderApiType::CountOf));

            const RenderApiType synthRenderApiType = RenderApiType(index);

            _calcSynthesizedTests(context, synthRenderApiType, testList.tests, synthesizedTests);

            // Disable the bit
            missingApis &= ~(RenderApiFlags(1) << index);
        }

        // Add all the synthesized tests
        testList.tests.addRange(synthesizedTests);
    }

    if (context->options.synthesizeCompileTargets)
    {
        List<TestDetails> compileTargetTests;
        _calcSynthesizedCompileTargetTests(context, filePath, testList.tests, compileTargetTests);
        testList.tests.addRange(compileTargetTests);
    }

    // If explicit test order is requested, reorder subtests by prefix order
    List<Index> testOrder;
    for (Index i = 0; i < testList.tests.getCount(); i++)
        testOrder.add(i);

    if (context->options.explicitTestOrder && context->options.testPrefixes.getCount() > 0)
    {
        auto& prefixes = context->options.testPrefixes;
        auto getTestPrefixIndex = [&](Index testIdx) -> Index
        {
            // Build the outputStem for this test
            StringBuilder stem;
            stem << filePath;
            if (testIdx != 0)
                stem << "." << testIdx;
            String outputStem = stem.produceString();

            for (Index i = 0; i < prefixes.getCount(); i++)
            {
                // Check if prefix matches this specific subtest
                if (TestToolUtil::entryMatchesSubtest(prefixes[i], filePath, outputStem, testIdx))
                    return i;
            }
            return prefixes.getCount();
        };

        std::stable_sort(
            testOrder.begin(),
            testOrder.end(),
            [&](Index a, Index b) { return getTestPrefixIndex(a) < getTestPrefixIndex(b); });
    }

    // We have found a test to run!
    for (Index orderIdx = 0; orderIdx < testOrder.getCount(); orderIdx++)
    {
        // Stop scheduling new tests if too many consecutive failures suggest a systemic issue.
        if (context->stopSchedulingTests.load())
            return SLANG_OK;

        Index subTestIndex = testOrder[orderIdx];
        auto& testDetails = testList.tests[subTestIndex];

        // When -only-synthesized is set, only run synthesized compile-target tests
        if (context->options.onlySynthesized &&
            !(testDetails.options.isSynthesized && testDetails.options.command == "COMPILE_TARGET"))
        {
            continue;
        }

        // Check that the test passes our current category mask
        if (!testPassesCategoryMask(context, testDetails.options))
        {
            continue;
        }

        // Work out the test stem

        StringBuilder outputStem;
        outputStem << filePath;
        if (subTestIndex != 0)
        {
            outputStem << "." << subTestIndex;
        }

        // Work out the test name - taking into account render api / if synthesized
        StringBuilder testName(outputStem);

        if (testDetails.options.isSynthesized)
        {
            testName << " syn";
        }

        const auto& requirements = testDetails.requirements;

        // For synthesized compile-target tests, show the render API name
        if (testDetails.options.isSynthesized && testDetails.options.command == "COMPILE_TARGET")
        {
            RenderApiType renderApi = _getRenderApiFromArgs(testDetails.options.args);
            if (renderApi != RenderApiType::Unknown)
            {
                testName << " (" << RenderApiUtil::getApiName(renderApi) << ")";
            }
        }

        // Display list of used apis on render test
        if (requirements.usedRenderApiFlags)
        {
            RenderApiFlags usedFlags = requirements.usedRenderApiFlags;
            testName << " (";
            bool isPrev = false;
            while (usedFlags)
            {
                const int index = ByteEncodeUtil::calcMsb8(usedFlags);
                const RenderApiType renderApiType = RenderApiType(index);
                if (isPrev)
                {
                    testName << ",";
                }
                testName << RenderApiUtil::getApiName(renderApiType);

                // Disable bit
                usedFlags &= ~(RenderApiFlags(1) << index);
                isPrev = true;
            }
            testName << ")";
        }

        // Per-subtest exclusion, and it has to happen HERE rather than in
        // shouldRunTest(): that runs before subtests are expanded, so it can
        // only see the source path. A synthesized variant such as
        // `tests/compute/parameter-block.slang.6 syn (llvm)` can crash the
        // worker outright, which also rules out -expected-failure-list —
        // that reclassifies a result only after the test returns, and this
        // one never does. The skip must be pre-dispatch, so it is.
        if (TestToolUtil::isSubtestExcluded(
                context->options.excludePrefixes,
                context->options.skipList,
                filePath,
                outputStem,
                subTestIndex))
        {
            if (context->options.verbosity >= VerbosityLevel::Info)
            {
                StringBuilder msg;
                msg << "skipping excluded subtest: " << testName;
                context->getTestReporter()->message(TestMessageType::Info, msg.produceString());
            }
            continue;
        }

        // Check if any prefix is more specific than the file path (has subtest index).
        // If so, filter to only run tests whose outputStem matches the prefix.
        if (context->options.testPrefixes.getCount() > 0)
        {
            bool matchesSpecificPrefix = false;
            bool hasSpecificPrefix = false;

            for (auto& p : context->options.testPrefixes)
            {
                // Two separate questions, and only the second is the shared
                // matching rule: whether the entry NAMES a subtest at all
                // (which arms the filter), and whether it matches THIS one.
                if (TestToolUtil::getSubtestIndex(p, filePath) >= 0)
                {
                    hasSpecificPrefix = true;
                }
                if (TestToolUtil::entryMatchesSubtest(p, filePath, outputStem, subTestIndex))
                {
                    matchesSpecificPrefix = true;
                    break;
                }
            }

            if (hasSpecificPrefix && !matchesSpecificPrefix)
            {
                continue;
            }
        }

        // In dry-run mode, just print the test name without running
        if (context->options.dryRun)
        {
            // For the first test, show .0 suffix only if there are multiple tests
            // so users know what to type to select just this test
            if (subTestIndex == 0 && testList.tests.getCount() > 1)
            {
                printf("%s\n", insertSubtestIndex(testName, 0).getBuffer());
            }
            else
            {
                printf("%s\n", testName.getBuffer());
            }
            continue;
        }

        // Report the test and run/ignore
        {
            TestReporter::TestScope scope(context->getTestReporter(), testName);

            TestResult testResult = TestResult::Fail;

            // If this test can be ignored
            if (_canIgnore(context, testDetails))
            {
                testResult = TestResult::Ignored;
                context->getTestReporter()->addResult(testResult);
            }
            else
            {
                testResult = runTest(context, filePath, outputStem, testName, testDetails.options);
                if (testResult == TestResult::Fail && !context->options.disableRetries &&
                    !context->getTestReporter()->isExpectedFailure(testName))
                {
                    RefPtr<FileTestInfoImpl> fileTestInfo = new FileTestInfoImpl();
                    fileTestInfo->filePath = filePath;
                    fileTestInfo->testName = testName;
                    fileTestInfo->outputStem = outputStem;
                    fileTestInfo->options = testDetails.options;

                    std::lock_guard lock(context->mutexFailedTests);
                    context->failedFileTests.add(fileTestInfo);

                    // Mark test as pending retry - it won't be counted in statistics yet
                    context->getTestReporter()->addResult(TestResult::PendingRetry);
                }
                else
                {
                    context->getTestReporter()->addResult(testResult);
                }

                // Track consecutive failures for early abort on systemic issues
                if (testResult == TestResult::Fail || testResult == TestResult::PendingRetry)
                    context->reportTestFailure();
                else if (testResult == TestResult::Pass)
                    context->reportTestPass();
            }
        }
    }

    return SLANG_OK;
}


static bool endsWithAllowedExtension(TestContext* /*context*/, String filePath)
{
    char const* allowedExtensions[] = {
        ".slang.md", ".slang", ".hlsl", ".fx",   ".glsl",     ".vert", ".frag",
        ".geom",     ".tesc",  ".tese", ".comp", ".internal", ".ahit", ".chit",
        ".miss",     ".rgen",  ".c",    ".cpp",  ".cu",
    };

    for (auto allowedExtension : allowedExtensions)
    {
        if (filePath.endsWith(allowedExtension))
            return true;
    }

    return false;
}

static bool shouldRunTest(TestContext* context, String filePath)
{
    if (!endsWithAllowedExtension(context, filePath))
        return false;

    // Check exclude prefixes first - if any match, skip the test
    for (auto& excludePrefix : context->options.excludePrefixes)
    {
        if (filePath.startsWith(excludePrefix))
        {
            if (context->options.verbosity == VerbosityLevel::Verbose)
            {
                context->getTestReporter()->messageFormat(
                    TestMessageType::Info,
                    "%s file is excluded from the test because it is found from the exclusion "
                    "list\n",
                    filePath.getBuffer());
            }
            return false;
        }
    }

    // Check skip list - if any entry matches, skip the test
    for (auto& skipEntry : context->options.skipList)
    {
        if (filePath.startsWith(skipEntry))
        {
            if (context->options.verbosity == VerbosityLevel::Verbose)
            {
                context->getTestReporter()->messageFormat(
                    TestMessageType::Info,
                    "%s file is skipped because it is found in the skip list\n",
                    filePath.getBuffer());
            }
            return false;
        }
    }

    if (!context->options.testPrefixes.getCount())
    {
        return true;
    }

    // If we have prefixes, it has to match one of them
    for (auto& p : context->options.testPrefixes)
    {
        if (filePath.startsWith(p))
        {
            return true;
        }
        // Also match if the prefix specifies a subtest index
        // (e.g., prefix "foo.slang.1" should include file "foo.slang")
        if (TestToolUtil::getSubtestIndex(p, filePath) >= 0)
        {
            return true;
        }
    }
    return false;
}

void getFilesInDirectory(String directoryPath, List<String>& files)
{
    {
        List<String> localFiles;
        DirectoryUtil::findFiles(directoryPath, localFiles);
        files.addRange(localFiles);
    }
    {
        List<String> subDirs;
        DirectoryUtil::findDirectories(directoryPath, subDirs);
        for (auto subDir : subDirs)
        {
            getFilesInDirectory(subDir, files);
        }
    }
}

template<typename F>
void runTestsInParallel(TestContext* context, int count, const F& f)
{
    auto originalReporter = context->getTestReporter();

    // Pre-create test-server processes sequentially to avoid concurrent fork() issues.
    // This eliminates the thundering herd problem when all threads start simultaneously.
    if (context->options.defaultSpawnType == SpawnType::UseTestServer ||
        context->options.defaultSpawnType == SpawnType::UseFullyIsolatedTestServer)
    {
        for (int threadId = 0; threadId < context->options.serverCount; threadId++)
        {
            context->setThreadIndex(threadId);
            context->getOrCreateJSONRPCConnection();
        }
    }

    std::atomic<int> consumePtr;
    consumePtr = 0;
    auto threadFunc = [&](int threadId)
    {
        TestReporter reporter;
        reporter.init(context->options, true);
        TestReporter::SuiteScope suiteScope(&reporter, "tests");
        context->setThreadIndex(threadId);
        context->setTestReporter(&reporter);
        do
        {
            if (context->stopSchedulingTests.load())
                break;
            int index = consumePtr.fetch_add(1);
            if (index >= count)
                break;
            f(index);
        } while (true);
        {
            std::lock_guard<std::mutex> lock(context->mutex);
            originalReporter->consolidateWith(&reporter);
        }
        context->setTestReporter(nullptr);
    };
    List<std::thread> threads;
    for (int threadId = 0; threadId < context->options.serverCount; threadId++)
    {
        threads.add(std::thread(threadFunc, threadId));
    }
    for (auto& t : threads)
        t.join();
    context->setTestReporter(originalReporter);
}

void runTestsInDirectory(TestContext* context)
{
    List<String> files;
    getFilesInDirectory(context->options.testDir, files);

    // Also add any test prefixes that point to actual files outside the test directory
    for (const auto& testPrefix : context->options.testPrefixes)
    {
        if (File::exists(testPrefix))
        {
            // Avoid duplicates - only add if not already in the list
            if (files.indexOf(testPrefix) == Index(-1))
            {
                files.add(testPrefix);
            }
        }
    }

    // NTFS on Windows stores files in sorted order but not on Linux/Macos.
    // Because of that, the testing on Linux/Macos were randomly failing, which
    // is a good thing because it reveals problems. But it is useless
    // if we cannot reproduce the failures deterministically.
    // https://github.com/shader-slang/slang/issues/7388

    files.sort();

    // If asked, shuffle the list using seed for deterministic behavior.
    if (context->options.shuffleTests)
    {
        std::mt19937 mt(context->options.shuffleSeed);
        std::shuffle(files.begin(), files.end(), mt);
    }

    // If explicit test order is requested, reorder tests by the order of their matching prefixes.
    // Tests matching the same prefix maintain alphabetical order (from the sort above).
    // Tests not matching any prefix appear at the end in alphabetical order.
    if (context->options.explicitTestOrder && context->options.testPrefixes.getCount() > 0)
    {
        auto& prefixes = context->options.testPrefixes;
        auto getPrefixIndex = [&](const String& filePath) -> Index
        {
            for (Index i = 0; i < prefixes.getCount(); i++)
            {
                if (filePath.startsWith(prefixes[i]))
                {
                    return i;
                }
                // Also match subtest prefixes (e.g., "foo.slang.1" matches file "foo.slang")
                if (TestToolUtil::getSubtestIndex(prefixes[i], filePath) >= 0)
                {
                    return i;
                }
            }
            return prefixes.getCount(); // No match - put at end
        };

        // Use stable sort to preserve alphabetical order within same prefix
        std::stable_sort(
            files.begin(),
            files.end(),
            [&](const String& a, const String& b)
            { return getPrefixIndex(a) < getPrefixIndex(b); });
    }

    auto processFile = [&](String file)
    {
        if (shouldRunTest(context, file))
        {
            SlangResult result = _runTestsOnFile(context, file);
            if (SLANG_FAILED(result))
            {
                {
                    TestReporter::TestScope scope(context->getTestReporter(), file);
                    context->getTestReporter()->messageFormat(
                        TestMessageType::RunError,
                        "slang-test: unable to parse test (error code: 0x%08X)",
                        (unsigned int)result);

                    context->getTestReporter()->addResult(TestResult::Fail);
                }

                // Output there was some kind of error trying to run the tests on this file
                // fprintf(stderr, "slang-test: unable to parse test '%s'\n", file.getBuffer());
            }
        }
    };
    bool useMultiThread = false;
    switch (context->options.defaultSpawnType)
    {
    case SpawnType::UseFullyIsolatedTestServer:
    case SpawnType::UseTestServer:
        useMultiThread = true;
        break;
    }
    if (context->options.serverCount == 1)
    {
        useMultiThread = false;
    }
    if (!useMultiThread)
    {
        for (auto file : files)
        {
            processFile(file);
        }
    }
    else
    {
        runTestsInParallel(
            context,
            (int)files.getCount(),
            [&](int index) { processFile(files[index]); });
    }
}

static void _disableCPPBackends(TestContext* context)
{
    const SlangPassThrough cppPassThrus[] = {
        SLANG_PASS_THROUGH_GENERIC_C_CPP,
        SLANG_PASS_THROUGH_VISUAL_STUDIO,
        SLANG_PASS_THROUGH_CLANG,
        SLANG_PASS_THROUGH_GCC,
    };

    for (auto passThru : cppPassThrus)
    {
        context->availableBackendFlags &= ~(PassThroughFlags(1) << int(passThru));
        context->availableRenderApiFlags &= ~(RenderApiFlag::CPU);
        context->options.enabledApis &= ~(RenderApiFlag::CPU);
    }
}

static void _disableD3D12Backend(TestContext* context)
{
    context->options.enabledApis &= ~(RenderApiFlag::D3D12);
}

static TestResult _asTestResult(ToolReturnCode retCode)
{
    switch (retCode)
    {
    default:
        return TestResult::Fail;
    case ToolReturnCode::Success:
        return TestResult::Pass;
    case ToolReturnCode::Ignored:
        return TestResult::Ignored;
    }
}

/// Loads a DLL containing unit test functions and run them one by one.
static SlangResult runUnitTestModule(
    TestContext* context,
    TestOptions& testOptions,
    SpawnType spawnType,
    const char* moduleName)
{
    ISlangSharedLibraryLoader* loader = DefaultSharedLibraryLoader::getSingleton();
    ComPtr<ISlangSharedLibrary> moduleLibrary;

    SLANG_RETURN_ON_FAIL(loader->loadSharedLibrary(
        Path::combine(context->dllDirectoryPath, moduleName).getBuffer(),
        moduleLibrary.writeRef()));

    UnitTestGetModuleFunc getModuleFunc =
        (UnitTestGetModuleFunc)moduleLibrary->findFuncByName("slangUnitTestGetModule");
    if (!getModuleFunc)
        return SLANG_FAIL;

    IUnitTestModule* testModule = getModuleFunc();
    if (!testModule)
        return SLANG_FAIL;

    renderer_test::CoreDebugCallback coreDebugCallback;

    UnitTestContext unitTestContext;
    unitTestContext.slangGlobalSession = context->getSession();
    unitTestContext.workDirectory = "";
    // Intersect with probed available APIs so unit tests skip instead of fail
    // when the required device type is not present on the current machine.
    unitTestContext.enabledApis =
        context->options.enabledApis & _getAvailableRenderApiFlags(context);
    unitTestContext.enableDebugLayers = context->options.enableDebugLayers;
    unitTestContext.executableDirectory = context->exeDirectoryPath.getBuffer();
    unitTestContext.debugCallback = nullptr;

    auto testCount = testModule->getTestCount();

    struct TestItem
    {
        UnitTestFunc testFunc;
        String testName;
        String command;
    };

    List<TestItem> tests;

    // Discover all tests first.
    for (SlangInt i = 0; i < testCount; i++)
    {
        auto testFunc = testModule->getTestFunc(i);
        auto testName = testModule->getTestName(i);

        auto command =
            makeUnitTestKey(UnownedStringSlice(moduleName), UnownedStringSlice(testName));

        if (shouldRunTest(context, command))
        {
            if (testPassesCategoryMask(context, testOptions))
            {
                tests.add(TestItem{testFunc, testName, command});
            }
        }
    }

    auto runUnitTest = [&](TestItem test)
    {
        if (context->options.dryRun)
        {
            printf("%s\n", test.command.getBuffer());
            return;
        }

        auto reporter = context->getTestReporter();
        TestOptions options = testOptions;
        options.command = test.command;

        if (spawnType == SpawnType::UseTestServer ||
            spawnType == SpawnType::UseFullyIsolatedTestServer)
        {
            TestServerProtocol::ExecuteUnitTestArgs args;
            args.enabledApis = context->options.enabledApis & _getAvailableRenderApiFlags(context);
            args.enableDebugLayers = context->options.enableDebugLayers;
            args.moduleName = moduleName;
            args.testName = test.testName;

            {
                TestReporter::TestScope scopeTest(reporter, options.command);
                ExecuteResult exeRes;
                // Initialize the ExecuteResult, otherwise we can get bogus
                // error results.
                exeRes.init();

                SlangResult rpcRes = _executeRPC(
                    context,
                    spawnType,
                    TestServerProtocol::ExecuteUnitTestArgs::g_methodName,
                    &args,
                    exeRes);
                auto testResult = _asTestResult(ToolReturnCode(exeRes.resultCode));

                bool isFailed = (SLANG_FAILED(rpcRes) || testResult == TestResult::Fail);

                // If the rpc failed, output an error message
                if (SLANG_FAILED(rpcRes))
                {
                    // The call never reached the test, so this is not a verdict about it. Tell the
                    // reporter, which needs to know a retry that skips the test is a real answer
                    // here rather than a skipped failure.
                    testResult = TestResult::Fail;
                    reporter->message(TestMessageType::RunError, "rpc failed");
                    reporter->noteDispatchFailure(options.command);
                }

                // Check for VVL errors in unit tests
                if (exeRes.debugLayer.getLength() > 0)
                {
                    testResult = TestResult::Fail;
                    reporter->message(TestMessageType::TestFailure, exeRes.debugLayer);
                }

                // If the test fails, output any output - which might give information about
                // individual tests that have failed.
                if (testResult == TestResult::Fail)
                {
                    String output = getOutput(exeRes);
                    reporter->message(TestMessageType::TestFailure, output.getBuffer());
                }

                // If the test failed and it is not an expected failure, add it to the list of
                // failed unit tests so that we can retry.
                // The expected-failure list is keyed by the reporter key, not the bare test
                // name, so the key is built by makeUnitTestKey() rather than chosen here. That
                // matters because choosing wrong has no visible symptom -- the lookup just never
                // matches, and the only cost is the pointless retry this gate exists to avoid.
                if (isFailed && !context->isRetry && !context->options.disableRetries &&
                    !context->getTestReporter()->isExpectedFailure(makeUnitTestKey(
                        UnownedStringSlice(moduleName),
                        test.testName.getUnownedSlice())))
                {
                    std::lock_guard lock(context->mutexFailedTests);
                    context->failedUnitTests.add(test.command);

                    // Mark test as pending retry - it won't be counted in statistics yet
                    reporter->addResult(TestResult::PendingRetry);
                }
                else
                {
                    reporter->addResult(testResult);
                }
            }
        }
        else
        {
            TestReporter::TestScope scopeTest(reporter, options.command);

            // TODO(JS): Problem here could be exception not handled properly across
            // shared library boundary.
            testModule->setTestReporter(reporter);

            // Clear any previous debug messages
            coreDebugCallback.clear();
            auto rhiDebugBridge = renderer_test::createRetainedCoreToRHIDebugBridge();
            unitTestContext.debugCallback = rhiDebugBridge.Ptr();
            renderer_test::ScopedCoreDebugCallback scopedDebugCallback(
                *rhiDebugBridge,
                &coreDebugCallback);

            try
            {
                slang_replayMarker(test.testName.getBuffer());
                test.testFunc(&unitTestContext);

                // Check for VVL errors after test completion
                String debugMessages = coreDebugCallback.getString();
                if (debugMessages.getLength() > 0)
                {
                    reporter->message(TestMessageType::TestFailure, debugMessages);
                    reporter->addResult(TestResult::Fail);
                }
            }
            catch (...)
            {
                reporter->message(
                    TestMessageType::TestFailure,
                    "Exception was thrown during execution");
                reporter->addResult(TestResult::Fail);
            }
        }
    };

    bool useMultiThread = false;
    if (spawnType == SpawnType::UseTestServer || spawnType == SpawnType::UseFullyIsolatedTestServer)
    {
        if (context->options.serverCount > 1)
        {
            useMultiThread = true;
        }
    }

    if (useMultiThread)
    {
        runTestsInParallel(
            context,
            (int)tests.getCount(),
            [&](int index) { runUnitTest(tests[index]); });
    }
    else
    {
        auto reporter = TestReporter::get();

        testModule->setTestReporter(reporter);

        for (auto t : tests)
            runUnitTest(t);
    }

    // Note `testModule->destroy()` is deliberately not called here. The registry it would empty has
    // process lifetime and is filled in once, by the module's load-time static constructors, so
    // this function must leave it intact for the retry pass to enumerate. (The test server, which
    // holds the same kind of module, releases its own copy from its destructor at shutdown.)
    //
    // No unit test guards this: the cross-pass dlopen / static-constructor path it turns on cannot
    // be driven from an in-process SLANG_UNIT_TEST, so a real two-pass run under CI is the only
    // positive check. What does exist is a backstop -- reinstating the call would leave every
    // unit-test deferral unredeemed, and `TestReporter::reconcilePendingRetries()` would then count
    // them as failures. So the regression surfaces as red CI rather than as the silent green it
    // used to be, but only because that safety net is there. Do not "tidy up" the missing
    // destroy() on the assumption the unit tests cover it.
    return SLANG_OK;
}

static void cleanupRenderTestDeviceCache(TestContext& context)
{
    auto cleanFunc = context.getCleanDeviceCacheFunc("render-test");
    if (cleanFunc)
    {
        cleanFunc();
    }
}

SlangResult innerMain(int argc, char** argv)
{
    auto stdWriters = StdWriters::initDefaultSingleton();

    // The context holds useful things used during testing
    TestContext context;
    SLANG_RETURN_ON_FAIL(context.init(argv[0]))

    auto& categorySet = context.categorySet;

    // Set up our test categories here
    auto fullTestCategory = categorySet.add("full", nullptr);
    auto quickTestCategory = categorySet.add("quick", fullTestCategory);
    auto smokeTestCategory = categorySet.add("smoke", quickTestCategory);
    auto renderTestCategory = categorySet.add("render", fullTestCategory);
    /*auto computeTestCategory = */ categorySet.add("compute", fullTestCategory);
    auto vulkanTestCategory = categorySet.add("vulkan", fullTestCategory);
    auto unitTestCategory = categorySet.add("unit-test", fullTestCategory);
    auto cudaTestCategory = categorySet.add("cuda", fullTestCategory);
    auto optixTestCategory = categorySet.add("optix", cudaTestCategory);

    auto waveTestCategory = categorySet.add("wave", fullTestCategory);
    auto waveMaskCategory = categorySet.add("wave-mask", waveTestCategory);
    auto waveActiveCategory = categorySet.add("wave-active", waveTestCategory);

    auto compatibilityIssueCategory = categorySet.add("compatibility-issue", fullTestCategory);

    auto sharedLibraryCategory = categorySet.add("shared-library", fullTestCategory);

    categorySet.add("compile-target", fullTestCategory);

#if SLANG_WINDOWS_FAMILY
    auto windowsCategory = categorySet.add("windows", fullTestCategory);
#endif

#if SLANG_UNIX_FAMILY
    auto unixCategory = categorySet.add("unix", fullTestCategory);
#endif

#if SLANG_PTR_IS_64
    auto ptr64Category = categorySet.add("64-bit", fullTestCategory);
#else
    auto ptr32Category = categorySet.add("32-bit", fullTestCategory);
#endif

    // An un-categorized test will always belong to the `full` category
    categorySet.defaultCategory = fullTestCategory;

    // All following values are initialized to '0', so null.
    TestCategory* passThroughCategories[SLANG_PASS_THROUGH_COUNT_OF] = {nullptr};

    // Work out what backends/pass-thrus are available. This has to run before Options::parse below
    // because `-category`/`-exclude <backend-name>` resolves against the categories registered
    // here. The "Supported backends:" line, however, is informational and gated on verbosity, which
    // is only known after the parse, so we accumulate it here and print it once options are parsed.
    StringBuilder supportedBackends;
    {
        SlangSession* session = context.getSession();

        for (int i = 0; i < SLANG_PASS_THROUGH_COUNT_OF; ++i)
        {
            const SlangPassThrough passThru = SlangPassThrough(i);
            if (passThru == SLANG_PASS_THROUGH_NONE)
            {
                continue;
            }

            if (SLANG_SUCCEEDED(session->checkPassThroughSupport(passThru)))
            {
                context.availableBackendFlags |= PassThroughFlags(1) << int(i);

                StringBuilder buf;

                auto name = TypeTextUtil::getPassThroughName(passThru);

                buf << " " << name;

                SLANG_ASSERT(passThroughCategories[i] == nullptr);
                passThroughCategories[i] = categorySet.add(buf.getBuffer() + 1, fullTestCategory);

                // Each token keeps its leading space (the `+ 1` above strips it only for the
                // category name), so the joined line reads "Supported backends: a b". CI greps the
                // literal "Supported backends: " (with the trailing space), so this is
                // load-bearing.
                supportedBackends << buf;
            }
        }
    }

    {
        SlangSession* session = context.getSession();

        const bool hasLlvm =
            SLANG_SUCCEEDED(session->checkPassThroughSupport(SLANG_PASS_THROUGH_LLVM));
        const auto hostCallableCompiler = session->getDownstreamCompilerForTransition(
            SLANG_CPP_SOURCE,
            SLANG_SHADER_HOST_CALLABLE);

        if (hasLlvm)
        {
            SLANG_RETURN_ON_FAIL(context.locateLLVMFileCheck());
        }

        if (hasLlvm && hostCallableCompiler == SLANG_PASS_THROUGH_LLVM && SLANG_PROCESSOR_X86)
        {
            // TODO(JS)
            // For some reason host-callable with llvm/double produces different results on x86
        }
        else
        {
            // Special category to mark a test only works for targets that work correctly with
            // double (ie not x86/llvm)
            categorySet.add("war-double-host-callable", fullTestCategory);
        }
    }

    // Working out what renderApis is worked on on demand through
    // _getAvailableRenderApiFlags()

    {
        // We can set the slangc command line tool, to just use the function defined here
        context.setInnerMainFunc("slangc", &SlangCTool::innerMain);
    }

    {
        // We can set the slangc command line tool, to just use the function defined here
        context.setInnerMainFunc("slangi", &SlangITool::innerMain);
    }

    SLANG_RETURN_ON_FAIL(Options::parse(
        argc,
        argv,
        &categorySet,
        StdWriters::getOut(),
        StdWriters::getError(),
        &context.options));

    Options& options = context.options;

    // CI greps this at default (Info) verbosity, so suppress it only below Info (e.g. `-v
    // failure`).
    if (options.verbosity >= VerbosityLevel::Info)
    {
        StdWriters::getOut().print("Supported backends:%s\n", supportedBackends.getBuffer());
    }

    context.setMaxTestRunnerThreadCount(options.serverCount);

    // Set up the prelude/s
    TestToolUtil::setSessionDefaultPreludeFromExePath(argv[0], context.getSession());

    if (options.outputMode == TestOutputMode::TeamCity)
    {
        // On TeamCity CI there is an issue with unix/linux targets where test system may be
        // different from the build system That we rely on having compilation tools present such
        // that on x64 systems we can build x86 binaries, and that appears to not always be the
        // case. For now we only allow CPP backends to run on x86_64 targets
#if SLANG_UNIX_FAMILY && !SLANG_PROCESSOR_X86_64
        _disableCPPBackends(&context);
#endif
    }

#if SLANG_PROCESSOR_X86
    // Disable d3d12 tests on x86 right now since dxc for 32-bit windows doesn't seem to recognize
    // sm_6_6.
    _disableD3D12Backend(&context);
#endif

    // If -only-api-detection mode, run API detection and exit
    if (options.apiDetectionOnly)
    {
        // Create a TestReporter since _getAvailableRenderApiFlags may use it in verbose mode
        TestReporter reporter;
        SLANG_RETURN_ON_FAIL(reporter.init(options));
        context.setTestReporter(&reporter);

        _getAvailableRenderApiFlags(&context);

        // Print which APIs were not checked
        printf("Not checked:");
        bool anyNotChecked = false;
        for (int i = 0; i < int(RenderApiType::CountOf); ++i)
        {
            const RenderApiType apiType = RenderApiType(i);

            // An API was "not checked" if it's not available on this platform
            bool wasChecked = false;
            if (apiType == RenderApiType::CPU)
            {
                wasChecked = (context.availableBackendFlags & PassThroughFlag::Generic_C_CPP) != 0;
            }
            else
            {
                wasChecked = RenderApiUtil::calcHasApi(apiType);
            }

            if (!wasChecked)
            {
                auto name = RenderApiUtil::getApiName(apiType);
                printf(" %.*s", (int)name.getLength(), name.begin());
                anyNotChecked = true;
            }
        }
        if (!anyNotChecked)
        {
            printf(" (none)");
        }
        printf("\n");
        fflush(stdout);

        return SLANG_OK;
    }

    if (options.subCommand.getLength())
    {
        // Get the function from the tool
        auto func = context.getInnerMainFunc(options.binDir, options.subCommand);
        if (!func)
        {
            StdWriters::getError().print(
                "error: Unable to launch tool '%s'\n",
                options.subCommand.getBuffer());
            return SLANG_FAIL;
        }

        // Copy args to a char* list
        const auto& srcArgs = options.subCommandArgs;
        List<const char*> args;
        args.setCount(srcArgs.getCount());
        for (Index i = 0; i < srcArgs.getCount(); ++i)
        {
            args[i] = srcArgs[i].getBuffer();
        }

        return func(
            StdWriters::getSingleton(),
            context.getSession(),
            int(args.getCount()),
            args.getBuffer());
    }

    if (options.includeCategories.getCount() == 0)
    {
        options.includeCategories.add(fullTestCategory, fullTestCategory);
    }

    // Exclude rendering tests when building under AppVeyor.
    //
    // TODO: this is very ad hoc, and we should do something cleaner.
    if (options.outputMode == TestOutputMode::AppVeyor)
    {
        options.excludeCategories.add(renderTestCategory, renderTestCategory);
        options.excludeCategories.add(vulkanTestCategory, vulkanTestCategory);
    }

    {
        // Setup the reporter
        TestReporter reporter;
        SLANG_RETURN_ON_FAIL(reporter.init(options));

        context.setTestReporter(&reporter);

        {
            TestReporter::SuiteScope suiteScope(&reporter, "tests");
            // Enumerate test files according to policy
            runTestsInDirectory(&context);
        }

        // Run the unit tests (these are internal C++ tests - not specified via files in a
        // directory) They are registered with SLANG_UNIT_TEST macro
        //
        //
        if (context.canRunUnitTests())
        {
            TestReporter::SuiteScope suiteScope(&reporter, "unit tests");
            TestReporter::set(&reporter);

            for (bool isRetry : {false, true})
            {
                auto spawnType = context.getFinalSpawnType();
                context.isRetry = isRetry;
                if (isRetry)
                {
                    if (context.options.disableRetries || context.failedUnitTests.getCount() == 0)
                        break;

                    printf("Retrying unit tests...\n");
                    context.options.testPrefixes = context.failedUnitTests;
                    context.failedUnitTests.clear();
                }

                // Run the unit tests
                {
                    TestOptions testOptions;
                    testOptions.categories.add(unitTestCategory);
                    testOptions.categories.add(smokeTestCategory);
                    runUnitTestModule(&context, testOptions, spawnType, "slang-unit-test-tool");
                }

                {
                    TestOptions testOptions;
                    testOptions.categories.add(unitTestCategory);
                    runUnitTestModule(&context, testOptions, spawnType, "gfx-unit-test-tool");
                }
            }

            TestReporter::set(nullptr);
        }

        // If we have a couple failed tests, they maybe intermittent failures due to parallel
        // excution or driver instability. We can try running them again. Debug build has more
        // instability at this moment, so we allow more retries.
        if (context.stopSchedulingTests.load())
        {
            fprintf(
                stderr,
                "\n*** Stopped scheduling new tests after too many consecutive failures.\n"
                "*** This usually indicates a systemic issue such as a GPU driver crash.\n"
                "*** Skipping retries for %d failed tests.\n\n",
                (int)context.failedFileTests.getCount());
            fflush(stderr);

            // Skipping the retries is right; dropping the results is not. A test deferred for
            // retry has only been recorded as "pending retry", which is a placeholder rather
            // than a verdict, and the retry loop below is what normally turns it into one. On
            // this branch that loop never runs, so before this the tests vanished:
            // m_failedTestCount stayed 0, didAllSucceed() returned true, and slang-test exited
            // 0 announcing "0% of tests passed (0/0)".
            //
            // The deferred tests still reach the totals: reconcilePendingRetries() below
            // turns every unredeemed deferral into a failure, which is the general form of
            // the rule this branch used to apply for itself. What it cannot supply is the
            // `aborted` term in the exit code -- an abort tripped on a path that deferred
            // nothing leaves reconcile with nothing to fail, and the run would exit 0 again.
        }

        if (!context.options.disableRetries && !context.stopSchedulingTests.load())
        {
#if _DEBUG
            static constexpr int kFailedTestLimitForRetry = 100;
#else
            static constexpr int kFailedTestLimitForRetry = 16;
#endif
            if (context.failedFileTests.getCount() <= kFailedTestLimitForRetry)
            {
                if (context.failedFileTests.getCount() > 0)
                    printf(
                        "Retrying %d failed tests...\n",
                        (int)context.failedFileTests.getCount());
                for (auto& test : context.failedFileTests)
                {
                    context.isRetry = true;
                    FileTestInfoImpl* fileTestInfo = static_cast<FileTestInfoImpl*>(test.Ptr());
                    TestReporter::SuiteScope suiteScope(&reporter, "tests");
                    TestReporter::TestScope scope(&reporter, fileTestInfo->testName);
                    auto newResult = runTest(
                        &context,
                        fileTestInfo->filePath,
                        fileTestInfo->outputStem,
                        fileTestInfo->testName,
                        fileTestInfo->options);
                    reporter.addResult(newResult);
                }
            }
            else
            {
                // If there are too many failed tests, don't bother retrying.
                printf(
                    "Too many failed tests for retry(%d) - setting all to failed\n",
                    (int)context.failedFileTests.getCount());
                fflush(stdout);
                // Left to reconcilePendingRetries() below, as on the abort branch above.
            }
        }

        // Every retry pass has now run, so any test whose result is still deferred is never going
        // to get one. Turn those into failures before they reach the summary.
        //
        // The position matters and no unit test can hold it: the reporter tests call
        // reconcilePendingRetries() directly, so moving this above the retry loop -- where it would
        // count deferrals the retry was about to redeem -- or dropping it entirely would not fail
        // any of them. It has to run after the last retry and before outputSummary().
        reporter.reconcilePendingRetries();

        reporter.outputSummary();

        cleanupRenderTestDeviceCache(context);

        // An abort is a failure in its own right, whatever ended up recorded.
        //
        // Deliberately belt-and-braces, and not independently testable: reconcilePendingRetries()
        // converts every deferral, so any abort reachable today also leaves recorded failures and
        // would exit non-zero without this term. It is kept because the two facts are independent
        // -- one is "some tests failed", the other is "we stopped running tests" -- and only the
        // second is true of a run that abandoned its work. A future change that downgrades or
        // redeems those failures (an expected-failure list covering them, say) would restore the
        // exit-0 hole this PR exists to close, and this term is what would still catch it.
        const bool aborted = context.stopSchedulingTests.load();
        return (reporter.didAllSucceed() && !aborted) ? SLANG_OK : SLANG_FAIL;
    }
}

int main(int argc, char** argv)
{
#if SLANG_UNIX_FAMILY
    // Ignore SIGPIPE so that writing to a broken pipe (e.g. a crashed test-server)
    // returns EPIPE instead of killing this process (exit code 141).
    signal(SIGPIPE, SIG_IGN);
#endif

#if SLANG_IGNORE_ABORT_MSG && defined(_MSC_VER)
    // Suppress the modal abort() dialog in unattended/LLM-driven builds.
    _set_abort_behavior(0, _WRITE_ABORT_MSG);
#endif

    // Fallback: run without cleanup if context initialization fails
    SlangResult res = innerMain(argc, argv);
    slang::shutdown();
    Slang::RttiInfo::deallocateAll();

#ifdef _MSC_VER
    _CrtDumpMemoryLeaks();
#endif
    return SLANG_SUCCEEDED(res) ? 0 : 1;
}
