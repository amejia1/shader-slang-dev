// options.cpp
#include "options.h"

#include "core/slang-io.h"
#include "core/slang-string-util.h"
#include "slang-test-optimization-options.h"

#include <stdio.h>
#include <stdlib.h>

using namespace Slang;

/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!! CategorySet !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */

TestCategory* TestCategorySet::add(String const& name, TestCategory* parent)
{
    RefPtr<TestCategory> category(new TestCategory);
    category->name = name;
    category->parent = parent;

    m_categoryMap.add(name, category);
    return category;
}

TestCategory* TestCategorySet::find(String const& name)
{
    if (auto category = m_categoryMap.tryGetValue(name))
    {
        return category->Ptr();
    }
    return nullptr;
}

TestCategory* TestCategorySet::findOrError(String const& name)
{
    TestCategory* category = find(name);
    if (!category)
    {
        StdWriters::getError().print("error: unknown test category name '%s'\n", name.getBuffer());
    }
    return category;
}

/* We need a way to differentiate a subCommand from say a test prefix. Here
we assume a command is just alpha characters or -, and this would differentiate it from
typical prefix usage (which is generally a directory). */
static bool _isSubCommand(const char* arg)
{
    for (; *arg; arg++)
    {
        const char c = *arg;
        // A command is just letters
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '-'))
        {
            return false;
        }
    }
    return true;
}

/* !!!!!!!!!!!!!!!!!!!!!!!!!!!!! Options !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! */

/* static */ void Options::showHelp(WriterHelper stdOut)
{
    stdOut.print(
        "Usage: slang-test [options] [test-prefix...]\n"
        "\n"
        "Options:\n"
        "  -h, --help                     Show this help message\n"
        "  -bindir <path>                 Set directory for binaries (default: the path to the "
        "slang-test executable)\n"
        "  -test-dir <path>               Set directory for test files (default: tests/)\n"
        "  -v [level]                     Set verbosity level (verbose, info, failure)\n"
        "                                 Default: verbose when -v used, info otherwise\n"
        "  -hide-ignored                  Hide results from ignored tests\n"
        "  -api-only                      Only run tests that use specified APIs\n"
        "  -verbose-paths                 Use verbose paths in output\n"
        "  -category <name>               Only run tests in specified category\n"
        "  -exclude <name>                Exclude tests in specified category\n"
        "  -exclude-prefix <prefix>       Exclude tests with specified path prefix\n"
        "  -api <expr>                    Enable specific APIs, e.g. 'vk+dx12', 'all-vk',\n"
        "                                 or '+dx11'. '+'/'-' add/remove an API; a leading\n"
        "                                 name resets the set. Keywords: all, none,\n"
        "                                 vk (vulkan), dx11 (d3d11), dx12 (d3d12),\n"
        "                                 mtl (metal), cuda, cpu, llvm, wgpu (webgpu)\n"
        "  -synthesizedTestApi <expr>     Set APIs for synthesized tests (same <expr> as -api)\n"
        "  -skip-api-detection            Skip API availability detection\n"
        "  -only-api-detection            Only run API detection and print results, then exit\n"
        "  -server-count <n>              Set number of test servers (default: 1)\n"
        "  -OX                            Set the default slangc optimization level for tests,\n"
        "                                 where X is between 0 and 3\n"
        "  -show-adapter-info             Show detailed adapter information\n"
        "  -generate-hlsl-baselines       Generate HLSL test baselines\n"
        "  -skip-reference-image-generation Skip generating reference images for render tests\n"
        "  -emit-spirv-via-glsl           Emit SPIR-V through GLSL instead of directly\n"
        "  -expected-failure-list <file>  Specify file containing expected failures\n"
        "  -skip-list <file>              Specify file containing tests to skip (path prefixes)\n"
        "  -use-shared-library            Run tests in-process using shared library\n"
        "  -use-test-server               Run tests using test server\n"
        "  -use-fully-isolated-test-server  Run each test in isolated server\n"
        "  -capability <name>             Compile with the given capability\n"
        "  -shuffle-tests                 Shuffle tests in directories\n"
        "  -shuffle-seed <seed>           Set shuffle seed (default: 1)\n"
        "  -explicit-test-order           Run tests in the order specified on command line\n"
        "                                 (alphabetical for prefixes matching multiple tests)\n"
        "  -dry-run                       List tests that would be run without running them\n"
        "  -disable-retries               Disable automatic retries of failed tests\n"
        "  -synthesize-compile-targets    Synthesize compile-only tests for all available\n"
        "                                 backends from GPU-requiring tests, exercising\n"
        "                                 emit paths without needing a GPU\n"
        "  -only-synthesized             Only run synthesized compile-target tests\n"
        "                                 (implies -synthesize-compile-targets)\n"

        "  -enable-debug-layers [true|false] Enable or disable Validation Layer for Vulkan\n"
        "                                 and Debug Device for DX\n"
        "  -cache-rhi-device [true|false] Enable or disable RHI device caching (default: true)\n"
#if _DEBUG
        "  -disable-debug-layers          Disable the debug layers (default enabled in debug "
        "build)\n"
#endif
        "\n"
        "Output modes:\n"
        "  -appveyor                      Use AppVeyor output format\n"
        "  -travis                        Use Travis CI output format\n"
        "  -teamcity                      Use TeamCity output format\n"
        "  -xunit                         Use xUnit output format\n"
        "  -xunit2                        Use xUnit 2 output format\n"
        "\n"
        "Test prefixes are used to filter which tests to run. If no prefix is specified,\n"
        "all tests will be run.\n");
}

/* static */ Result Options::parse(
    int argc,
    char** argv,
    TestCategorySet* categorySet,
    Slang::WriterHelper stdOut,
    Slang::WriterHelper stdError,
    Options* optionsOut)
{
    // Reset the options
    *optionsOut = Options();

    List<const char*> positionalArgs;

    // Track whether an -api / -synthesizedTestApi option has been seen so a
    // later name-leading expression (which resets the API set and silently
    // discards earlier options) can be rejected. Operator-leading (+/-)
    // expressions still accumulate.
    bool apiOptionSeen = false;
    bool synthesizedApiOptionSeen = false;

    int argCount = argc;
    char const* const* argCursor = argv;
    char const* const* argEnd = argCursor + argCount;

#if _DEBUG
    // Enabling debug layers by default in debug builds.
    // For DX12 it will use the debug layer, for Vulkan it will enable validation layers.
    //
    // CI/CD will explicitly disable this until we address all of VUID errors.
    // https://github.com/shader-slang/slang/issues/4798
    //
    // When you run the Debug build locally, you may see more errors if not disabled with
    // '-enable-debug-layers false'.
    //
    optionsOut->enableDebugLayers = true;
#endif

    // first argument is the application name
    if (argCursor != argEnd)
    {
        optionsOut->appName = *argCursor++;
    }

    // Check for help flags first
    for (int i = 1; i < argc; i++)
    {
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0)
        {
            showHelp(stdOut);
            return SLANG_FAIL;
        }
    }

    // now iterate over arguments to collect options
    while (argCursor != argEnd)
    {
        char const* arg = *argCursor++;

        if (arg[0] != '-')
        {
            // We need to determine if this is a command, the confusion is that
            // previously we can specify a test prefix as just a single positional arg.
            // To rule this out, here it can only be a subCommand if it is just text

            if (_isSubCommand(arg))
            {
                optionsOut->subCommand = arg;
                // Make the first arg the command name
                optionsOut->subCommandArgs.add(optionsOut->subCommand);

                // Add all the remaining commands to subCommands
                for (; argCursor != argEnd; ++argCursor)
                {
                    optionsOut->subCommandArgs.add(*argCursor);
                }
                // Done
                return SLANG_OK;
            }

            positionalArgs.add(arg);
            continue;
        }

        if (strcmp(arg, "--") == 0)
        {
            // Add all positional args at the end
            while (argCursor != argEnd)
            {
                positionalArgs.add(*argCursor++);
            }
            break;
        }

        if (strcmp(arg, "-bindir") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            optionsOut->binDir = *argCursor++;
        }
        else if (strcmp(arg, "-use-shared-library") == 0)
        {
            optionsOut->defaultSpawnType = SpawnType::UseSharedLibrary;
        }
        else if (strcmp(arg, "-use-test-server") == 0)
        {
            optionsOut->defaultSpawnType = SpawnType::UseTestServer;
        }
        else if (strcmp(arg, "-use-fully-isolated-test-server") == 0)
        {
            optionsOut->defaultSpawnType = SpawnType::UseFullyIsolatedTestServer;
        }
        else if (strcmp(arg, "-v") == 0)
        {
            if (argCursor == argEnd)
            {
                // Default to verbose if no argument provided (backward compatibility)
                optionsOut->verbosity = VerbosityLevel::Verbose;
            }
            else
            {
                const char* verbosityArg = *argCursor;
                if (strcmp(verbosityArg, "verbose") == 0)
                {
                    optionsOut->verbosity = VerbosityLevel::Verbose;
                    argCursor++;
                }
                else if (strcmp(verbosityArg, "info") == 0)
                {
                    optionsOut->verbosity = VerbosityLevel::Info;
                    argCursor++;
                }
                else if (strcmp(verbosityArg, "failure") == 0)
                {
                    optionsOut->verbosity = VerbosityLevel::Failure;
                    argCursor++;
                }
                else
                {
                    // Not a verbosity level, treat as old-style -v
                    optionsOut->verbosity = VerbosityLevel::Verbose;
                }
            }
        }
        else if (strcmp(arg, "-hide-ignored") == 0)
        {
            optionsOut->hideIgnored = true;
        }
        else if (strcmp(arg, "-api-only") == 0)
        {
            optionsOut->apiOnly = true;
        }
        else if (strcmp(arg, "-verbose-paths") == 0)
        {
            optionsOut->verbosePaths = true;
        }
        else if (strcmp(arg, "-generate-hlsl-baselines") == 0)
        {
            optionsOut->generateHLSLBaselines = true;
        }
        else if (strcmp(arg, "-shuffle-tests") == 0)
        {
            optionsOut->shuffleTests = true;
        }
        else if (strcmp(arg, "-explicit-test-order") == 0)
        {
            optionsOut->explicitTestOrder = true;
        }
        else if (strcmp(arg, "-dry-run") == 0)
        {
            optionsOut->dryRun = true;
        }
        else if (strcmp(arg, "-disable-retries") == 0)
        {
            optionsOut->disableRetries = true;
        }
        else if (strcmp(arg, "-synthesize-compile-targets") == 0)
        {
            optionsOut->synthesizeCompileTargets = true;
        }
        else if (strcmp(arg, "-only-synthesized") == 0)
        {
            optionsOut->onlySynthesized = true;
            optionsOut->synthesizeCompileTargets = true;
        }
        else if (strcmp(arg, "-shuffle-seed") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            optionsOut->shuffleSeed = stringToInt(*argCursor++);
            if (optionsOut->shuffleSeed <= 0)
            {
                optionsOut->shuffleSeed = 1;
            }
        }
        else if (strcmp(arg, "-release") == 0)
        {
            // Assumed to be handle by .bat file that called us
        }
        else if (strcmp(arg, "-debug") == 0)
        {
            // Assumed to be handle by .bat file that called us
        }
        else if (strcmp(arg, "-configuration") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            argCursor++;
            // Assumed to be handle by .bat file that called us
        }
        else if (strcmp(arg, "-platform") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            argCursor++;
            // Assumed to be handle by .bat file that called us
        }
        else if (strcmp(arg, "-server-count") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            optionsOut->serverCount = stringToInt(*argCursor++);
            if (optionsOut->serverCount <= 0)
            {
                optionsOut->serverCount = 1;
            }
        }
        else if (SlangTest::isSlangTestOptimizationArg(UnownedStringSlice(arg)))
        {
            optionsOut->defaultOptimizationLevel = arg;
        }
        else if (strcmp(arg, "-appveyor") == 0)
        {
            optionsOut->outputMode = TestOutputMode::AppVeyor;
            optionsOut->dumpOutputOnFailure = true;
        }
        else if (strcmp(arg, "-travis") == 0)
        {
            optionsOut->outputMode = TestOutputMode::Travis;
            optionsOut->dumpOutputOnFailure = true;
        }
        else if (strcmp(arg, "-xunit") == 0)
        {
            optionsOut->outputMode = TestOutputMode::XUnit;
        }
        else if (strcmp(arg, "-xunit2") == 0)
        {
            optionsOut->outputMode = TestOutputMode::XUnit2;
        }
        else if (strcmp(arg, "-teamcity") == 0)
        {
            optionsOut->outputMode = TestOutputMode::TeamCity;
        }
        else if (strcmp(arg, "-category") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            auto category = categorySet->findOrError(*argCursor++);
            if (category)
            {
                optionsOut->includeCategories.add(category, category);
            }
        }
        else if (strcmp(arg, "-exclude") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            auto category = categorySet->findOrError(*argCursor++);
            if (category)
            {
                optionsOut->excludeCategories.add(category, category);
            }
        }
        else if (strcmp(arg, "-exclude-prefix") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            Slang::StringBuilder sb;
            Slang::Path::simplify(*argCursor++, Slang::Path::SimplifyStyle::NoRoot, sb);
            optionsOut->excludePrefixes.add(sb);
        }
        else if (strcmp(arg, "-api") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print(
                    "error: expecting an api expression (eg 'vk+dx12' or '+dx11') '%s'\n",
                    arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            const char* apiList = *argCursor++;

            // Each -api expression is parsed relative to the previous result,
            // but that previous value is only kept when the expression begins
            // with an operator ('+' or '-'). An expression that begins with an
            // API name resets from scratch and silently discards any earlier
            // -api. Reject that case so a later -api cannot quietly override an
            // earlier one; combine them into one expression or lead with +/-.
            if (apiOptionSeen && apiList[0] != '+' && apiList[0] != '-')
            {
                stdError.print(
                    "error: -api expression '%s' would discard the previous -api; "
                    "begin it with '+' or '-' to combine, or merge them into a single "
                    "expression (eg 'vk+dx12' or 'all-vk')\n",
                    apiList);
                return SLANG_FAIL;
            }
            apiOptionSeen = true;

            SlangResult res = RenderApiUtil::parseApiFlags(
                UnownedStringSlice(apiList),
                optionsOut->enabledApis,
                &optionsOut->enabledApis);
            if (SLANG_FAILED(res))
            {
                stdError.print("error: unable to parse api expression '%s'\n", apiList);
                return res;
            }
        }
        else if (strcmp(arg, "-synthesizedTestApi") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print(
                    "error: expected an api expression (eg 'vk+dx12' or '+dx11') '%s'\n",
                    arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            const char* apiList = *argCursor++;

            // Same silent-override hazard as -api: a name-leading expression
            // resets the set and discards any earlier -synthesizedTestApi.
            if (synthesizedApiOptionSeen && apiList[0] != '+' && apiList[0] != '-')
            {
                stdError.print(
                    "error: -synthesizedTestApi expression '%s' would discard the previous "
                    "-synthesizedTestApi; begin it with '+' or '-' to combine, or merge them "
                    "into a single expression (eg 'vk+dx12' or 'all-vk')\n",
                    apiList);
                return SLANG_FAIL;
            }
            synthesizedApiOptionSeen = true;

            SlangResult res = RenderApiUtil::parseApiFlags(
                UnownedStringSlice(apiList),
                optionsOut->synthesizedTestApis,
                &optionsOut->synthesizedTestApis);
            if (SLANG_FAILED(res))
            {
                stdError.print("error: unable to parse api expression '%s'\n", apiList);
                return res;
            }
        }
        else if (strcmp(arg, "-skip-api-detection") == 0)
        {
            if (optionsOut->apiDetectionOnly)
            {
                stdError.print(
                    "error: -only-api-detection and -skip-api-detection are mutually exclusive\n");
                return SLANG_FAIL;
            }
            optionsOut->skipApiDetection = true;
        }
        else if (strcmp(arg, "-only-api-detection") == 0)
        {
            if (optionsOut->skipApiDetection)
            {
                stdError.print(
                    "error: -only-api-detection and -skip-api-detection are mutually exclusive\n");
                return SLANG_FAIL;
            }
            optionsOut->apiDetectionOnly = true;
        }
        else if (strcmp(arg, "-emit-spirv-via-glsl") == 0)
        {
            optionsOut->emitSPIRVDirectly = false;
        }
        else if (strcmp(arg, "-capability") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            optionsOut->capabilities.add(*argCursor++);
        }
        else if (strcmp(arg, "-expected-failure-list") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            auto fileName = *argCursor++;
            String text;
            File::readAllText(fileName, text);
            List<UnownedStringSlice> lines;
            StringUtil::split(text.getUnownedSlice(), '\n', lines);
            int fileEntryCount = 0;
            for (auto line : lines)
            {
                // Remove comments (everything after '#' character)
                auto trimmedLine = line;
                auto commentIndex = line.indexOf('#');
                if (commentIndex != -1)
                {
                    trimmedLine = line.head(commentIndex);
                }

                // Trim whitespace and skip empty lines
                trimmedLine = trimmedLine.trim();
                if (trimmedLine.getLength() > 0)
                {
                    optionsOut->expectedFailureList.add(trimmedLine);
                    fileEntryCount++;
                }
            }
            Options::TestListFileInfo fileInfo;
            fileInfo.fileName = fileName;
            fileInfo.count = fileEntryCount;
            optionsOut->expectedFailureFiles.add(fileInfo);
        }
        else if (strcmp(arg, "-skip-list") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            auto fileName = *argCursor++;
            String text;
            File::readAllText(fileName, text);
            List<UnownedStringSlice> lines;
            StringUtil::split(text.getUnownedSlice(), '\n', lines);
            int fileEntryCount = 0;
            for (auto line : lines)
            {
                // Remove comments (everything after '#' character)
                auto trimmedLine = line;
                auto commentIndex = line.indexOf('#');
                if (commentIndex != -1)
                {
                    trimmedLine = line.head(commentIndex);
                }

                // Trim whitespace and skip empty lines
                trimmedLine = trimmedLine.trim();
                if (trimmedLine.getLength() > 0)
                {
                    Slang::StringBuilder sb;
                    Slang::Path::simplify(trimmedLine, Slang::Path::SimplifyStyle::NoRoot, sb);
                    optionsOut->skipList.add(sb);
                    fileEntryCount++;
                }
            }
            Options::TestListFileInfo fileInfo;
            fileInfo.fileName = fileName;
            fileInfo.count = fileEntryCount;
            optionsOut->skipListFiles.add(fileInfo);
        }
        else if (strcmp(arg, "-test-dir") == 0)
        {
            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }
            optionsOut->testDir = *argCursor++;
        }
        else if (strcmp(arg, "-show-adapter-info") == 0)
        {
            optionsOut->showAdapterInfo = true;
        }
        else if (strcmp(arg, "-skip-reference-image-generation") == 0)
        {
            optionsOut->skipReferenceImageGeneration = true;
        }
        else if (strcmp(arg, "-enable-debug-layers") == 0)
        {
            optionsOut->enableDebugLayers = true;

            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }

            // Check for false variants
            const char* value = *argCursor++;
            if (value[0] == 'f' || value[0] == 'F' || value[0] == 'n' || value[0] == 'N' ||
                value[0] == '0' ||
                ((value[0] == 'o' || value[0] == 'O') && (value[1] == 'f' || value[1] == 'F')))
            {
                optionsOut->enableDebugLayers = false;
            }
        }
        else if (strcmp(arg, "-cache-rhi-device") == 0)
        {
            optionsOut->cacheRhiDevice = true;

            if (argCursor == argEnd)
            {
                stdError.print("error: expected operand for '%s'\n", arg);
                showHelp(stdError);
                return SLANG_FAIL;
            }

            // Check for false variants
            const char* value = *argCursor++;
            if (value[0] == 'f' || value[0] == 'F' || value[0] == 'n' || value[0] == 'N' ||
                value[0] == '0' ||
                ((value[0] == 'o' || value[0] == 'O') && (value[1] == 'f' || value[1] == 'F')))
            {
                optionsOut->cacheRhiDevice = false;
            }
        }
#if _DEBUG
        else if (strcmp(arg, "-disable-debug-layers") == 0)
        {
            stdError.print("warning: '-disable-debug-layers' is deprecated, use "
                           "'-enable-debug-layers false'\n");
            optionsOut->enableDebugLayers = false;
        }
#endif
        else
        {
            stdError.print("unknown option '%s'\n", arg);
            showHelp(stdError);
            return SLANG_FAIL;
        }
    }

    {
        // Find out what apis are available
        const int availableApis = RenderApiUtil::getAvailableApis();
        // Only allow apis we know are available
        optionsOut->enabledApis &= availableApis;

        // Can only synth for apis that are available
        optionsOut->synthesizedTestApis &= optionsOut->enabledApis;
    }

    // Check for conflicting options
    if (optionsOut->shuffleTests && optionsOut->explicitTestOrder)
    {
        stdError.print("error: -shuffle-tests and -explicit-test-order are mutually exclusive\n");
        return SLANG_FAIL;
    }

    // first positional argument is source shader path
    optionsOut->testPrefixes.clear();
    optionsOut->testPrefixes.reserve(positionalArgs.getCount());
    for (auto testPrefix : positionalArgs)
    {
        Slang::StringBuilder sb;
        Slang::Path::simplify(testPrefix, Slang::Path::SimplifyStyle::NoRoot, sb);
        optionsOut->testPrefixes.add(sb);
    }

    if (optionsOut->binDir.getLength() == 0)
    {
        // If the binDir isn't set try using the path to the executable
        String exePath = Path::getExecutablePath();
        if (exePath.getLength())
        {
            optionsOut->binDir = Path::getParentDirectory(exePath);
        }
    }

    if (optionsOut->testDir.getLength() == 0)
    {
        // If the test directory isn't set, use the "tests" directory
        optionsOut->testDir = String("tests/");
    }

    if (optionsOut->verbosity >= VerbosityLevel::Info &&
        optionsOut->expectedFailureFiles.getCount() > 0)
    {
        stdOut.print("Expected failure lists:\n");
        for (const auto& fileInfo : optionsOut->expectedFailureFiles)
        {
            stdOut.print(" - %s : %d tests\n", fileInfo.fileName.getBuffer(), fileInfo.count);
        }
    }

    if (optionsOut->verbosity >= VerbosityLevel::Info && optionsOut->skipListFiles.getCount() > 0)
    {
        stdOut.print("Skip lists:\n");
        for (const auto& fileInfo : optionsOut->skipListFiles)
        {
            stdOut.print(" - %s : %d entries\n", fileInfo.fileName.getBuffer(), fileInfo.count);
        }
    }

    return SLANG_OK;
}
