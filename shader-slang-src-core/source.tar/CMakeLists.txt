cmake_minimum_required(VERSION 3.22)

# Our module dir, include that now so that we can get the version automatically
# from git describe
list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_LIST_DIR}/cmake")
include(GitVersion)
get_git_version(
    SLANG_VERSION_NUMERIC
    SLANG_VERSION_FULL
    "${CMAKE_CURRENT_LIST_DIR}"
)

#
# Our project
#
project(slang VERSION "${SLANG_VERSION_NUMERIC}" LANGUAGES)
set(PROJECT_VERSION "${SLANG_VERSION_FULL}")

#
# Global CMake options
#
if(${CMAKE_VERSION} VERSION_GREATER_EQUAL "3.24")
    cmake_policy(SET CMP0135 NEW)
endif()
cmake_policy(SET CMP0077 NEW)
set(CMAKE_POLICY_DEFAULT_CMP0077 NEW)
if(${CMAKE_VERSION} VERSION_GREATER_EQUAL "3.25")
    cmake_policy(SET CMP0141 NEW)
endif()
cmake_policy(SET CMP0091 NEW)

# Don't use absolute paths to the build tree in RPATH, this makes the build
# tree relocatable
set(CMAKE_BUILD_RPATH_USE_ORIGIN TRUE)

# Export the compile datebase as a json file, this can be used by VIM language server
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# Enable placing targets into a hierarchy for IDE generators
set_property(GLOBAL PROPERTY USE_FOLDERS ON)

# Default to `-Og` for Debug builds on GNU-style compilers: it enables the
# optimizations that do not interfere with debugging, producing noticeably
# faster Debug binaries while keeping a faithful step-through/inspection
# experience.
#
# The `NOT WIN32` guard excludes MSVC and clang-cl, which expect MSVC-style
# flags and have no `-Og` equivalent. `CMAKE_CXX_COMPILER_ID` is not yet known
# at this point (it is set by enable_language() below), so the platform is
# the closest available proxy. A side effect is that MinGW builds do not get
# `-Og` by default. Those users can pass `-DCMAKE_CXX_FLAGS_DEBUG="-Og -g"`
# explicitly.
#
# Note: We use `string(PREPEND ...)` rather than `set(...)`: a
# toolchain file is processed by the `project()` call above, and some
# toolchains seed these same `_INIT` variables. Prepending keeps
# whatever the toolchain asked for, giving precedence to the toolchain
# option definitions (e.g., optimization level).
if(NOT WIN32)
    string(PREPEND CMAKE_C_FLAGS_DEBUG_INIT "-Og ")
    string(PREPEND CMAKE_CXX_FLAGS_DEBUG_INIT "-Og ")
endif()

#
# CMake-supplied modules and our utils
#
enable_language(C CXX)

include(FindPackageHandleStandardArgs)
include(CMakeDependentOption)
include(GNUInstallDirs)

include(CCacheDebugInfoWorkaround)
include(CompilerFlags)
include(Glob)
include(LLVM)
include(SlangTarget)
include(AutoOption)
include(GitHubRelease)
include(FetchedSharedLibrary)
include(CheckSecureCRT)

#
# Options
#

auto_option(
    SLANG_ENABLE_CUDA
    CUDAToolkit
    "Enable CUDA tests using CUDA found in CUDA_PATH"
)
# Check if SLANG_ENABLE_OPTIX was explicitly set by user before auto_option
set(_SLANG_ENABLE_OPTIX_USER_SPECIFIED FALSE)
get_property(
    _SLANG_ENABLE_OPTIX_CACHE_TYPE
    CACHE SLANG_ENABLE_OPTIX
    PROPERTY TYPE
)
if(
    DEFINED SLANG_ENABLE_OPTIX
    AND NOT SLANG_ENABLE_OPTIX STREQUAL "AUTO"
    AND _SLANG_ENABLE_OPTIX_CACHE_TYPE STREQUAL "BOOL"
)
    set(_SLANG_ENABLE_OPTIX_USER_SPECIFIED TRUE)
endif()

auto_option(
    SLANG_ENABLE_OPTIX
    OptiX
    "Enable OptiX build/tests, requires SLANG_ENABLE_CUDA"
)
auto_option(
    SLANG_ENABLE_NVAPI
    NVAPI
    "Enable NVAPI usage (Only available for builds targeting Windows)"
)
if(CMAKE_SYSTEM_NAME MATCHES "Linux")
    auto_option(
        SLANG_ENABLE_XLIB
        X11
        "Build gfx and platform with Xlib to support windowed apps on Linux"
    )
else()
    set(SLANG_ENABLE_XLIB OFF)
endif()
auto_option(
    SLANG_ENABLE_AFTERMATH
    Aftermath
    "Enable Aftermath in GFX, and add aftermath crash example to project"
)
advanced_option(
    SLANG_ENABLE_DX_ON_VK
    "Use dxvk and vkd3d-proton for DirectX support"
    OFF
)
advanced_option(SLANG_ENABLE_SLANG_RHI "Use slang-rhi as dependency" ON)

option(
    SLANG_EMBED_CORE_MODULE_SOURCE
    "Embed core module source in the binary"
    ON
)
option(
    SLANG_EMBED_CORE_MODULE
    "Build slang with an embedded version of the core module"
    ON
)

option(SLANG_ENABLE_DXIL "Enable generating DXIL with DXC" ON)

option(SLANG_ENABLE_VALIDATION_IR "Enable full IR validation (SLOW!)")
option(SLANG_ENABLE_VALIDATION_VM_BYTECODE "Enable VM bytecode validation" ON)
option(
    SLANG_ENABLE_VALIDATION_FOSSIL
    "Enable fossil deserialization validation"
)
option(SLANG_ENABLE_IR_BREAK_ALLOC "Enable _debugUID on IR allocation")
option(
    SLANG_IGNORE_ABORT_MSG
    "Ignore the system modal assert dialog while running build tools to help LLM workflow."
    OFF
)
if(SLANG_IGNORE_ABORT_MSG)
    add_compile_definitions(SLANG_IGNORE_ABORT_MSG=1)
endif()
option(
    SLANG_ENABLE_ASAN
    "Enable AddressSanitizer (ASan), and UndefinedBehaviorSanitizer (UBSan) if available as well"
)
option(
    SLANG_ENABLE_TSAN
    "Enable ThreadSanitizer (TSan); clang/gcc on non-Windows only. Mutually exclusive with SLANG_ENABLE_ASAN."
)
# The compiler driver rejects combining -fsanitize=address and -fsanitize=thread,
# so a build with both options enabled would otherwise fail at compile time on
# the first instrumented file. Reject the combination here at configure time to
# fail fast with a clear message instead.
if(SLANG_ENABLE_ASAN AND SLANG_ENABLE_TSAN)
    message(
        FATAL_ERROR
        "SLANG_ENABLE_ASAN and SLANG_ENABLE_TSAN are mutually exclusive; enable at most one."
    )
endif()
# ThreadSanitizer has no Windows implementation in clang-cl, MinGW, or MSVC.
# Reject it here alongside the mutual-exclusion check so both SLANG_ENABLE_TSAN
# constraints fail fast at configure time in one place, rather than surfacing
# later during per-target setup.
if(SLANG_ENABLE_TSAN AND WIN32)
    message(FATAL_ERROR "SLANG_ENABLE_TSAN is not supported on Windows.")
endif()
option(SLANG_ENABLE_COVERAGE "Enable code coverage instrumentation")
option(
    SLANG_ENABLE_TIME_TRACE
    "Enable Clang time trace profiling for build analysis"
)
option(SLANG_ENABLE_PCH "Enable precompiled headers for faster builds" ON)

option(
    SLANG_STANDARD_MODULE_DEVELOP_BUILD
    "Enable development build for standard modules (enables UNIT_TEST macro). Disable for release builds."
    ON
)
set(SLANG_DISABLE_NOTE_IDS
    ""
    CACHE STRING
    "Comma-separated note IDs disabled by runtime sessions and module builds"
)

option(SLANG_ENABLE_GFX "Enable gfx targets" ON)
option(
    SLANG_BUILD_MONOLITHIC_STANDARD_MODULE_LIBRARY
    "Build and install all standard modules in one shared library separate from the compiler, instead of loose module files"
    OFF
)
option(SLANG_ENABLE_SLANGD "Enable language server target" ON)
option(SLANG_ENABLE_SLANGC "Enable standalone compiler target" ON)
option(SLANG_ENABLE_SLANGI "Enable Slang interpreter target" ON)
option(SLANG_ENABLE_SLANGRT "Enable runtime target" ON)
option(
    SLANG_ENABLE_SLANG_GLSLANG
    "Enable glslang dependency and slang-glslang wrapper target"
    ON
)
option(
    SLANG_ENABLE_SLANG_PROXY
    "Build the legacy slang.dll proxy and libslang symlink backward-compatibility outputs for slang-compiler"
    ON
)
option(
    SLANG_ENABLE_TESTS
    "Enable test targets, some tests may require SLANG_ENABLE_SLANG_RHI, SLANG_ENABLE_SLANGD or SLANG_ENABLE_SLANGRT"
    ON
)
option(
    SLANG_ENABLE_EXAMPLES
    "Enable example targets (most require SLANG_ENABLE_SLANG_RHI)"
    ON
)
option(SLANG_ENABLE_REPLAYER "Enable slang-replay tool" ON)
option(
    SLANG_ENABLE_RECORD_REPLAY
    "Build the API record-replay layer and its slang_*RecordLayer/*Replay C API. When OFF, the record-replay sources are excluded and that C API is compiled as exported disabled stubs (ABI preserved)."
    ON
)

# The slang-replay tool links the record-replay subsystem, so it cannot be built once that
# subsystem is excluded. Force it off (rather than erroring) so an existing SLANG_ENABLE_REPLAYER=ON
# cache entry does not make the two options contradict each other.
if(NOT SLANG_ENABLE_RECORD_REPLAY AND SLANG_ENABLE_REPLAYER)
    message(
        STATUS
        "SLANG_ENABLE_RECORD_REPLAY is OFF; forcing SLANG_ENABLE_REPLAYER OFF (the slang-replay tool depends on the record-replay subsystem)."
    )
    set(SLANG_ENABLE_REPLAYER OFF CACHE BOOL "Enable slang-replay tool" FORCE)
endif()

advanced_option(SLANG_USE_SYSTEM_MINIZ "Build using system Miniz library" OFF)
advanced_option(SLANG_USE_SYSTEM_LZ4 "Build using system LZ4 library" OFF)
advanced_option(SLANG_USE_SYSTEM_LUA "Build slang-fiddle using system Lua" OFF)
advanced_option(
    SLANG_USE_SYSTEM_VULKAN_HEADERS
    "Build using system Vulkan headers"
    OFF
)
advanced_option(
    SLANG_USE_SYSTEM_SPIRV_HEADERS
    "Build using system SPIR-V headers"
    OFF
)
advanced_option(
    SLANG_USE_SYSTEM_UNORDERED_DENSE
    "Build using system unordered dense"
    OFF
)
advanced_option(
    SLANG_USE_SYSTEM_SPIRV_TOOLS
    "Build using system SPIR-V tools library"
    OFF
)
advanced_option(
    SLANG_USE_SYSTEM_GLSLANG
    "Build using system glslang library"
    OFF
)
if(WIN32)
    set(SLANG_ENABLE_SPIRV_TOOLS_MIMALLOC_DEFAULT ON)
else()
    set(SLANG_ENABLE_SPIRV_TOOLS_MIMALLOC_DEFAULT OFF)
endif()

advanced_option(
    SLANG_ENABLE_SPIRV_TOOLS_MIMALLOC
    "Enable mimalloc for SPIRV-Tools to improve compilation performance"
    ${SLANG_ENABLE_SPIRV_TOOLS_MIMALLOC_DEFAULT}
)

option(
    SLANG_SPIRV_HEADERS_INCLUDE_DIR
    "Provide a specific path for the SPIR-V headers and grammar files"
)
mark_as_advanced(SLANG_SPIRV_HEADERS_INCLUDE_DIR)

# Options for user defined paths for external modules.
#
# Note that these paths point to a directory containing an subdirectory of the
# dependency name, rather than to the dependency directory itself, for example
# SLANG_OVERRIDE_LZ4_PATH points to a directory containing a directory called
# `lz4` containing the lz4 source.
#
advanced_option(
    SLANG_OVERRIDE_LZ4_PATH
    "Build using user defined path for LZ4"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_MINIZ_PATH
    "Build using user defined path for Miniz"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_UNORDERED_DENSE_PATH
    "Build using user defined path for unordered_dense"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_VULKAN_HEADERS_PATH
    "Build using user defined path for Vulkan headers"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_SPIRV_HEADERS_PATH
    "Build using user defined path for SPIR-V headers"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_SPIRV_TOOLS_PATH
    "Build using user defined path for SPIR-V tools"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_GLSLANG_PATH
    "Build using user defined path for glslang"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_GLM_PATH
    "Build using user defined path for glm"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_IMGUI_PATH
    "Build using user defined path for imgui"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_SLANG_RHI_PATH
    "Build using user defined path for slang-rhi"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_TINYOBJLOADER_PATH
    "Build using user defined path for tinyobjloader"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_LUA_PATH
    "Build using user defined path for lua"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_MIMALLOC_PATH
    "Build using user defined path for mimalloc"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_CMARK_PATH
    "Build using user defined path for cmark"
    OFF
)
advanced_option(
    SLANG_OVERRIDE_FAST_FLOAT_PATH
    "Build using user defined path for fast_float"
    OFF
)

set(SLANG_EXCLUDE_DAWN_DEFAULT ON)
if(CMAKE_SYSTEM_NAME STREQUAL "Windows")
    set(SLANG_EXCLUDE_DAWN_DEFAULT OFF)
endif()
advanced_option(
    SLANG_EXCLUDE_DAWN
    "Optionally exclude Dawn WebGPU support from the build"
    ${SLANG_EXCLUDE_DAWN_DEFAULT}
)
set(SLANG_HAS_WEBGPU_SUPPORT OFF)
if(NOT SLANG_EXCLUDE_DAWN)
    set(SLANG_HAS_WEBGPU_SUPPORT ON)
endif()

advanced_option(
    SLANG_EXCLUDE_TINT
    "Optionally exclude slang-tint from the build"
    OFF
)

enum_option(
    SLANG_LIB_TYPE
    # Default
    SHARED
    "How to build the slang-compiler lib:"
    # Options
    SHARED
    "Build slang-compiler as a shared library (default)"
    STATIC
    "Build slang-compiler as a static library"
)

set(SLANG_ENABLE_MIMALLOC_DEFAULT OFF)
if(
    WIN32
    AND CMAKE_CXX_COMPILER_ID STREQUAL "MSVC"
    AND SLANG_LIB_TYPE STREQUAL "SHARED"
    AND NOT SLANG_ENABLE_ASAN
)
    set(SLANG_ENABLE_MIMALLOC_DEFAULT ON)
endif()
advanced_option(
    SLANG_ENABLE_MIMALLOC
    "Use mimalloc for Slang-owned allocations"
    ${SLANG_ENABLE_MIMALLOC_DEFAULT}
)
if(SLANG_ENABLE_MIMALLOC AND SLANG_ENABLE_ASAN)
    message(
        WARNING
        "SLANG_ENABLE_MIMALLOC is enabled with SLANG_ENABLE_ASAN, but this mimalloc configuration does not enable ASan tracking"
    )
endif()
if(SLANG_ENABLE_MIMALLOC AND SLANG_ENABLE_TSAN)
    message(
        WARNING
        "SLANG_ENABLE_MIMALLOC is enabled with SLANG_ENABLE_TSAN, but this mimalloc configuration is not built with TSan instrumentation (MI_DEBUG_TSAN), so data races inside mimalloc's own allocator are not detected"
    )
endif()

option(
    SLANG_ENABLE_RELEASE_DEBUG_INFO
    "Generate debug info for Release builds"
    ON
)

option(SLANG_ENABLE_RELEASE_LTO "Enable LTO for Release builds" OFF)

enum_option(
    SLANG_INSTALL_USER_SKILLS
    AUTO
    "Whether to install the pinned Slang user skills:"
    AUTO
    "Install them when the exact, clean submodule checkout is available"
    ON
    "Require and install the exact, clean submodule checkout"
    OFF
    "Do not install Slang user skills"
)

option(
    SLANG_ENABLE_SPLIT_DEBUG_INFO
    "Generate split debug info for debug builds"
    ON
)

set(SLANG_GENERATORS_PATH
    ""
    CACHE PATH
    "An optional path to the outputs of the all-generators target compiled for the build platform, used when cross-compiling"
)

enum_option(
    SLANG_SLANG_LLVM_FLAVOR
    # Default
    FETCH_BINARY_IF_POSSIBLE
    "How to get or build slang-llvm:"
    # Options
    FETCH_BINARY
    "Use a binary distribution of the slang-llvm library instead of building or using LLVM"
    FETCH_BINARY_IF_POSSIBLE
    "Like FETCH_BINARY, except falls back to DISABLE if a prebuilt slang-llvm can't be downloaded"
    USE_SYSTEM_LLVM
    "Build slang-llvm using system-provided LLVM and Clang binaries"
    DISABLE
    "Do not build llvm or fetch slang-llvm"
)

if(SLANG_SLANG_LLVM_FLAVOR MATCHES FETCH_BINARY)
    # If the user didn't specify a URL, find the best one now
    if(NOT SLANG_SLANG_LLVM_BINARY_URL)
        get_best_slang_binary_release_url(url)
        if(NOT DEFINED url)
            if(SLANG_SLANG_LLVM_FLAVOR STREQUAL FETCH_BINARY_IF_POSSIBLE)
                message(
                    WARNING
                    "Unable to find a prebuilt binary for slang-llvm, Slang will be built without LLVM support. Please consider setting SLANG_SLANG_LLVM_BINARY_URL manually"
                )
            else()
                message(
                    FATAL_ERROR
                    "Unable to find binary release for slang-llvm, please set a different SLANG_SLANG_LLVM_FLAVOR or set SLANG_SLANG_LLVM_BINARY_URL manually"
                )
            endif()
        endif()
    endif()
    set(SLANG_SLANG_LLVM_BINARY_URL
        ${url}
        CACHE STRING
        "URL specifying the location of the slang-llvm prebuilt library"
    )
endif()

if(SLANG_HAS_WEBGPU_SUPPORT)
    if(NOT DEFINED SLANG_WEBGPU_DAWN_BINARY_URL)
        set(webgpu_dawn_release_tag "webgpu_dawn-0")
        if(
            CMAKE_SYSTEM_NAME MATCHES "Windows"
            AND CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|amd64|AMD64"
        )
            set(SLANG_WEBGPU_DAWN_BINARY_URL
                "https://github.com/shader-slang/dawn/releases/download/${webgpu_dawn_release_tag}/webgpu_dawn-windows-x64.zip"
            )
        endif()
    endif()
endif()

if(NOT SLANG_EXCLUDE_TINT)
    if(NOT DEFINED SLANG_SLANG_TINT_BINARY_URL)
        set(slang_tint_release_tag "slang-tint-0")
        if(
            CMAKE_SYSTEM_NAME MATCHES "Windows"
            AND CMAKE_SYSTEM_PROCESSOR MATCHES "x86_64|amd64|AMD64"
        )
            set(SLANG_SLANG_TINT_BINARY_URL
                "https://github.com/shader-slang/dawn/releases/download/${slang_tint_release_tag}/slang-tint-windows-x64.zip"
            )
        endif()
    endif()
endif()

#
# sccache support
#
# Enable sccache as the compiler launcher for faster rebuilds. Can be activated
# via -DSLANG_USE_SCCACHE=ON or by setting the SLANG_USE_SCCACHE environment
# variable to a truthy value. When enabled, precompiled headers are automatically
# disabled due to a known incompatibility that causes linker errors.
#
option(
    SLANG_USE_SCCACHE
    "Use sccache as compiler launcher for faster rebuilds"
    OFF
)
if(NOT CMAKE_C_COMPILER_LAUNCHER AND NOT CMAKE_CXX_COMPILER_LAUNCHER)
    if(
        NOT SLANG_USE_SCCACHE
        AND DEFINED ENV{SLANG_USE_SCCACHE}
        AND "$ENV{SLANG_USE_SCCACHE}"
    )
        set(SLANG_USE_SCCACHE ON CACHE BOOL "" FORCE)
    endif()
    if(SLANG_USE_SCCACHE)
        find_program(SCCACHE_PROGRAM sccache)
        if(SCCACHE_PROGRAM)
            message(STATUS "Using sccache: ${SCCACHE_PROGRAM}")
            set(CMAKE_C_COMPILER_LAUNCHER "${SCCACHE_PROGRAM}")
            set(CMAKE_CXX_COMPILER_LAUNCHER "${SCCACHE_PROGRAM}")
            # Re-run the MSVC debug-info workaround now that the launcher is set
            include(CCacheDebugInfoWorkaround)
            # Disable PCH: sccache + PCH causes linker errors
            if(SLANG_ENABLE_PCH)
                message(
                    STATUS
                    "Disabling precompiled headers (incompatible with sccache)"
                )
                set(SLANG_ENABLE_PCH OFF CACHE BOOL "" FORCE)
            endif()
        else()
            message(
                WARNING
                "SLANG_USE_SCCACHE is ON but sccache was not found in PATH"
            )
        endif()
    endif()
endif()

#
# Option validation
#

if(NOT SLANG_EMBED_CORE_MODULE AND NOT SLANG_EMBED_CORE_MODULE_SOURCE)
    message(
        SEND_ERROR
        "One of SLANG_EMBED_CORE_MODULE and SLANG_EMBED_CORE_MODULE_SOURCE must be enabled"
    )
endif()

if(SLANG_ENABLE_OPTIX AND NOT SLANG_ENABLE_CUDA)
    if(_SLANG_ENABLE_OPTIX_USER_SPECIFIED)
        message(
            SEND_ERROR
            "SLANG_ENABLE_OPTIX is not supported without SLANG_ENABLE_CUDA"
        )
    else()
        message(
            STATUS
            "OptiX is not supported without CUDA. Automatically disabling SLANG_ENABLE_OPTIX."
        )
        set(SLANG_ENABLE_OPTIX OFF)
    endif()
endif()

if(SLANG_ENABLE_NVAPI AND NOT CMAKE_SYSTEM_NAME MATCHES "Windows")
    message(SEND_ERROR "SLANG_ENABLE_NVAPI is only supported on Windows")
endif()

if(SLANG_ENABLE_TESTS AND NOT SLANG_ENABLE_SLANG_RHI)
    message(SEND_ERROR "SLANG_ENABLE_TESTS requires SLANG_ENABLE_SLANG_RHI")
endif()

#
# Dependencies, most of these are however handled inside the "auto_option"
# calls above
#

find_package(Threads REQUIRED)

if(${SLANG_USE_SYSTEM_UNORDERED_DENSE})
    find_package(unordered_dense CONFIG QUIET)
endif()

if(SLANG_USE_SYSTEM_SPIRV_HEADERS)
    find_package(SPIRV-Headers REQUIRED)
endif()

if(${SLANG_USE_SYSTEM_MINIZ})
    find_package(miniz REQUIRED)
    if(NOT TARGET miniz)
        add_library(miniz ALIAS miniz::miniz)
    endif()
endif()

if(${SLANG_USE_SYSTEM_LZ4})
    find_package(lz4 CONFIG QUIET)
    if(NOT TARGET LZ4::lz4 AND NOT TARGET lz4_static)
        # Homebrew's LZ4 exposes pkg-config metadata but no CMake package.
        find_package(PkgConfig REQUIRED)
        pkg_check_modules(LZ4 REQUIRED IMPORTED_TARGET GLOBAL liblz4)
    endif()
    if(NOT TARGET lz4_static)
        if(TARGET LZ4::lz4)
            add_library(lz4_static ALIAS LZ4::lz4)
        else()
            add_library(lz4_static ALIAS PkgConfig::LZ4)
        endif()
    endif()
endif()

if(${SLANG_USE_SYSTEM_VULKAN_HEADERS})
    find_package(VulkanHeaders REQUIRED)
endif()

if(${SLANG_USE_SYSTEM_SPIRV_TOOLS})
    # The wrapper links the opt and link libraries, which are separate CMake packages.
    find_package(SPIRV-Tools REQUIRED)
    find_package(SPIRV-Tools-opt REQUIRED)
    find_package(SPIRV-Tools-link REQUIRED)
endif()

if(${SLANG_USE_SYSTEM_GLSLANG})
    find_package(glslang REQUIRED)
    if(
        NOT SLANG_USE_SYSTEM_SPIRV_TOOLS
        AND (TARGET SPIRV-Tools-opt OR TARGET SPIRV-Tools-link)
    )
        message(
            FATAL_ERROR
            "The installed glslang package imports SPIRV-Tools targets; set SLANG_USE_SYSTEM_SPIRV_TOOLS=ON to avoid conflicting with bundled targets"
        )
    endif()
    if(NOT TARGET glslang)
        add_library(glslang ALIAS glslang::glslang)
    endif()
    if(NOT TARGET SPIRV)
        # Keep the wrapper's target name while using the installed glslang library location.
        add_library(SPIRV ALIAS glslang::SPIRV)
    endif()
endif()

if(SLANG_ENABLE_DXIL)
    include(FetchDXC)
endif()

add_subdirectory(external)

# webgpu_dawn is only available as a fetched shared library, since Dawn's nested source
# trees are too large and onerous for us to depend on.
# We ignore the failure to fetch the library, since it's not required for the build to succeed.
if(SLANG_WEBGPU_DAWN_BINARY_URL)
    copy_fetched_shared_library(
        "webgpu_dawn"
        "${SLANG_WEBGPU_DAWN_BINARY_URL}"
        IGNORE_FAILURE
    )
endif()

# slang-tint is only available as a fetched shared library, since it's hosted in the Dawn
# repository, and Dawn's nested source trees are too large and onerous for us to depend
# on.
# We ignore the failure to fetch the library, since it's not required for the build to succeed.
if(SLANG_SLANG_TINT_BINARY_URL)
    copy_fetched_shared_library(
        "slang-tint"
        "${SLANG_SLANG_TINT_BINARY_URL}"
        IGNORE_FAILURE
    )
endif()

fetch_or_build_slang_llvm()

# slang-glslang gets mimalloc only through SPIRV-Tools-opt, and an overridden or system
# SPIRV-Tools-opt may not link it, so we decide from SPIRV-Tools-opt's actual link dependencies.
# We read INTERFACE_LINK_LIBRARIES because it is what slang-glslang inherits, and an imported
# SPIRV-Tools-opt has no LINK_LIBRARIES. A static SPIRV-Tools-opt records its private mimalloc
# dependency there as $<LINK_ONLY:mimalloc-static>; a shared one keeps mimalloc inside its own DLL.
set(SLANG_GLSLANG_USES_MIMALLOC OFF)
if(WIN32 AND TARGET SPIRV-Tools-opt AND TARGET mimalloc-static)
    get_target_property(
        _spirv_tools_opt_interface
        SPIRV-Tools-opt
        INTERFACE_LINK_LIBRARIES
    )
    if(
        mimalloc-static IN_LIST _spirv_tools_opt_interface
        OR "$<LINK_ONLY:mimalloc-static>" IN_LIST _spirv_tools_opt_interface
    )
        set(SLANG_GLSLANG_USES_MIMALLOC ON)
    endif()
endif()

#
# Our targets
#

add_subdirectory(source/core)
add_subdirectory(source/slang-rt)
add_subdirectory(source/compiler-core)
add_subdirectory(source/slang-wasm)
add_subdirectory(source/slang-glslang)
add_subdirectory(tools)
add_subdirectory(prelude)
add_subdirectory(source/slang-core-module)
add_subdirectory(source/slang-glsl-module)
add_subdirectory(source/slang)
add_subdirectory(source/slangc)
if(TARGET slangc)
    # Keep DXC runtime artifacts and headers staged for targeted slangc builds.
    foreach(_dxc_stage_target copy-dxcompiler copy-dxil stage-dxc-headers)
        if(TARGET ${_dxc_stage_target})
            add_dependencies(slangc ${_dxc_stage_target})
        endif()
    endforeach()
endif()
add_subdirectory(source/slang-dispatcher)
add_subdirectory(source/standard-modules)
if(SLANG_BUILD_MONOLITHIC_STANDARD_MODULE_LIBRARY)
    # Optional single-library packaging of the standard modules. Added after
    # standard-modules so the SLANG_STANDARD_MODULE_FILES manifest it depends on
    # is already populated.
    add_subdirectory(source/slang-monolithic-standard-module-library)
endif()
add_subdirectory(examples)

#
# Packaging
#
set(CPACK_ARCHIVE_COMPONENT_INSTALL ON)
set(CPACK_COMPONENTS_ALL_IN_ONE_PACKAGE ON)
set(CPACK_STRIP_FILES FALSE)
install(
    FILES "${slang_SOURCE_DIR}/README.md" "${slang_SOURCE_DIR}/LICENSE"
    DESTINATION .
    COMPONENT metadata
    EXCLUDE_FROM_ALL
)
install(
    DIRECTORY "${slang_SOURCE_DIR}/LICENSES"
    DESTINATION .
    COMPONENT metadata
    EXCLUDE_FROM_ALL
    PATTERN ".*" EXCLUDE
)

# The vendored deps below are statically linked into the shipped libraries, and
# their licenses -- BSD-2-Clause (cmark, lz4) and glslang's mixed
# BSD/MIT/Apache-2.0 license (see external/README.md) -- require reproducing the
# copyright notice in binary redistributions. Ship each one's own notice file
# (its real COPYING/LICENSE, which carries the copyright lines a generic SPDX
# template omits). Each condition mirrors the source selection in
# external/CMakeLists.txt, installing the notice only when the vendored
# submodule -- not a system copy or an override path -- is the source we build
# against; a missing notice file then fails the install loudly rather than
# silently shipping a non-compliant package.
if(NOT SLANG_OVERRIDE_CMARK_PATH)
    install(
        FILES "${slang_SOURCE_DIR}/external/cmark/COPYING"
        DESTINATION third-party-notices
        RENAME cmark-COPYING
        COMPONENT metadata
        EXCLUDE_FROM_ALL
    )
endif()
if(NOT SLANG_USE_SYSTEM_LZ4 AND NOT SLANG_OVERRIDE_LZ4_PATH)
    install(
        FILES "${slang_SOURCE_DIR}/external/lz4/lib/LICENSE"
        DESTINATION third-party-notices
        RENAME lz4-LICENSE
        COMPONENT metadata
        EXCLUDE_FROM_ALL
    )
endif()
if(
    SLANG_ENABLE_SLANG_GLSLANG
    AND NOT SLANG_USE_SYSTEM_GLSLANG
    AND NOT SLANG_OVERRIDE_GLSLANG_PATH
)
    install(
        FILES "${slang_SOURCE_DIR}/external/glslang/LICENSE.txt"
        DESTINATION third-party-notices
        RENAME glslang-LICENSE.txt
        COMPONENT metadata
        EXCLUDE_FROM_ALL
    )
endif()

# The vendored deps below are MIT-licensed (miniz, mimalloc, unordered_dense)
# or Apache-2.0-licensed (spirv-tools), and are likewise statically linked
# into the shipped libraries -- miniz and unordered_dense unconditionally
# into `core`, mimalloc when Slang-owned allocations or SPIRV-Tools request
# it, and spirv-tools when glslang support is built. MIT's license-and-
# copyright-notice clause and Apache-2.0's attribution-retention requirement
# (Apache-2.0 SS4; spirv-tools carries no upstream NOTICE file, so SS4(d)'s
# NOTICE-carry clause does not apply here) both require reproducing the
# dependency's own notice in binary redistributions, same as the BSD trio
# above. Each condition again mirrors the source selection in
# external/CMakeLists.txt.
if(NOT SLANG_USE_SYSTEM_MINIZ AND NOT SLANG_OVERRIDE_MINIZ_PATH)
    install(
        FILES "${slang_SOURCE_DIR}/external/miniz/LICENSE"
        DESTINATION third-party-notices
        RENAME miniz-LICENSE
        COMPONENT metadata
        EXCLUDE_FROM_ALL
    )
endif()
if(
    NOT SLANG_USE_SYSTEM_UNORDERED_DENSE
    AND NOT SLANG_OVERRIDE_UNORDERED_DENSE_PATH
)
    install(
        FILES "${slang_SOURCE_DIR}/external/unordered_dense/LICENSE"
        DESTINATION third-party-notices
        RENAME unordered_dense-LICENSE
        COMPONENT metadata
        EXCLUDE_FROM_ALL
    )
endif()
if(
    (
        SLANG_ENABLE_MIMALLOC
        OR (
            SLANG_ENABLE_SLANG_GLSLANG
            AND NOT SLANG_USE_SYSTEM_SPIRV_TOOLS
            AND SLANG_ENABLE_SPIRV_TOOLS_MIMALLOC
        )
    )
    AND NOT SLANG_OVERRIDE_MIMALLOC_PATH
)
    install(
        FILES "${slang_SOURCE_DIR}/external/mimalloc/LICENSE"
        DESTINATION third-party-notices
        RENAME mimalloc-LICENSE
        COMPONENT metadata
        EXCLUDE_FROM_ALL
    )
endif()
if(
    SLANG_ENABLE_SLANG_GLSLANG
    AND NOT SLANG_USE_SYSTEM_SPIRV_TOOLS
    AND NOT SLANG_OVERRIDE_SPIRV_TOOLS_PATH
)
    install(
        FILES "${slang_SOURCE_DIR}/external/spirv-tools/LICENSE"
        DESTINATION third-party-notices
        RENAME spirv-tools-LICENSE
        COMPONENT metadata
        EXCLUDE_FROM_ALL
    )
endif()

install(
    DIRECTORY "${slang_SOURCE_DIR}/docs/"
    DESTINATION share/doc/slang
    PATTERN ".*" EXCLUDE
)
install(
    DIRECTORY "${slang_SOURCE_DIR}/include"
    DESTINATION .
    PATTERN ".*" EXCLUDE
)
include(SlangUserSkills)
slang_install_user_skills()
include(CPack)

# Write basic package config version file using standard CMakePackageConfigHelpers utility
include(CMakePackageConfigHelpers)
write_basic_package_version_file(
    "${PROJECT_NAME}ConfigVersion.cmake"
    VERSION ${PROJECT_VERSION}
    COMPATIBILITY SameMajorVersion
)

# Write SlangConfig.cmake which should allow find_package(SLANG) to work correctly
# SlangConfig.cmake will define slang::slang target that can be linked with using
# target_link_libraries. It will also define SLANG_EXECUTABLE export variable that
# should point to slangc if SLANG_ENABLE_SLANGC is ON.
if(WIN32)
    set(SLANG_CMAKE_CONFIG_DIR cmake)
else()
    set(SLANG_CMAKE_CONFIG_DIR ${CMAKE_INSTALL_LIBDIR}/cmake/${PROJECT_NAME})
endif()
configure_package_config_file(
    "${PROJECT_SOURCE_DIR}/cmake/SlangConfig.cmake.in"
    "${PROJECT_BINARY_DIR}/${PROJECT_NAME}Config.cmake"
    INSTALL_DESTINATION ${SLANG_CMAKE_CONFIG_DIR}
)

# Conditionally handle the case for Emscripten where slang does not create
# linkable targets. In this case do not export the targets. Otherwise, just
# export the slang targets.
#
# A STATIC build used to be excluded here because slang's internal link
# dependencies (core, prelude, compiler-core, slang-capability-*,
# slang-lookup-tables, SPIRV-Headers, ...) leaked onto its public link
# interface and weren't in any export set, which made install(EXPORT ...) fail
# (see issue #5821 / PR #6158). slang_add_target now wraps private link deps in
# $<BUILD_LOCAL_INTERFACE:...> / $<BUILD_INTERFACE:...> (cmake/SlangTarget.cmake),
# so those targets no longer appear in the install/export interface and a static
# install exports cleanly. Exporting also for STATIC keeps SlangConfig.cmake's
# unconditional include() of slangTargets.cmake (cmake/SlangConfig.cmake.in)
# satisfied, so find_package(slang) works for static installs too.
if(NOT CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
    install(
        EXPORT SlangTargets
        FILE ${PROJECT_NAME}Targets.cmake
        NAMESPACE ${PROJECT_NAME}::
        DESTINATION ${SLANG_CMAKE_CONFIG_DIR}
    )

    # The pkgconfig file stays gated on non-STATIC builds. Unlike the CMake
    # export above, extras/pkgconfig/slang-compiler.pc.in cannot describe a
    # static link: it lists only `-lslang-compiler` and leaves Libs.private
    # empty (it explicitly documents that `pkg-config --static` is unsupported).
    # Installing it for a STATIC build would hand downstream users a link line
    # that omits every transitive internal archive (core, compiler-core,
    # slang-capability-*, slang-lookup-tables, bundled miniz/lz4, ...), causing
    # unresolved-symbol errors at link time. Static consumers should use
    # find_package(slang) instead, which the export above now supports.
    if(UNIX AND NOT ${SLANG_LIB_TYPE} STREQUAL "STATIC")
        configure_file(
            "${PROJECT_SOURCE_DIR}/extras/pkgconfig/slang-compiler.pc.in"
            "${PROJECT_BINARY_DIR}/slang-compiler.pc"
            @ONLY
        )

        # TODO: When build system is changed to respect CMAKE_INSTALL_LIBDIR,
        # update this destination.
        install(
            FILES "${PROJECT_BINARY_DIR}/slang-compiler.pc"
            DESTINATION "lib/pkgconfig"
        )
    endif()
endif()

install(
    FILES
        "${PROJECT_BINARY_DIR}/${PROJECT_NAME}Config.cmake"
        "${PROJECT_BINARY_DIR}/${PROJECT_NAME}ConfigVersion.cmake"
    DESTINATION ${SLANG_CMAKE_CONFIG_DIR}
)
