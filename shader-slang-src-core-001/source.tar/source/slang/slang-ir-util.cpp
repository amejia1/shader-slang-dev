#include "slang-ir-util.h"

#include "core/slang-short-list.h"
#include "slang-ir-clone.h"
#include "slang-ir-dce.h"
#include "slang-ir-dominators.h"
#include "slang-ir-insts.h"
#include "slang-rich-diagnostics.h"

namespace Slang
{

// Share the struct-field traversal while allowing callers to choose which field types disappear.
// DCE's existing query ignores only void and nested empty structs. Payload boundaries also need
// arrays of empty elements, but must preserve target-intrinsic types even when they have no fields.
static bool isStructEmpty(IRType* type, bool (*isEmptyFieldType)(IRType*))
{
    auto structType = as<IRStructType>(type);
    if (!structType)
        return false;

    for (auto field : structType->getFields())
    {
        if (!isEmptyFieldType(field->getFieldType()))
            return false;
    }
    return true;
}

// Keep DCE's historical field classification independent of the broader payload query.
static bool isVoidOrEmptyStruct(IRType* type)
{
    return as<IRVoidType>(type) || isStructEmpty(type);
}

bool isStructEmpty(IRType* type)
{
    return isStructEmpty(type, isVoidOrEmptyStruct);
}

bool isEmptyType(IRType* type)
{
    if (type->findDecoration<IRTargetIntrinsicDecoration>())
        return false;
    if (as<IRVoidType>(type))
        return true;
    if (auto arrayType = as<IRArrayTypeBase>(type))
        return isEmptyType(arrayType->getElementType());

    // Only ordinary structs and arrays recurse. Pointers, resources, and opaque work-graph
    // record types carry their own representation even when their element type is empty.
    return isStructEmpty(type, isEmptyType);
}

bool doesInstOnlyDependOnOperandTypes(IRInst* inst)
{
    // Some static type queries take a runtime value and inspect only its static type. Others
    // compare types directly or query their layout. We enumerate both forms so that value-use
    // analyses can ignore their operands while conservatively treating every unlisted instruction
    // as a value use.
    switch (inst->getOp())
    {
    case kIROp_IsBool:
    case kIROp_IsInt:
    case kIROp_IsUnsignedInt:
    case kIROp_IsSignedInt:
    case kIROp_IsHalf:
    case kIROp_IsFloat:
    case kIROp_IsCoopFloat:
    case kIROp_IsVector:
    case kIROp_IsBindlessTextureNVEncodable:
    case kIROp_GetNaturalStride:
    case kIROp_GetNaturalAlignment:
    case kIROp_TypeEquals:
        return true;
    default:
        return false;
    }
}

bool isSingleResourceValueType(IRInst* type)
{
    // We first remove attributed and rate wrappers. We then accept exactly the four IR type
    // families that represent one texture or typed-buffer, sampler, structured-buffer, or
    // byte-address-buffer value. Pass-specific restrictions on individual members of those
    // families belong in the caller.
    type = unwrapAttributedType(type);
    if (!type)
        return false;
    if (as<IRResourceTypeBase>(type))
        return true;
    if (as<IRSamplerStateTypeBase>(type))
        return true;
    if (as<IRHLSLStructuredBufferTypeBase>(type))
        return true;
    return as<IRByteAddressBufferTypeBase>(type) != nullptr;
}

bool isResourceValueOrArrayTypeSupportedForPerInvocationReplacement(IRInst* type)
{
    // Semantic checking admits language types in
    // `_isResourceTypeSupportedForPerInvocationReplacement` in `slang-check-decl.cpp`. This
    // predicate recognizes IR types that the replacement pass can carry. Every admitted language
    // type must lower to a type that satisfies this check after the target's selected resource-
    // and empty-type legalization passes. Recognizing an IR type here does not make its
    // corresponding language type legal in a mutable global declaration.
    //
    // We strip attributed and rate wrappers at every level because either wrapper may surround an
    // array or its element. `IRArrayType` identifies a fixed-size array; we reject
    // `IRUnsizedArrayType` without asking a separate recursive type query to infer that fact.
    for (;;)
    {
        type = unwrapAttributedType(type);
        if (!type || as<IRUnsizedArrayType>(type))
            return false;

        if (auto arrayType = as<IRArrayType>(type))
        {
            type = arrayType->getOperand(0);
            continue;
        }

        break;
    }

    // The replacement pass creates one local for the whole value in each affected function. A
    // non-entry-point function with runtime access also receives one generated parameter. We
    // therefore require a type with one target-independent value. We reject aggregate and
    // container forms, combined texture-samplers, and append or consume buffers because some
    // target pipelines split them into several values.
    if (!isSingleResourceValueType(type))
        return false;

    if (auto resourceType = as<IRResourceTypeBase>(type))
        return !resourceType->isCombined();

    switch (type->getOp())
    {
    case kIROp_HLSLAppendStructuredBufferType:
    case kIROp_HLSLConsumeStructuredBufferType:
        return false;
    default:
        return true;
    }
}

IRType* getGlobalVarValueType(IRGlobalVar* globalVar)
{
    // IR transformations may retain attributes by wrapping the pointer type of a global variable.
    // After removing those wrappers, the linked representation must contain a concrete pointer and
    // pointee type. We retain wrappers on the pointee because they remain part of the stored value.
    auto pointerType = as<IRPtrTypeBase>(unwrapAttributedType(globalVar->IRInst::getDataType()));
    SLANG_RELEASE_ASSERT(pointerType);
    auto valueType = as<IRType>(pointerType->getOperand(0));
    SLANG_RELEASE_ASSERT(valueType);
    return valueType;
}

bool isResourceGlobalCandidateForPerInvocationReplacement(IRGlobalVar* globalVar)
{
    // AST-to-IR lowering marks file- or namespace-scope mutable `static` variables and mutable
    // uniform-parameter shadows synthesized for `-Gec`. The marker records those declaration
    // categories but does not determine their storage rate. We therefore also require the absence
    // of an explicit rate. For example, `groupshared` storage is shared among threads, and
    // `actual-global` storage persists across entry-point invocations.
    if (globalVar->getRate() ||
        !globalVar->findDecoration<IRFileOrNamespaceScopeMutableVarDecoration>())
        return false;

    return isResourceValueOrArrayTypeSupportedForPerInvocationReplacement(
        getGlobalVarValueType(globalVar));
}

bool isShaderOrCudaKernelEntryPoint(IRFunc* func)
{
    return func->findDecoration<IREntryPointDecoration>() != nullptr ||
           func->findDecoration<IRCudaKernelDecoration>() != nullptr;
}

bool hasGenericAssemblyImplementation(IRFunc* func)
{
    // `IRGenericAsm` is a block terminator whose text supplies emitted target code instead of
    // ordinary instructions in that block. Translation-unit lowering has already removed
    // error-handling and `defer` terminators, so no other terminator represents generic assembly.
    for (auto block : func->getBlocks())
    {
        if (as<IRGenericAsm>(block->getTerminator()))
            return true;
    }
    return false;
}

bool isPointerOfType(IRInst* type, IROp opCode)
{
    if (auto ptrType = as<IRPtrTypeBase>(type))
    {
        return ptrType->getValueType() && ptrType->getValueType()->getOp() == opCode;
    }
    return false;
}

bool isUserPointerType(IRInst* type)
{
    auto ptrType = as<IRPtrType>(type);
    if (!ptrType)
        return false;
    return ptrType->getAddressSpace() == AddressSpace::UserPointer;
}

bool isAddressInst(IRInst* inst)
{
    switch (inst->getOp())
    {
    case kIROp_FieldAddress:
    case kIROp_GetElementPtr:
    case kIROp_GetOffsetPtr:
    case kIROp_RWStructuredBufferGetElementPtr:
    case kIROp_NodeOutputRecordGetElementPtr:
        return true;
    default:
        return false;
    }
}

bool doesUserResultTransferStorageAccessFromUse(IRUse* use)
{
    // We ask whether a later access through the user's result can transfer to or from storage
    // supplied by this exact operand use. Every supported transfer operation takes that storage in
    // operand zero; another operand may instead supply an index, a type, or a stored value.
    auto user = use->getUser();
    if (user->getOperandCount() == 0 || user->getOperandUse(0) != use)
        return false;

    // An address projection derives its result from the storage named by operand zero.
    if (isAddressInst(user))
        return true;

    switch (user->getOp())
    {
    case kIROp_GetAddress:
    case kIROp_AssumeAddress:
        // These operations expose the address represented by operand zero.
        return true;
    case kIROp_BitCast:
    case kIROp_Reinterpret:
    case kIROp_PtrCast:
    case kIROp_OutImplicitCast:
    case kIROp_InOutImplicitCast:
        // Only the pointer-to-pointer form can transfer access to operand-zero storage. An `inout`
        // cast transfers reads into its temporary and writes back; an `out` cast transfers only
        // writes back. This direction-independent predicate accepts either relation. Type
        // attributes do not change the pointer relation, so we remove them before testing it.
        return as<IRPtrTypeBase>(unwrapAttributedType(use->get()->getDataType())) != nullptr &&
               as<IRPtrTypeBase>(unwrapAttributedType(user->getDataType())) != nullptr;
    default:
        return false;
    }
}

IRInst* findCallArgumentParameterType(IRCall* call, IRUse* argumentUse)
{
    // We match the exact operand use rather than its value, because one value may be passed to
    // multiple parameters with different direction contracts. Operand zero is the callee, and the
    // remaining operands correspond positionally to the function-type parameters.
    if (argumentUse == call->getCalleeUse())
        return nullptr;

    Index argumentIndex = -1;
    for (UInt i = 0; i < call->getArgCount(); ++i)
    {
        if (call->getOperandUse(i + 1) == argumentUse)
        {
            argumentIndex = Index(i);
            break;
        }
    }
    if (argumentIndex < 0)
        return nullptr;

    // The callee's data type is the signature at this call site. It already contains generic
    // substitutions and also covers indirect function-valued callees.
    auto funcType = as<IRFuncType>(call->getCallee()->getDataType());
    if (!funcType || UInt(argumentIndex) >= funcType->getParamCount())
        return nullptr;
    // `IRFuncType::getParamType` assumes that every parameter operand derives from `IRType`.
    // Generic functions can instead use a type parameter directly as a parameter type. We only
    // need to inspect direction wrappers, so we retain the more general `IRInst*` representation.
    return unwrapAttributedType(funcType->getOperand(UInt(argumentIndex) + 1));
}

IRType* getVectorElementType(IRType* type)
{
    if (auto vectorType = as<IRVectorType>(type))
        return vectorType->getElementType();
    if (auto coopVecType = as<IRCoopVectorType>(type))
        return coopVecType->getElementType();
    if (auto coopMatType = as<IRCoopMatrixType>(type))
        return coopMatType->getElementType();
    return type;
}

IRType* getVectorOrCoopMatrixElementType(IRType* type)
{
    auto vectorElementType = getVectorElementType(type);
    if (vectorElementType != type)
        return vectorElementType;
    if (auto coopMatrixType = as<IRCoopMatrixType>(type))
        return coopMatrixType->getElementType();
    return type;
}

IRType* getMatrixElementType(IRType* type)
{
    if (auto matrixType = as<IRMatrixType>(type))
        return matrixType->getElementType();
    return type;
}

Dictionary<IRInst*, IRInst*> buildInterfaceRequirementDict(IRInterfaceType* interfaceType)
{
    Dictionary<IRInst*, IRInst*> result;
    for (UInt i = 0; i < interfaceType->getOperandCount(); i++)
    {
        auto entry = as<IRInterfaceRequirementEntry>(interfaceType->getOperand(i));
        if (!entry)
            continue;
        result[entry->getRequirementKey()] = entry->getRequirementVal();
    }
    return result;
}

bool isPointerOfType(IRInst* type, IRInst* elementType)
{
    if (auto ptrType = as<IRPtrTypeBase>(type))
    {
        return ptrType->getValueType() &&
               isTypeEqual(ptrType->getValueType(), (IRType*)elementType);
    }
    return false;
}

bool isAnnotation(IRInst* inst)
{
    return as<IRAnnotation>(inst);
}

bool isPtrToClassType(IRInst* type)
{
    return isPointerOfType(type, kIROp_ClassType);
}

bool isPtrToArrayType(IRInst* type)
{
    return isPointerOfType(type, kIROp_ArrayType) || isPointerOfType(type, kIROp_UnsizedArrayType);
}


bool isComInterfaceType(IRType* type)
{
    if (!type)
        return false;
    if (type->findDecoration<IRComInterfaceDecoration>() || type->getOp() == kIROp_ComPtrType)
    {
        return true;
    }
    if (auto witnessTableType = as<IRWitnessTableTypeBase>(type))
    {
        return isComInterfaceType((IRType*)witnessTableType->getConformanceType());
    }
    if (auto ptrType = as<IRNativePtrType>(type))
    {
        auto valueType = ptrType->getValueType();
        return valueType->findDecoration<IRComInterfaceDecoration>() != nullptr;
    }

    return false;
}

IROp getTypeStyle(IROp op)
{
    switch (op)
    {
    case kIROp_VoidType:
    case kIROp_BoolType:
    case kIROp_EnumType:
        {
            return op;
        }
    case kIROp_Int8Type:
    case kIROp_Int16Type:
    case kIROp_IntType:
    case kIROp_UInt8Type:
    case kIROp_UInt16Type:
    case kIROp_UIntType:
    case kIROp_Int64Type:
    case kIROp_UInt64Type:
    case kIROp_IntPtrType:
    case kIROp_UIntPtrType:
        {
            // All int like
            return kIROp_IntType;
        }
    case kIROp_HalfType:
    case kIROp_FloatType:
    case kIROp_DoubleType:
    case kIROp_FloatE4M3Type:
    case kIROp_FloatE5M2Type:
    case kIROp_BFloat16Type:
        {
            // All float like
            return kIROp_FloatType;
        }
    default:
        return kIROp_Invalid;
    }
}

IROp getTypeStyle(BaseType op)
{
    switch (op)
    {
    case BaseType::Void:
        return kIROp_VoidType;
    case BaseType::Bool:
        return kIROp_BoolType;
    case BaseType::Char:
    case BaseType::Int8:
    case BaseType::Int16:
    case BaseType::Int:
    case BaseType::Int64:
    case BaseType::IntPtr:
    case BaseType::UInt8:
    case BaseType::UInt16:
    case BaseType::UInt:
    case BaseType::UInt64:
    case BaseType::UIntPtr:
        return kIROp_IntType;
    case BaseType::Half:
    case BaseType::Float:
    case BaseType::Double:
        return kIROp_FloatType;
    default:
        return kIROp_Invalid;
    }
}

// Split parameter type into a direction and a type
std::tuple<ParameterDirectionInfo, IRType*> splitParameterDirectionAndType(IRType* paramType)
{
    if (as<IROutParamType>(paramType))
        return {
            ParameterDirectionInfo(ParameterDirectionInfo::Kind::Out),
            as<IROutParamType>(paramType)->getValueType()};
    else if (as<IRBorrowInOutParamType>(paramType))
        return {
            ParameterDirectionInfo(ParameterDirectionInfo::Kind::BorrowInOut),
            as<IRBorrowInOutParamType>(paramType)->getValueType()};
    else if (auto refParamType = as<IRRefParamType>(paramType))
    {
        ParameterDirectionInfo info(
            ParameterDirectionInfo::Kind::Ref,
            refParamType->getAddressSpace());
        info.accessQualifier = refParamType->getAccessQualifier();
        return {info, refParamType->getValueType()};
    }
    else if (as<IRBorrowInParamType>(paramType))
        return {
            ParameterDirectionInfo(
                ParameterDirectionInfo::Kind::BorrowIn,
                as<IRBorrowInParamType>(paramType)->getAddressSpace()),
            as<IRBorrowInParamType>(paramType)->getValueType()};
    else
        return {ParameterDirectionInfo(ParameterDirectionInfo::Kind::In), paramType};
}

// Join parameter direction and a type back into a parameter type
IRType* fromDirectionAndType(IRBuilder* builder, ParameterDirectionInfo info, IRType* type)
{
    switch (info.kind)
    {
    case ParameterDirectionInfo::Kind::In:
        return type;
    case ParameterDirectionInfo::Kind::Out:
        return builder->getOutParamType(type);
    case ParameterDirectionInfo::Kind::BorrowInOut:
        return builder->getBorrowInOutParamType(type);
    case ParameterDirectionInfo::Kind::BorrowIn:
        return builder->getBorrowInParamType(type, info.addressSpace);
    case ParameterDirectionInfo::Kind::Ref:
        return builder->getRefParamType(type, info.accessQualifier, info.addressSpace);
    default:
        SLANG_UNEXPECTED("Unhandled parameter info in fromDirectionAndType");
    }
}

IRInst* specializeWithGeneric(
    IRBuilder& builder,
    IRInst* genericToSpecialize,
    IRGeneric* userGeneric)
{
    List<IRInst*> genArgs;
    for (auto param : userGeneric->getFirstBlock()->getParams())
    {
        genArgs.add(param);
    }

    // Default to type kind for now.
    IRType* typeForSpecialization = builder.getTypeKind();

    auto dataType = genericToSpecialize->getDataType();
    if (dataType)
    {
        if (dataType->getOp() == kIROp_TypeKind || dataType->getOp() == kIROp_GenericKind)
        {
            typeForSpecialization = (genericToSpecialize)->getDataType();
        }
        else if (dataType->getOp() == kIROp_Generic)
        {
            typeForSpecialization = (IRType*)builder.emitSpecializeInst(
                builder.getTypeKind(),
                (genericToSpecialize)->getDataType(),
                genArgs.getCount(),
                genArgs.getBuffer());
        }
    }

    return builder.emitSpecializeInst(
        typeForSpecialization,
        genericToSpecialize,
        (UInt)genArgs.getCount(),
        genArgs.getBuffer());
}

IRInst* maybeSpecializeWithGeneric(
    IRBuilder& builder,
    IRInst* genericToSpecailize,
    IRInst* userGeneric)
{
    if (auto gen = as<IRGeneric>(userGeneric))
    {
        if (auto toSpecialize = as<IRGeneric>(genericToSpecailize))
        {
            return specializeWithGeneric(builder, toSpecialize, gen);
        }
    }
    return genericToSpecailize;
}

// Returns true if is not possible to produce side-effect from a value of `dataType`.
bool isValueType(IRInst* dataType)
{
    dataType = getResolvedInstForDecorations(unwrapAttributedType(dataType));
    if (as<IRBasicType>(dataType))
        return true;
    switch (dataType->getOp())
    {
    case kIROp_StructType:
    case kIROp_InterfaceType:
    case kIROp_ClassType:
    case kIROp_VectorType:
    case kIROp_MatrixType:
    case kIROp_TupleType:
    case kIROp_ResultType:
    case kIROp_OptionalType:
    case kIROp_ConditionalType:
    case kIROp_DifferentialPairType:
    case kIROp_DynamicType:
    case kIROp_AnyValueType:
    case kIROp_ArrayType:
    case kIROp_FuncType:
    case kIROp_RaytracingAccelerationStructureType:
    case kIROp_GLSLAtomicUintType:
    case kIROp_EnumType:
    // Work-graph input records are immutable payload views, so treat them as values.
    case kIROp_DispatchNodeInputRecordType:
    case kIROp_ThreadNodeInputRecordType:
    case kIROp_GroupNodeInputRecordsType:
    case kIROp_EmptyNodeInputType:
        return true;
    default:
        // Read-only resource handles are considered as Value type.
        if (auto resType = as<IRResourceTypeBase>(dataType))
            return (resType->getAccess() == SLANG_RESOURCE_ACCESS_READ);
        else if (as<IRSamplerStateTypeBase>(dataType))
            return true;
        else if (as<IRHLSLByteAddressBufferType>(dataType))
            return true;
        else if (as<IRHLSLStructuredBufferType>(dataType))
            return true;
        return false;
    }
}

bool isScalarOrVectorType(IRInst* type)
{
    switch (type->getOp())
    {
    case kIROp_VectorType:
        return true;
    default:
        return as<IRBasicType>(type) != nullptr;
    }
}

bool isSimpleDataType(IRType* type)
{
    type = (IRType*)unwrapAttributedType(type);
    if (as<IRBasicType>(type))
        return true;
    switch (type->getOp())
    {
    case kIROp_StructType:
        {
            auto structType = as<IRStructType>(type);
            for (auto field : structType->getFields())
            {
                if (!isSimpleDataType(field->getFieldType()))
                    return false;
            }
            return true;
            break;
        }
    case kIROp_Param:
    case kIROp_VectorType:
    case kIROp_MatrixType:
    case kIROp_InterfaceType:
    case kIROp_AnyValueType:
    case kIROp_PtrType:
        return true;
    case kIROp_EnumType:
        {
            auto enumType = as<IREnumType>(type);
            auto tagType = enumType->getTagType();
            return isSimpleDataType(tagType);
        }
    case kIROp_ArrayType:
    case kIROp_UnsizedArrayType:
        return isSimpleDataType((IRType*)type->getOperand(0));
    default:
        return false;
    }
}

bool isSimpleHLSLDataType(IRInst* inst)
{
    // TODO: Add criteria
    // https://github.com/shader-slang/slang/issues/4792
    SLANG_UNUSED(inst);
    return true;
}

bool isWrapperType(IRInst* inst)
{
    switch (inst->getOp())
    {
    case kIROp_ArrayType:
    case kIROp_TextureType:
    case kIROp_VectorType:
    case kIROp_MatrixType:
    case kIROp_PtrType:
    case kIROp_RefParamType:
    case kIROp_BorrowInParamType:
    case kIROp_HLSLStructuredBufferType:
    case kIROp_HLSLRWStructuredBufferType:
    case kIROp_HLSLRasterizerOrderedStructuredBufferType:
    case kIROp_HLSLAppendStructuredBufferType:
    case kIROp_HLSLConsumeStructuredBufferType:
    case kIROp_TupleType:
    case kIROp_OptionalType:
    case kIROp_ConditionalType:
    case kIROp_TypePack:
        return true;
    default:
        return false;
    }
}

SourceLoc findFirstUseLoc(IRInst* inst)
{
    for (auto use = inst->firstUse; use; use = use->nextUse)
    {
        if (use->getUser()->sourceLoc.isValid())
        {
            return use->getUser()->sourceLoc;
        }
    }
    return inst->sourceLoc;
}

IRInst* hoistValueFromGeneric(
    IRBuilder& inBuilder,
    IRInst* value,
    IRInst*& outSpecializedVal,
    bool replaceExistingValue)
{
    auto outerGeneric = as<IRGeneric>(findOuterGeneric(value));
    if (!outerGeneric)
        return value;
    IRBuilder builder = inBuilder;
    builder.setInsertBefore(outerGeneric);
    auto newGeneric = builder.emitGeneric();
    builder.setInsertInto(newGeneric);
    builder.emitBlock();
    IRInst* newResultVal = nullptr;

    // Clone insts in outerGeneric up until `value`.
    IRCloneEnv cloneEnv;
    for (auto inst : outerGeneric->getFirstBlock()->getChildren())
    {
        auto newInst = cloneInst(&cloneEnv, &builder, inst);
        if (inst == value)
        {
            builder.emitReturn(newInst);
            newResultVal = newInst;
            break;
        }
    }
    SLANG_RELEASE_ASSERT(newResultVal);
    if (newResultVal->getOp() == kIROp_Func)
    {
        IRBuilder subBuilder = builder;
        IRInst* subOutSpecialized = nullptr;
        auto genericFuncType = hoistValueFromGeneric(
            subBuilder,
            newResultVal->getFullType(),
            subOutSpecialized,
            false);
        newGeneric->setFullType((IRType*)genericFuncType);
    }
    else if (newResultVal->getOp() == kIROp_WitnessTable)
    {
        IRBuilder subBuilder = builder;
        IRInst* subOutSpecialized = nullptr;
        auto genericWitnessTableType = hoistValueFromGeneric(
            subBuilder,
            newResultVal->getFullType(),
            subOutSpecialized,
            false);
        newGeneric->setFullType((IRType*)genericWitnessTableType);
    }
    else
    {
        newGeneric->setFullType(builder.getTypeKind());
    }
    if (replaceExistingValue)
    {
        builder.setInsertBefore(value);
        outSpecializedVal = specializeWithGeneric(builder, newGeneric, outerGeneric);
        value->replaceUsesWith(outSpecializedVal);
        value->removeAndDeallocate();
    }
    eliminateDeadCode(newGeneric);
    return newGeneric;
}

void moveInstChildren(IRInst* dest, IRInst* src)
{
    for (auto child = dest->getFirstDecorationOrChild(); child;)
    {
        auto next = child->getNextInst();
        child->removeAndDeallocate();
        child = next;
    }
    for (auto child = src->getFirstDecorationOrChild(); child;)
    {
        auto next = child->getNextInst();
        child->insertAtEnd(dest);
        child = next;
    }
}

String dumpIRToString(IRInst* root, IRDumpOptions options)
{
    StringBuilder sb;
    StringWriter writer(&sb, Slang::WriterFlag::AutoFlush);
    dumpIR(root, options, nullptr, &writer);
    return sb.toString();
}

void copyNameHintAndDebugDecorations(IRInst* dest, IRInst* src)
{
    IRDecoration* nameHintDecoration = nullptr;
    IRDecoration* linkageDecoration = nullptr;
    IRDecoration* debugLocationDecoration = nullptr;
    for (auto decor = src->getFirstDecoration(); decor; decor = decor->getNextDecoration())
    {
        switch (decor->getOp())
        {
        case kIROp_NameHintDecoration:
            nameHintDecoration = decor;
            break;
        case kIROp_ImportDecoration:
        case kIROp_ExportDecoration:
            linkageDecoration = decor;
            break;
        case kIROp_DebugLocationDecoration:
            debugLocationDecoration = decor;
            break;
        }
    }
    if (nameHintDecoration)
    {
        cloneDecoration(nameHintDecoration, dest);
    }
    if (linkageDecoration)
    {
        cloneDecoration(linkageDecoration, dest);
    }
    if (debugLocationDecoration)
    {
        cloneDecoration(debugLocationDecoration, dest);
    }
}

void getTypeNameHint(StringBuilder& sb, IRInst* type)
{
    if (!type)
        return;

    switch (type->getOp())
    {
    case kIROp_BoolType:
        sb << "bool";
        break;
    case kIROp_FloatType:
        sb << "float";
        break;
    case kIROp_HalfType:
        sb << "half";
        break;
    case kIROp_DoubleType:
        sb << "double";
        break;
    case kIROp_IntType:
        sb << "int";
        break;
    case kIROp_Int8Type:
        sb << "int8_t";
        break;
    case kIROp_Int16Type:
        sb << "int16_t";
        break;
    case kIROp_Int64Type:
        sb << "int64_t";
        break;
    case kIROp_IntPtrType:
        sb << "intptr_t";
        break;
    case kIROp_UIntType:
        sb << "uint";
        break;
    case kIROp_UInt8Type:
        sb << "uint8_t";
        break;
    case kIROp_UInt16Type:
        sb << "uint16_t";
        break;
    case kIROp_UInt64Type:
        sb << "uint64_t";
        break;
    case kIROp_UIntPtrType:
        sb << "uintptr_t";
        break;
    case kIROp_CharType:
        sb << "char";
        break;
    case kIROp_StringType:
        sb << "string";
        break;
    case kIROp_ArrayType:
        sb << "array<";
        getTypeNameHint(sb, type->getOperand(0));
        sb << ",";
        getTypeNameHint(sb, as<IRArrayType>(type)->getElementCount());
        sb << ">";
        break;
    case kIROp_UnsizedArrayType:
        sb << "runtime_array<";
        getTypeNameHint(sb, type->getOperand(0));
        sb << ">";
        break;
    case kIROp_SubpassInputType:
        {
            auto subpassInputType = as<IRSubpassInputType>(type);
            sb << "SubpassInput";
            // Handle isMultisample individually - if constant, use pretty name; if generic, include
            // it
            auto isMS = subpassInputType->getIsMultisampleInst();
            if (auto isMSLit = as<IRIntLit>(isMS))
            {
                if (isMSLit->getValue() != 0)
                    sb << "MS";
            }
            else
            {
                // Generic parameter - include in output for uniqueness
                sb << "<";
                getTypeNameHint(sb, isMS);
                sb << ">";
            }
            break;
        }
    case kIROp_TextureType:
    case kIROp_GLSLImageType:
        {
            auto textureType = as<IRResourceTypeBase>(type);
            switch (textureType->getAccess())
            {
            case SLANG_RESOURCE_ACCESS_APPEND:
                sb << "Append";
                break;
            case SLANG_RESOURCE_ACCESS_CONSUME:
                sb << "Consume";
                break;
            case SLANG_RESOURCE_ACCESS_RASTER_ORDERED:
                sb << "RasterizerOrdered";
                break;
            case SLANG_RESOURCE_ACCESS_WRITE:
                sb << "RW";
                break;
            case SLANG_RESOURCE_ACCESS_FEEDBACK:
                sb << "Feedback";
                break;
            case SLANG_RESOURCE_ACCESS_READ:
                break;
            }

            auto isCombinedInst = textureType->getIsCombinedInst();
            auto isCombinedLit = as<IRIntLit>(isCombinedInst);
            if (isCombinedLit)
            {
                bool isCombined = (isCombinedLit->getValue() != 0);
                if (isCombined)
                {
                    switch (textureType->GetBaseShape())
                    {
                    case SLANG_TEXTURE_1D:
                        sb << "Sampler1D";
                        break;
                    case SLANG_TEXTURE_2D:
                        sb << "Sampler2D";
                        break;
                    case SLANG_TEXTURE_3D:
                        sb << "Sampler3D";
                        break;
                    case SLANG_TEXTURE_CUBE:
                        sb << "SamplerCube";
                        break;
                    case SLANG_TEXTURE_BUFFER:
                        sb << "SamplerBuffer";
                        break;
                    }
                }
                else
                {
                    switch (textureType->GetBaseShape())
                    {
                    case SLANG_TEXTURE_1D:
                        sb << "Texture1D";
                        break;
                    case SLANG_TEXTURE_2D:
                        sb << "Texture2D";
                        break;
                    case SLANG_TEXTURE_3D:
                        sb << "Texture3D";
                        break;
                    case SLANG_TEXTURE_CUBE:
                        sb << "TextureCube";
                        break;
                    case SLANG_TEXTURE_BUFFER:
                        sb << "Buffer";
                        break;
                    }
                }
            }

            // Handle each boolean flag individually
            auto isMultisampleInst = textureType->getIsMultisampleInst();
            if (auto lit = as<IRIntLit>(isMultisampleInst))
            {
                if (lit->getValue() != 0)
                    sb << "MS";
            }

            auto isArrayInst = textureType->getIsArrayInst();
            if (auto lit = as<IRIntLit>(isArrayInst))
            {
                if (lit->getValue() != 0)
                    sb << "Array";
            }

            auto isShadowInst = textureType->getIsShadowInst();
            if (auto lit = as<IRIntLit>(isShadowInst))
            {
                if (lit->getValue() != 0)
                    sb << "Shadow";
            }

            // If any parameters are generic (not constants), append them for uniqueness
            bool hasGenericParams = !as<IRIntLit>(textureType->getAccessInst()) || !isCombinedLit ||
                                    !as<IRIntLit>(isMultisampleInst) ||
                                    !as<IRIntLit>(isArrayInst) || !as<IRIntLit>(isShadowInst);

            if (hasGenericParams)
            {
                sb << "<";
                bool first = true;
                auto appendParam = [&](IRInst* inst)
                {
                    if (!as<IRIntLit>(inst))
                    {
                        if (!first)
                            sb << ",";
                        getTypeNameHint(sb, inst);
                        first = false;
                    }
                };
                appendParam(textureType->getAccessInst());
                appendParam(isCombinedInst);
                appendParam(isMultisampleInst);
                appendParam(isArrayInst);
                appendParam(isShadowInst);
                sb << ">";
            }
        }
        break;
    case kIROp_ParameterBlockType:
        sb << "ParameterBlock<";
        getTypeNameHint(sb, as<IRParameterBlockType>(type)->getElementType());
        sb << ">";
        break;
    case kIROp_ConstantBufferType:
        sb << "cbuffer<";
        getTypeNameHint(sb, as<IRConstantBufferType>(type)->getElementType());
        sb << ">";
        break;
    case kIROp_TextureBufferType:
        sb << "tbuffer<";
        getTypeNameHint(sb, as<IRTextureBufferType>(type)->getElementType());
        sb << ">";
        break;
    case kIROp_GLSLShaderStorageBufferType:
        sb << "StorageBuffer<";
        getTypeNameHint(sb, as<IRGLSLShaderStorageBufferType>(type)->getElementType());
        sb << ">";
        break;
    case kIROp_HLSLByteAddressBufferType:
        sb << "ByteAddressBuffer";
        break;
    case kIROp_HLSLRWByteAddressBufferType:
        sb << "RWByteAddressBuffer";
        break;
    case kIROp_HLSLRasterizerOrderedByteAddressBufferType:
        sb << "RasterizerOrderedByteAddressBuffer";
        break;
    case kIROp_GLSLAtomicUintType:
        sb << "AtomicCounter";
        break;
    case kIROp_RaytracingAccelerationStructureType:
        sb << "RaytracingAccelerationStructure";
        break;
    case kIROp_HitObjectType:
        sb << "HitObject";
        break;
    case kIROp_HLSLStructuredBufferType:
        sb << "StructuredBuffer<";
        getTypeNameHint(sb, as<IRHLSLStructuredBufferTypeBase>(type)->getElementType());
        sb << ">";
        break;
    case kIROp_HLSLRWStructuredBufferType:
        sb << "RWStructuredBuffer<";
        getTypeNameHint(sb, as<IRHLSLStructuredBufferTypeBase>(type)->getElementType());
        sb << ">";
        break;
    case kIROp_HLSLAppendStructuredBufferType:
        sb << "AppendStructuredBuffer<";
        getTypeNameHint(sb, as<IRHLSLStructuredBufferTypeBase>(type)->getElementType());
        sb << ">";
        break;
    case kIROp_HLSLConsumeStructuredBufferType:
        sb << "ConsumeStructuredBuffer<";
        getTypeNameHint(sb, as<IRHLSLStructuredBufferTypeBase>(type)->getElementType());
        sb << ">";
        break;
    case kIROp_HLSLRasterizerOrderedStructuredBufferType:
        sb << "RasterizerOrderedStructuredBuffer<";
        getTypeNameHint(sb, as<IRHLSLStructuredBufferTypeBase>(type)->getElementType());
        sb << ">";
        break;
    case kIROp_SamplerStateType:
        sb << "SamplerState";
        break;
    case kIROp_SamplerComparisonStateType:
        sb << "SamplerComparisonState";
        break;
    case kIROp_TextureFootprintType:
        sb << "TextureFootprint";
        break;
    // The following opaque builtin types carry no name-hint/linkage decoration, and their operands
    // form the type's identity. Each case renders the surface name plus those operands, so
    // consumers (chiefly SPIR-V debug info) get a real name instead of the empty hint that would
    // collapse distinct instantiations into the literal "unnamed".
    case kIROp_DescriptorHandleType:
        sb << "DescriptorHandle<";
        getTypeNameHint(sb, as<IRDescriptorHandleType>(type)->getResourceType());
        sb << ">";
        break;
    case kIROp_RayQueryType:
        // The first operand is the ray-flags value (RayQueryType has min_operands == 1, so
        // getOperand(0) is in bounds); include it so `RayQuery<flags>` instantiations that differ
        // only in flags get distinct names.
        sb << "RayQuery<";
        getTypeNameHint(sb, type->getOperand(0));
        sb << ">";
        break;
    case kIROp_CoopVectorType:
        sb << "CoopVec<";
        getTypeNameHint(sb, as<IRCoopVectorType>(type)->getElementType());
        sb << ",";
        getTypeNameHint(sb, as<IRCoopVectorType>(type)->getElementCount());
        sb << ">";
        break;
    case kIROp_CoopMatrixType:
        {
            // Include every operand (scope and use as well as element/shape): each is part of the
            // cooperative-matrix type identity, so omitting any would collide distinct types.
            auto coopMat = as<IRCoopMatrixType>(type);
            sb << "CoopMat<";
            getTypeNameHint(sb, coopMat->getElementType());
            sb << ",";
            getTypeNameHint(sb, coopMat->getScope());
            sb << ",";
            getTypeNameHint(sb, coopMat->getRowCount());
            sb << ",";
            getTypeNameHint(sb, coopMat->getColumnCount());
            sb << ",";
            getTypeNameHint(sb, coopMat->getMatrixUse());
            sb << ">";
        }
        break;
    case kIROp_TensorAddressingTensorLayoutType:
        {
            auto tensorLayout = as<IRTensorAddressingTensorLayoutType>(type);
            sb << "TensorLayout<";
            getTypeNameHint(sb, tensorLayout->getDimension());
            sb << ",";
            getTypeNameHint(sb, tensorLayout->getClampMode());
            sb << ">";
        }
        break;
    case kIROp_TensorAddressingTensorViewType:
        {
            // Operands are [dimension, hasDimension, permutation...]; the two leading operands are
            // rendered by name, so the remaining `getOperandCount() - 2` are the permutation. Only
            // the first `dimension`-many permutation entries are meaningful; trailing slots are the
            // sentinel 255 (padding that the OpTypeTensorViewNV writer in the SPIR-V emitter
            // ignores). This function deliberately renders every slot so the name stays a faithful,
            // collision-free function of the full operand list.
            auto tensorView = as<IRTensorAddressingTensorViewType>(type);
            sb << "TensorView<";
            getTypeNameHint(sb, tensorView->getDimension());
            sb << ",";
            getTypeNameHint(sb, tensorView->getHasDimension());
            UInt permutationCount = tensorView->getOperandCount() - 2;
            for (UInt i = 0; i < permutationCount; i++)
            {
                sb << ",";
                getTypeNameHint(sb, tensorView->getPermutation((int)i));
            }
            sb << ">";
        }
        break;
    case kIROp_Specialize:
        {
            auto specialize = as<IRSpecialize>(type);
            getTypeNameHint(sb, specialize->getBase());
            sb << "<";
            bool isFirst = true;
            for (UInt i = 0; i < specialize->getArgCount(); i++)
            {
                auto arg = specialize->getArg(i);
                if (!arg->getDataType())
                    continue;
                if (arg->getDataType()->getOp() == kIROp_WitnessTableType)
                    continue;
                if (!isFirst)
                    sb << ",";
                getTypeNameHint(sb, arg);
                isFirst = false;
            }
            sb << ">";
        }
        break;
    case kIROp_AttributedType:
        getTypeNameHint(sb, as<IRAttributedType>(type)->getBaseType());
        break;
    case kIROp_RateQualifiedType:
        getTypeNameHint(sb, as<IRRateQualifiedType>(type)->getValueType());
        break;
    case kIROp_VectorType:
        sb << "vector<";
        getTypeNameHint(sb, type->getOperand(0));
        sb << ",";
        getTypeNameHint(sb, as<IRVectorType>(type)->getElementCount());
        sb << ">";
        break;
    case kIROp_MatrixType:
        sb << "matrix<";
        getTypeNameHint(sb, type->getOperand(0));
        sb << ",";
        getTypeNameHint(sb, as<IRMatrixType>(type)->getRowCount());
        sb << ",";
        getTypeNameHint(sb, as<IRMatrixType>(type)->getColumnCount());
        sb << ">";
        break;
    case kIROp_IntLit:
        sb << as<IRIntLit>(type)->getValue();
        break;
    case kIROp_BoolLit:
        sb << (as<IRBoolLit>(type)->getValue() ? "true" : "false");
        break;
    case kIROp_FloatLit:
        sb << as<IRFloatLit>(type)->getValue();
        break;
    case kIROp_StringLit:
        {
            auto stringLit = as<IRStringLit>(type);
            sb << "\"";
            sb << stringLit->getStringSlice();
            sb << "\"";
        }
        break;
    case kIROp_VoidLit:
        sb << "void";
        break;
    case kIROp_PtrLit:
        {
            auto ptrLit = as<IRPtrLit>(type);
            sb << "ptr_";
            sb << (UInt64)ptrLit->getValue();
        }
        break;
    case kIROp_FloatE4M3Type:
        sb << "FloatE4M3";
        break;
    case kIROp_FloatE5M2Type:
        sb << "FloatE5M2";
        break;
    case kIROp_BFloat16Type:
        sb << "BFloat16";
        break;
    default:
        if (auto decor = type->findDecoration<IRNameHintDecoration>())
            sb << decor->getName();
        break;
    }
}

IRInst* getRootAddr(IRInst* addr)
{
    for (;;)
    {
        switch (addr->getOp())
        {
        case kIROp_GetElementPtr:
        case kIROp_FieldAddress:
        case kIROp_NodeOutputRecordGetElementPtr:
            addr = addr->getOperand(0);
            continue;
        default:
            break;
        }
        break;
    }
    return addr;
}

// Walk `addr` to its root, appending each access-chain key LEAF-FIRST. Shared by
// the public `getRootAddr` (which reverses afterwards, so callers see root-first)
// and by `canAddressesPotentiallyAlias`, which indexes from the end instead so it
// can keep its chains on the stack. Templated on the list type for exactly that
// reason -- one walker means the two cannot drift apart.
template<typename TChainList, typename TTypeList>
static IRInst* _collectAccessChainLeafFirst(
    IRInst* addr,
    TChainList& outAccessChain,
    TTypeList* outTypes)
{
    for (;;)
    {
        switch (addr->getOp())
        {
        case kIROp_GetElementPtr:
        case kIROp_FieldAddress:
        case kIROp_NodeOutputRecordGetElementPtr:
            outAccessChain.add(addr->getOperand(1));
            if (outTypes)
                outTypes->add(addr->getFullType());
            addr = addr->getOperand(0);
            continue;
        default:
            break;
        }
        break;
    }
    return addr;
}

// Overload for callers that want the chain but not the types. It exists so the
// common case needs no explicit template arguments: passing `nullptr` for
// `outTypes` cannot deduce `TTypeList` (its type is `std::nullptr_t`), which
// would otherwise force every call site to spell out both parameters, the
// second of them naming the type of a list that is never written.
template<typename TChainList>
static IRInst* _collectAccessChainLeafFirst(IRInst* addr, TChainList& outAccessChain)
{
    return _collectAccessChainLeafFirst<TChainList, List<IRInst*>>(addr, outAccessChain, nullptr);
}

IRInst* getRootAddr(IRInst* addr, List<IRInst*>& outAccessChain, List<IRInst*>* outTypes)
{
    auto root = _collectAccessChainLeafFirst(addr, outAccessChain, outTypes);
    outAccessChain.reverse();
    if (outTypes)
        outTypes->reverse();
    return root;
}


IRInst* getRootBufferOrAddr(IRInst* addr)
{
    auto rootAddr = getRootAddr(addr);
    if (as<IRRWStructuredBufferGetElementPtr>(rootAddr))
    {
        auto bufferHandle = rootAddr->getOperand(0);
        // Check if the bufferHandle itself is a load from a global parameter.
        if (auto load = as<IRLoad>(bufferHandle))
        {
            auto newRoot = getRootAddr(load->getPtr());
            if (newRoot->getOp() == kIROp_GlobalParam)
                return newRoot;
        }
    }
    return rootAddr;
}

// The aliasing class of an address. This is used to determine
// if two addresses may alias.
enum class AddressAliasingClass
{
    Unknown,
    UserPointer,      // A user pointer into global memory
    Var,              // A thread-local or groupshared var.
    ConstantBuffer,   // A constant buffer or parameter block.
    BoundBuffer,      // A bound buffer.
    BoundTexture,     // A bound texture resource.
    DescriptorHandle, // A bindless buffer or resource.
};

AddressAliasingClass getAliasingClass(IRInst* addr)
{
    if (auto globalParam = as<IRGlobalParam>(addr))
    {
        auto type = unwrapArray(globalParam->getDataType());
        if (!type)
            return AddressAliasingClass::Unknown;
        switch (type->getOp())
        {
        case kIROp_TextureType:
            return AddressAliasingClass::BoundTexture;
        case kIROp_HLSLStructuredBufferType:
        case kIROp_HLSLRWStructuredBufferType:
        case kIROp_HLSLAppendStructuredBufferType:
        case kIROp_HLSLConsumeStructuredBufferType:
        case kIROp_HLSLRasterizerOrderedStructuredBufferType:
        case kIROp_HLSLByteAddressBufferType:
        case kIROp_HLSLRWByteAddressBufferType:
        case kIROp_HLSLRasterizerOrderedByteAddressBufferType:
        case kIROp_GLSLShaderStorageBufferType:
            return AddressAliasingClass::BoundBuffer;
        case kIROp_ConstantBufferType:
        case kIROp_ParameterBlockType:
            return AddressAliasingClass::ConstantBuffer;
        case kIROp_PtrType:
            if (isUserPointerType(type))
                return AddressAliasingClass::UserPointer;
            return AddressAliasingClass::Unknown;
        case kIROp_DynamicResourceType:
            return AddressAliasingClass::DescriptorHandle;
        default:
            return AddressAliasingClass::Unknown;
        }
    }
    else if (as<IRVar>(addr))
        return AddressAliasingClass::Var;
    else if (as<IRGlobalVar>(addr))
        return AddressAliasingClass::Var;
    else if (as<IRRWStructuredBufferGetElementPtr>(addr))
        return AddressAliasingClass::DescriptorHandle;
    else if (as<IRCastDescriptorHandleToResource>(addr))
        return AddressAliasingClass::DescriptorHandle;

    auto type = addr->getDataType();
    if (isUserPointerType(type))
        return AddressAliasingClass::UserPointer;
    return AddressAliasingClass::Unknown;
}

bool canAddrClassesAlias(AddressAliasingClass c1, AddressAliasingClass c2)
{
    if (c1 == AddressAliasingClass::Unknown || c2 == AddressAliasingClass::Unknown)
        return true;

    switch (c1)
    {
    case AddressAliasingClass::Unknown:
        return true;
    case AddressAliasingClass::UserPointer:
    case AddressAliasingClass::Var:
        // A users pointer or var can only alias with another
        // object that is either a user pointer or var.
        //
        // Generally, a var should never alias with anything else that isn't a var,
        // if we never allow the user to take address of a local var.
        // We don't allow taking addresses of a local var on most GPU targets, but
        // we currently do expose an internal intrinsic to do so when targeting CPU.
        // We should consider disallowing this across the board, or enable more aggresive
        // criteria when targeting GPU backends.
        // For now we stay conservative and just report true even when addr1 is var and
        // addr2 is not rooted from a var.
        //
        return c2 == AddressAliasingClass::UserPointer || c2 == AddressAliasingClass::Var;
    case AddressAliasingClass::BoundBuffer:
    case AddressAliasingClass::BoundTexture:
        // A bound resource can only alias with another
        // object that is a bound resource or descriptor handle
        return c2 == c1 || c2 == AddressAliasingClass::DescriptorHandle;

    case AddressAliasingClass::DescriptorHandle:
        // Can alias with any other resource.
        switch (c2)
        {
        case AddressAliasingClass::BoundBuffer:
        case AddressAliasingClass::BoundTexture:
        case AddressAliasingClass::DescriptorHandle:
            return true;
        default:
            return false;
        }
    case AddressAliasingClass::ConstantBuffer:
        // Constant buffer cannot alias with anything.
        return false;
    }
    // For any other unknown case, assume they may alias.
    return true;
}

// Has `var` being used in a way that may allow it to alias with a user pointer?
bool canVarAliasWithUserPointer(TargetRequest* target, IRInst* var)
{
    if (target && !isCPUTarget(target))
    {
        // We don't allow taking the address of a variable on anything other
        // than the CPU target. Therefore a var can never alias with a user
        // pointer on these targets.
        return false;
    }

    SLANG_UNUSED(var);
    return true;
}

// A simple and conservative address aliasing check.
bool canAddressesPotentiallyAlias(
    TargetRequest* target,
    IRGlobalValueWithCode* func,
    IRInst* addr1,
    IRInst* addr2)
{
    if (addr1 == addr2)
        return true;

    auto root1 = getRootBufferOrAddr(addr1);
    auto root2 = getRootBufferOrAddr(addr2);

    auto addr1Class = getAliasingClass(root1);
    auto addr2Class = getAliasingClass(root2);

    if (!canAddrClassesAlias(addr1Class, addr2Class))
        return false;

    if (addr1Class == addr2Class)
    {
        // For these classes of addresses, the identity of the root
        // determines whether or not the addresse can alias.
        // Note that we assume two different bound resources can never
        // alias, and two different variables can never alias.
        switch (addr1Class)
        {
        case AddressAliasingClass::Var:
        case AddressAliasingClass::BoundBuffer:
        case AddressAliasingClass::BoundTexture:
        case AddressAliasingClass::ConstantBuffer:
            if (root1 != root2)
                return false;
            break;
        }
    }

    // A param and a var can never alias.
    if (root1->getOp() == kIROp_Param && root1->getParent() == func->getFirstBlock() &&
            root2->getOp() == kIROp_Var ||
        root1->getOp() == kIROp_Var && root2->getOp() == kIROp_Param &&
            root2->getParent() == func->getFirstBlock())
        return false;

    // If one addr is user pointer and one addr is a var,
    // they can never alias, if the user code never took the address of
    // the var.
    if (addr1Class == AddressAliasingClass::Var && addr2Class == AddressAliasingClass::UserPointer)
    {
        return canVarAliasWithUserPointer(target, root1);
    }
    if (addr2Class == AddressAliasingClass::Var && addr1Class == AddressAliasingClass::UserPointer)
    {
        return canVarAliasWithUserPointer(target, root2);
    }

    // If two addrs are rooted from the same object but found to statically differ in access chain,
    // then they cannot alias.
    if (root1 == root2)
    {
        // Stack-allocated, and collected leaf-first so no reverse is needed: the
        // loop below indexes from the end instead. This branch is the hot one
        // whenever a target flattens shader parameters into one aggregate
        // (Metal, and the CPU-like targets), because then every address in the
        // function shares a root and lands here -- at which point two heap
        // allocations per query, once per (address, instruction) scan step, are
        // most of what the surrounding pass does. 8 is generous headroom for the access-chain
        // depths seen in practice, not a hard limit -- nesting is user-controlled and unbounded,
        // so deeper chains still work, they just spill to the heap as before.
        ShortList<IRInst*, 8> accessChain1;
        ShortList<IRInst*, 8> accessChain2;

        // Since getRootBufferOrAddr has a different behavior around
        // RWStructuredBufferGetElementPtr compared to getRootAddr,
        // we need to call getRootAddr here again to get a simpler access chain
        // that we can handle here, so that we don't need to handle the nuance
        // of whether or not to trace past any RWStructuredBufferGetElementPtr.
        //
        root1 = _collectAccessChainLeafFirst(addr1, accessChain1);
        root2 = _collectAccessChainLeafFirst(addr2, accessChain2);
        if (root1 != root2)
            return true;
        const Index count1 = accessChain1.getCount();
        const Index count2 = accessChain2.getCount();
        for (Index i = 0; i < Math::Min(count1, count2); i++)
        {
            // Indices run root-first, as they did when both chains were reversed
            // into root-first `List`s; these are leaf-first, so walk from the end.
            auto node1 = accessChain1[count1 - 1 - i];
            auto node2 = accessChain2[count2 - 1 - i];
            if (as<IRStructKey>(node1) && as<IRStructKey>(node2))
            {
                // Two different field keys means the two addresses cannot alias.
                // TODO: If we are going to support union types, we need to exclude that
                // here.
                if (node1 != node2)
                    return false;
                // If the keys are the same, continue looking further down the access chain.
                continue;
            }
            // Two different constant indices means the two addresses cannot alias.
            auto index1 = as<IRIntLit>(node1);
            auto index2 = as<IRIntLit>(node2);
            if (index1 && index2 && index1->getValue() != index2->getValue())
                return false;
            // In all other cases, such as when either one of the indices is
            // a untime value, we treat the two indices as potentially being the same.
            return true;
        }
    }
    return true;
}

bool canAddressesPotentiallyAlias(IRGlobalValueWithCode* func, IRInst* addr1, IRInst* addr2)
{
    return canAddressesPotentiallyAlias(nullptr, func, addr1, addr2);
}

bool isPtrLikeOrHandleType(IRInst* type)
{
    if (!type)
        return false;
    if (as<IRPointerLikeType>(type))
        return true;
    if (as<IRPseudoPtrType>(type))
        return true;
    if (as<IRHLSLStructuredBufferTypeBase>(type))
        return true;
    switch (type->getOp())
    {
    case kIROp_ComPtrType:
    case kIROp_RawPointerType:
    case kIROp_RTTIPointerType:
    case kIROp_OutParamType:
    case kIROp_BorrowInOutParamType:
    case kIROp_PtrType:
    case kIROp_RefParamType:
    case kIROp_BorrowInParamType:
    case kIROp_GLSLShaderStorageBufferType:
    // Work-graph output records are mutable handles, so treat them as pointer-like.
    case kIROp_ThreadNodeOutputRecordsType:
    case kIROp_GroupNodeOutputRecordsType:
    case kIROp_NodeOutputType:
    case kIROp_NodeOutputArrayType:
    case kIROp_EmptyNodeOutputType:
    case kIROp_EmptyNodeOutputArrayType:
        return true;
    }
    return false;
}

bool canInstHaveSideEffectAtAddress(
    IRGlobalValueWithCode* func,
    IRInst* inst,
    IRInst* addr,
    Dictionary<IRInst*, bool>* calleeSideEffectCache)
{
    switch (inst->getOp())
    {
    case kIROp_Store:
        // If the target of the store inst may overlap addr, return true.
        if (canAddressesPotentiallyAlias(func, as<IRStore>(inst)->getPtr(), addr))
            return true;
        break;
    case kIROp_SwizzledStore:
        // If the target of the swizzled store inst may overlap addr, return true.
        if (canAddressesPotentiallyAlias(func, as<IRSwizzledStore>(inst)->getDest(), addr))
            return true;
        break;
    case kIROp_Call:
        {
            auto call = as<IRCall>(inst);

            // If addr is a global variable, calling a function may change its value.
            // So we need to return true here to be conservative.
            if (!isChildInstOf(getRootAddr(addr), func))
            {
                auto callee = call->getCallee();
                if (callee && !doesCalleeHaveSideEffect(callee, calleeSideEffectCache))
                {
                    // An exception is if the callee is side-effect free and is not reading from
                    // memory.
                }
                else
                {
                    return true;
                }
            }

            // If any pointer typed argument of the call inst may overlap addr, return true.
            for (UInt i = 0; i < call->getArgCount(); i++)
            {
                SLANG_RELEASE_ASSERT(call->getArg(i)->getDataType());
                if (isPtrLikeOrHandleType(call->getArg(i)->getDataType()))
                {
                    if (canAddressesPotentiallyAlias(func, call->getArg(i), addr))
                        return true;
                }
                else if (!isValueType(call->getArg(i)->getDataType()))
                {
                    // This is some unknown handle type, we assume it can have any side effects.
                    return true;
                }
            }
        }
        break;
    case kIROp_UnconditionalBranch:
    case kIROp_Loop:
        {
            auto branch = as<IRUnconditionalBranch>(inst);
            // If any pointer typed argument of the branch inst may overlap addr, return true.
            for (UInt i = 0; i < branch->getArgCount(); i++)
            {
                SLANG_RELEASE_ASSERT(branch->getArg(i)->getDataType());
                if (isPtrLikeOrHandleType(branch->getArg(i)->getDataType()))
                {
                    if (canAddressesPotentiallyAlias(func, branch->getArg(i), addr))
                        return true;
                }
                else if (!isValueType(branch->getArg(i)->getDataType()))
                {
                    // This is some unknown handle type, we assume it can have any side effects.
                    return true;
                }
            }
        }
        break;
    case kIROp_CastPtrToInt:
    case kIROp_Reinterpret:
    case kIROp_BitCast:
        {
            // If we are trying to cast an address to something else, return true.
            if (isPtrLikeOrHandleType(inst->getOperand(0)->getDataType()) &&
                canAddressesPotentiallyAlias(func, inst->getOperand(0), addr))
                return true;
            else if (!isValueType(inst->getOperand(0)->getDataType()))
            {
                // This is some unknown handle type, we assume it can have any side effects.
                return true;
            }
        }
        break;
    case kIROp_RequireTargetExtension:
        // A target-extension requirement is consumed only when code is emitted and neither reads
        // nor writes memory, so loads and stores can be forwarded across it. It still reports a
        // side effect through `mightHaveSideEffects`, which is what keeps the otherwise unused
        // requirement alive through DCE.
        break;
    default:
        // Default behavior is that any insts that have side effect may affect `addr`.
        if (inst->mightHaveSideEffects())
            return true;
        break;
    }
    return false;
}

IRInst* getUnitPoisonVal(IRBuilder* builder)
{
    builder->setInsertInto(builder->getModule()->getModuleInst());
    return builder->getPoison(builder->getVoidType());
}

IROp getSwapSideComparisonOp(IROp op)
{
    switch (op)
    {
    case kIROp_Eql:
        return kIROp_Eql;
    case kIROp_Neq:
        return kIROp_Neq;
    case kIROp_Leq:
        return kIROp_Geq;
    case kIROp_Geq:
        return kIROp_Leq;
    case kIROp_Less:
        return kIROp_Greater;
    case kIROp_Greater:
        return kIROp_Less;
    default:
        return kIROp_Nop;
    }
}

IRInst* emitLoopBlocks(
    IRBuilder* builder,
    IRInst* initVal,
    IRInst* finalVal,
    IRBlock*& loopBodyBlock,
    IRBlock*& loopBreakBlock)
{
    IRBuilder loopBuilder = *builder;
    auto loopHeadBlock = loopBuilder.emitBlock();
    loopBodyBlock = loopBuilder.emitBlock();
    auto ifBreakBlock = loopBuilder.emitBlock();
    loopBreakBlock = loopBuilder.emitBlock();
    auto loopContinueBlock = loopBuilder.emitBlock();
    builder->emitLoop(loopHeadBlock, loopBreakBlock, loopContinueBlock, 1, &initVal);
    loopBuilder.setInsertInto(loopHeadBlock);
    auto loopParam = loopBuilder.emitParam(initVal->getFullType());
    auto cmpResult = loopBuilder.emitLess(loopParam, finalVal);
    loopBuilder.emitIfElse(cmpResult, loopBodyBlock, ifBreakBlock, ifBreakBlock);
    loopBuilder.setInsertInto(loopBodyBlock);
    loopBuilder.emitBranch(loopContinueBlock);
    loopBuilder.setInsertInto(loopContinueBlock);
    auto newParam = loopBuilder.emitAdd(
        loopParam->getFullType(),
        loopParam,
        loopBuilder.getIntValue(loopBuilder.getIntType(), 1));
    loopBuilder.emitBranch(loopHeadBlock, 1, &newParam);
    loopBuilder.setInsertInto(ifBreakBlock);
    loopBuilder.emitBranch(loopBreakBlock);
    return loopParam;
}

void sortBlocksInFunc(IRGlobalValueWithCode* func)
{
    auto order = getReverseMirroredPostorder(func);
    for (auto block : order)
        block->insertAtEnd(func);
}

void removeLinkageDecorations(IRInst* inst)
{
    if (!inst)
        return;

    List<IRInst*> toRemove;
    for (auto decoration : inst->getDecorations())
    {
        switch (decoration->getOp())
        {
        case kIROp_ImportDecoration:
        case kIROp_ExportDecoration:
        case kIROp_ExternCppDecoration:
        case kIROp_PublicDecoration:
        case kIROp_KeepAliveDecoration:
        case kIROp_DllImportDecoration:
        case kIROp_CudaDeviceExportDecoration:
        case kIROp_DllExportDecoration:
        case kIROp_HLSLExportDecoration:
            toRemove.add(decoration);
            break;
        default:
            break;
        }
    }
    for (auto decoration : toRemove)
        decoration->removeAndDeallocate();
}

void setInsertBeforeOrdinaryInst(IRBuilder* builder, IRInst* inst)
{
    if (as<IRParam, IRDynamicCastBehavior::NoUnwrap>(inst))
    {
        SLANG_RELEASE_ASSERT(as<IRBlock>(inst->getParent()));
        auto lastParam = as<IRBlock>(inst->getParent())->getLastParam();
        builder->setInsertAfter(lastParam);
    }
    else
    {
        builder->setInsertBefore(inst);
    }
}

void setInsertAfterOrdinaryInst(IRBuilder* builder, IRInst* inst)
{
    if (as<IRParam, IRDynamicCastBehavior::NoUnwrap>(inst))
    {
        SLANG_RELEASE_ASSERT(as<IRBlock>(inst->getParent()));
        auto lastParam = as<IRBlock>(inst->getParent())->getLastParam();
        builder->setInsertAfter(lastParam);
    }
    else
    {
        builder->setInsertAfter(inst);
    }
}

IRInst* tryFindBasePtr(IRInst* inst, IRInst* parentFunc)
{
    // Keep going up the tree until we find a variable.
    switch (inst->getOp())
    {
    case kIROp_Var:
        return getParentFunc(inst) == parentFunc ? inst : nullptr;
    case kIROp_Param:
        return getParentFunc(inst) == parentFunc ? inst : nullptr;
    case kIROp_GetElementPtr:
        return tryFindBasePtr(as<IRGetElementPtr>(inst)->getBase(), parentFunc);
    case kIROp_FieldAddress:
        return tryFindBasePtr(as<IRFieldAddress>(inst)->getBase(), parentFunc);
    case kIROp_NodeOutputRecordGetElementPtr:
        return tryFindBasePtr(inst->getOperand(0), parentFunc);
    default:
        return nullptr;
    }
}

bool areCallArgumentsSideEffectFree(IRCall* call, SideEffectAnalysisOptions options)
{
    // If the function has no side effect and is not writing to any outputs,
    // we can safely treat the call as a normal inst.

    IRFunc* parentFunc = nullptr;

    IRParam* param = nullptr;
    if (auto calleeFunc = getResolvedInstForDecorations(call->getCallee()))
    {
        if (auto block = calleeFunc->getFirstBlock())
        {
            param = block->getFirstParam();
        }
    }

    for (UInt i = 0; i < call->getArgCount();
         i++, (param = param ? param->getNextParam() : nullptr))
    {
        auto arg = call->getArg(i);
        if (isValueType(arg->getDataType()))
            continue;

        // If the argument type is not a known value type,
        // assume it is a pointer or handle through which side effect can take place.
        if (!parentFunc)
        {
            parentFunc = getParentFunc(call);
            if (!parentFunc)
                return false;
        }

        auto module = parentFunc->getModule();
        if (!module)
            return false;

        if (arg->getOp() == kIROp_Var && getParentFunc(arg) == parentFunc)
        {
            IRDominatorTree* dom = nullptr;
            if (isBitSet(options, SideEffectAnalysisOptions::UseDominanceTree))
                dom = module->findOrCreateDominatorTree(parentFunc);

            // If the pointer argument is a local variable (thus can't alias with other
            // addresses) and it is never read from in the function, we can safely treat the
            // call as having no side-effect. This is a conservative test, but is sufficient to
            // detect the most common case where a temporary variable is used as the inout
            // argument and the result stored in the temp variable isn't being used elsewhere in
            // the parent func.
            //
            // A more aggresive test can check all other address uses reachable from the call
            // site and see if any of them are aliasing with the argument.
            for (auto use = arg->firstUse; use; use = use->nextUse)
            {
                if (as<IRDecoration>(use->getUser()))
                    continue;
                switch (use->getUser()->getOp())
                {
                case kIROp_Store:
                case kIROp_SwizzledStore:
                    // We are fine with stores into the variable, since store operations
                    // are not dependent on whatever we do in the call here.
                    continue;
                default:
                    // Skip the call itself if the var is used as an argument to an out
                    // parameter since we are checking if the call has side effect. We can't
                    // treat the call as side effect free if var is used as an inout parameter,
                    // because if the call is inside a loop there will be a visible side effect
                    // after the call.
                    if (use->getUser() == call)
                    {
                        auto funcType = as<IRFuncType>(call->getCallee()->getDataType());
                        if (!funcType)
                            return false;
                        if (funcType->getParamCount() > i &&
                            as<IROutParamType>(funcType->getParamType(i)))
                            continue;

                        // We are an argument to an inout parameter.
                        // We can only treat the call as side effect free if the call is not
                        // inside a loop.
                        //
                        // If we don't have the loop information here, we will conservatively
                        // return false.
                        //
                        if (!dom)
                            return false;

                        // If we have dominator tree available, use it to check if the call is
                        // inside a loop.
                        auto callBlock = as<IRBlock>(call->getParent());
                        if (!callBlock)
                            return false;
                        auto varBlock = as<IRBlock>(arg->getParent());
                        if (!varBlock)
                            return false;
                        auto idom = callBlock;
                        while (idom != varBlock)
                        {
                            idom = dom->getImmediateDominator(idom);
                            if (!idom)
                                return false; // If we are here, var does not dominate the call,
                                              // which should never happen.
                            if (auto loop = as<IRLoop>(idom->getTerminator()))
                            {
                                if (!dom->dominates(loop->getBreakBlock(), callBlock))
                                    return false; // The var is used in a loop, must return
                                                  // false.
                            }
                        }
                        // If we reach here, the var is used as an inout parameter for the call,
                        // but the call is not nested in a loop at an higher nesting level than
                        // where the var is defined, so we can treat the use as DCE-able.
                        continue;
                    }
                    // We have some other unknown use of the variable address, they can
                    // be loads, or calls using addresses derived from the variable,
                    // we will treat the call as having side effect to be safe.
                    return false;
                }
            }
        }
        else
        {
            if (param && !as<IROutParamType>(param->getDataType()) &&
                param->findDecoration<IRIgnoreSideEffectsDecoration>())
                continue;

            return false;
        }
    }
    return true;
}

bool isPureFunctionalCall(IRCall* call, SideEffectAnalysisOptions options)
{
    auto callee = getResolvedInstForDecorations(call->getCallee());
    if (callee->findDecoration<IRReadNoneDecoration>())
    {
        return areCallArgumentsSideEffectFree(call, options);
    }
    return false;
}

bool isSideEffectFreeFunctionalCall(
    IRCall* call,
    SideEffectAnalysisOptions options,
    Dictionary<IRInst*, bool>* calleeSideEffectCache)
{
    if (!doesCalleeHaveSideEffect(call->getCallee(), calleeSideEffectCache))
    {
        return areCallArgumentsSideEffectFree(call, options);
    }
    return false;
}

// Enumerate any associated functions of 'func'
// that might be used by a pass (e.g. auto-diff)
//
template<typename TFunc>
void forEachAssociatedCallee(IRInst* callee, TFunc callback)
{
    // PRECONDITION: `callback` must not add or remove uses of `callee`. This
    // walks the use list live, so mutating it invalidates `use->nextUse` under
    // the iteration. `traverseUsers` snapshots into a `List<IRUse*>` precisely
    // to tolerate that, and this does not -- because the snapshot costs a heap
    // allocation and a full copy on every query, and on a hot intrinsic the use
    // list holds one entry per call site. Callers that memoize the enclosing
    // query pay that once per callee; the uncached ones that remain
    // (slang-ir-simplify-for-emit.cpp, the autodiff passes) pay it per query.
    //
    // A mutating callback belongs on `traverseUsers`, not here.
    //
    // The precondition isn't otherwise enforced, so a future mutating callback would silently
    // walk a freed `use->nextUse`. Re-check `firstUse` after every callback invocation to turn
    // the most common violation -- a use added or removed at the head of the list -- into a
    // debug-build `SLANG_ASSERT` instead of a silent use-after-free. Release builds have no
    // guard at all (`SLANG_ASSERT` compiles out); the precondition is a hard requirement there,
    // not just in debug. This also doesn't catch every possible mutation (e.g. one that leaves
    // `firstUse` unchanged but frees a later use) -- it's a cheap debug-build guard rail for the
    // shape a mutating callback is most likely to produce, not a substitute for the precondition.
    for (auto use = callee->firstUse; use; use = use->nextUse)
    {
        if (use->usedValue != callee)
            continue;
        auto annotation = as<IRAnnotation>(use->getUser());
        if (annotation && annotation->getTarget() == callee)
        {
            auto expectedFirstUse = callee->firstUse;
            callback(annotation->getInst());
            SLANG_ASSERT(callee->firstUse == expectedFirstUse);
        }
    }
}

bool doesCalleeHaveSideEffect(IRInst* callee)
{
    bool sideEffect = !isNoSideEffectCallee(callee);

    // If the callee has no side effect, check if any of its associated functions have side
    // effect. If so, we want to keep the callee around.
    //
    // Typically, once the relevant pass has completed, the association is removed,
    // and at that point we can remove the function.
    //
    // TODO: We can narrow this check down a bit.. this check is only really
    // needed if the parent function that is performing the call is an operand
    // of a translate inst (i.e. IRTranslateBase/IRTranslatedTypeBase)
    //
    if (!sideEffect)
    {
        forEachAssociatedCallee(
            callee,
            [&](IRInst* associatedCallee)
            {
                sideEffect |= !isNoSideEffectCallee(associatedCallee);
                return;
            });
    }

    return sideEffect;
}

bool doesCalleeHaveSideEffect(IRInst* callee, Dictionary<IRInst*, bool>* cache)
{
    if (!cache)
        return doesCalleeHaveSideEffect(callee);

    if (auto cached = cache->tryGetValue(callee))
        return *cached;

    const bool sideEffect = doesCalleeHaveSideEffect(callee);
    cache->add(callee, sideEffect);
    return sideEffect;
}

IRInst* findInterfaceRequirement(IRInterfaceType* type, IRInst* key)
{
    for (UInt i = 0; i < type->getOperandCount(); i++)
    {
        if (auto req = as<IRInterfaceRequirementEntry>(type->getOperand(i)))
        {
            if (req->getRequirementKey() == key)
                return req->getRequirementVal();
        }
    }
    return nullptr;
}

IRInst* findWitnessTableEntry(IRWitnessTable* table, IRInst* key)
{
    if (table->getConformanceType()->getOp() == kIROp_VoidType)
    {
        IRBuilder builder(table->getModule());
        return builder.getVoidValue();
    }

    for (auto entry : table->getEntries())
    {
        if (entry->getRequirementKey() == key)
            return entry->getSatisfyingVal();
    }
    return nullptr;
}

IRInst* getVulkanPayloadLocation(IRInst* payloadGlobalVar)
{
    IRInst* location = nullptr;
    for (auto decor : payloadGlobalVar->getDecorations())
    {
        switch (decor->getOp())
        {
        case kIROp_VulkanRayPayloadDecoration:
        case kIROp_VulkanRayPayloadInDecoration:
        case kIROp_VulkanCallablePayloadDecoration:
        case kIROp_VulkanCallablePayloadInDecoration:
        case kIROp_VulkanHitObjectAttributesDecoration:
            return decor->getOperand(0);
        default:
            continue;
        }
    }
    return location;
}

IRInst* getInstInBlock(IRInst* inst)
{
    SLANG_RELEASE_ASSERT(inst);

    if (const auto block = as<IRBlock>(inst->getParent()); block)
        return inst;

    return getInstInBlock(inst->getParent());
}

ShortList<IRInst*> getPhiArgs(IRInst* phiParam)
{
    ShortList<IRInst*> result;
    auto block = cast<IRBlock>(phiParam->getParent());
    UInt paramIndex = 0;
    for (auto p = block->getFirstParam(); p; p = p->getNextParam())
    {
        if (p == phiParam)
            break;
        paramIndex++;
    }
    for (auto predBlock : block->getPredecessors())
    {
        auto termInst = as<IRUnconditionalBranch>(predBlock->getTerminator());
        SLANG_ASSERT(paramIndex < termInst->getArgCount());
        result.add(termInst->getArg(paramIndex));
    }
    return result;
}

void removePhiArgs(IRInst* phiParam)
{
    auto block = cast<IRBlock>(phiParam->getParent());
    UInt paramIndex = 0;
    for (auto p = block->getFirstParam(); p; p = p->getNextParam())
    {
        if (p == phiParam)
            break;
        paramIndex++;
    }
    for (auto predBlock : block->getPredecessors())
    {
        auto termInst = as<IRUnconditionalBranch>(predBlock->getTerminator());
        SLANG_ASSERT(paramIndex < termInst->getArgCount());
        termInst->removeArgument(paramIndex);
    }
}

int getParamIndexInBlock(IRParam* paramInst)
{
    auto block = as<IRBlock>(paramInst->getParent());
    if (!block)
        return -1;
    int paramIndex = 0;
    for (auto param : block->getParams())
    {
        if (param == paramInst)
            return paramIndex;
        paramIndex++;
    }
    return -1;
}

bool isGlobalOrUnknownMutableAddress(IRGlobalValueWithCode* parentFunc, IRInst* inst)
{
    auto root = getRootAddr(inst);

    auto type = unwrapAttributedType(inst->getDataType());
    if (!isPtrLikeOrHandleType(type))
        return false;

    if (root)
    {
        if (as<IRGLSLShaderStorageBufferType>(root->getDataType()))
        {
            // A storage buffer is mutable, so we need to treat it as a mutable address.
            return true;
        }
        // If this is a global readonly resource, it is not a mutable address.
        if (as<IRParameterGroupType>(root->getDataType()))
        {
            return false;
        }
        if (as<IRHLSLStructuredBufferType>(root->getDataType()))
        {
            return false;
        }
    }

    switch (root->getOp())
    {
    case kIROp_GlobalVar:
    case kIROp_GlobalParam:
    case kIROp_GlobalConstant:
    case kIROp_Var:
    case kIROp_Param:
        break;
    case kIROp_Call:
        return true;
    default:
        return true;
    }

    auto addrInstParent = getParentFunc(root);
    return (addrInstParent != parentFunc);
}

bool isZero(IRInst* inst)
{
    switch (inst->getOp())
    {
    case kIROp_IntLit:
        return as<IRIntLit>(inst)->getValue() == 0;
    case kIROp_FloatLit:
        return as<IRFloatLit>(inst)->getValue() == 0.0;
    case kIROp_BoolLit:
        return as<IRBoolLit>(inst)->getValue() == false;
    case kIROp_MakeCoopVector:
    case kIROp_MakeVector:
    case kIROp_MakeVectorFromScalar:
    case kIROp_MakeMatrix:
    case kIROp_MakeMatrixFromScalar:
    case kIROp_MatrixReshape:
    case kIROp_VectorReshape:
        {
            for (UInt i = 0; i < inst->getOperandCount(); i++)
            {
                if (!isZero(inst->getOperand(i)))
                {
                    return false;
                }
            }
            return true;
        }
    case kIROp_CastIntToFloat:
    case kIROp_CastFloatToInt:
        return isZero(inst->getOperand(0));
    default:
        return false;
    }
}

bool isOne(IRInst* inst)
{
    switch (inst->getOp())
    {
    case kIROp_IntLit:
        return as<IRIntLit>(inst)->getValue() == 1;
    case kIROp_FloatLit:
        return as<IRFloatLit>(inst)->getValue() == 1.0;
    case kIROp_BoolLit:
        return as<IRBoolLit>(inst)->getValue();
    case kIROp_MakeCoopVector:
    case kIROp_MakeVector:
    case kIROp_MakeVectorFromScalar:
    case kIROp_MakeMatrix:
    case kIROp_MakeMatrixFromScalar:
    case kIROp_MatrixReshape:
    case kIROp_VectorReshape:
        {
            for (UInt i = 0; i < inst->getOperandCount(); i++)
            {
                if (!isOne(inst->getOperand(i)))
                {
                    return false;
                }
            }
            return true;
        }
    case kIROp_CastIntToFloat:
    case kIROp_CastFloatToInt:
        return isOne(inst->getOperand(0));
    default:
        return false;
    }
}

IRPtrTypeBase* asRelevantPtrType(IRInst* inst)
{
    if (auto ptrType = as<IRPtrTypeBase>(inst))
    {
        if (ptrType->getAddressSpace() != AddressSpace::UserPointer)
            return ptrType;
    }
    return nullptr;
}

IRPtrTypeBase* isMutablePointerType(IRInst* inst)
{
    switch (inst->getOp())
    {
    case kIROp_BorrowInParamType:
        return nullptr;
    default:
        return asRelevantPtrType(inst);
    }
}

void initializeScratchData(IRInst* inst)
{
    List<IRInst*> workList;
    workList.add(inst);
    while (workList.getCount() != 0)
    {
        auto item = workList.getLast();
        workList.removeLast();
        item->scratchData = 0;
        for (auto child = item->getLastDecorationOrChild(); child; child = child->getPrevInst())
            workList.add(child);
    }
}


///
/// IRBlock related common helper methods
///
void moveParams(IRBlock* dest, IRBlock* src)
{
    for (auto param = src->getFirstChild(); param;)
    {
        auto nextInst = param->getNextInst();
        if (as<IRDecoration>(param) || as<IRParam, IRDynamicCastBehavior::NoUnwrap>(param))
        {
            param->insertAtEnd(dest);
        }
        else
        {
            break;
        }
        param = nextInst;
    }
}

List<IRBlock*> collectBlocksInRegion(
    IRDominatorTree* dom,
    IRLoop* loop,
    bool* outHasMultiLevelBreaks)
{
    return collectBlocksInRegion(
        dom,
        loop->getBreakBlock(),
        loop->getTargetBlock(),
        true,
        outHasMultiLevelBreaks);
}

List<IRBlock*> collectBlocksInRegion(IRDominatorTree* dom, IRLoop* loop)
{
    bool hasMultiLevelBreaks = false;
    return collectBlocksInRegion(
        dom,
        loop->getBreakBlock(),
        loop->getTargetBlock(),
        true,
        &hasMultiLevelBreaks);
}

List<IRBlock*> collectBlocksInRegion(
    IRDominatorTree* dom,
    IRSwitch* switchInst,
    bool* outHasMultiLevelBreaks)
{
    return collectBlocksInRegion(
        dom,
        switchInst->getBreakLabel(),
        as<IRBlock>(switchInst->getParent()),
        false,
        outHasMultiLevelBreaks);
}

List<IRBlock*> collectBlocksInRegion(IRDominatorTree* dom, IRSwitch* switchInst)
{
    bool hasMultiLevelBreaks = false;
    return collectBlocksInRegion(
        dom,
        switchInst->getBreakLabel(),
        as<IRBlock>(switchInst->getParent()),
        false,
        &hasMultiLevelBreaks);
}

HashSet<IRBlock*> getParentBreakBlockSet(IRDominatorTree* dom, IRBlock* block)
{
    HashSet<IRBlock*> parentBreakBlocksSet;
    for (IRBlock* currBlock = dom->getImmediateDominator(block); currBlock;
         currBlock = dom->getImmediateDominator(currBlock))
    {
        if (auto loopInst = as<IRLoop>(currBlock->getTerminator()))
        {
            if (!dom->dominates(loopInst->getBreakBlock(), block))
                parentBreakBlocksSet.add(loopInst->getBreakBlock());
        }
        else if (auto switchInst = as<IRSwitch>(currBlock->getTerminator()))
        {
            if (!dom->dominates(switchInst->getBreakLabel(), block))
                parentBreakBlocksSet.add(switchInst->getBreakLabel());
        }
    }

    return parentBreakBlocksSet;
}

List<IRBlock*> collectBlocksInRegion(
    IRDominatorTree* dom,
    IRBlock* breakBlock,
    IRBlock* firstBlock,
    bool includeFirstBlock,
    bool* outHasMultiLevelBreaks)
{
    List<IRBlock*> regionBlocks;
    HashSet<IRBlock*> regionBlocksSet;
    auto addBlock = [&](IRBlock* block)
    {
        if (regionBlocksSet.add(block))
            regionBlocks.add(block);
    };

    // Use dominator tree heirarchy to find break blocks of
    // all parent regions. We'll need to this to detect breaks
    // to outer regions (particularly when our region has no reachable
    // break block of its own)
    //
    HashSet<IRBlock*> parentBreakBlocksSet = getParentBreakBlockSet(dom, firstBlock);

    *outHasMultiLevelBreaks = false;

    addBlock(firstBlock);
    for (Index i = 0; i < regionBlocks.getCount(); i++)
    {
        auto block = regionBlocks[i];
        for (auto succ : block->getSuccessors())
        {
            if (parentBreakBlocksSet.contains(succ) && succ != breakBlock)
            {
                *outHasMultiLevelBreaks = true;
                continue;
            }

            if (succ == breakBlock)
                continue;
            if (!dom->dominates(firstBlock, succ))
                continue;
            if (!as<IRUnreachableBase>(breakBlock->getTerminator()))
            {
                if (dom->dominates(breakBlock, succ))
                    continue;
            }

            addBlock(succ);
        }
    }

    if (!includeFirstBlock)
    {
        regionBlocksSet.remove(firstBlock);
        regionBlocks.remove(firstBlock);
    }

    return regionBlocks;
}

List<IRBlock*> collectBlocksInRegion(
    IRGlobalValueWithCode* func,
    IRLoop* loopInst,
    bool* outHasMultiLevelBreaks)
{
    auto dom = computeDominatorTree(func);
    return collectBlocksInRegion(dom, loopInst, outHasMultiLevelBreaks);
}

List<IRBlock*> collectBlocksInRegion(IRGlobalValueWithCode* func, IRLoop* loopInst)
{
    auto dom = computeDominatorTree(func);
    bool hasMultiLevelBreaks = false;
    return collectBlocksInRegion(dom, loopInst, &hasMultiLevelBreaks);
}

IRBlock* getBlock(IRInst* inst)
{
    if (!inst)
        return nullptr;

    while (inst)
    {
        if (auto block = as<IRBlock>(inst))
            return block;
        inst = inst->getParent();
    }
    return nullptr;
}

///
/// End of IRBlock utility methods
///
IRVarLayout* findVarLayout(IRInst* value)
{
    if (auto layoutDecoration = value->findDecoration<IRLayoutDecoration>())
        return as<IRVarLayout>(layoutDecoration->getLayout());
    return nullptr;
}

UnownedStringSlice getBuiltinFuncName(IRInst* callee)
{
    auto decor = getResolvedInstForDecorations(callee)->findDecoration<IRKnownBuiltinDecoration>();
    if (!decor)
        return UnownedStringSlice();

    // For backward compatibility, convert enum back to string
    switch (decor->getName())
    {
    case KnownBuiltinDeclName::GeometryStreamAppend:
        return UnownedStringSlice::fromLiteral("GeometryStreamAppend");
    case KnownBuiltinDeclName::GeometryStreamRestart:
        return UnownedStringSlice::fromLiteral("GeometryStreamRestart");
    case KnownBuiltinDeclName::GetAttributeAtVertex:
        return UnownedStringSlice::fromLiteral("GetAttributeAtVertex");
    case KnownBuiltinDeclName::DispatchMesh:
        return UnownedStringSlice::fromLiteral("DispatchMesh");
    case KnownBuiltinDeclName::saturated_cooperation:
        return UnownedStringSlice::fromLiteral("saturated_cooperation");
    case KnownBuiltinDeclName::saturated_cooperation_using:
        return UnownedStringSlice::fromLiteral("saturated_cooperation_using");
    case KnownBuiltinDeclName::IDifferentiable:
        return UnownedStringSlice::fromLiteral("IDifferentiable");
    case KnownBuiltinDeclName::IDifferentiablePtr:
        return UnownedStringSlice::fromLiteral("IDifferentiablePtr");
    case KnownBuiltinDeclName::IForwardDifferentiable:
        return UnownedStringSlice::fromLiteral("IForwardDifferentiable");
    case KnownBuiltinDeclName::IBackwardDifferentiable:
        return UnownedStringSlice::fromLiteral("IBackwardDifferentiable");
    case KnownBuiltinDeclName::IBwdCallable:
        return UnownedStringSlice::fromLiteral("IBwdCallable");
    case KnownBuiltinDeclName::NullDifferential:
        return UnownedStringSlice::fromLiteral("NullDifferential");
    case KnownBuiltinDeclName::OperatorAddressOf:
        return UnownedStringSlice::fromLiteral("OperatorAddressOf");
    case KnownBuiltinDeclName::WaveIsFirstLane:
        return UnownedStringSlice::fromLiteral("WaveIsFirstLane");
    case KnownBuiltinDeclName::WaveReadLaneFirst:
        return UnownedStringSlice::fromLiteral("WaveReadLaneFirst");
    default:
        return UnownedStringSlice();
    }
}

KnownBuiltinDeclName getBuiltinFuncEnum(IRInst* callee)
{
    auto decor = getResolvedInstForDecorations(callee)->findDecoration<IRKnownBuiltinDecoration>();
    if (!decor)
        return KnownBuiltinDeclName::COUNT; // Use COUNT as invalid value
    return decor->getName();
}

void hoistInstOutOfASMBlocks(IRBlock* block)
{
    for (auto inst : block->getChildren())
    {
        if (auto asmBlock = as<IRSPIRVAsm>(inst))
        {
            IRInst* next = nullptr;
            for (auto i = asmBlock->getFirstChild(); i; i = next)
            {
                next = i->getNextInst();
                if (!as<IRSPIRVAsmInst>(i) && !as<IRSPIRVAsmOperand>(i))
                    i->insertBefore(asmBlock);
            }
        }
    }
}

IRType* getSPIRVSampledElementType(IRInst* sampledType)
{
    auto sampledElementType = getVectorElementType((IRType*)sampledType);

    IRBuilder builder(sampledType);
    switch (sampledElementType->getOp())
    {
    case kIROp_HalfType:
        sampledElementType = builder.getBasicType(BaseType::Float);
        break;
    case kIROp_UInt16Type:
    case kIROp_UInt8Type:
    case kIROp_CharType:
        sampledElementType = builder.getBasicType(BaseType::UInt);
        break;
    case kIROp_Int8Type:
    case kIROp_Int16Type:
        sampledElementType = builder.getBasicType(BaseType::Int);
        break;
    default:
        break;
    }
    return sampledElementType;
}

IRType* replaceVectorElementType(IRType* originalVectorType, IRType* t)
{
    if (auto orignalVectorType = as<IRVectorType>(originalVectorType))
    {
        IRBuilder builder(originalVectorType);
        return builder.getVectorType(t, orignalVectorType->getElementCount());
    }
    return t;
}

IRParam* getParamAt(IRBlock* block, UIndex ii)
{
    UIndex index = 0;
    for (auto param : block->getParams())
    {
        if (ii == index)
            return param;

        index++;
    }
    SLANG_UNEXPECTED("ii >= paramCount");
}

UnownedStringSlice getBasicTypeNameHint(IRType* basicType)
{
    switch (basicType->getOp())
    {
    case kIROp_IntType:
        return UnownedStringSlice::fromLiteral("int");
    case kIROp_Int8Type:
        return UnownedStringSlice::fromLiteral("int8_t");
    case kIROp_Int16Type:
        return UnownedStringSlice::fromLiteral("int16_t");
    case kIROp_Int64Type:
        return UnownedStringSlice::fromLiteral("int64_t");
    case kIROp_IntPtrType:
        return UnownedStringSlice::fromLiteral("intptr_t");
    case kIROp_UIntType:
        return UnownedStringSlice::fromLiteral("uint");
    case kIROp_UInt8Type:
        return UnownedStringSlice::fromLiteral("uint8_t");
    case kIROp_UInt16Type:
        return UnownedStringSlice::fromLiteral("uint16_t");
    case kIROp_UInt64Type:
        return UnownedStringSlice::fromLiteral("uint64_t");
    case kIROp_UIntPtrType:
        return UnownedStringSlice::fromLiteral("uintptr_t");
    case kIROp_FloatType:
        return UnownedStringSlice::fromLiteral("float");
    case kIROp_HalfType:
        return UnownedStringSlice::fromLiteral("half");
    case kIROp_DoubleType:
        return UnownedStringSlice::fromLiteral("double");
    case kIROp_BoolType:
        return UnownedStringSlice::fromLiteral("bool");
    case kIROp_VoidType:
        return UnownedStringSlice::fromLiteral("void");
    case kIROp_CharType:
        return UnownedStringSlice::fromLiteral("char");
    default:
        return UnownedStringSlice();
    }
}

struct GenericChildrenMigrationContextImpl
{
    IRCloneEnv cloneEnv;
    IRGeneric* srcGeneric;
    IRGeneric* dstGeneric;
    DeduplicateContext deduplicateContext;

    void init(IRGeneric* genericSrc, IRGeneric* genericDst, IRInst* insertBefore)
    {
        srcGeneric = genericSrc;
        dstGeneric = genericDst;

        if (!genericSrc)
            return;
        auto srcParam = genericSrc->getFirstBlock()->getFirstParam();
        auto dstParam = genericDst->getFirstBlock()->getFirstParam();
        while (srcParam && dstParam)
        {
            cloneEnv.mapOldValToNew[srcParam] = dstParam;
            srcParam = srcParam->getNextParam();
            dstParam = dstParam->getNextParam();
        }
        cloneEnv.mapOldValToNew[genericSrc] = genericDst;
        cloneEnv.mapOldValToNew[genericSrc->getFirstBlock()] = genericDst->getFirstBlock();

        if (insertBefore)
        {
            for (auto inst = genericDst->getFirstBlock()->getFirstOrdinaryInst();
                 inst && inst != insertBefore;
                 inst = inst->getNextInst())
            {
                IRInstKey key = {inst};
                deduplicateContext.deduplicateMap.addIfNotExists(key, inst);
            }
        }
    }

    IRInst* deduplicate(IRInst* value)
    {
        return deduplicateContext.deduplicate(
            value,
            [this](IRInst* inst)
            {
                if (inst->getParent() != dstGeneric->getFirstBlock())
                    return false;
                switch (inst->getOp())
                {
                case kIROp_Param:
                case kIROp_StructType:
                case kIROp_StructKey:
                case kIROp_InterfaceType:
                case kIROp_ClassType:
                case kIROp_Func:
                case kIROp_Generic:
                case kIROp_Expand:
                    return false;
                default:
                    break;
                }
                if (as<IRConstant>(inst))
                    return false;
                if (getIROpInfo(inst->getOp()).isHoistable())
                    return false;
                return true;
            });
    }

    IRInst* cloneInst(IRBuilder* builder, IRInst* src)
    {
        if (!srcGeneric)
            return src;
        if (findOuterGeneric(src) == srcGeneric)
        {
            auto cloned = Slang::cloneInst(&cloneEnv, builder, src);
            auto deduplicated = deduplicate(cloned);
            if (deduplicated != cloned)
                cloneEnv.mapOldValToNew[src] = deduplicated;
            return deduplicated;
        }
        return src;
    }
};

GenericChildrenMigrationContext::GenericChildrenMigrationContext()
{
    impl = new GenericChildrenMigrationContextImpl();
}

GenericChildrenMigrationContext::~GenericChildrenMigrationContext()
{
    delete impl;
}

IRCloneEnv* GenericChildrenMigrationContext::getCloneEnv()
{
    return &impl->cloneEnv;
}

void GenericChildrenMigrationContext::init(
    IRGeneric* genericSrc,
    IRGeneric* genericDst,
    IRInst* insertBefore)
{
    impl->init(genericSrc, genericDst, insertBefore);
}

IRInst* GenericChildrenMigrationContext::deduplicate(IRInst* value)
{
    return impl->deduplicate(value);
}

IRInst* GenericChildrenMigrationContext::cloneInst(IRBuilder* builder, IRInst* src)
{
    return impl->cloneInst(builder, src);
}

IRType* dropNormAttributes(IRType* const t)
{
    if (const auto a = as<IRAttributedType>(t))
    {
        switch (a->getAttr()->getOp())
        {
        case kIROp_UNormAttr:
        case kIROp_SNormAttr:
            return dropNormAttributes(a->getBaseType());
        }
    }
    return t;
}

DerivativeGroupMode inferDerivativeGroupMode(IRFunc* entryPoint)
{
    if (auto decoration = entryPoint->findDecoration<IRDerivativeGroupDecoration>())
        return decoration->getMode();

    if (auto numThreads = entryPoint->findDecoration<IRNumThreadsDecoration>())
    {
        // Y selects the default grouping; the full thread-group shape is validated separately.
        // Only inspect a literal Y; a specialization constant's default can be overridden.
        if (auto y = numThreads->getY())
            return y->getValue() == 1 ? DerivativeGroupMode::Linear : DerivativeGroupMode::Quad;
    }
    return DerivativeGroupMode::Quad;
}

/// Gets a literal thread count, unwrapping a specialization constant's default when needed.
static IRIntLit* _getDefaultThreadCount(IRInst* threadCount)
{
    if (auto intLit = as<IRIntLit>(threadCount))
        return intLit;

    auto globalParam = as<IRGlobalParam>(threadCount);
    auto defaultValueDecor =
        globalParam ? globalParam->findDecoration<IRDefaultValueDecoration>() : nullptr;
    if (defaultValueDecor)
        if (auto defaultIntLit = as<IRIntLit>(defaultValueDecor->getOperand(0)))
            return defaultIntLit;

    IRBuilder builder(globalParam ? (IRInst*)globalParam : threadCount);
    return cast<IRIntLit>(
        builder.getIntValue(globalParam ? globalParam->getDataType() : builder.getIntType(), 1));
}

void verifyComputeDerivativeGroupModifiers(
    DiagnosticSink* sink,
    SourceLoc errorLoc,
    bool quadAttr,
    bool linearAttr,
    IRNumThreadsDecoration* numThreadsDecor)
{
    if (!numThreadsDecor)
        return;

    if (quadAttr && linearAttr)
    {
        sink->diagnose(
            Diagnostics::OnlyOneOfDerivativeGroupLinearOrQuadCanBeSet{.location = errorLoc});
    }

    IRIntegerValue x = _getDefaultThreadCount(numThreadsDecor->getOperand(0))->getValue();
    IRIntegerValue y = _getDefaultThreadCount(numThreadsDecor->getOperand(1))->getValue();
    IRIntegerValue z = _getDefaultThreadCount(numThreadsDecor->getOperand(2))->getValue();

    if (quadAttr)
    {
        if (x % 2 != 0 || y % 2 != 0)
            sink->diagnose(
                Diagnostics::DerivativeGroupQuadMustBeMultiple2ForXyThreads{.location = errorLoc});
    }
    else if (linearAttr)
    {
        if ((x * y * z) % 4 != 0)
            sink->diagnose(Diagnostics::DerivativeGroupLinearMustBeMultiple4ForTotalThreadCount{
                .location = errorLoc});
    }
}

int getIRVectorElementSize(IRType* type)
{
    if (type->getOp() != kIROp_VectorType)
        return 1;
    return (int)(as<IRIntLit>(as<IRVectorType>(type)->getElementCount())->value.intVal);
}
IRType* getIRVectorBaseType(IRType* type)
{
    if (type->getOp() != kIROp_VectorType)
        return type;
    return as<IRVectorType>(type)->getElementType();
}

IRType* getElementType(IRBuilder& builder, IRType* valueType)
{
    valueType = (IRType*)unwrapAttributedType(valueType);
    if (auto arrayType = as<IRArrayTypeBase>(valueType))
    {
        return arrayType->getElementType();
    }
    else if (auto vectorType = as<IRVectorType>(valueType))
    {
        return vectorType->getElementType();
    }
    else if (auto packedVectorType = as<IRMetalPackedVectorType>(valueType))
    {
        return packedVectorType->getElementType();
    }
    else if (auto basicType = as<IRBasicType>(valueType))
    {
        return basicType;
    }
    else if (auto coopVecType = as<IRCoopVectorType>(valueType))
    {
        return coopVecType->getElementType();
    }
    else if (auto matrixType = as<IRMatrixType>(valueType))
    {
        return builder.getVectorType(matrixType->getElementType(), matrixType->getColumnCount());
    }
    else if (auto coopMatType = as<IRCoopMatrixType>(valueType))
    {
        return coopMatType->getElementType();
    }
    else if (auto hlslInputPatchType = as<IRHLSLInputPatchType>(valueType))
    {
        return hlslInputPatchType->getElementType();
    }
    return nullptr;
}

IRType* getFieldType(IRType* valueType, IRStructKey* key)
{
    valueType = (IRType*)unwrapAttributedType(valueType);
    if (auto structType = as<IRStructType>(valueType))
    {
        for (auto field : structType->getFields())
        {
            if (field->getKey() == key)
            {
                return field->getFieldType();
            }
        }
    }
    return nullptr;
}

Int getSpecializationConstantId(IRGlobalParam* param)
{
    auto layout = findVarLayout(param);
    if (!layout)
        return 0;

    auto offset = layout->findOffsetAttr(LayoutResourceKind::SpecializationConstant);
    if (!offset)
        return 0;

    return offset->getOffset();
}

IRBlock* getLoopHeaderForConditionBlock(IRBlock* block)
{
    // Go through uses and check if any of them are a loop condition block.
    for (auto use = block->firstUse; use; use = use->nextUse)
    {
        if (auto loop = as<IRLoop>(use->getUser()))
        {
            if (loop->getTargetBlock() == block)
                return cast<IRBlock>(loop->getParent());
        }
    }
    return nullptr;
}

// Return true if `inst` is defined at the start of `block`.
// That is, either `inst` is defined in a block that dominates `block`,
// or `inst` is defined in a parent of `block`.
bool isInstAvailableAtBlock(IRDominatorTree& dom, IRInst* inst, IRBlock* block)
{
    auto defBlock = as<IRBlock>(inst->getParent());
    if (!defBlock)
        return true;
    if (dom.dominates(defBlock, block))
        return true;
    // If inst is a parent of block, it is available.
    for (IRInst* curr = block; curr; curr = curr->getParent())
    {
        if (curr == defBlock)
            return true;
    }
    return false;
}


bool doesTargetSupportUnrestrictedPointers(TargetRequest* req)
{
    return isCPUTarget(req) || isCUDATarget(req) || isCPUTargetViaLLVM(req);
}

bool canInstBeStored(IRInst* inst)
{
    // Cannot store insts whose value is a type or a witness table, or a function.
    // These insts get lowered to target-specific logic, and cannot be
    // stored into variables or context structs as normal values.
    //
    if (as<IRTypeType>(inst->getDataType()) || as<IRWitnessTableType>(inst->getDataType()) ||
        as<IRTypeKind>(inst->getDataType()) || as<IRGenericKind>(inst->getDataType()) ||
        as<IRFuncType>(inst->getDataType()) || !inst->getDataType())
        return false;

    return true;
}

// Should `inst` be duplicated at use sites instead of being
// stored to a temporary variable?
// Some targets such as spirv don't support forming variables of pointer types,
// so in those cases we will duplicate pointer access chains at use sites.
//
bool shouldDuplicateInstAtUseSite(IRInst* inst, TargetProgram* target)
{
    switch (inst->getOp())
    {
    case kIROp_CastDescriptorHandleToResource:
    case kIROp_CastDynamicResource:
        // These casts potentially produces non-storable types, so we will always duplicate them at
        // use sites.
        return true;
    }

    if (!canInstBeStored(inst))
        return true;

    // For targets that don't support forming variables of pointer types,
    // we will duplicate pointer access chains at use sites.
    if (isPtrLikeOrHandleType(inst->getDataType()))
    {
        if (doesTargetSupportUnrestrictedPointers(target->getTargetReq()))
            return false;
        if (auto ptrType = as<IRPtrTypeBase>(inst->getDataType()))
        {
            // A user-pointer type can be stored to a variable.
            if (ptrType->getAddressSpace() == AddressSpace::UserPointer)
                return false;
        }
        return true;
    }
    return false;
}

void legalizeDefUse(IRGlobalValueWithCode* func, TargetProgram* target)
{
    // After multi-level break lowering, we may create situations where an inst
    // defined in an inner region is referenced from an outer region, which creates
    // an invalid IR form where the def does not dominate its use. This function
    // fixes up such situations by creating temporary variables in the common dominator block, and
    // insert a store to the variable in the inner region, and replacing the uses with loads from
    // the variable.
    auto dom = computeDominatorTree(func);

    // Make a map of loop condition blocks to their loop header.
    // We need this because we'll be treating loop condition blocks as
    // special cases (they are the special blocks since they "dominate" themselves,
    // in the dominator tree sense)
    //
    Dictionary<IRBlock*, IRBlock*> loopHeaderBlockMap;
    for (auto block : func->getBlocks())
    {
        if (auto header = getLoopHeaderForConditionBlock(block))
            loopHeaderBlockMap.add(block, header);
    }
    bool needRerun = true;
    while (needRerun)
    {
        needRerun = false;
        for (auto block : func->getBlocks())
        {
            for (auto inst : block->getModifiableChildren())
            {
                // Inspect all uses of `inst` and find the common dominator of all use sites.
                IRBlock* commonDominator = block;
                for (auto use = inst->firstUse; use; use = use->nextUse)
                {
                    auto userBlock = as<IRBlock>(use->getUser()->getParent());
                    if (!userBlock)
                        continue;
                    while (commonDominator && !dom->dominates(commonDominator, userBlock))
                    {
                        commonDominator = dom->getImmediateDominator(commonDominator);
                    }
                }
                SLANG_ASSERT(commonDominator);

                // If commonDominator is 'block' and if the inst is not a Var in
                // a loop condition block, we can skip the legalization.
                //
                if (commonDominator == block &&
                    !(as<IRVar>(inst) && loopHeaderBlockMap.containsKey(block)))
                    continue;

                // Normally, if the common dominator is not `block`, we can simply move the
                // definition to the common dominator. An exception is when the common dominator is
                // the target block of a loop. Another exception is when a var in the loop condition
                // block is accessed both inside and outside the loop. It is technically visible,
                // but effects on the 'var' are not visible outside the loop, so we'll need to hoist
                // it out of the loop.
                //
                // Note that after normalization, loops are in the form of:
                // ```
                // loop { if (condition) block; else break; }
                // ```
                // If we find ourselves needing to make the inst available right before
                // the `if`, it means we are seeing uses of the inst outside the loop.
                // In this case, we should insert a var/move the inst before the loop
                // instead of before the `if`. This situation can occur in the IR if
                // the original code is lowered from a `do-while` loop.
                //
                if (loopHeaderBlockMap.containsKey(commonDominator))
                {
                    bool shouldMoveToHeader = false;

                    // Check that the break-block dominates any of the uses are past the break
                    // block
                    for (auto _use = inst->firstUse; _use; _use = _use->nextUse)
                    {
                        if (dom->dominates(
                                as<IRLoop>(loopHeaderBlockMap[commonDominator]->getTerminator())
                                    ->getBreakBlock(),
                                _use->getUser()->getParent()))
                        {
                            shouldMoveToHeader = true;
                            break;
                        }
                    }
                    if (shouldMoveToHeader)
                    {
                        commonDominator = loopHeaderBlockMap[commonDominator];
                    }
                }

                // Now we can legalize uses based on the type of `inst`.
                if (auto var = as<IRVar>(inst))
                {
                    // If inst is an var, this is easy, we just move it to the
                    // common dominator.
                    if (var->getParent() != commonDominator)
                        var->insertBefore(commonDominator->getTerminator());
                }
                else if (shouldDuplicateInstAtUseSite(inst, target))
                {
                    // If inst must be duplicated at use sites due to target restrictions,
                    // we will make a copy of it at its use, and rerun the entire processing loop
                    // to transitively duplicate referenced operands.
                    traverseUses(
                        inst,
                        [&](IRUse* use)
                        {
                            auto userBlock = as<IRBlock>(use->getUser()->getParent());
                            if (!userBlock)
                                return;
                            // Only fix the use of the current definition of `inst` does not
                            // dominate it.
                            if (!dom->dominates(block, userBlock))
                            {
                                IRBuilder builder(func);
                                builder.setInsertBefore(use->getUser());
                                IRCloneEnv env;
                                auto clonedInst = Slang::cloneInst(&env, &builder, inst);
                                builder.replaceOperand(use, clonedInst);

                                // If any operands of the gep inst is not defined at the use site,
                                // we need to rerun the legalization and make sure they are
                                // also made available.
                                for (UInt i = 0; i < inst->getOperandCount(); i++)
                                {
                                    auto operand = inst->getOperand(i);
                                    if (!isInstAvailableAtBlock(*dom, operand, userBlock))
                                    {
                                        needRerun = true;
                                        break;
                                    }
                                }
                            }
                        });
                }
                else
                {
                    // For all other insts, we need to create a local var for it,
                    // and replace all uses with a load from the local var.
                    IRBuilder builder(func);
                    builder.setInsertBefore(commonDominator->getTerminator());
                    IRVar* tempVar = builder.emitVar(inst->getFullType());

                    traverseUses(
                        inst,
                        [&](IRUse* use)
                        {
                            auto userBlock = as<IRBlock>(use->getUser()->getParent());
                            if (!userBlock)
                                return;
                            // Only fix the use of the current definition of `inst` does not
                            // dominate it.
                            if (!dom->dominates(block, userBlock))
                            {
                                // Replace the use with a load of tempVar.
                                builder.setInsertBefore(use->getUser());
                                auto load = builder.emitLoad(tempVar);
                                builder.replaceOperand(use, load);
                            }
                        });
                    builder.setInsertAfter(inst);
                    builder.emitStore(tempVar, inst);
                }
            }
        }
    }
}

UnownedStringSlice getMangledName(IRInst* inst)
{
    for (auto decor : inst->getDecorations())
    {
        if (auto linkageDecor = as<IRLinkageDecoration>(decor))
            return linkageDecor->getMangledName();
    }
    return UnownedStringSlice();
}

bool isFirstBlock(IRInst* inst)
{
    auto block = as<IRBlock>(inst);
    if (!block)
        return false;
    if (!block->getParent())
        return false;
    return block->getParent()->getFirstBlock() == block;
}

bool isSpecConstRateType(IRType* type)
{
    if (auto rateQualifiedType = as<IRRateQualifiedType>(type))
    {
        if (as<IRSpecConstRate>(rateQualifiedType->getRate()))
        {
            return true;
        }
    }
    return false;
}

IRType* maybeAddRateType(IRBuilder* builder, IRType* rateQulifiedType, IRType* oldType)
{
    if (as<IRRateQualifiedType>(oldType))
    {
        return oldType;
    }

    if (isSpecConstRateType(rateQulifiedType))
    {
        return builder->getRateQualifiedType(builder->getSpecConstRate(), oldType);
    }
    return oldType;
}

// Ensures `type` carries a SpecConst rate.
// If the type already has a different rate (e.g. ConstExpr from a `static const`
// expression whose operands are specialization constants), the existing rate is
// replaced, as a value that depends on a spec-const is only known at pipeline
// creation time, so `ConstExpr` (compile-time) would be incorrect.
//
IRType* ensureSpecConstRate(IRBuilder* builder, IRType* type)
{
    if (isSpecConstRateType(type))
        return type;

    // Strip any existing rate (e.g. ConstExpr) to avoid double-wrapping,
    // since getRateQualifiedType does not unwrap for us.
    if (auto rateQualified = as<IRRateQualifiedType>(type))
        return builder->getRateQualifiedType(
            builder->getSpecConstRate(),
            rateQualified->getValueType());

    return builder->getRateQualifiedType(builder->getSpecConstRate(), type);
}

bool canOperationBeSpecConst(IROp op, IRType* resultType, IRInst* const* fixedArgs, IRUse* operands)
{
    // Returns true for ops that can be declared as an operation under `OpSpecConstantOp`.
    //
    // Integer arithmetic and comparison operations can be `OpSpecConstantOp` with the `Shader`
    // capability, while floating-point arithmetic and comparison operations require the
    // `Kernel` capability. We only support `Shader` capability for now, return false when
    // floating-point arithmetic/comparison is encountered.
    switch (op)
    {
    case kIROp_Add:
    case kIROp_Sub:
    case kIROp_Mul:
    case kIROp_Div:
    case kIROp_Neg:
        return !isFloatingType(resultType);

    case kIROp_Eql:
    case kIROp_Neq:
    case kIROp_Leq:
    case kIROp_Geq:
    case kIROp_Less:
    case kIROp_Greater:
    case kIROp_And:
    case kIROp_Or:
        {
            IRInst* operand1;
            IRInst* operand2;
            if (fixedArgs)
            {
                operand1 = fixedArgs[0];
                operand2 = fixedArgs[1];
            }
            else
            {
                operand1 = operands[0].get();
                operand2 = operands[1].get();
            }
            return !isFloatingType(operand1->getDataType()) &&
                   !isFloatingType(operand2->getDataType());
        }

    case kIROp_Not:
    case kIROp_IRem:
    case kIROp_Lsh:
    case kIROp_Rsh:
    case kIROp_BitAnd:
    case kIROp_BitOr:
    case kIROp_BitXor:
    case kIROp_BitNot:
    case kIROp_IntCast:
    case kIROp_FloatCast:
    case kIROp_Select:
        return true;

    default:
        return false;
    }
}

bool shouldHaveSpecConstRate(
    IROp op,
    IRType* resultType,
    UInt operandCount,
    IRInst* const* operands)
{
    if (operandCount == 0)
        return false;

    // Unwrap any rate qualification so canOperationBeSpecConst sees the bare
    // value type. isFloatingType checks as<IRBasicType> which doesn't match
    // rate-qualified types like @ConstExpr float, so without unwrapping we
    // would incorrectly allow float arithmetic as `OpSpecConstantOp`.
    IRType* valueType = resultType;
    if (auto rateQualifiedType = as<IRRateQualifiedType>(resultType))
        valueType = rateQualifiedType->getValueType();

    if (!canOperationBeSpecConst(op, valueType, operands, nullptr))
        return false;

    // An instruction whose result carries a spec-const rate is hoisted and
    // emitted as OpSpecConstantOp for SPIR-V. That is only valid when
    // every operand is itself a specialization constant or a plain
    // constant. Mixing in a runtime value would produce invalid SPIR-V.
    bool hasSpecConstOperand = false;
    for (UInt ii = 0; ii < operandCount; ++ii)
    {
        if (isSpecConstRateType(operands[ii]->getFullType()))
            hasSpecConstOperand = true;
        else if (!as<IRConstant>(operands[ii]))
            return false;
    }
    return hasSpecConstOperand;
}

bool isInstHoistable(IROp op)
{
    return (getIROpInfo(op).flags & kIROpFlag_Hoistable);
}

IRType* getUnsignedTypeFromSignedType(IRBuilder* builder, IRType* type)
{
    SLANG_RELEASE_ASSERT(isSignedType(type));

    auto elementType = getVectorOrCoopMatrixElementType(type);

    IROp op = type->getOp();
    switch (op)
    {
    case kIROp_MatrixType:
        {
            auto unsignedTypeOp = getOppositeSignIntTypeOp(elementType->getOp());
            auto matType = as<IRMatrixType>(type);
            SLANG_RELEASE_ASSERT(matType);
            return builder->getMatrixType(
                builder->getType(unsignedTypeOp),
                matType->getRowCount(),
                matType->getColumnCount(),
                matType->getLayout());
        }
    case kIROp_VectorType:
        {
            auto unsignedTypeOp = getOppositeSignIntTypeOp(elementType->getOp());
            auto vecType = as<IRVectorType>(type);
            SLANG_RELEASE_ASSERT(vecType);
            return builder->getVectorType(
                builder->getType(unsignedTypeOp),
                vecType->getElementCount());
        }
    case kIROp_IntType:
    case kIROp_Int16Type:
    case kIROp_Int64Type:
    case kIROp_Int8Type:
        return builder->getType(getOppositeSignIntTypeOp(elementType->getOp()));
    default:
        return type;
    }
}

bool isSignedType(IRType* type)
{
    switch (type->getOp())
    {
    case kIROp_FloatType:
    case kIROp_DoubleType:
    case kIROp_FloatE4M3Type:
    case kIROp_FloatE5M2Type:
    case kIROp_BFloat16Type:
        return true;
    case kIROp_IntType:
    case kIROp_Int16Type:
    case kIROp_Int64Type:
    case kIROp_Int8Type:
        return true;
    case kIROp_VectorType:
        return isSignedType(as<IRVectorType>(type)->getElementType());
    case kIROp_MatrixType:
        return isSignedType(as<IRMatrixType>(type)->getElementType());
    default:
        return false;
    }
}

bool isIROpaqueType(IRType* type)
{
    switch (type->getOp())
    {
    case kIROp_TextureType:
    case kIROp_GLSLImageType:
    case kIROp_SamplerStateType:
    case kIROp_SamplerComparisonStateType:
    case kIROp_SubpassInputType:
    case kIROp_RaytracingAccelerationStructureType:
    case kIROp_RayQueryType:
    case kIROp_HitObjectType:
        return true;
    default:
        return false;
    }
}

IRInst* peelAddressForwardingOps(IRInst* addr)
{
    for (;;)
    {
        switch (addr->getOp())
        {
        case kIROp_FieldAddress:
        case kIROp_GetElementPtr:
        case kIROp_GetOffsetPtr:
        case kIROp_BitCast:
        case kIROp_Reinterpret:
        case kIROp_PtrCast:
            addr = addr->getOperand(0);
            continue;
        default:
            return addr;
        }
    }
}

bool isDebugInfoInst(IRInst* inst)
{
    // Debug instructions describe source locations, variables, and scopes rather than executing at
    // runtime. This classification lets an analysis ignore them when they do not affect the
    // question it answers. An optimization must still preserve required debug information.
    switch (inst->getOp())
    {
    case kIROp_DebugValue:
    case kIROp_DebugVar:
    case kIROp_DebugLine:
    case kIROp_DebugLocationDecoration:
    case kIROp_DebugFuncDecoration:
    case kIROp_DebugSource:
    case kIROp_DebugInlinedAt:
    case kIROp_DebugInlinedVariable:
    case kIROp_DebugScope:
    case kIROp_DebugNoScope:
    case kIROp_DebugFunction:
    case kIROp_DebugLexicalBlock:
    case kIROp_DebugBuildIdentifier:
    case kIROp_DebugCompilationUnit:
        return true;
    default:
        return false;
    }
}

bool doesOpReadResourceContents(IROp op)
{
    // These dedicated operations produce results that depend on resource contents. A resource
    // method represented as an `IRCall` is classified through its callee instead. Operations that
    // only query resource dimensions or other metadata do not read the contents.
    switch (op)
    {
    case kIROp_ImageGatherOffset:
    case kIROp_ImageLoad:
    case kIROp_Sample:
    case kIROp_SampleGrad:
    case kIROp_StructuredBufferLoad:
    case kIROp_ByteAddressBufferLoad:
    case kIROp_StructuredBufferLoadStatus:
    case kIROp_RWStructuredBufferLoad:
    case kIROp_RWStructuredBufferLoadStatus:
    case kIROp_StructuredBufferConsume:
    case kIROp_SubpassLoad:
        return true;
    default:
        return false;
    }
}

bool doesOpProduceResourceContentAddress(IROp op)
{
    // These operations create an address whose storage belongs to a resource. Analyses should
    // classify them as resource-content roots before applying the general rule that follows operand
    // zero through other address projections and pointer casts.
    switch (op)
    {
    case kIROp_GetStructuredBufferPtr:
    case kIROp_GetUntypedBufferPtr:
    case kIROp_RWStructuredBufferGetElementPtr:
    case kIROp_ImageSubscript:
    case kIROp_ImageTexelPointer:
    case kIROp_SPIRVLoadTexelPointerFromHeap:
        return true;
    default:
        return false;
    }
}

// True if `addr`'s chain bottoms out at `GetOptiXSbtDataPtr` (the OptiX SBT), peeling every
// forwarding op, including the `BitCast`/`GetOffsetPtr` that `getRootAddr` does not peel.
static bool isAddressIntoOptiXShaderBindingTable(IRInst* addr)
{
    return peelAddressForwardingOps(addr)->getOp() == kIROp_GetOptiXSbtDataPtr;
}

bool isPointerToImmutableLocation(IRInst* loc)
{
    // The OptiX SBT (`GetOptiXSbtDataPtr`) is typed as a `ConstantBuffer<>` but is mutated
    // in place by the host between dispatches, so it is not immutable; otherwise CUDA emit
    // would route its loads through the read-only cache (`__ldg`) and read stale data.
    // Genuine `ConstantBuffer<>` (not SBT-rooted) is unaffected. See shader-slang/slang#10188.
    if (isAddressIntoOptiXShaderBindingTable(loc))
        return false;

    switch (loc->getOp())
    {
    case kIROp_GetStructuredBufferPtr:
    case kIROp_RWStructuredBufferGetElementPtr:
    case kIROp_ImageSubscript:
        return isPointerToImmutableLocation(loc->getOperand(0));
    default:
        break;
    }

    auto type = loc->getDataType();
    if (!type)
        return false;

    switch (type->getOp())
    {
    case kIROp_HLSLStructuredBufferType:
    case kIROp_HLSLByteAddressBufferType:
    case kIROp_ConstantBufferType:
    case kIROp_ParameterBlockType:
        return true;
    default:
        break;
    }

    if (auto textureType = as<IRTextureType>(type))
        return textureType->getAccess() == SLANG_RESOURCE_ACCESS_READ;

    if (auto ptrType = as<IRPtrTypeBase>(type))
    {
        switch (ptrType->getAddressSpace())
        {
        case AddressSpace::BuiltinInput:
        case AddressSpace::Input:
        case AddressSpace::MetalObjectData:
        case AddressSpace::Uniform:
        case AddressSpace::UniformConstant:
            return true;
        }
        if (ptrType->getAccessQualifier() == AccessQualifier::Immutable)
            return true;
    }
    return false;
}

bool isGenericParameter(IRInst* inst)
{
    // The generic parameter must be in the first block
    bool isParam = inst->getOp() == kIROp_Param;
    bool isGeneric = false;
    if (auto irBlock = as<IRBlock>(inst->parent))
    {
        isGeneric = as<IRGeneric>(irBlock->getParent()) != nullptr;
    }
    return isParam && isGeneric;
}

bool canRelaxInstOrderRule(IRInst* inst, IRInst* useOfInst)
{
    bool isSameBlock = (inst->getParent() == useOfInst->getParent());
    return isSameBlock && isGenericParameter(useOfInst) && (useOfInst->getDataType() == inst);
}

IRIntegerValue getInterfaceAnyValueSize(IRInst* type, SourceLoc usageLoc)
{
    SLANG_UNUSED(usageLoc);

    if (auto decor = type->findDecoration<IRAnyValueSizeDecoration>())
    {
        return decor->getSize();
    }

    // We could conceivably make it an error to have an interface
    // without an `[anyValueSize(...)]` attribute, but then we risk
    // producing error messages even when doing 100% static specialization.
    //
    // It is simpler to use a reasonable default size and treat any
    // type without an explicit attribute as using that size.
    //
    return kDefaultAnyValueSize;
}

IRType* getTextureTypeFromCombinedTextureSampler(IRType* type)
{
    IRBuilder builder(type);
    builder.setInsertBefore(type);
    auto textureType = as<IRTextureTypeBase>(type);
    return builder.getTextureType(
        textureType->getElementType(),
        textureType->getShapeInst(),
        textureType->getIsArrayInst(),
        textureType->getIsMultisampleInst(),
        textureType->getSampleCountInst(),
        textureType->getAccessInst(),
        textureType->getIsShadowInst(),
        builder.getIntValue(builder.getIntType(), 0),
        textureType->getFormatInst());
}

IRType* getSamplerTypeFromCombinedTextureSampler(IRType* type)
{
    IRBuilder builder(type);
    builder.setInsertBefore(type);

    auto textureType = as<IRTextureTypeBase>(type);

    if (getIntVal(textureType->getIsShadowInst()) != 0)
        return builder.getType(kIROp_SamplerComparisonStateType);
    else
        return builder.getType(kIROp_SamplerStateType);
}

IRInst* getInnerMostGenericReturnVal(IRGeneric* generic)
{
    auto returnVal = findGenericReturnVal(generic);
    if (auto innerGeneric = as<IRGeneric>(returnVal))
        return getInnerMostGenericReturnVal(innerGeneric);
    return returnVal;
}

bool isReadNoneCallee(IRInst* callee)
{
    if (auto func = as<IRFunc>(callee))
    {
        if (func->findDecoration<IRReadNoneDecoration>())
            return true;
    }

    if (as<IRSpecialize>(callee))
    {
        if (auto specialize = as<IRSpecialize>(callee->getOperand(0)))
        {
            return isReadNoneCallee(specialize);
        }
        else if (auto generic = as<IRGeneric>(callee->getOperand(0)))
        {
            auto genericReturnVal = getInnerMostGenericReturnVal(generic);

            if (genericReturnVal)
                return isReadNoneCallee(genericReturnVal);
            else
                return false;
        }
    }

    if (as<IRTranslateBase>(callee))
    {
        switch (callee->getOp())
        {
        // Translations that have the same readNone property as the original function.
        case kIROp_BackwardDifferentiatePrimal:
        case kIROp_BackwardPrimalFromLegacyBwdDiffFunc:
        case kIROp_ForwardDifferentiate:
        case kIROp_TrivialForwardDifferentiate:
        case kIROp_TrivialBackwardDifferentiatePrimal:
        case kIROp_FunctionCopy:
            return isReadNoneCallee(callee->getOperand(0));

        case kIROp_BackwardPropagateFromLegacyBwdDiffFunc:
            return isReadNoneCallee(callee->getOperand(1));

        // Translations that produce a readNone function even if the original function
        // is not readNone.
        case kIROp_BackwardRemat:
        case kIROp_BackwardRematFromLegacyBwdDiffFunc:
        case kIROp_TrivialBackwardDifferentiatePropagate:
        case kIROp_TrivialBackwardRemat:
            return true;
        }
    }

    // Default: cannot assume that unknown op-codes are read-none
    return false;
}

bool isReadNoneCalleeAndAllDerivatives(IRInst* callee)
{
    // The primary callee must be read-none first; the carry-set gate cannot
    // weaken its existing guarantee.
    if (!isReadNoneCallee(callee))
        return false;

    // Look annotations up on the resolved inner function rather than on the
    // unresolved callee. This is intentionally conservative: stdlib generics
    // (e.g. `sqrt`) attach `[ForwardDerivativeOf]` / `[BackwardDerivativeOf]`
    // annotations on the `IRSpecialize` wrapper, and those derivatives are
    // genuinely pure but typically NOT marked `[__readNone]` (the stdlib
    // doesn't bother). Looking them up on the unresolved callee would find
    // them and force a non-readNone verdict on every call site to a stdlib
    // math function, regressing the false-positive fixes from #11286.
    //
    // The trade-off is that user-defined generic primaries (whose
    // `[ForwardDerivative]` / `[BackwardDerivative]` annotations also live
    // on the `IRSpecialize`) bypass this gate. That's an under-approximation
    // — a generic `[__readNone]` primary with a side-effecting user-supplied
    // derivative is not currently caught. A more accurate fix would
    // distinguish "stdlib-style pure derivative not explicitly annotated"
    // from "user-supplied derivative with possible side effects" without
    // requiring stdlib annotation churn; see follow-up tracking.
    IRInst* annotated = getResolvedInstForDecorations(callee);
    if (!annotated)
        return true;

    IRBuilder builder(annotated->getModule());

    auto isAssociatedDerivativeReadNone = [&](AnnotationKind kind) -> bool
    {
        IRInst* derivativeFunc = builder.tryLookupAnnotation(annotated, kind);
        if (!derivativeFunc)
            return true;
        return isReadNoneCallee(derivativeFunc);
    };

    // ForwardDerivative points directly at the user's fwd-diff function.
    if (!isAssociatedDerivativeReadNone(AnnotationKind::ForwardDerivative))
        return false;

    // BackwardDerivativePropagate points at the synthesized propagate-phase
    // wrapper. `isReadNoneCallee`'s `IRTranslateBase` switch above unwraps
    // that wrapper via `kIROp_BackwardPropagateFromLegacyBwdDiffFunc`
    // (operand 1 = user's bwd-diff function copy), so the wrapper's
    // readNone-ness correctly inherits from the user-supplied backward
    // function.
    //
    // `AnnotationKind::BackwardDerivativeApply` is intentionally NOT
    // consulted: its wrapper is `BackwardPrimalFromLegacyBwdDiffFunc(primary,
    // bwd_diff)`, which the same switch unwraps via
    // `kIROp_BackwardPrimalFromLegacyBwdDiffFunc` -> operand 0 = primary.
    // Apply therefore inherits its readNone-ness from the already-checked
    // primary callee and adds no information beyond the first
    // `isReadNoneCallee(callee)` gate above.
    if (!isAssociatedDerivativeReadNone(AnnotationKind::BackwardDerivativePropagate))
        return false;

    return true;
}


bool isNoSideEffectCallee(IRInst* callee)
{
    if (auto func = as<IRFunc>(callee))
    {
        if (func->findDecoration<IRNoSideEffectDecoration>() ||
            func->findDecoration<IRReadNoneDecoration>())
            return true;
    }

    if (as<IRSpecialize>(callee))
    {
        if (auto specialize = as<IRSpecialize>(callee->getOperand(0)))
        {
            return isNoSideEffectCallee(specialize);
        }
        else if (auto generic = as<IRGeneric>(callee->getOperand(0)))
        {
            auto genericReturnVal = getInnerMostGenericReturnVal(generic);

            if (genericReturnVal)
                return isNoSideEffectCallee(genericReturnVal);
            else
                return false;
        }
    }

    if (as<IRTranslateBase>(callee))
    {
        switch (callee->getOp())
        {
        // Translations that have the same noSideEffect property as the original function.
        case kIROp_BackwardDifferentiatePrimal:
        case kIROp_BackwardPrimalFromLegacyBwdDiffFunc:
        case kIROp_ForwardDifferentiate:
        case kIROp_TrivialForwardDifferentiate:
        case kIROp_TrivialBackwardDifferentiatePrimal:
        case kIROp_FunctionCopy:
            return isNoSideEffectCallee(callee->getOperand(0));

        case kIROp_BackwardPropagateFromLegacyBwdDiffFunc:
            return isNoSideEffectCallee(callee->getOperand(1));

        // Translations that produce a noSideEffect function even if the original function
        // is not noSideEffect.
        case kIROp_BackwardRemat:
        case kIROp_BackwardRematFromLegacyBwdDiffFunc:
        case kIROp_TrivialBackwardDifferentiatePropagate:
        case kIROp_TrivialBackwardRemat:
            return true;
        }
    }

    // Default: cannot assume that unknown op-codes are read-none
    return false;
}

bool tryGetConstantIntLit(IRInst* inst, Int64& outValue)
{
    if (auto intLit = as<IRIntLit>(inst))
    {
        outValue = intLit->getValue();
        return true;
    }
    return false;
}

bool areKnownEqualShapeElements(IRInst* left, IRInst* right)
{
    if (left == right)
        return true;

    auto leftInt = as<IRIntLit>(left);
    auto rightInt = as<IRIntLit>(right);
    return leftInt && rightInt && leftInt->getValue() == rightInt->getValue();
}

IRInst* emitPackLike(IRModule* module, IRInst* oldInst, ArrayView<IRInst*> elements)
{
    auto resultType = as<IRType>(oldInst->getDataType());
    if (!resultType)
        return nullptr;

    IRBuilder builder(module);
    IRBuilderSourceLocRAII srcLocRAII(&builder, oldInst->sourceLoc);
    builder.setInsertBefore(oldInst);

    if (resultType->getOp() == kIROp_TupleType)
        return builder.emitMakeTuple(resultType, elements.getCount(), elements.getBuffer());

    return builder.emitMakeValuePack(resultType, elements.getCount(), elements.getBuffer());
}

bool isWorkGraphRecordType(IRType* type)
{
    SLANG_ASSERT(type);
    switch (type->getOp())
    {
    case kIROp_DispatchNodeInputRecordType:
    case kIROp_ThreadNodeInputRecordType:
    case kIROp_GroupNodeInputRecordsType:
    case kIROp_EmptyNodeInputType:
    case kIROp_ThreadNodeOutputRecordsType:
    case kIROp_GroupNodeOutputRecordsType:
    case kIROp_NodeOutputType:
    case kIROp_NodeOutputArrayType:
    case kIROp_EmptyNodeOutputType:
    case kIROp_EmptyNodeOutputArrayType:
        return true;
    default:
        return false;
    }
}

IRType* getWorkGraphRecordElementType(IRType* type)
{
    SLANG_ASSERT(type);

    switch (type->getOp())
    {
    case kIROp_DispatchNodeInputRecordType:
    case kIROp_ThreadNodeInputRecordType:
    case kIROp_GroupNodeInputRecordsType:
    case kIROp_ThreadNodeOutputRecordsType:
    case kIROp_GroupNodeOutputRecordsType:
    case kIROp_NodeOutputType:
    case kIROp_NodeOutputArrayType:
        return as<IRType>(type->getOperand(0));
    default:
        break;
    }

    return nullptr;
}

// True when a resource `type`'s `DescriptorHandle` is a native `uint64` bindless handle under
// `spvBindlessTextureNV` (rather than a `uint2` heap index) — exactly the texture and sampler
// types. This is the source of truth: the core-module query `__isBindlessTextureNVEncodable<T>()`
// folds through this classifier (peephole over `kIROp_IsBindlessTextureNVEncodable`), and the AST
// twin `_isBindlessTextureNVUInt64ElementType` (`slang-type-layout.cpp`) must stay in agreement.
bool isBindlessTextureNVEncodableResourceType(IRType* type)
{
    auto unwrapped = unwrapAttributedType(type);
    return as<IRTextureType>(unwrapped) || as<IRSamplerStateTypeBase>(unwrapped);
}

bool isDescriptorHandleRepresentedAsUInt64(IRInst* descriptorHandleType, bool hasBindlessTextureNV)
{
    if (!hasBindlessTextureNV)
        return false;
    auto handleType = as<IRDescriptorHandleType>(descriptorHandleType);
    if (!handleType)
        return false;
    return isBindlessTextureNVEncodableResourceType(handleType->getResourceType());
}

} // namespace Slang
