// slang-check-decl.cpp
#include "slang-ast-clone.h"
#include "slang-ast-modifier.h"
#include "slang-ast-support-types.h"
#include "slang-check-impl.h"

// This file constaints the semantic checking logic and
// related queries for declarations.
//
// Because declarations are the top-level construct
// of the AST (in turn containing all the statements,
// types, and expressions), the declaration-checking
// logic also orchestrates the overall flow and how
// and when things get checked.

#include "slang-ast-forward-declarations.h"
#include "slang-ast-iterator.h"
#include "slang-ast-print.h"
#include "slang-ast-synthesis.h"
#include "slang-lookup.h"
#include "slang-mangle.h"
#include "slang-parser.h"
#include "slang-rich-diagnostics.h"
#include "slang-syntax.h"

#include <limits>

namespace Slang
{

static Val* _getNonEmptyConstraintPackVal(
    ASTBuilder* astBuilder,
    DeclRef<NonEmptyPackConstraintDecl> const& constraintDeclRef);

/// Return the outermost declaration in a synthesized declaration's generic wrapper chain.
///
/// Witness synthesis can wrap an inner callable or type in one or more cloned `GenericDecl`s. The
/// wrapper is the root that owns the cloned parameters and constraints, so registering only the
/// inner declaration would leave part of the synthesized declaration graph unchecked.
static Decl* _getSynthesizedDeclRoot(Decl* decl)
{
    SLANG_RELEASE_ASSERT(decl);
    while (auto genericDecl = as<GenericDecl>(decl->parentDecl))
        decl = genericDecl;
    return decl;
}

// ============================================================================
// Declaration nesting validation (disallowed-by-default)
//
// A data-driven table determines which declaration categories are legal inside
// which container categories. Any combination not explicitly allowed is
// rejected with a diagnostic.
// ============================================================================

/// Categories for child declarations (what is being declared).
enum class DeclNestingCategory : uint32_t
{
    StructType,        // StructDecl, ClassDecl
    InterfaceType,     // InterfaceDecl
    EnumType,          // EnumDecl
    AssocType,         // AssocTypeDecl
    Extension,         // ExtensionDecl
    Function,          // FuncDecl
    Constructor,       // ConstructorDecl
    Subscript,         // SubscriptDecl
    Property,          // PropertyDecl
    Accessor,          // GetterDecl, SetterDecl, RefAccessorDecl
    InstanceVar,       // VarDecl/LetDecl without static modifier
    StaticVar,         // VarDecl/LetDecl with HLSLStaticModifier
    TypeAlias,         // TypeDefDecl, TypeAliasDecl
    EnumCase,          // EnumCaseDecl
    Inheritance,       // InheritanceDecl
    Import,            // ImportDecl
    Using,             // UsingDecl
    Namespace,         // NamespaceDecl
    Empty,             // EmptyDecl
    ModuleDeclaration, // ModuleDeclarationDecl
    Include,           // IncludeDecl, ImplementingDecl
    Capability,        // RequireCapabilityDecl

    Count,
    Unknown = Count, // compiler-generated or unclassified (skip validation)
};

/// Categories for parent containers.
enum class ContainerNestingCategory : uint32_t
{
    Module,        // ModuleDecl, FileDecl, NamespaceDeclBase
    StructOrClass, // StructDecl, ClassDecl
    Interface,     // InterfaceDecl
    Enum,          // EnumDecl
    Extension,     // ExtensionDecl
    Subscript,     // SubscriptDecl
    Property,      // PropertyDecl
    Function,      // FunctionDeclBase (function/method bodies)

    Count,
    Unknown = Count, // skip validation
};

/// Classify a declaration into a DeclNestingCategory.
static DeclNestingCategory classifyDeclForNesting(Decl* decl)
{
    // Order matters for inheritance: check more-derived types first.
    if (as<AccessorDecl>(decl))
        return DeclNestingCategory::Accessor;
    if (as<ConstructorDecl>(decl))
        return DeclNestingCategory::Constructor;
    if (as<FuncDecl>(decl))
        return DeclNestingCategory::Function;
    if (as<SubscriptDecl>(decl))
        return DeclNestingCategory::Subscript;
    if (as<PropertyDecl>(decl))
        return DeclNestingCategory::Property;

    if (as<InterfaceDecl>(decl))
        return DeclNestingCategory::InterfaceType;
    if (as<StructDecl>(decl) || as<ClassDecl>(decl))
        return DeclNestingCategory::StructType;
    if (as<EnumDecl>(decl))
        return DeclNestingCategory::EnumType;
    if (as<AssocTypeDecl>(decl))
        return DeclNestingCategory::AssocType;
    if (as<ExtensionDecl>(decl))
        return DeclNestingCategory::Extension;

    if (auto varDecl = as<VarDeclBase>(decl))
    {
        // ParamDecl / ModernParamDecl are structural, not user-chosen nesting.
        if (as<ParamDecl>(decl) || as<ModernParamDecl>(decl))
            return DeclNestingCategory::Unknown;
        // GenericValueParamDecl and friends are inside GenericDecl, skip.
        if (as<GenericValueParamDecl>(decl) || as<GenericValuePackParamDecl>(decl) ||
            as<GlobalGenericValueParamDecl>(decl))
            return DeclNestingCategory::Unknown;
        // `extern` vars in extensions reference existing fields, not new declarations.
        if (varDecl->hasModifier<ExternModifier>() && as<ExtensionDecl>(varDecl->parentDecl))
            return DeclNestingCategory::Unknown;

        if (varDecl->hasModifier<HLSLStaticModifier>())
            return DeclNestingCategory::StaticVar;
        return DeclNestingCategory::InstanceVar;
    }

    if (as<TypeDefDecl>(decl))
        return DeclNestingCategory::TypeAlias;
    if (as<EnumCaseDecl>(decl))
        return DeclNestingCategory::EnumCase;
    if (as<InheritanceDecl>(decl))
        return DeclNestingCategory::Inheritance;
    if (as<ImportDecl>(decl))
        return DeclNestingCategory::Import;
    if (as<UsingDecl>(decl))
        return DeclNestingCategory::Using;
    if (as<NamespaceDecl>(decl))
        return DeclNestingCategory::Namespace;
    if (as<EmptyDecl>(decl))
        return DeclNestingCategory::Empty;
    if (as<ModuleDeclarationDecl>(decl))
        return DeclNestingCategory::ModuleDeclaration;
    if (as<IncludeDecl>(decl) || as<ImplementingDecl>(decl))
        return DeclNestingCategory::Include;
    if (as<RequireCapabilityDecl>(decl))
        return DeclNestingCategory::Capability;

    // Everything else is compiler-generated or unclassified: skip validation.
    return DeclNestingCategory::Unknown;
}

/// Walk up the parent chain, skipping GenericDecl and ScopeDecl wrappers,
/// to find the nearest container relevant to nesting validation.
///
/// This is intentionally separate from getParentDecl() (which only skips
/// GenericDecl) to avoid changing behaviour for the ~30 other callsites
/// that rely on the shared utility.
static ContainerDecl* getParentContainerForNesting(Decl* decl)
{
    auto parentDecl = decl->parentDecl;
    for (;;)
    {
        if (auto genericDecl = as<GenericDecl>(parentDecl))
            parentDecl = genericDecl->parentDecl;
        else if (auto scopeDecl = as<ScopeDecl>(parentDecl))
            parentDecl = scopeDecl->parentDecl;
        else
            break;
    }
    return parentDecl;
}

/// Classify a container declaration into a ContainerNestingCategory.
static ContainerNestingCategory classifyContainerForNesting(ContainerDecl* container)
{
    if (as<NamespaceDeclBase>(container) || as<FileDecl>(container))
        return ContainerNestingCategory::Module;
    if (as<StructDecl>(container) || as<ClassDecl>(container))
        return ContainerNestingCategory::StructOrClass;
    if (as<InterfaceDecl>(container))
        return ContainerNestingCategory::Interface;
    if (as<EnumDecl>(container))
        return ContainerNestingCategory::Enum;
    if (as<ExtensionDecl>(container))
        return ContainerNestingCategory::Extension;
    if (as<SubscriptDecl>(container))
        return ContainerNestingCategory::Subscript;
    if (as<PropertyDecl>(container))
        return ContainerNestingCategory::Property;
    if (as<FunctionDeclBase>(container))
        return ContainerNestingCategory::Function;

    // GenericDecl and ScopeDecl are unwrapped by getParentContainerForNesting();
    // anything else is compiler-internal — skip.
    return ContainerNestingCategory::Unknown;
}

/// Build a bitmask from one ContainerNestingCategory value.
static constexpr uint32_t containerBit(ContainerNestingCategory c)
{
    return 1u << static_cast<uint32_t>(c);
}

/// Build a bitmask from multiple ContainerNestingCategory values.
template<typename... Ts>
static constexpr uint32_t allowedIn(Ts... cats)
{
    return (containerBit(cats) | ...);
}

using CC = ContainerNestingCategory;

/// One row in the nesting-rule table: which containers a declaration kind may appear in.
struct NestingRule
{
    DeclNestingCategory child;
    uint32_t allowedContainers;
    const char* childName;
};

/// The nesting-rule table.  Each row reads as:
///   "<childName> declaration is allowed in <allowedContainers>."
///
/// Note: The parser restricts enum body syntax to cases and a limited set of
/// members, so some CC::Enum entries (e.g. Constructor, Subscript, Property)
/// only take effect when these constructs appear on an enum type via extension.
// clang-format off
static const NestingRule kNestingRules[] = {
//  child category                          allowed containers                                       display name
    {DeclNestingCategory::StructType,       allowedIn(CC::Module, CC::StructOrClass, CC::Extension, CC::Function), "struct/class"},
    {DeclNestingCategory::InterfaceType,    allowedIn(CC::Module),                                   "interface"},
    {DeclNestingCategory::EnumType,         allowedIn(CC::Module, CC::StructOrClass, CC::Enum, CC::Extension, CC::Function), "enum"},
    {DeclNestingCategory::AssocType,        allowedIn(CC::Interface),                                "associatedtype"},
    {DeclNestingCategory::Extension,        allowedIn(CC::Module),                                   "extension"},
    {DeclNestingCategory::Function,         allowedIn(CC::Module, CC::StructOrClass, CC::Interface, CC::Extension, CC::Enum), "function"},
    {DeclNestingCategory::Constructor,      allowedIn(CC::StructOrClass, CC::Interface, CC::Extension, CC::Enum), "constructor"},
    {DeclNestingCategory::Subscript,        allowedIn(CC::StructOrClass, CC::Interface, CC::Extension, CC::Enum), "subscript"},
    {DeclNestingCategory::Property,         allowedIn(CC::Module, CC::StructOrClass, CC::Interface, CC::Extension, CC::Enum), "property"},
    {DeclNestingCategory::Accessor,         allowedIn(CC::Subscript, CC::Property),                  "accessor"},
    {DeclNestingCategory::InstanceVar,      allowedIn(CC::Module, CC::StructOrClass, CC::Function),  "non-static member variable"},
    {DeclNestingCategory::StaticVar,        allowedIn(CC::Module, CC::StructOrClass, CC::Interface, CC::Extension, CC::Enum, CC::Function), "static variable"},
    {DeclNestingCategory::TypeAlias,        allowedIn(CC::Module, CC::StructOrClass, CC::Interface, CC::Extension, CC::Enum, CC::Function), "typealias"},
    {DeclNestingCategory::EnumCase,         allowedIn(CC::Enum),                                     "enum case"},
    {DeclNestingCategory::Inheritance,      allowedIn(CC::StructOrClass, CC::Interface, CC::Enum, CC::Extension), "inheritance"},
    {DeclNestingCategory::Import,           allowedIn(CC::Module),                                   "import"},
    {DeclNestingCategory::Using,            allowedIn(CC::Module, CC::StructOrClass, CC::Interface, CC::Extension, CC::Function), "using"},
    {DeclNestingCategory::Namespace,        allowedIn(CC::Module),                                   "namespace"},
    {DeclNestingCategory::Empty,            allowedIn(CC::Module, CC::StructOrClass, CC::Interface, CC::Enum, CC::Extension, CC::Subscript, CC::Property, CC::Function), "empty"},
    {DeclNestingCategory::ModuleDeclaration,allowedIn(CC::Module),                                   "module declaration"},
    {DeclNestingCategory::Include,          allowedIn(CC::Module),                                   "include"},
    {DeclNestingCategory::Capability,       allowedIn(CC::Module),                                   "require capability"},
};
// clang-format on

static_assert(
    SLANG_COUNT_OF(kNestingRules) == static_cast<SlangSSizeT>(DeclNestingCategory::Count),
    "kNestingRules must have one entry per DeclNestingCategory");

static_assert(
    static_cast<uint32_t>(ContainerNestingCategory::Count) <= 32,
    "Too many ContainerNestingCategory values for uint32_t bitmask");

/// Return a human-readable name for a ContainerNestingCategory.
static const char* getContainerNestingCategoryName(ContainerNestingCategory cat)
{
    switch (cat)
    {
    case ContainerNestingCategory::Module:
        return "module/namespace";
    case ContainerNestingCategory::StructOrClass:
        return "struct/class";
    case ContainerNestingCategory::Interface:
        return "interface";
    case ContainerNestingCategory::Enum:
        return "enum";
    case ContainerNestingCategory::Extension:
        return "extension";
    case ContainerNestingCategory::Subscript:
        return "subscript";
    case ContainerNestingCategory::Property:
        return "property";
    case ContainerNestingCategory::Function:
        return "function";
    default:
        return "unknown";
    }
}

/// Look up the nesting rule for a given declaration category.
/// The table is ordered 1:1 with DeclNestingCategory (enforced by static_assert).
static const NestingRule& findNestingRule(DeclNestingCategory child)
{
    return kNestingRules[static_cast<uint32_t>(child)];
}

/// Validate that a declaration is allowed in its parent container.
/// Returns true if a diagnostic was emitted (i.e. the nesting is invalid).
static bool validateDeclNesting(SemanticsVisitor* visitor, Decl* decl)
{
    auto childCategory = classifyDeclForNesting(decl);
    if (childCategory == DeclNestingCategory::Unknown)
        return false;

    // Unwrap GenericDecl and ScopeDecl to reach the user-visible container.
    // This uses a nesting-specific helper rather than the shared getParentDecl()
    // to avoid changing behaviour for ~30 other callsites.
    auto parentContainer = getParentContainerForNesting(decl);
    if (!parentContainer)
        return false;

    auto parentCategory = classifyContainerForNesting(parentContainer);
    if (parentCategory == ContainerNestingCategory::Unknown)
        return false;

    auto& rule = findNestingRule(childCategory);

    if (rule.allowedContainers & containerBit(parentCategory))
        return false; // allowed

    // The parser's isDeclAllowed (slang-parser.cpp:5177) and
    // parseVarDeclrStatement (slang-parser.cpp:6607) set
    // nestingAlreadyDiagnosed when they emit a nesting diagnostic.
    // Skip our diagnostic to avoid showing duplicates to the user.
    if (decl->nestingAlreadyDiagnosed)
        return true;

    visitor->getSink()->diagnose(Diagnostics::DeclNotAllowedInContext{
        .childKind = rule.childName,
        .parentKind = getContainerNestingCategoryName(parentCategory),
        .decl = decl});
    return true;
}

// ============================================================================

static bool isAssociatedTypeDecl(Decl* decl)
{
    auto d = decl;
    while (auto genericDecl = as<GenericDecl>(d))
        d = genericDecl->inner;
    if (as<AssocTypeDecl>(d))
        return true;
    return false;
}

bool isSlang2026OrLater(SemanticsVisitor* visitor)
{
    return visitor->getShared()->getLanguageVersion() >= SLANG_LANGUAGE_VERSION_2026;
}

bool isSlang202cOrLater(SemanticsVisitor* visitor)
{
    return visitor->getShared()->getLanguageVersion() >= SLANG_LANGUAGE_VERSION_202C;
}

static bool allowExperimentalDynamicDispatch(
    SemanticsVisitor* visitor,
    CompilerOptionSet& optionSet)
{
    return optionSet.getBoolOption(CompilerOptionName::EnableExperimentalDynamicDispatch) ||
           !isSlang2026OrLater(visitor);
}

static void validateDynInterfaceUsage(
    SemanticsDeclVisitorBase* visitor,
    DiagnosticSink* sink,
    CompilerOptionSet& optionSet,
    InterfaceDecl* decl)
{
    if (allowExperimentalDynamicDispatch(visitor, optionSet))
        return;

    if (!decl->hasModifier<DynModifier>())
        return;

    // validate members inside `dyn interface`
    for (auto m : decl->getDirectMemberDecls())
    {
        if (isAssociatedTypeDecl(m))
        {
            sink->diagnose(Diagnostics::CannotHaveAssociatedTypeInDynInterface{.member = m});
            continue;
        }
        else if (auto genericDecl = as<GenericDecl>(m))
        {
            if (as<FuncDecl>(genericDecl->inner))
            {
                sink->diagnose(Diagnostics::CannotHaveGenericMethodInDynInterface{.member = m});
            }
            continue;
        }
        else if (auto funcDecl = as<FuncDecl>(m))
        {
            visitor->ensureDecl(m, DeclCheckState::ModifiersChecked);
            for (auto modifier : funcDecl->modifiers)
            {
                if (as<MutatingAttribute>(modifier))
                {
                    sink->diagnose(
                        Diagnostics::CannotHaveMutatingMethodInDynInterface{.member = m});
                }
                else if (as<DifferentiableAttribute>(modifier))
                {
                    sink->diagnose(
                        Diagnostics::CannotHaveDifferentiableMethodInDynInterface{.member = m});
                }
            }
            continue;
        }
        else if (auto inheritanceDecl = as<InheritanceDecl>(m))
        {
            visitor->ensureDecl(m, DeclCheckState::ReadyForLookup);
            auto inheritedInterfaceDeclRefType =
                isDeclRefTypeOf<InterfaceDecl>(inheritanceDecl->base.type);
            if (!inheritedInterfaceDeclRefType)
                continue;

            auto inheritedInterfaceDecl = inheritedInterfaceDeclRefType.getDecl();
            if (!inheritedInterfaceDecl->hasModifier<DynModifier>())
                sink->diagnose(Diagnostics::DynInterfaceCannotInheritNonDynInterface{
                    .dynInterface = decl,
                    .inherited = inheritedInterfaceDecl,
                    .inheritance = m});
        }
    }

    // dyn interface cannot be generic
    if (visitor->GetOuterGeneric(decl))
    {
        sink->diagnose(Diagnostics::CannotHaveGenericDynInterface{.decl = decl});
    }
}

static void validateDynInterfaceUseWithInheritanceDecl(
    SemanticsDeclVisitorBase* visitor,
    DiagnosticSink* sink,
    CompilerOptionSet& optionSet,
    InheritanceDecl* decl)
{
    auto interfaceDeclRef = isDeclRefTypeOf<InterfaceDecl>(decl->base.type);
    if (!interfaceDeclRef)
        return;
    auto interfaceDecl = interfaceDeclRef.getDecl();
    bool interfaceDeclIsDyn = interfaceDecl->hasModifier<DynModifier>();
    if (!interfaceDeclIsDyn)
        return;

    if (!allowExperimentalDynamicDispatch(visitor, optionSet))
    {
        if (auto extensionDeclParent = as<ExtensionDecl>(decl->parentDecl))
        {
            // not allowed to extend to conform to a 'dyn interface'
            sink->diagnose(Diagnostics::CannotUseExtensionToMakeTypeConformToDynInterface{
                .interface = interfaceDecl,
                .extension = extensionDeclParent});
        }
        else if (visitor->GetOuterGeneric(decl->parentDecl))
        {
            sink->diagnose(Diagnostics::CannotConformGenericToDynInterface{
                .generic = decl->parentDecl,
                .interface = interfaceDecl,
                .inheritance = decl});
        }
    }
    if (auto aggTypeDeclParent = as<AggTypeDecl>(decl->parentDecl))
    {
        // Ensure if we inherit from a `dyn interface` that the parent does not have: opaque
        // types, unsized types, non-copyable types
        for (auto varDecl : aggTypeDeclParent->getDirectMemberDeclsOfType<VarDecl>())
        {
            visitor->ensureDecl(varDecl, DeclCheckState::ReadyForLookup);

            if (isNonCopyableType(varDecl->getType()))
            {
                sink->diagnose(Diagnostics::CannotHaveNonCopyableMemberWhenInheritingDynInterface{
                    .interface = interfaceDecl,
                    .member = varDecl});
            }

            int varTypeTags = (int)visitor->getTypeTags(varDecl->getType());
            bool isUnsized = varTypeTags & (int)TypeTag::Unsized;
            bool isOpaque = varTypeTags & (int)TypeTag::Opaque;
            if (isUnsized)
                sink->diagnose(Diagnostics::CannotHaveUnsizedMemberWhenInheritingDynInterface{
                    .interface = interfaceDecl,
                    .member = varDecl});
            if (isOpaque)
                sink->diagnose(Diagnostics::CannotHaveOpaqueMemberWhenInheritingDynInterface{
                    .interface = interfaceDecl,
                    .member = varDecl});
        }
    }
}

static ConstructorDecl* _getDefaultCtor(StructDecl* structDecl);
static List<ConstructorDecl*> _getCtorList(
    ASTBuilder* m_astBuilder,
    SemanticsVisitor* visitor,
    StructDecl* structDecl,
    ConstructorDecl** defaultCtorOut);
static Expr* constructDefaultInitExprForType(SemanticsVisitor* visitor, VarDeclBase* varDecl);

int compareVals(Val& lhs, Val& rhs);

/// Visitor to transition declarations to `DeclCheckState::CheckedModifiers`
struct SemanticsDeclModifiersVisitor : public SemanticsDeclVisitorBase,
                                       public DeclVisitor<SemanticsDeclModifiersVisitor>
{
    SemanticsDeclModifiersVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    void visitDeclGroup(DeclGroup*) {}

    void visitVarDecl(VarDecl* decl)
    {
        visitDecl(decl);

        // Export'd/Extern'd variables must be `const`, otherwise we may have a mismatch
        // causing errors.
        bool hasConst = false;
        bool hasUniform = false;
        bool hasExportOrExtern = false;
        bool hasStatic = false;
        bool hasSpecializationConstant = false;
        for (auto m : decl->modifiers)
        {
            if (as<ExternModifier>(m) || as<HLSLExportModifier>(m))
                hasExportOrExtern = true;
            else if (as<ConstModifier>(m))
                hasConst = true;
            else if (as<HLSLUniformModifier>(m))
                hasUniform = true;
            else if (as<HLSLStaticModifier>(m))
                hasStatic = true;
            else if (as<SpecializationConstantAttribute>(m) || as<VkConstantIdAttribute>(m))
                hasSpecializationConstant = true;
        }
        if (hasExportOrExtern && hasConst != hasStatic)
            getSink()->diagnose(Diagnostics::ExternAndExportVarDeclMustBeConst{.decl = decl});


        // Global const or uniform variables with initializers must be static
        // In HLSL, const global variables without static are uniform parameters
        // that cannot have default values
        // Exception: specialization constants are allowed to have initializers
        // Exception: In GLSL mode, global const variables are real constants, not uniform
        // parameters
        if (isGlobalDecl(decl) && (hasConst || hasUniform) && !hasStatic &&
            !hasSpecializationConstant && decl->initExpr)
        {
            if (!getShared()->isGLSLSourceLanguage())
            {
                getSink()->diagnose(
                    Diagnostics::ConstGlobalVarWithInitRequiresStatic{.decl = decl});
            }
        }
    }

    void visitDecl(Decl* decl)
    {
        validateDeclNesting(this, decl);
        checkModifiers(decl);
    }

    void visitStructDecl(StructDecl* structDecl);

    void visitInterfaceDecl(InterfaceDecl* interfaceDecl);
};

struct SemanticsDeclScopeWiringVisitor : public SemanticsDeclVisitorBase,
                                         public DeclVisitor<SemanticsDeclScopeWiringVisitor>
{
    SemanticsDeclScopeWiringVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    void visitDeclGroup(DeclGroup*) {}

    void visitDecl(Decl*) {}

    void visitUsingDecl(UsingDecl* decl);

    void visitImplementingDecl(ImplementingDecl* decl);

    void visitNamespaceDecl(NamespaceDecl* decl);
};

struct SemanticsDeclDifferentialAttributesVisitor
    : public SemanticsDeclVisitorBase,
      public DeclVisitor<SemanticsDeclDifferentialAttributesVisitor>
{
    SemanticsDeclDifferentialAttributesVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    void visitDecl(Decl*) {}
    void visitDeclGroup(DeclGroup*) {}

    void visitFunctionDeclBase(FunctionDeclBase* decl);

    void checkForwardDerivativeOfAttribute(
        FunctionDeclBase* funcDecl,
        ForwardDerivativeOfAttribute* attr);

    void checkBackwardDerivativeOfAttribute(
        FunctionDeclBase* funcDecl,
        BackwardDerivativeOfAttribute* attr);

    void checkPrimalSubstituteOfAttribute(
        FunctionDeclBase* funcDecl,
        PrimalSubstituteOfAttribute* attr);
};

struct SemanticsDeclAttributesVisitor : public SemanticsDeclVisitorBase,
                                        public DeclVisitor<SemanticsDeclAttributesVisitor>
{
    SemanticsDeclAttributesVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    void visitDecl(Decl*) {}
    void visitDeclGroup(DeclGroup*) {}

    void visitStructDecl(StructDecl* structDecl);

    void checkVarDeclCommon(VarDeclBase* varDecl);

    void checkHLSLRegisterSemantic(VarDeclBase* varDecl, HLSLRegisterSemantic* registerSematnic);

    void visitVarDecl(VarDecl* varDecl) { checkVarDeclCommon(varDecl); }

    // Synthesize the constructor declaration for a struct during header visit, as we
    // need to have such declaration first such that the overloading resolution can lookup
    // such constructor and complete the initialize list to constructor translation.
    //
    // We will defer the actual implementation of the constructor to the body visit, because
    // we will have full information about each field in the struct during that stage.
    bool _synthesizeCtorSignature(StructDecl* structDecl);
    bool collectInitializableMembers(
        StructDecl* structDecl,
        const DeclVisibility ctorVisibility,
        List<VarDeclBase*>& resultMembers);
};

struct SemanticsDeclHeaderVisitor : public SemanticsDeclVisitorBase,
                                    public DeclVisitor<SemanticsDeclHeaderVisitor>
{
    SemanticsDeclHeaderVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    void visitDecl(Decl*) {}
    void visitDeclGroup(DeclGroup*) {}

    void checkDerivativeMemberAttributeParent(
        VarDeclBase* varDecl,
        DerivativeMemberAttribute* attr);
    void checkExtensionExternVarAttribute(VarDeclBase* varDecl, ExtensionExternVarModifier* m);
    void checkMeshOutputDecl(VarDeclBase* varDecl);
    void maybeApplyLayoutModifier(VarDeclBase* varDecl);
    void deriveVarTypeFromInitExpr(VarDeclBase* varDecl);
    void checkVarDeclCommon(VarDeclBase* varDecl);
    void checkPushConstantBufferType(VarDeclBase* varDecl);

    // Determine the type and mutability of a uniform parameter shadow.
    //
    // Requires the parser-created association in `decl->uniformParameter`. Sets the checked type
    // and `shouldBeImmutableAlias`; the shadow has no written type or initializer to check.
    void visitUniformParameterShadowVarDecl(UniformParameterShadowVarDecl* decl);

    void visitVarDecl(VarDecl* varDecl) { checkVarDeclCommon(varDecl); }

    void visitGlobalGenericValueParamDecl(GlobalGenericValueParamDecl* decl)
    {
        checkVarDeclCommon(decl);
    }

    void visitImportDecl(ImportDecl* decl);

    void visitIncludeDecl(IncludeDecl* decl);

    void visitGenericTypeParamDecl(GenericTypeParamDecl* decl);

    void visitGenericValueParamDecl(GenericValueParamDecl* decl);

    void visitGenericValuePackParamDecl(GenericValuePackParamDecl* decl);

    bool diagnoseDefaultOnExtensionGenericParam(Decl* paramDecl, Expr* defaultValue);

    void visitGenericTypeConstraintDecl(GenericTypeConstraintDecl* decl);

    void checkGenericTypeEqualityConstraintSubType(GenericTypeConstraintDecl* decl);

    void visitTypeCoercionConstraintDecl(TypeCoercionConstraintDecl* decl);

    void visitNonEmptyPackConstraintDecl(NonEmptyPackConstraintDecl* decl);
    void visitGenericVariadicPackCountConstraintDecl(GenericVariadicPackCountConstraintDecl* decl);

    void visitHasDiffTypeInfoConstraintDecl(HasDiffTypeInfoConstraintDecl* decl);

    bool validateGenericConstraintSubType(
        GenericTypeConstraintDecl* decl,
        TypeExp type,
        DiagnosticSink* sink = nullptr);

    void checkForwardReferencesInGenericDecl(Decl* decl, Expr* expr, Val* val);

    void visitGenericDecl(GenericDecl* genericDecl);

    void visitTypeDefDecl(TypeDefDecl* decl);

    // Propagate optional generic constraints from the body of a generic typealias to its
    // own GenericDecl. Consider `typealias Baz<T> = Foo<T>` where Foo has an optional
    // constraint `T : IFoo?`. When the body is checked, T is unconstrained, so the
    // constraint arg is resolved to NoneWitness. This helper adds an equivalent optional
    // constraint on Baz's GenericDecl and replaces the NoneWitness with a
    // DeclaredSubtypeWitness so that `Baz<float>` correctly resolves the constraint at
    // instantiation time.
    void propagateOptionalConstraintsThroughTypealias(TypeDefDecl* decl);

    void visitGlobalGenericParamDecl(GlobalGenericParamDecl* decl);

    void visitAssocTypeDecl(AssocTypeDecl* decl);

    void checkDifferentiableCallableSignature(CallableDecl* decl);
    void synthesizeDifferentiabilityRequirements(CallableDecl* decl);

    void checkInterfaceRequirement(Decl* decl);

    void checkCallableDeclCommon(CallableDecl* decl);
    void checkCallableErrorType(CallableDecl* decl);
    void maybeInferPrefixModifierForOperator(CallableDecl* decl);
    void maybeDiagnoseOperatorDeclaredAsMember(FuncDecl* decl);
    void checkPublicCallableOperandVisibility(CallableDecl* decl);

    void checkCallableConstraints(CallableDecl* decl);

    void visitCallableDecl(CallableDecl* decl);

    void visitFunctionDeclBase(FunctionDeclBase* decl);

    void visitFuncDecl(FuncDecl* funcDecl);

    void visitParamDecl(ParamDecl* paramDecl);

    void visitConstructorDecl(ConstructorDecl* decl);

    void visitAbstractStorageDeclCommon(ContainerDecl* decl);

    void visitSubscriptDecl(SubscriptDecl* decl);

    void visitPropertyDecl(PropertyDecl* decl);

    void visitSemanticDecl(SemanticDecl* decl);
    void visitSemanticGetterDecl(SemanticGetterDecl* decl);
    void visitSemanticSetterDecl(SemanticSetterDecl* decl);

    void visitStructDecl(StructDecl* decl);

    void visitClassDecl(ClassDecl* decl);

    /// Get the type of the storage accessed by an accessor.
    ///
    /// The type of storage is determined by the parent declaration.
    Type* _getAccessorStorageType(AccessorDecl* decl);

    void visitAccessorDecl(AccessorDecl* decl);
    void visitSetterDecl(SetterDecl* decl);

    void cloneModifiers(Decl* dest, Decl* src);
    void setFuncTypeIntoRequirementDecl(CallableDecl* decl, FuncType* funcType);
};

struct SemanticsDeclRedeclarationVisitor : public SemanticsDeclVisitorBase,
                                           public DeclVisitor<SemanticsDeclRedeclarationVisitor>
{
    SemanticsDeclRedeclarationVisitor(SemanticsContext const& outer, RedeclarationSeverity severity)
        : SemanticsDeclVisitorBase(outer), m_severity(severity)
    {
    }

    void visitDecl(Decl*) {}
    void visitDeclGroup(DeclGroup*) {}

#define CASE(TYPE) \
    void visit##TYPE(TYPE* decl) { checkForRedeclaration(decl, m_severity); }

    CASE(EnumCaseDecl)
    CASE(FuncDecl)
    CASE(SimpleTypeDecl)
    CASE(AggTypeDecl)
    CASE(VarDeclBase)

#undef CASE

    RedeclarationSeverity m_severity;
};


struct SemanticsDeclBasesVisitor : public SemanticsDeclVisitorBase,
                                   public DeclVisitor<SemanticsDeclBasesVisitor>
{
    SemanticsDeclBasesVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    void visitDecl(Decl*) {}
    void visitDeclGroup(DeclGroup*) {}

    void visitInheritanceDecl(InheritanceDecl* inheritanceDecl);

    void visitThisTypeConstraintDecl(ThisTypeConstraintDecl* thisTypeConstraintDecl);

    /// Validate that `decl` isn't illegally inheriting from a type in another module.
    ///
    /// This call checks a single `inheritanceDecl` to make sure that it either
    ///     * names a base type from the same module as `decl`, or
    ///     * names a type that allows cross-module inheritance
    void _validateCrossModuleInheritance(AggTypeDeclBase* decl, InheritanceDecl* inheritanceDecl);

    void visitInterfaceDecl(InterfaceDecl* decl);

    void visitStructDecl(StructDecl* decl);

    void visitClassDecl(ClassDecl* decl);

    void visitEnumDecl(EnumDecl* decl);

    void visitCallableDecl(CallableDecl* decl);

    /// Validate that the target type of an extension `decl` is valid.
    void _validateExtensionDeclTargetType(ExtensionDecl* decl);
    void _validateExtensionDeclMembers(ExtensionDecl* decl);
    void _validateExtensionDeclGenericParams(ExtensionDecl* decl);

    void visitExtensionDecl(ExtensionDecl* decl);

    void visitFuncExtensionDecl(FuncExtensionDecl* decl);

    // Helpers for visitFuncExtensionDecl — one per higher-order expression type.
    void _funcExtensionForwardDiff(
        ExtensionDecl* extensionDecl,
        FuncDecl* innerFunc,
        Type* baseFuncAsType,
        DeclVisibility visibility);
    void _funcExtensionBackwardDiff(
        ExtensionDecl* extensionDecl,
        FuncDecl* innerFunc,
        Type* baseFuncAsType,
        DeclVisibility visibility);
    void _funcExtensionApply(
        ExtensionDecl* extensionDecl,
        FuncDecl* innerFunc,
        Type* baseFuncAsType,
        DeclVisibility visibility,
        SourceLoc loc);
};

struct SemanticsDeclTypeResolutionVisitor : public SemanticsDeclVisitorBase,
                                            public DeclVisitor<SemanticsDeclTypeResolutionVisitor>
{
    SemanticsDeclTypeResolutionVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    void visitDecl(Decl*) {}
    void visitDeclGroup(DeclGroup*) {}

    void visitTypeExp(TypeExp& exp) { exp.type = resolveType(exp.type); }

    void visitVarDeclBase(VarDeclBase* varDecl) { visitTypeExp(varDecl->type); }

    void visitGenericTypeConstraintDecl(GenericTypeConstraintDecl* decl)
    {
        visitTypeExp(decl->sup);
    }

    // void visitFuncTypeConstraintDecl(FuncTypeConstraintDecl* decl) { visitTypeExp(decl->sub); }

    void visitTypeDefDecl(TypeDefDecl* decl) { visitTypeExp(decl->type); }

    void visitGenericTypeParamDecl(GenericTypeParamDecl* paramDecl)
    {
        visitTypeExp(paramDecl->initType);
    }

    void visitInheritanceDecl(InheritanceDecl* inheritanceDecl)
    {
        visitTypeExp(inheritanceDecl->base);
        validateDynInterfaceUseWithInheritanceDecl(
            this,
            getSink(),
            getOptionSet(),
            inheritanceDecl);
    }

    void visitCallableDecl(CallableDecl* decl)
    {
        for (auto paramDecl : decl->getMembersOfType<ParamDecl>())
            visitTypeExp(paramDecl->type);

        visitTypeExp(decl->returnType);
        visitTypeExp(decl->errorType);

        if (decl->funcType.type)
            visitTypeExp(decl->funcType);
    }

    void visitPropertyDecl(PropertyDecl* decl) { visitTypeExp(decl->type); }

    void visitSemanticGetterDecl(SemanticGetterDecl* decl) { visitTypeExp(decl->type); }
    void visitSemanticSetterDecl(SemanticSetterDecl* decl) { visitTypeExp(decl->type); }

    void visitSemanticDecl(SemanticDecl* decl)
    {
        for (auto member : decl->getMembers())
            dispatch(member);
    }
};

struct SemanticsDeclBodyVisitor : public SemanticsDeclVisitorBase,
                                  public DeclVisitor<SemanticsDeclBodyVisitor>
{
    SemanticsDeclBodyVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    void visitDecl(Decl*) {}
    void visitDeclGroup(DeclGroup*) {}

    void checkVarDeclCommon(VarDeclBase* varDecl);

    // Check the body of a synthesized uniform parameter shadow.
    void visitUniformParameterShadowVarDecl(UniformParameterShadowVarDecl*)
    {
        // We have no initializer expression to check for a shadow: the parser only records
        // its associated parameter. Lowering will initialize the shadow from that parameter,
        // which we check independently as an ordinary shader parameter declaration.
    }

    void visitVarDecl(VarDecl* varDecl) { checkVarDeclCommon(varDecl); }

    void visitGenericValueParamDecl(GenericValueParamDecl* genValDecl)
    {
        checkVarDeclCommon(genValDecl);
    }

    void visitGenericValuePackParamDecl(GenericValuePackParamDecl* genValPackDecl)
    {
        checkVarDeclCommon(genValPackDecl);
    }

    void visitGlobalGenericValueParamDecl(GlobalGenericValueParamDecl* decl)
    {
        checkVarDeclCommon(decl);
    }

    void visitEnumCaseDecl(EnumCaseDecl* decl);

    void visitEnumDecl(EnumDecl* decl);

    void visitFunctionDeclBase(FunctionDeclBase* funcDecl);

    void visitParamDecl(ParamDecl* paramDecl);

    void visitAggTypeDecl(AggTypeDecl* aggTypeDecl);

    SemanticsContext registerDifferentiableTypesForFunc(FunctionDeclBase* funcDecl);

private:
    struct DeclAndCtorInfo
    {
        StructDecl* parent = nullptr;
        ConstructorDecl* defaultCtor = nullptr;
        List<ConstructorDecl*> ctorList;
        Type* type = nullptr;
        DeclAndCtorInfo() {}
        DeclAndCtorInfo(
            ASTBuilder* m_astBuilder,
            SemanticsVisitor* visitor,
            StructDecl* inParent,
            Type* inType,
            const bool getOnlyDefault)
        {
            parent = inParent;
            type = inType;
            if (getOnlyDefault)
                defaultCtor = _getDefaultCtor(parent);
            else
                ctorList = _getCtorList(m_astBuilder, visitor, parent, &defaultCtor);
        }
    };

    void synthesizeCtorBody(
        DeclAndCtorInfo& structDeclInfo,
        List<DeclAndCtorInfo>& inheritanceDefaultCtorList,
        StructDecl* structDecl);
    void synthesizeCtorBodyForBases(
        ConstructorDecl* ctor,
        List<DeclAndCtorInfo>& inheritanceDefaultCtorList,
        ThisExpr* thisExpr,
        SeqStmt* seqStmtChild,
        bool isMemberInitCtor,
        Index& paramIndex);

    void synthesizeCtorBodyForMemberVar(
        ConstructorDecl* ctor,
        VarDeclBase* member,
        ThisExpr* thisExpr,
        Dictionary<Decl*, Expr*>& cachedDeclToCheckedVar,
        SeqStmt* seqStmtChild,
        bool isMemberInitCtor,
        Index& paramIndex);

    AssignExpr* createMemberAssignmentExpr(
        ThisExpr* thisExpr,
        Scope* scope,
        Decl* member,
        Expr* rightHandSideExpr);
    Expr* createCtorParamExpr(ConstructorDecl* ctor, Index paramIndex);
};

template<typename VisitorType>
struct SemanticsDeclReferenceVisitor : public SemanticsDeclVisitorBase,
                                       public StmtVisitor<VisitorType>,
                                       public ExprVisitor<VisitorType>,
                                       public ValVisitor<VisitorType>,
                                       public DeclVisitor<VisitorType>
{
    SemanticsDeclReferenceVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    List<SourceLoc> sourceLocStack;

    struct PushSourceLocRAII
    {
        List<SourceLoc>& stack;
        bool shouldPop = false;
        PushSourceLocRAII(List<SourceLoc>& sourceLocStack, SourceLoc loc)
            : stack(sourceLocStack)
        {
            if (loc.isValid())
            {
                stack.add(loc);
                shouldPop = true;
            }
        }
        ~PushSourceLocRAII()
        {
            if (shouldPop)
            {
                stack.removeLast();
            }
        }
    };

    virtual void processReferencedDecl(Decl* decl) = 0;

    virtual void processDeclModifiers(Decl* decl, SourceLoc refLoc) = 0;

    void dispatchIfNotNull(Stmt* stmt)
    {
        if (!stmt)
            return;
        PushSourceLocRAII sourceLocRAII(sourceLocStack, stmt->loc);
        return StmtVisitor<VisitorType>::dispatch(stmt);
    }
    void dispatchIfNotNull(Expr* expr)
    {
        if (!expr)
            return;
        PushSourceLocRAII sourceLocRAII(sourceLocStack, expr->loc);
        return ExprVisitor<VisitorType>::dispatch(expr);
    }
    void dispatchIfNotNull(Val* val)
    {
        if (!val)
            return;
        return ValVisitor<VisitorType>::dispatch(val);
    }
    void dispatchIfNotNull(DeclBase* val)
    {
        if (!val)
            return;
        return DeclVisitor<VisitorType>::dispatch(val);
    }

    // Expr Visitor
    void visitExpr(Expr*) {}

    void visitOpenRefExpr(OpenRefExpr* expr) { dispatchIfNotNull(expr->innerExpr); }

    void visitIndexExpr(IndexExpr* subscriptExpr)
    {
        for (auto arg : subscriptExpr->indexExprs)
            dispatchIfNotNull(arg);
        dispatchIfNotNull(subscriptExpr->baseExpression);
    }

    void visitParenExpr(ParenExpr* expr) { dispatchIfNotNull(expr->base); }

    void visitTupleExpr(TupleExpr* expr)
    {
        for (auto element : expr->elements)
            dispatchIfNotNull(element);
    }

    void visitAddressOfExpr(AddressOfExpr* expr) { dispatchIfNotNull(expr->arg); }

    void visitAssignExpr(AssignExpr* expr)
    {
        dispatchIfNotNull(expr->left);
        dispatchIfNotNull(expr->right);
    }

    void visitGenericAppExpr(GenericAppExpr* genericAppExpr)
    {
        dispatchIfNotNull(genericAppExpr->functionExpr);
        for (auto arg : genericAppExpr->arguments)
            dispatchIfNotNull(arg);
    }

    void visitSharedTypeExpr(SharedTypeExpr* expr) { dispatchIfNotNull(expr->base.exp); }

    void visitInvokeExpr(InvokeExpr* expr)
    {
        dispatchIfNotNull(expr->functionExpr);
        for (auto arg : expr->arguments)
            dispatchIfNotNull(arg);
    }

    // A fast-path builtin operator (e.g. `getClock() + 1`) is a `BuiltinOperatorExpr`, not an
    // `InvokeExpr`, so it needs its own recursion into the operands -- otherwise decl references
    // inside an operand (and their inferred capability requirements) would be missed.
    void visitBuiltinOperatorExpr(BuiltinOperatorExpr* expr)
    {
        for (auto arg : expr->arguments)
            dispatchIfNotNull(arg);
    }

    void visitTypeCastExpr(TypeCastExpr* expr)
    {
        dispatchIfNotNull(expr->functionExpr);
        for (auto arg : expr->arguments)
            dispatchIfNotNull(arg);
    }

    void visitDerefExpr(DerefExpr* expr) { dispatchIfNotNull(expr->base); }
    void visitMatrixSwizzleExpr(MatrixSwizzleExpr* expr) { dispatchIfNotNull(expr->base); }
    void visitSwizzleExpr(SwizzleExpr* expr) { dispatchIfNotNull(expr->base); }
    void visitOverloadedExpr(OverloadedExpr*) { return; }
    void visitOverloadedExpr2(OverloadedExpr2*) { return; }
    void visitAggTypeCtorExpr(AggTypeCtorExpr*) { return; }
    void visitCastToSuperTypeExpr(CastToSuperTypeExpr* expr) { dispatchIfNotNull(expr->valueArg); }
    void visitModifierCastExpr(ModifierCastExpr* expr) { dispatchIfNotNull(expr->valueArg); }
    void visitLetExpr(LetExpr* expr) { dispatchIfNotNull(expr->body); }
    void visitExtractExistentialValueExpr(ExtractExistentialValueExpr* expr)
    {
        dispatchIfNotNull(expr->declRef.declRefBase);
    }

    void visitDeclRefExpr(DeclRefExpr* expr)
    {
        dispatchIfNotNull(expr->type.type);
        dispatchIfNotNull(expr->declRef.declRefBase);

        // Pass down the callee location
        processDeclModifiers(expr->declRef.getDecl(), expr->loc);
    }

    void visitMemberExpr(MemberExpr* expr)
    {
        dispatchIfNotNull(expr->baseExpression);
        visitDeclRefExpr(expr);
    }

    void visitStaticMemberExpr(StaticMemberExpr* expr)
    {
        dispatchIfNotNull(expr->declRef.declRefBase);
    }
    void visitInitializerListExpr(InitializerListExpr* expr)
    {
        for (auto arg : expr->args)
        {
            dispatchIfNotNull(arg);
        }
    }

    void visitThisExpr(ThisExpr*) { return; }

    void visitThisTypeExpr(ThisTypeExpr*) { return; }
    void visitHLSLUnsignedTypeExpr(HLSLUnsignedTypeExpr*) { return; }
    void visitThisInterfaceExpr(ThisInterfaceExpr*) { return; }
    void visitAndTypeExpr(AndTypeExpr* expr)
    {
        dispatchIfNotNull(expr->left.type);
        dispatchIfNotNull(expr->right.type);
    }
    void visitPointerTypeExpr(PointerTypeExpr* expr) { dispatchIfNotNull(expr->base.type); }
    void visitAsTypeExpr(AsTypeExpr* expr)
    {
        dispatchIfNotNull(expr->value);
        dispatchIfNotNull(expr->witnessArg);
    }
    void visitIsTypeExpr(IsTypeExpr* expr)
    {
        dispatchIfNotNull(expr->value);
        dispatchIfNotNull(expr->witnessArg);
    }
    void visitMakeOptionalExpr(MakeOptionalExpr* expr)
    {
        dispatchIfNotNull(expr->value);
        dispatchIfNotNull(expr->typeExpr);
    }
    void visitCastOptionalExpr(CastOptionalExpr* expr)
    {
        dispatchIfNotNull(expr->valueArg);
        // innerVarDecl is synthetic; innerCoercedExpr references it
        dispatchIfNotNull(expr->innerCoercedExpr);
    }
    void visitPartiallyAppliedGenericExpr(PartiallyAppliedGenericExpr*) { return; }
    void visitSPIRVAsmExpr(SPIRVAsmExpr*) { return; }
    void visitModifiedTypeExpr(ModifiedTypeExpr* expr) { dispatchIfNotNull(expr->base.type); }
    void visitFuncTypeExpr(FuncTypeExpr* expr)
    {
        for (const auto& t : expr->parameters)
        {
            dispatchIfNotNull(t.type);
        }
        dispatchIfNotNull(expr->result.type);
    }
    void visitTupleTypeExpr(TupleTypeExpr* expr)
    {
        for (auto t : expr->members)
        {
            dispatchIfNotNull(t.type);
        }
    }
    void visitShapePackTransformExpr(ShapePackTransformExpr* expr)
    {
        for (auto arg : expr->args)
            dispatchIfNotNull(arg);
    }
    void visitPackBranchTypeExpr(PackBranchTypeExpr* expr)
    {
        dispatchIfNotNull(expr->packOperand.type);
        dispatchIfNotNull(expr->emptyType.type);
        dispatchIfNotNull(expr->nonEmptyType.type);
    }
    void visitTryExpr(TryExpr* expr) { dispatchIfNotNull(expr->base); }
    void visitHigherOrderInvokeExpr(HigherOrderInvokeExpr* expr)
    {
        dispatchIfNotNull(expr->baseFunction);
    }
    void visitTreatAsDifferentiableExpr(TreatAsDifferentiableExpr* expr)
    {
        dispatchIfNotNull(expr->innerExpr);
    }

    // Stmt Visitor

    void visitDeclStmt(DeclStmt* stmt) { dispatchIfNotNull(stmt->decl); }

    void visitBlockStmt(BlockStmt* stmt) { dispatchIfNotNull(stmt->body); }

    void visitSeqStmt(SeqStmt* seqStmt)
    {
        for (auto stmt : seqStmt->stmts)
            dispatchIfNotNull(stmt);
    }

    void visitLabelStmt(LabelStmt* stmt) { dispatchIfNotNull(stmt->innerStmt); }

    void visitBreakStmt(BreakStmt*) { return; }

    void visitContinueStmt(ContinueStmt*) { return; }

    void visitDoWhileStmt(DoWhileStmt* stmt)
    {
        dispatchIfNotNull(stmt->predicate);
        dispatchIfNotNull(stmt->statement);
    }

    void visitForStmt(ForStmt* stmt)
    {
        dispatchIfNotNull(stmt->initialStatement);
        dispatchIfNotNull(stmt->predicateExpression);
        dispatchIfNotNull(stmt->sideEffectExpression);
        dispatchIfNotNull(stmt->statement);
    }

    void visitCompileTimeForStmt(CompileTimeForStmt* stmt)
    {
        dispatchIfNotNull(stmt->rangeBeginExpr);
        dispatchIfNotNull(stmt->rangeEndExpr);
        dispatchIfNotNull(stmt->body);
    }

    void visitSwitchStmt(SwitchStmt* stmt)
    {
        dispatchIfNotNull(stmt->condition);
        dispatchIfNotNull(stmt->body);
    }

    void visitCaseStmt(CaseStmt* stmt) { dispatchIfNotNull(stmt->expr); }

    void visitTargetSwitchStmt(TargetSwitchStmt* stmt)
    {
        for (auto targetCase : stmt->targetCases)
            dispatchIfNotNull(targetCase);
    }

    void visitTargetCaseStmt(TargetCaseStmt* stmt) { dispatchIfNotNull(stmt->body); }

    void visitIntrinsicAsmStmt(IntrinsicAsmStmt*) { return; }

    void visitDefaultStmt(DefaultStmt*) { return; }

    void visitIfStmt(IfStmt* stmt)
    {
        dispatchIfNotNull(stmt->predicate);
        dispatchIfNotNull(stmt->positiveStatement);
        dispatchIfNotNull(stmt->negativeStatement);
    }

    void visitUnparsedStmt(UnparsedStmt*) { return; }

    void visitEmptyStmt(EmptyStmt*) { return; }

    void visitDiscardStmt(DiscardStmt*) { return; }

    void visitReturnStmt(ReturnStmt* stmt) { dispatchIfNotNull(stmt->expression); }

    void visitDeferStmt(DeferStmt* stmt) { dispatchIfNotNull(stmt->statement); }

    void visitThrowStmt(ThrowStmt* stmt) { dispatchIfNotNull(stmt->expression); }

    void visitCatchStmt(CatchStmt* stmt)
    {
        dispatchIfNotNull(stmt->errorVar);
        dispatchIfNotNull(stmt->tryBody);
        dispatchIfNotNull(stmt->handleBody);
    }

    void visitWhileStmt(WhileStmt* stmt)
    {
        dispatchIfNotNull(stmt->predicate);
        dispatchIfNotNull(stmt->statement);
    }

    void visitGpuForeachStmt(GpuForeachStmt*) { return; }

    void visitExpressionStmt(ExpressionStmt* stmt) { dispatchIfNotNull(stmt->expression); }

    void visitRequireCapabilityStmt(RequireCapabilityStmt*) { return; }

    // Val Visitor

    void visitDirectDeclRef(DirectDeclRef* declRef)
    {
        // If we have already visited, return.
        // Otherwise add it to visited set.
        if (!visitedVals.add(declRef))
            return;

        processReferencedDecl(declRef->getDecl());
    }

    void visitVal(Val* val)
    {
        // If we have already visited, return.
        // Otherwise add it to visited set.
        if (!visitedVals.add(val))
            return;

        for (Index i = 0; i < val->getOperandCount(); i++)
        {
            auto& operand = val->m_operands[i];
            switch (operand.kind)
            {
            case ValNodeOperandKind::ValNode:
                dispatchIfNotNull(val->getOperand(i));
                break;
            default:
                break;
            }
        }
        return;
    }

    HashSet<Val*> visitedVals;

    // Decl visitor
    void visitDeclBase(DeclBase*) {}

    void visitContainerDecl(ContainerDecl* decl)
    {
        for (auto m : decl->getDirectMemberDecls())
        {
            dispatchIfNotNull(m);
        }
    }

    void visitFunctionDeclBase(FunctionDeclBase* decl)
    {
        visitContainerDecl(decl);
        dispatchIfNotNull(decl->body);
    }

    void visitVarDeclBase(VarDeclBase* varDecl)
    {
        dispatchIfNotNull(varDecl->type.type);
        dispatchIfNotNull(varDecl->initExpr);
    }
};

struct SemanticsDeclCapabilityVisitor : public SemanticsDeclVisitorBase,
                                        public DeclVisitor<SemanticsDeclCapabilityVisitor>
{
    CapabilitySet m_anyPlatfromCapabilitySet;

    SemanticsDeclCapabilityVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    CapabilitySet& getAnyPlatformCapabilitySet()
    {
        if (m_anyPlatfromCapabilitySet.isEmpty())
        {
            m_anyPlatfromCapabilitySet = CapabilitySet(CapabilityName::any_target);
        }
        return m_anyPlatfromCapabilitySet;
    }

    CapabilitySet getDeclaredCapabilitySet(Decl* decl);

    void visitDecl(Decl*) {}
    void visitDeclGroup(DeclGroup*) {}
    void checkVarDeclCommon(VarDeclBase* varDecl);
    void visitContainerDecl(ContainerDecl* decl);

    void visitVarDecl(VarDecl* varDecl) { checkVarDeclCommon(varDecl); }

    void visitParamDecl(ParamDecl* paramDecl) { checkVarDeclCommon(paramDecl); }

    void visitFunctionDeclBase(FunctionDeclBase* funcDecl);

    void visitExtensionDecl(ExtensionDecl* extensionDecl);

    void visitSubscriptDecl(SubscriptDecl* subscriptDecl);

    void visitPropertyDecl(PropertyDecl* propertyDecl);

    void visitInheritanceDecl(InheritanceDecl* inheritanceDecl);

    // Check that a callable or property extension member's own [require(...)] attributes are
    // compatible with the extension's target type capabilities. Shared by
    // visitFunctionDeclBase (functions and constructors), visitSubscriptDecl, and
    // visitPropertyDecl.
    void _checkExtensionMemberCapConflict(Decl* memberDecl);

    enum class UndeclaredCapabilityDiagnosticKind
    {
        UseOfUndeclaredCapability,
        UseOfUndeclaredCapabilityOfInterfaceRequirement,
        UseOfUndeclaredCapabilityOfInheritanceDecl
    };

    void diagnoseUndeclaredCapability(
        Decl* decl,
        UndeclaredCapabilityDiagnosticKind diagKind,
        const CapabilityAtomSet& failedAtomsInsideAvailableSet,
        bool printProvenance);
};


/// Should the given `decl` nested in `parentDecl` be treated as a static rather than instance
/// declaration?
bool isEffectivelyStatic(Decl* decl, ContainerDecl* parentDecl)
{
    // Things at the global scope are always "members" of their module.
    //
    if (as<NamespaceDeclBase>(parentDecl))
        return false;
    if (as<FileDecl>(parentDecl))
        return false;

    // Anything explicitly marked `static` and not at module scope
    // counts as a static rather than instance declaration.
    //
    if (decl->hasModifier<HLSLStaticModifier>())
        return true;

    // For declarations that directly extend functions, their static-ness
    // is the same as the function they extend.
    //
    if (auto extDecl = as<ExtensionDecl>(parentDecl))
    {
        if (isDeclRefTypeOf<CallableDecl>(extDecl->targetType))
            return isEffectivelyStatic(
                as<DeclRefType>(extDecl->targetType)->getDeclRef().getDecl());
    }

    // Next we need to deal with cases where a declaration is
    // effectively `static` even if the language doesn't make
    // the user say so. Most languages make the default assumption
    // that nested types are `static` even if they don't say
    // so (Java is an exception here, perhaps due to some
    // influence from the Scandanavian OOP tradition of Beta/gbeta).
    //
    if (as<AggTypeDecl>(decl))
        return true;
    if (as<SimpleTypeDecl>(decl))
        return true;

    // Initializer/constructor declarations are effectively `static`
    // in Slang. They behave like functions that return an instance
    // of the enclosing type, rather than as functions that are
    // called on a pre-existing value.
    //
    if (as<ConstructorDecl>(decl))
        return true;

    if (as<EnumCaseDecl>(decl))
        return true;

    // Things nested inside functions may have dependencies
    // on values from the enclosing scope, but this needs to
    // be dealt with via "capture" so they are also effectively
    // `static`
    //
    if (as<FunctionDeclBase>(parentDecl))
        return true;

    // Type constraint declarations are used in member-reference
    // context as a form of casting operation, so we treat them
    // as if they are instance members. This is a bit of a hack,
    // but it achieves the result we want until we have an
    // explicit representation of up-cast operations in the
    // AST.
    //
    if (as<TypeConstraintDecl>(decl))
        return false;

    return false;
}

bool isEffectivelyStatic(Decl* decl)
{
    // For the purposes of an ordinary declaration, when determining if
    // it is static or per-instance, the "parent" declaration we really
    // care about is the next outer non-generic declaration.
    //
    // TODO: This idiom of getting the "next outer non-generic declaration"
    // comes up just enough that we should probably have a convenience
    // function for it.

    auto parentDecl = decl->parentDecl;
    while (auto genericDecl = as<GenericDecl>(parentDecl))
        parentDecl = genericDecl->parentDecl;

    return isEffectivelyStatic(decl, parentDecl);
}

bool isGlobalDecl(Decl* decl)
{
    if (!decl)
        return false;
    auto parentDecl = decl->parentDecl;
    while (auto genericDecl = as<GenericDecl>(parentDecl))
        parentDecl = genericDecl->parentDecl;
    return as<NamespaceDeclBase>(parentDecl) != nullptr || as<FileDecl>(parentDecl) != nullptr;
}

bool isUnsafeForceInlineFunc(FunctionDeclBase* funcDecl)
{
    return funcDecl->hasModifier<UnsafeForceInlineEarlyAttribute>();
}

/// Is `decl` a global shader parameter declaration?
bool isGlobalShaderParameter(VarDeclBase* decl)
{
    // We exclude uniform shadows because they are implementation variables, not shader inputs.
    if (as<UniformParameterShadowVarDecl>(decl))
        return false;

    // If it's an *actual* global it is not a global shader parameter
    if (decl->hasModifier<ActualGlobalModifier>())
    {
        return false;
    }

    // A global shader parameter must be declared at global or namespace
    // scope, so that it has a single definition across the module.
    //
    if (!isGlobalDecl(decl))
        return false;

    for (auto modifier : decl->modifiers)
    {
        // A global variable marked `static` indicates a traditional
        // global variable (albeit one that is implicitly local to
        // the translation unit)
        //
        if (as<HLSLStaticModifier>(modifier))
            return false;

        // While not normally allowed, out variables are not constant
        // parameters, this can happen for example in GLSL mode
        if (as<OutModifier>(modifier))
            return false;
        if (as<InModifier>(modifier))
            return false;

        // The `groupshared` modifier indicates that a variable cannot
        // be a shader parameters, but is instead transient storage
        // allocated for the duration of a thread-group's execution.
        //
        if (as<HLSLGroupSharedModifier>(modifier))
            return false;
    }

    return true;
}

[[maybe_unused]] static bool _isUncheckedLocalVar(const Decl* decl)
{
    auto checkStateExt = decl->checkState;
    auto isUnchecked =
        checkStateExt.getState() == DeclCheckState::Unchecked || checkStateExt.isBeingChecked();
    return isUnchecked && isLocalVar(decl);
}

// Get the type to use when referencing a declaration
QualType getTypeForDeclRef(
    ASTBuilder* astBuilder,
    SemanticsVisitor* sema,
    DiagnosticSink* sink,
    DeclRef<Decl> declRef,
    Type** outTypeResult,
    SourceLoc loc)
{
    if (sema)
    {
        // If this is a local variable which hasn't been checked yet then
        // it's probably a declare-after-use which has incorrectly got
        // through declref resolution.
        SLANG_ASSERT(!_isUncheckedLocalVar(declRef.getDecl()));

        // Once we've ruled out the case of referencing a local declaration
        // before it has been checked, we will go ahead and ensure that
        // semantic checking has been performed on the chosen declaration,
        // at least up to the point where we can query its type.
        //
        sema->ensureDecl(declRef, DeclCheckState::CanUseTypeOfValueDecl);
    }

    // We need to insert an appropriate type for the expression, based on
    // what we found.
    if (auto varDeclRef = declRef.as<VarDeclBase>())
    {
        QualType qualType;
        qualType.type = getType(astBuilder, varDeclRef);

        bool isLValue = true;
        if (auto shadowVar = as<UniformParameterShadowVarDecl>(varDeclRef.getDecl()))
        {
            // Header checking applies the mutable-global type restriction to a shadow.
            // We make references immutable when the shadow must alias its parameter instead.
            isLValue = !shadowVar->shouldBeImmutableAlias;
        }
        if (varDeclRef.getDecl()->findModifier<ConstModifier>())
            isLValue = false;

        bool isReadOnlyMemoryLocation = false;
        if (auto paramDecl = as<ParamDecl>(varDeclRef.getDecl()))
        {
            // Function parameters declared in the "modern" style
            // are immutable unless their passing mode is meant to be written.
            const bool isModernParam = as<ModernParamDecl>(paramDecl) != nullptr;

            // The effective passing mode decides whether the body may write a parameter.
            switch (getParamPassingMode(paramDecl))
            {
            case ParamPassingMode::In:
                // A legacy (C-style) `in` parameter is a mutable local copy.
                if (isModernParam)
                    isLValue = false;
                break;
            case ParamPassingMode::BorrowIn:
                // TODO(#13833): A borrow is an immutable borrow of its argument, so its body should
                // not be able to write it, and code that does is already incorrect. Making it
                // read-only is a bug fix that requires updating existing tests, so we leave it to a
                // separate change. Until then, a borrow follows the rule for `in`.
                if (isModernParam)
                    isLValue = false;
                break;
            case ParamPassingMode::Out:
            case ParamPassingMode::BorrowInOut:
            case ParamPassingMode::RefReadWrite:
            case ParamPassingMode::RefWriteOnly:
                // These parameters are meant to be written.
                break;
            case ParamPassingMode::RefReadOnly:
                isLValue = false;
                isReadOnlyMemoryLocation = true;
                break;
            default:
                SLANG_UNEXPECTED("unhandled parameter-passing mode");
            }
        }

        // Global-scope shader parameters should not be writable,
        // since they are effectively program inputs.
        //
        // With HLSL compatibility enabled, the parser introduces a shadow variable for uses
        // within the shader. The underlying parameter remains immutable in either mode.
        //
        if (isGlobalShaderParameter(varDeclRef.getDecl()))
            isLValue = false;

        // Variables declared with `let` are always immutable.
        if (varDeclRef.is<LetDecl>())
            isLValue = false;

        // Generic value parameters are always immutable
        if (isGenericValueParam(varDeclRef))
            isLValue = false;

        // An explicit `readonly` or `writeonly` qualifier still restricts parameter uses in
        // compatibility mode. The parser keeps these modifiers on the underlying parameter,
        // so we obtain them from that declaration without replacing the shadow's value type.
        auto declForMemoryQualifier = varDeclRef.getDecl();
        if (auto shadow = as<UniformParameterShadowVarDecl>(declForMemoryQualifier))
            declForMemoryQualifier = shadow->uniformParameter;

        bool isWriteOnly = false;
        if (auto collection = declForMemoryQualifier->findModifier<MemoryQualifierSetModifier>())
        {
            if (collection->getMemoryQualifierBit() & MemoryQualifierSetModifier::Flags::kReadOnly)
            {
                isLValue = false;
                qualType.hasReadOnlyOnTarget = true;
            }
            if (collection->getMemoryQualifierBit() & MemoryQualifierSetModifier::Flags::kWriteOnly)
                isWriteOnly = true;
        }

        qualType.isLeftValue = isLValue;
        qualType.isReadOnlyMemoryLocation = isReadOnlyMemoryLocation;
        qualType.isWriteOnly = isWriteOnly;
        return qualType;
    }
    else if (auto propertyDeclRef = declRef.as<PropertyDecl>())
    {
        // Access to a declared `property` is similar to
        // access to a variable/field, except that it
        // is mediated through accessors (getters, seters, etc.).

        QualType qualType;
        qualType.type = getType(astBuilder, propertyDeclRef);

        bool isLValue = false;

        // If the property has any declared accessors that
        // can be used to set the property, then the resulting
        // expression behaves as an l-value.
        //
        if (propertyDeclRef.getDecl()->getMembersOfType<SetterDecl>().isNonEmpty())
            isLValue = true;
        if (propertyDeclRef.getDecl()->getMembersOfType<RefAccessorDecl>().isNonEmpty())
            isLValue = true;

        qualType.isLeftValue = isLValue;
        return qualType;
    }
    else if (auto enumCaseDeclRef = declRef.as<EnumCaseDecl>())
    {
        sema->ensureDecl(declRef.declRefBase, DeclCheckState::DefinitionChecked);
        QualType qualType;
        qualType.type = getType(astBuilder, enumCaseDeclRef);
        qualType.isLeftValue = false;
        return qualType;
    }
    else if (auto typeAliasDeclRef = declRef.as<TypeDefDecl>())
    {
        auto type = getNamedType(astBuilder, typeAliasDeclRef);
        *outTypeResult = type;
        return QualType(astBuilder->getTypeType(type));
    }
    else if (auto aggTypeDeclRef = declRef.as<AggTypeDecl>())
    {
        auto type = DeclRefType::create(astBuilder, aggTypeDeclRef);
        *outTypeResult = type;
        return QualType(astBuilder->getTypeType(type));
    }
    else if (auto simpleTypeDeclRef = declRef.as<SimpleTypeDecl>())
    {
        auto type = DeclRefType::create(astBuilder, simpleTypeDeclRef);
        *outTypeResult = type;
        return QualType(astBuilder->getTypeType(type));
    }
    else if (auto genericDeclRef = declRef.as<GenericDecl>())
    {
        auto type = getGenericDeclRefType(astBuilder, genericDeclRef);
        *outTypeResult = type;
        return QualType(astBuilder->getTypeType(type));
    }
    else if (auto funcDeclRef = declRef.as<CallableDecl>())
    {
        if (hasDirectFuncType(funcDeclRef))
        {
            return QualType(
                as<Type>(funcDeclRef.getDecl()
                             ->funcType.type->substitute(astBuilder, SubstitutionSet(declRef))
                             ->resolve()));
        }
        else
        {
            auto type = getFuncType(astBuilder, funcDeclRef);
            return QualType(type);
        }
    }
    else if (auto constraintDeclRef = declRef.as<TypeConstraintDecl>())
    {
        // When we access a constraint or an inheritance decl (as a member),
        // we are conceptually performing a "cast" to the given super-type,
        // with the declaration showing that such a cast is legal.
        auto type = getSup(astBuilder, constraintDeclRef);
        return QualType(type);
    }
    else if (auto namespaceDeclRef = declRef.as<NamespaceDeclBase>())
    {
        auto type = getNamespaceType(astBuilder, namespaceDeclRef);
        return QualType(type);
    }
    if (sink)
    {
        // The compiler is trying to form a reference to a declaration
        // that doesn't appear to be usable as an expression or type.
        //
        // In practice, this arises when user code has an undefined-identifier
        // error, but the name that was undefined in context also matches
        // a contextual keyword. Rather than confuse the user with the
        // details of contextual keywords in the compiler, we will diagnose
        // this as an undefined identifier.
        //
        // TODO: This code could break if we ever go down this path with
        // an identifier that doesn't have a name.
        //
        // Note: unlike the `VarExpr` lookup path, we do not attach a "did you
        // mean ...?" suggestion here. This site is reached for a name that
        // already resolved to a contextual keyword (not an ordinary in-scope
        // lookup), so a Levenshtein match against the lexical scope would be
        // misleading.
        sink->diagnose(
            Diagnostics::UndefinedIdentifier{.name = declRef.getName(), .location = loc});
    }
    return QualType(astBuilder->getErrorType());
}

QualType getTypeForDeclRef(ASTBuilder* astBuilder, DeclRef<Decl> declRef, SourceLoc loc)
{
    Type* typeResult = nullptr;
    return getTypeForDeclRef(astBuilder, nullptr, nullptr, declRef, &typeResult, loc);
}

DeclRef<ExtensionDecl> applyExtensionToType(
    SemanticsVisitor* semantics,
    ExtensionDecl* extDecl,
    Type* type,
    Dictionary<Type*, SubtypeWitness*>* additionalSubtypeWitness)
{
    if (!semantics)
        return DeclRef<ExtensionDecl>();

    return semantics->applyExtensionToType(extDecl, type, additionalSubtypeWitness);
}

Type* SemanticsVisitor::resolveType(Type* type)
{
    return (Type*)resolveVal(type);
}

bool SemanticsVisitor::isDeclUsableAsStaticMember(Decl* decl)
{
    if (m_allowStaticReferenceToNonStaticMember)
        return true;

    if (auto genericDecl = as<GenericDecl>(decl))
        decl = genericDecl->inner;

    if (decl->hasModifier<HLSLStaticModifier>())
        return true;

    if (as<ConstructorDecl>(decl))
        return true;

    if (as<EnumCaseDecl>(decl))
        return true;

    if (as<AggTypeDeclBase>(decl))
        return true;

    if (as<SimpleTypeDecl>(decl))
        return true;

    if (as<TypeConstraintDecl>(decl))
        return true;

    return false;
}

bool SemanticsVisitor::isUsableAsStaticMember(LookupResultItem const& item)
{
    if (m_allowStaticReferenceToNonStaticMember)
        return true;

    // There's a bit of a gotcha here, because a lookup result
    // item might include "breadcrumbs" that indicate more steps
    // along the lookup path. As a result it isn't always
    // valid to just check whether the final decl is usable
    // as a static member, because it might not even be a
    // member of the thing we are trying to work with.
    //

    Decl* decl = item.declRef.getDecl();
    for (auto bb = item.breadcrumbs; bb; bb = bb->next)
    {
        switch (bb->kind)
        {
        // In case lookup went through a `__transparent` member,
        // we are interested in the static-ness of that transparent
        // member, and *not* the static-ness of whatever was inside
        // of it.
        //
        // TODO: This would need some work if we ever had
        // transparent *type* members.
        //
        case LookupResultItem::Breadcrumb::Kind::Member:
            decl = bb->declRef.getDecl();
            break;

            // TODO: Are there any other cases that need special-case
            // handling here?

        default:
            break;
        }
    }

    // Okay, we've found the declaration we should actually
    // be checking, so lets validate that.

    return isDeclUsableAsStaticMember(decl);
}

/// Dispatch an appropriate visitor to check `decl` up to state `state`
///
/// The current state of `decl` must be `state-1`.
/// This call does *not* handle updating the state of `decl`; the
/// caller takes responsibility for doing so.
///
static void _dispatchDeclCheckingVisitor(
    Decl* decl,
    DeclCheckState state,
    SemanticsContext& shared);

void SemanticsVisitor::ensureOuterGenericConstraints(Decl* decl, DeclCheckState state)
{
    if (auto genericDecl = GetOuterGeneric(decl))
    {
        auto nextGeneric = findNextOuterGeneric(genericDecl);
        if (nextGeneric)
        {
            if (nextGeneric->checkState.getState() < state)
                ensureOuterGenericConstraints(nextGeneric, state);
        }
        ensureDecl(genericDecl, state);
    }
}

// Make sure a declaration has been checked, so we can refer to it.
// Note that this may lead to us recursively invoking checking,
// so this may not be the best way to handle things.
void SemanticsVisitor::ensureDecl(Decl* decl, DeclCheckState state, SemanticsContext* baseContext)
{
    // If the `decl` has already been checked up to or beyond `state`
    // then there is nothing for us to do.
    //
    if (decl->isChecked(state))
        return;

    // Is the declaration already being checked, somewhere up the
    // call stack from us?
    //
    if (decl->checkState.isBeingChecked())
    {
        // We tried to reference the same declaration while checking it!
        //
        // TODO: we should ideally be tracking a "chain" of declarations
        // being checked on the stack, so that we can report the full
        // chain that leads from this declaration back to itself.
        //
        getSink()->diagnose(Diagnostics::CyclicReference{.decl = decl});
        return;
    }

    // If we should skip the checking, return now.
    // A common case to skip checking is for the function bodies when we are in
    // the language server. In that case we only care about the function bodies in a
    // specific module and can skip checking the reference modules until they
    // are being opened/edited later.
    if (shouldSkipChecking(decl, state))
    {
        decl->setCheckState(state);
        return;
    }

    // Set the flag that indicates we are checking this declaration,
    // so that the cycle check above will catch us before we go
    // into any infinite loops.
    //
    decl->checkState.setIsBeingChecked(true);

    // Our task is to bring the `decl` up to `state` which may be
    // one or more steps ahead of where it currently is. We can
    // invoke a visitor designed to bring a declaration from state
    // N to state N+1, and in general we might need multiple such
    // passes to get `decl` to where we need it.
    //
    // The coding of this loop is somewhat defensive to deal
    // with special cases that will be described along the way.
    //
    auto outerScope = getScope(decl);
    for (;;)
    {
        // The first thing is to check what state the decl is
        // currently in at the start of this loop iteration,
        // and to bail out if it has been checked up to
        // (or beyond) our target state.
        //
        auto currentState = decl->checkState.getState();
        if (currentState >= state)
            break;

        // Because our visitors are only designed to go from state
        // N to N+1 in general, we will aspire to transition to
        // a state that is one greater than `currentState`.
        //
        auto nextState = DeclCheckState(Int(currentState) + 1);

        // We now dispatch an appropriate visitor based on `nextState`.
        //
        // Note that we always dispatch the visitor in a "fresh" semantic-checking
        // context, so that the state at the point where a declaration is *referenced*
        // cannot affect the state in which the declaration is *checked*.
        //
        SemanticsContext subContext =
            baseContext ? SemanticsContext(*baseContext) : SemanticsContext(getShared());
        if (outerScope)
            subContext = subContext.withOuterScope(outerScope);
        _dispatchDeclCheckingVisitor(decl, nextState, subContext);

        // A visitor can advance `decl` past several states at once. Consider `let x = 1;`:
        // the header visitor infers the type of `x` and marks `x` as `DefinitionChecked`. Of the
        // skipped steps, only `ReadyForReference` compares `decl` with other declarations, so we
        // still run it; without it, `int x; let x = 1;` would be accepted while
        // `let x = 1; int x;` is not. Earlier compiler releases skipped it, so a conflict that it
        // finds is a warning; Slang 202c may make it an error (shader-slang/slang#13956).
        //
        if (nextState < DeclCheckState::ReadyForReference &&
            decl->checkState.getState() >= DeclCheckState::ReadyForReference)
        {
            SemanticsDeclRedeclarationVisitor(subContext, RedeclarationSeverity::Warning)
                .dispatch(decl);
        }

        // In the common case, the visitor will have done the necessary
        // checking, but will *not* have updated the `checkState` on
        // `decl`. In that case we will do the update here, to save
        // us the complication of having to deal with state update in
        // every single visitor method.
        //
        // However, sometimes a visitor *will* want to manually update
        // the state of a declaration, and it may actually update it
        // *past* the `nextState` we asked for (or even past the
        // eventual target `state`). In those cases we don't want to
        // accidentally set the state of `decl` to something lower
        // than what has actually been checked, so we test for
        // such cases here.
        //
        if (nextState > decl->checkState.getState())
        {
            decl->setCheckState(nextState);
        }
    }

    // Once we are done here, the state of `decl` should have
    // been upgraded to (at least) `state`.
    //
    SLANG_ASSERT(decl->isChecked(state));

    // Now that we are done checking `decl` we need to restore
    // its "is being checked" flag so that we don't generate
    // errors the next time somebody calls `ensureDecl()` on it.
    //
    decl->checkState.setIsBeingChecked(false);
}

/// Recursively ensure the tree of declarations under `decl` is in `state`.
///
/// This function does *not* handle declarations nested in function bodies
/// because those cannot be meaningfully checked outside of the context
/// of their surrounding statement(s).
///
void SemanticsVisitor::ensureAllDeclsRec(Decl* decl, DeclCheckState state)
{
    // Ensure `decl` itself first.
    ensureDecl(decl, state);

    // If `decl` is a container, then we want to ensure its children.
    if (auto containerDecl = as<ContainerDecl>(decl))
    {
        // NOTE! We purposefully do not iterate with the for(auto childDecl :
        // containerDecl->members) here, because the visitor may add to `members` whilst iteration
        // takes place, invalidating the iterator and likely a crash.
        //
        // Accessing the members via index side steps the issue.
        for (Index i = 0; i < containerDecl->getDirectMemberDeclCount(); ++i)
        {
            Decl* childDecl = containerDecl->getDirectMemberDecl(i);

            // As an exception, if any of the child is a `ScopeDecl`,
            // then that indicates that it represents a scope for local
            // declarations under a statement (e.g., in a function body),
            // and we don't want to check such local declarations here.
            //

            if (as<ScopeDecl>(childDecl))
                continue;

            ensureAllDeclsRec(childDecl, state);
        }
    }

    // Note: the "inner" declaration of a `GenericDecl` is currently
    // not exposed as one of its children (despite a `GenericDecl`
    // being a `ContainerDecl`), so we need to handle the inner
    // declaration of a generic as another case here.
    //
    if (auto genericDecl = as<GenericDecl>(decl))
    {
        ensureAllDeclsRec(genericDecl->inner, state);
    }
}

void SemanticsVisitor::ensureRegisteredSynthesizedDecls(DeclCheckState state)
{
    auto shared = getShared();

    // Checking one root can publish another. Query the live count on every iteration so the new
    // declaration reaches this phase before we move on to the next one.
    for (Index i = 0; i < shared->getSynthesizedDeclRootCount(); ++i)
    {
        ensureAllDeclsRec(shared->getSynthesizedDeclRoot(i), state);
    }
}

bool isUnsizedArrayType(Type* type)
{
    // Not an array?
    auto arrayType = as<ArrayExpressionType>(type);
    if (!arrayType)
        return false;

    // Explicit element count given?
    return arrayType->isUnsized();
}

bool isInterfaceType(Type* type)
{
    if (auto declRefType = as<DeclRefType>(type))
    {
        if (auto interfaceDeclRef = declRefType->getDeclRef().as<InterfaceDecl>())
            return true;
    }
    return false;
}

EnumDecl* isEnumType(Type* type)
{
    if (auto declRefType = as<DeclRefType>(type))
    {
        return as<EnumDecl>(declRefType->getDeclRef().getDecl());
    }
    return nullptr;
}

bool doesTypeHaveAnUnusedBitPatternThatCanBeUsedForOptionalRepresentation(Type* type)
{
    if (as<PtrTypeBase>(type))
        return true;
    if (isDeclRefTypeOf<InterfaceDecl>(type))
        return true;
    if (isDeclRefTypeOf<ClassDecl>(type))
        return true;
    if (as<OptionalType>(type))
        return true;
    // TODO(tfoley): Somebody put the explicit `Ref<T>` types
    // here as a list of a nullable type, and it is
    if (as<ExplicitRefType>(type))
        return true;
    if (as<NativeStringType>(type))
        return true;
    return false;
}

bool SemanticsVisitor::shouldSkipChecking(Decl* decl, DeclCheckState state)
{
    if (state < DeclCheckState::DefinitionChecked)
        return false;
    // If we are in language server, we should skip checking all the function bodies
    // except for the module or function that the user cared about.
    // This optimization helps reduce the response time.
    if (!getLinkage()->isInLanguageServer())
    {
        return false;
    }
    if (auto funcDecl = as<FunctionDeclBase>(decl))
    {
        auto& assistInfo = getLinkage()->contentAssistInfo;
        // If this func is not defined in the primary module, skip checking its body.
        auto moduleDecl = getModuleDecl(decl);
        if (moduleDecl && moduleDecl->module->getNameObj() != assistInfo.primaryModuleName &&
            moduleDecl->getName() != assistInfo.primaryModuleName)
            return true;
        if (funcDecl->body)
        {
            auto humaneLoc =
                getLinkage()->getSourceManager()->getHumaneLoc(decl->loc, SourceLocType::Actual);
            if (humaneLoc.pathInfo.foundPath != assistInfo.primaryModulePath)
            {
                return true;
            }
            if (assistInfo.checkingMode == ContentAssistCheckingMode::Completion)
            {
                // For completion requests, we skip all funtion bodies except for the one
                // that the current cursor is in.
                auto startingLine = humaneLoc.line;
                for (auto modifier : funcDecl->modifiers)
                {
                    auto modifierLoc = getLinkage()->getSourceManager()->getHumaneLoc(
                        modifier->loc,
                        SourceLocType::Actual);
                    if (modifierLoc.line < startingLine)
                        startingLine = modifierLoc.line;
                }
                auto closingLoc = getLinkage()->getSourceManager()->getHumaneLoc(
                    funcDecl->closingSourceLoc,
                    SourceLocType::Actual);

                if (assistInfo.cursorLine < startingLine || assistInfo.cursorLine > closingLoc.line)
                    return true;
            }
        }
    }
    return false;
}

IntVal* SemanticsVisitor::_validateCircularVarDefinition(VarDeclBase* varDecl)
{
    // The easiest way to test if the declaration is circular is to
    // validate it as a constant.
    //
    // TODO: The logic here will only apply for `static const` declarations
    // of integer type, given that our constant folding currently only
    // applies to such types. A more robust fix would involve a truly
    // recursive walk of the AST declarations, and an even *more* robust
    // fix would wait until after IR linking to detect and diagnose circularity
    // in case it crosses module boundaries.
    //
    //
    if (!isScalarIntegerType(varDecl->type))
        return nullptr;
    return tryConstantFoldDeclRef(
        DeclRef<VarDeclBase>(varDecl),
        ConstantFoldingKind::SpecializationConstant,
        nullptr);
}

void SemanticsDeclModifiersVisitor::visitInterfaceDecl(InterfaceDecl* interfaceDecl)
{
    visitDecl(interfaceDecl);

    if (interfaceDecl->hasModifier<AnyValueSizeAttribute>())
        addModifier(interfaceDecl, m_astBuilder->create<DynModifier>());

    validateDynInterfaceUsage(this, getSink(), getOptionSet(), interfaceDecl);
}

void SemanticsDeclModifiersVisitor::visitStructDecl(StructDecl* structDecl)
{
    visitDecl(structDecl);

    // Replace any bitfield member with a property, do this here before
    // name lookup to avoid the original var decl being referenced
    //
    auto directMemberDeclCount = structDecl->getDirectMemberDeclCount();
    for (Index i = 0; i < directMemberDeclCount; ++i)
    {
        auto varDecl = as<VarDecl>(structDecl->getDirectMemberDecl(i));
        if (!varDecl)
            continue;

        const auto bitFieldModifier = varDecl->findModifier<BitFieldModifier>();
        if (!bitFieldModifier)
            continue;

        auto propertyDecl = m_astBuilder->create<PropertyDecl>();
        propertyDecl->modifiers = varDecl->modifiers;
        propertyDecl->type = varDecl->type;
        propertyDecl->loc = varDecl->loc;
        propertyDecl->nameAndLoc = varDecl->getNameAndLoc();
        propertyDecl->parentDecl = structDecl;
        propertyDecl->ownedScope = m_astBuilder->create<Scope>();
        propertyDecl->ownedScope->containerDecl = propertyDecl;
        propertyDecl->ownedScope->parent = getScope(structDecl);

        auto propertyDeclScope = getScope(propertyDecl);

        const auto getAccessorDecl = m_astBuilder->create<GetterDecl>();
        getAccessorDecl->ownedScope = m_astBuilder->create<Scope>();
        getAccessorDecl->ownedScope->containerDecl = getAccessorDecl;
        getAccessorDecl->ownedScope->parent = propertyDeclScope;
        propertyDecl->addMember(getAccessorDecl);

        const auto setAccessorDecl = m_astBuilder->create<SetterDecl>();
        addModifier(setAccessorDecl, m_astBuilder->create<MutatingAttribute>());
        setAccessorDecl->ownedScope = m_astBuilder->create<Scope>();
        setAccessorDecl->ownedScope->containerDecl = setAccessorDecl;
        setAccessorDecl->ownedScope->parent = propertyDeclScope;
        propertyDecl->addMember(setAccessorDecl);

        structDecl
            ->_replaceDirectMemberBitFieldVariableDeclAtIndexWithPropertyDeclThatWasSynthesizedForIt(
                i,
                varDecl,
                propertyDecl);
    }
}

void SemanticsDeclHeaderVisitor::checkDerivativeMemberAttributeParent(
    VarDeclBase* varDecl,
    DerivativeMemberAttribute* derivativeMemberAttr)
{
    auto memberType = checkProperType(getLinkage(), varDecl->type, getSink());
    auto diffType = getDifferentialType(m_astBuilder, memberType, varDecl->loc);
    if (as<ErrorType>(diffType))
    {
        getSink()->diagnose(
            Diagnostics::TypeIsNotDifferentiable{.type = memberType, .attr = derivativeMemberAttr});
    }
    auto thisType = calcThisType(makeDeclRef(varDecl->parentDecl));
    if (!thisType)
    {
        getSink()->diagnose(Diagnostics::DerivativeMemberAttributeCanOnlyBeUsedOnMembers{
            .attr = derivativeMemberAttr->loc});
    }
    auto diffThisType = getDifferentialType(m_astBuilder, thisType, derivativeMemberAttr->loc);
    if (!diffThisType)
    {
        getSink()->diagnose(
            Diagnostics::InvalidUseOfDerivativeMemberAttributeParentTypeIsNotDifferentiable{
                .attr = derivativeMemberAttr->loc});
    }
}

void SemanticsDeclHeaderVisitor::checkExtensionExternVarAttribute(
    VarDeclBase* varDecl,
    ExtensionExternVarModifier* extensionExternMemberModifier)
{
    if (const auto parentExtension = as<ExtensionDecl>(varDecl->parentDecl); parentExtension)
    {
        if (auto originalVarDecl = extensionExternMemberModifier->originalDecl.as<VarDeclBase>())
        {
            auto originalType = GetTypeForDeclRef(originalVarDecl, originalVarDecl.getLoc());
            auto extVarType = varDecl->type;
            if (!extVarType.type || !extVarType.type->equals(originalType))
            {
                getSink()->diagnose(Diagnostics::TypeOfExternDeclMismatchesOriginalDefinition{
                    .expectedType = originalType,
                    .decl = varDecl});
            }
            else
            {
                return;
            }
        }
        else
        {
            getSink()->diagnose(
                Diagnostics::DefinitionOfExternDeclMismatchesOriginalDefinition{.decl = varDecl});
        }
    }
}

ImageFormat inferImageFormatFromTextureType(
    VarDeclBase* varDecl,
    TextureTypeBase* textureType,
    bool& outIsInferred)
{
    outIsInferred = false;
    ImageFormat format = ImageFormat::unknown;
    if (auto formatVal = as<ConstantIntVal>(textureType->getFormat()))
    {
        format = (ImageFormat)formatVal->getValue();
    }
    if (format != ImageFormat::unknown)
        return format;

    if (auto formatAttrib = varDecl->findModifier<FormatAttribute>())
    {
        format = formatAttrib->format;
    }
    else
    {
        // If format is not specified explicitly through format attribute, we will derive a default
        // value from the element format.
        outIsInferred = true;
        auto elementType = textureType->getElementType();
        Int vectorWidth = 1;
        if (auto elementVecType = as<VectorExpressionType>(elementType))
        {
            if (auto intLitVal = as<ConstantIntVal>(elementVecType->getElementCount()))
            {
                vectorWidth = (Int)intLitVal->getValue();
            }
            else
            {
                vectorWidth = 1;
            }
            elementType = elementVecType->getElementType();
        }
        if (auto basicType = as<BasicExpressionType>(elementType))
        {
            switch (basicType->getBaseType())
            {
            case BaseType::UInt:
                switch (vectorWidth)
                {
                case 1:
                    format = ImageFormat::r32ui;
                    break;
                case 2:
                    format = ImageFormat::rg32ui;
                    break;
                case 4:
                    format = ImageFormat::rgba32ui;
                    break;
                }
                break;
            case BaseType::Int:
                switch (vectorWidth)
                {
                case 1:
                    format = ImageFormat::r32i;
                    break;
                case 2:
                    format = ImageFormat::rg32i;
                    break;
                case 4:
                    format = ImageFormat::rgba32i;
                    break;
                }
                break;
            case BaseType::UInt16:
                switch (vectorWidth)
                {
                case 1:
                    format = ImageFormat::r16ui;
                    break;
                case 2:
                    format = ImageFormat::rg16ui;
                    break;
                case 4:
                    format = ImageFormat::rgba16ui;
                    break;
                }
                break;
            case BaseType::Int16:
                switch (vectorWidth)
                {
                case 1:
                    format = ImageFormat::r16i;
                    break;
                case 2:
                    format = ImageFormat::rg16i;
                    break;
                case 4:
                    format = ImageFormat::rgba16i;
                    break;
                }
                break;
            case BaseType::UInt8:
                switch (vectorWidth)
                {
                case 1:
                    format = ImageFormat::r8ui;
                    break;
                case 2:
                    format = ImageFormat::rg8ui;
                    break;
                case 4:
                    format = ImageFormat::rgba8ui;
                    break;
                }
                break;
            case BaseType::Int8:
                switch (vectorWidth)
                {
                case 1:
                    format = ImageFormat::r8i;
                    break;
                case 2:
                    format = ImageFormat::rg8i;
                    break;
                case 4:
                    format = ImageFormat::rgba8i;
                    break;
                }
                break;
            case BaseType::Int64:
                switch (vectorWidth)
                {
                case 1:
                    format = ImageFormat::r64i;
                    break;
                default:
                    break;
                }
                break;
            case BaseType::UInt64:
                switch (vectorWidth)
                {
                case 1:
                    format = ImageFormat::r64ui;
                    break;
                default:
                    break;
                }
                break;
            case BaseType::Half:
                switch (vectorWidth)
                {
                case 1:
                    format = ImageFormat::r16f;
                    break;
                case 2:
                    format = ImageFormat::rg16f;
                    break;
                case 4:
                    format = ImageFormat::rgba16f;
                    break;
                }
                break;
            }
        }
    }
    return format;
}

void SemanticsDeclHeaderVisitor::maybeApplyLayoutModifier(VarDeclBase* varDecl)
{
    // Matrix layout modifiers are `TypeModifier`s, so for ordinary declarators the parser
    // moves them onto the type expression and `visitModifiedTypeExpr` bakes in the layout.
    // A traditional-style function parameter (leading-modifier syntax), however, parses its
    // modifiers before its type and keeps them on the decl, so this decl-side branch remains
    // the applier for that path.
    if (auto matrixType = as<MatrixExpressionType>(varDecl->type.type))
    {
        if (auto matrixLayoutModifier = varDecl->findModifier<MatrixLayoutModifier>())
        {
            auto matrixLayout = as<ColumnMajorLayoutModifier>(matrixLayoutModifier)
                                    ? SLANG_MATRIX_LAYOUT_COLUMN_MAJOR
                                    : SLANG_MATRIX_LAYOUT_ROW_MAJOR;
            auto newMatrixType = getASTBuilder()->getMatrixType(
                matrixType->getElementType(),
                matrixType->getRowCount(),
                matrixType->getColumnCount(),
                getASTBuilder()->getIntVal(matrixType->getLayout()->getType(), matrixLayout));
            varDecl->type.type = newMatrixType;
        }
    }
    else if (auto textureType = as<TextureTypeBase>(unwrapArrayType(varDecl->type.type)))
    {
        if (getLinkage()->m_optionSet.getBoolOption(CompilerOptionName::DefaultImageFormatUnknown))
            return;

        // For texture types, we will ensure there is a [format] attribute declared on the decl,
        // if not, we will infer the format from the texture type if it is not specified.
        //
        bool isInferred = false;
        auto format = inferImageFormatFromTextureType(varDecl, textureType, isInferred);
        if (format != ImageFormat::unknown && isInferred)
        {
            auto formatAttrib = m_astBuilder->create<FormatAttribute>();
            formatAttrib->format = format;
            addModifier(varDecl, formatAttrib);
        }
    }
    else
    {
        checkPushConstantBufferType(varDecl);
    }
}

bool isSpecializationConstant(VarDeclBase* varDecl)
{
    for (auto modifier : varDecl->modifiers)
    {
        if (as<SpecializationConstantAttribute>(modifier))
            return true;
        if (as<VkConstantIdAttribute>(modifier))
            return true;
    }
    return false;
}

void SemanticsDeclHeaderVisitor::checkPushConstantBufferType(VarDeclBase* varDecl)
{
    if (varDecl->findModifier<PushConstantAttribute>())
    {
        // If we see a ConstantBuffer<T, DefaultLayout> parameter marked as "push_constant", we need
        // to set its type to ConstantBuffer<T, Std430>.
        if (auto cbufferType = as<ConstantBufferType>(varDecl->type))
        {
            if (cbufferType->getLayoutType() == m_astBuilder->getDefaultLayoutType())
            {
                varDecl->type.type = getConstantBufferType(
                    cbufferType->getElementType(),
                    m_astBuilder->getDefaultPushConstantLayoutType());
            }
        }
        else if (isGlobalShaderParameter(varDecl))
        {
            // If this is a global variable with [vk::push_constant] attribute,
            // we need to make sure to wrap it in a `ConstantBuffer`.
            //
            varDecl->type.type = getConstantBufferType(
                varDecl->type,
                m_astBuilder->getDefaultPushConstantLayoutType());
        }
    }
}

void SemanticsDeclHeaderVisitor::deriveVarTypeFromInitExpr(VarDeclBase* varDecl)
{
    SemanticsContext contextToUse = withDeclToExcludeFromLookup(varDecl);

    auto initExpr = varDecl->initExpr;

    // If the parent function is differentiable, use withParentFunc to ensure
    // the differentiable context is preserved.
    // This ensures that calls in the initializer (like `dot`) get properly marked
    // with TreatAsDifferentiableExpr, which is needed for the IR lowering to add
    // the differentiableCallDecoration, also allows us to properly check the lambda
    // expressions nested in AST locations like: `let x = someFunc((int y)=>{...});
    // (checking of lambda exprs requires parentFunc to be available).
    auto parentFunc = getParentFunc(varDecl);
    if (parentFunc != m_parentFunc)
        contextToUse = contextToUse.withParentFunc(parentFunc);

    SemanticsVisitor subVisitor(contextToUse);
    initExpr = subVisitor.CheckExpr(initExpr);
    initExpr = maybeOpenRef(initExpr);

    // TODO: We might need some additional steps here to ensure
    // that the type of the expression is one we are okay with
    // inferring. E.g., if we ever decide that integer and floating-point
    // literals have a distinct type from the standard int/float types,
    // then we would need to "decay" a literal to an explicit type here.

    varDecl->initExpr = initExpr;
    varDecl->type.type = initExpr->type;

    varDecl->setCheckState(DeclCheckState::DefinitionChecked);
    _validateCircularVarDefinition(varDecl);
}

/// Return whether `type` meets the type requirements of the later post-link
/// `legalizeResourceGlobalVars` pass.
static bool _isResourceTypeSupportedForPerInvocationReplacement(Type* type)
{
    // We need the stored value to remain one IR value when `legalizeResourceGlobalVars` replaces
    // a mutable file- or namespace-scope resource variable with function-local storage and
    // additional parameters for non-entry-point functions. We therefore admit only types with
    // that representation on every target. Other semantic checks validate storage modifiers, and
    // the replacement pass diagnoses uses it cannot rewrite. The design comment at the top of
    // `slang-ir-legalize-resource-globals.cpp` explains the complete transformation.
    //
    // Semantic checking owns the language-level type restrictions. Every type accepted here must
    // lower to a type accepted by `isResourceValueOrArrayTypeSupportedForPerInvocationReplacement`
    // after the target's selected resource- and empty-type legalization passes. When changing
    // either predicate, we must check that relationship rather than compare AST and IR type names.

    // A type modifier does not change the representation that the replacement pass must carry.
    // We therefore look through each modifier before classifying the underlying type.
    for (;;)
    {
        if (auto modifiedType = as<ModifiedType>(type))
        {
            type = modifiedType->getBase();
            continue;
        }

        // A fixed-size array remains one IR value after linking and specialization resolve its
        // element count, so we continue with its element type. An unsized array has no element
        // count to resolve and cannot be allocated as a local.
        if (auto arrayType = as<ArrayExpressionType>(type))
        {
            if (arrayType->isUnsized())
                return false;
            type = arrayType->getElementType();
            continue;
        }

        break;
    }

    // By default we allow a `ResourceType` as a per-invocation variable because values of that
    // type remain one IR value when target-specific resource legalization runs. A combined
    // texture-sampler can instead be split into separate texture and sampler values, so we exclude
    // combined resources from a transformation that carries exactly one replacement value.
    if (auto resourceType = as<ResourceType>(type))
        return !resourceType->isCombined();

    // We allow a sampler state because target legalization also leaves it as one IR value.
    if (as<SamplerStateType>(type))
        return true;

    // We allow the listed structured buffers because each remains one IR value. We name the
    // variants individually because their common base class also includes append and consume
    // buffers, whose counter requires additional state that this transformation cannot carry.
    if (as<HLSLStructuredBufferType>(type))
        return true;
    if (as<HLSLRWStructuredBufferType>(type))
        return true;
    if (as<HLSLRasterizerOrderedStructuredBufferType>(type))
        return true;

    // We allow the listed byte-address buffers because each remains one IR value.
    if (as<HLSLByteAddressBufferType>(type))
        return true;
    if (as<HLSLRWByteAddressBufferType>(type))
        return true;
    if (as<HLSLRasterizerOrderedByteAddressBufferType>(type))
        return true;

    // Every remaining opaque type lacks an established representation for this transformation. An
    // append or consume buffer carries a counter in addition to its buffer data, and a struct or
    // parameter group may be legalized into several IR values. The pass cannot carry either shape
    // with one local and, in a helper, at most one parameter.
    //
    // Acceleration structures remain single values, but GLSL, SPIR-V, and WGSL do not permit those
    // values in function-local variables. On GLSL and SPIR-V, a `__DynamicResource` cast must
    // retain the identity of the module-scope parameter, or indexed element, that supplied its
    // value; assignment through a local could erase that identity. Because this front-end rule is
    // target-independent, we reject these types on every target as well.
    return false;
}

/// Return whether `decl` is a mutable `static` variable declared at file or namespace scope.
static bool _isMutableFileOrNamespaceScopeStaticVariable(VarDeclBase* decl)
{
    if (!isGlobalDecl(decl))
        return false;
    if (!decl->hasModifier<HLSLStaticModifier>())
        return false;
    return !decl->hasModifier<ConstModifier>();
}

/// Return whether `decl` requests storage or memory-access semantics that per-invocation resource
/// replacement cannot preserve.
static bool _hasStorageModifierUnsupportedForPerInvocationResourceReplacement(VarDeclBase* decl)
{
    // `groupshared` requires one value shared by a thread group. A memory qualifier such as
    // `globallycoherent` or `volatile` constrains accesses to the declared storage. Replacing
    // either declaration with ordinary function-local storage would discard the requested
    // semantics.
    if (decl->hasModifier<HLSLGroupSharedModifier>())
        return true;
    return decl->hasModifier<MemoryQualifierSetModifier>();
}

// Test whether `type` can use ordinary mutable variable storage or per-invocation resource
// replacement.
//
// This is the shared type restriction for ordinary `static` globals and uniform shadows.
// Requires `typeTags` to describe the checked `type`. A true result means either that ordinary
// mutable storage is supported or that resource-global legalization can replace the storage after
// linking. Shared IR validation checks the linked type before that replacement occurs.
static bool isTypeSupportedForMutableGlobalVariable(Type* type, TypeTag typeTags)
{
    // Opaque types need a separate representation rather than ordinary mutable storage. Resource
    // replacement provides that representation only for the resource values and fixed-size arrays
    // recognized by the semantic predicate.
    if ((int)typeTags & (int)TypeTag::Opaque)
        return _isResourceTypeSupportedForPerInvocationReplacement(type);

    // We cannot allocate a private variable containing an array with an absent or unbounded
    // element count. A count that will be resolved by linking is a separate, allowed case.
    if ((int)typeTags & (int)TypeTag::Unsized)
        return false;

    // Mutable global storage requires an addressable value that we can load and replace.
    // `ParameterBlock<T>` instead represents a binding container, so we cannot allocate
    // ordinary variable storage for it even when its elements have fixed sizes.
    if ((int)typeTags & (int)TypeTag::NonAddressable)
        return false;

    // No known storage restriction applies. We allow the general case, including types whose final
    // definition or array size will be supplied during linking. After linking and specialization,
    // `validateMutableGlobalVariableTypes` checks opaque and unsized storage.
    return true;
}

// Check the storage requirements of a mutable file- or namespace-scope `static` variable.
//
// Requires `typeTags` to describe `decl`'s checked type. Diagnoses an unsupported opaque or
// non-addressable type, and diagnoses a supported resource type when a storage or memory-access
// modifier prevents per-invocation replacement. The caller reports unsized storage first.
static void checkMutableGlobalVariableStorage(
    SemanticsVisitor* visitor,
    VarDeclBase* decl,
    TypeTag typeTags)
{
    // We answer three questions in order. First, is `decl` a mutable `static` variable at file or
    // namespace scope? Second, can its type use ordinary mutable storage or resource replacement?
    // Third, if replacement supports the resource value or fixed-size resource array, do the
    // declaration's modifiers require storage semantics that a function-local value cannot
    // preserve?
    if (!_isMutableFileOrNamespaceScopeStaticVariable(decl))
        return;

    // `checkVariableStorageRequirements` has already diagnosed an unsized variable. We stop before
    // applying the opaque-type policy so that an unbounded resource array produces one storage
    // diagnostic.
    if ((int)typeTags & (int)TypeTag::Unsized)
        return;

    if ((int)typeTags & (int)TypeTag::Opaque)
    {
        if (!_isResourceTypeSupportedForPerInvocationReplacement(decl->getType()))
        {
            // The type itself cannot be represented by resource replacement. We suggest a shader
            // parameter only when the declaration has no initializer and uses neither
            // `groupshared` nor a memory-access qualifier. A uniform parameter cannot provide the
            // semantics requested by either kind of modifier.
            visitor->getSink()->diagnose(Diagnostics::OpaqueTypeNotSupportedForMutableStatic{
                .type = decl->getType(),
                .decl = decl});
            if (!decl->initExpr)
            {
                if (!_hasStorageModifierUnsupportedForPerInvocationResourceReplacement(decl))
                    visitor->getSink()->diagnose(Diagnostics::DoYouMeanUniform{.decl = decl});
            }
            return;
        }

        // At this point the value has a supported resource representation. A storage or
        // memory-access modifier is therefore the only remaining front-end condition that can
        // prevent replacement.
        if (_hasStorageModifierUnsupportedForPerInvocationResourceReplacement(decl))
        {
            visitor->getSink()->diagnose(
                Diagnostics::MutableStaticResourceCannotUseSharedOrQualifiedStorage{.decl = decl});
        }
        return;
    }

    // A non-opaque type with no storage restriction uses ordinary mutable global storage.
    if (isTypeSupportedForMutableGlobalVariable(decl->getType(), typeTags))
        return;

    // We returned above for unsized and opaque types. Only a non-addressable value such as
    // `ParameterBlock<T>` can reach this point.
    SLANG_RELEASE_ASSERT((int)typeTags & (int)TypeTag::NonAddressable);
    visitor->getSink()->diagnose(Diagnostics::MutableGlobalRequiresAddressableType{.decl = decl});
}

// Test whether `decl` needs the sized-type check for independently stored variables.
static bool requiresSizedVariableType(VarDeclBase* decl)
{
    // Shader parameters and function parameters are supplied by the caller or application.
    // We exclude them from the unsized-variable diagnostic; their parameter checks own sizing.
    if (isGlobalShaderParameter(decl))
        return false;
    if (as<ParamDecl>(decl))
        return false;

    // A non-static field is stored as part of its aggregate. Its type can be unsized when
    // it is the final field. `SemanticsDeclBodyVisitor::checkVarDeclCommon` separately checks
    // its position within the aggregate, so we exclude instance fields from this diagnostic.
    if (as<AggTypeDecl>(getParentDecl(decl)))
        return isEffectivelyStatic(decl);

    return true;
}

// Apply the sized-type rule and mutable-global storage policy shared by header and body checking.
static void checkVariableStorageRequirements(
    SemanticsVisitor* visitor,
    VarDeclBase* decl,
    TypeTag typeTags)
{
    // Shader parameters receive their storage from the application, function parameters receive it
    // from the caller, and a non-static field is stored as part of its enclosing aggregate. Those
    // declarations have separate rules for unsized types.
    if (!requiresSizedVariableType(decl))
        return;

    // Every other variable must have a sized type. We report that general requirement
    // before applying the more specific policy for mutable file- or namespace-scope `static`
    // variables.
    if ((int)typeTags & (int)TypeTag::Unsized)
        visitor->getSink()->diagnose(Diagnostics::VarCannotBeUnsized{.decl = decl});

    checkMutableGlobalVariableStorage(visitor, decl, typeTags);
}

void SemanticsDeclHeaderVisitor::visitUniformParameterShadowVarDecl(
    UniformParameterShadowVarDecl* decl)
{
    // The parser introduces a shadow to implement assignments to a uniform shader parameter.
    // It records the associated parameter instead of a written type or initializer. We need
    // that parameter's checked type before we can choose the shadow's type and mutability.
    auto parameter = decl->uniformParameter;
    SLANG_RELEASE_ASSERT(parameter);
    ensureDecl(parameter, DeclCheckState::CanUseTypeOfValueDecl);

    // The type depends on the form of the parameter. For an ordinary file or namespace
    // parameter, we use exactly the parameter's type.
    Type* valueType = parameter->getType();

    // Consider `cbuffer CB { float x; }`. The parser desugars it to an implicit
    // `ConstantBuffer<T>`, where `T` is a struct containing `x`. We use `T` for the shadow
    // because assignments to the buffer's fields must update a copy of that struct.
    if (parameter->hasModifier<ImplicitParameterGroupVariableModifier>())
    {
        // The implicit-group modifier also occurs on legacy `tbuffer` declarations.
        // We only unwrap `ConstantBuffer<T>`; other parameter groups retain their own types.
        if (auto bufferType = as<ConstantBufferType>(valueType))
            valueType = bufferType->getElementType();
    }
    decl->type.type = valueType;

    // A mutable shadow must be able to represent both the parameter's value and the semantics of
    // its storage. We therefore use an immutable alias when either the value type cannot use
    // mutable global storage or the parameter has a memory qualifier. Aliasing a qualified
    // parameter keeps operations on the resource attached to the original declaration; copying
    // the resource value into ordinary storage would discard qualifiers such as
    // `globallycoherent`.
    decl->shouldBeImmutableAlias =
        !isTypeSupportedForMutableGlobalVariable(valueType, getTypeTags(valueType));
    if (_hasStorageModifierUnsupportedForPerInvocationResourceReplacement(parameter))
        decl->shouldBeImmutableAlias = true;

    // References to specialization constants must retain their identity as compile-time
    // constants, for example when used in `numthreads`. We alias these parameters even when
    // their value type would otherwise permit mutable storage.
    if (isSpecializationConstant(parameter))
        decl->shouldBeImmutableAlias = true;
}

void SemanticsDeclHeaderVisitor::checkVarDeclCommon(VarDeclBase* varDecl)
{
    // A variable that didn't have an explicit type written must
    // have its type inferred from the initial-value expression.
    //
    if (!varDecl->type.exp)
    {
        // In this case we need to perform all checking of the
        // variable (including semantic checking of the initial-value
        // expression) during the first phase of checking.

        auto initExpr = varDecl->initExpr;
        if (!initExpr)
        {
            if (!varDecl->type.type)
            {
                if (isGenericValueParam(varDecl))
                {
                    getSink()->diagnose(
                        Diagnostics::GenericValueParameterMustHaveType{.decl = varDecl});
                }
                else
                {
                    getSink()->diagnose(
                        Diagnostics::VarWithoutTypeMustHaveInitializer{.decl = varDecl});
                }
                varDecl->type.type = m_astBuilder->getErrorType();
            }
        }
        else
        {
            deriveVarTypeFromInitExpr(varDecl);
        }

        // If we've gone down this path, then the variable
        // declaration is actually pretty far along in checking
        varDecl->setCheckState(DeclCheckState::DefinitionChecked);
    }
    else
    {
        // A variable with an explicit type is simpler, for the
        // most part.
        SemanticsVisitor subVisitor(withDeclToExcludeFromLookup(varDecl));
        TypeExp typeExp = subVisitor.CheckUsableType(varDecl->type, varDecl);
        varDecl->type = typeExp;
        if (varDecl->type.equals(m_astBuilder->getVoidType()))
        {
            getSink()->diagnose(Diagnostics::InvalidTypeVoid{.location = varDecl->loc});
        }

        // Reject reference/parameter-passing-mode types as struct fields.
        // These types (Ref<T>, RefParam<T>, BorrowInParam<T>, etc.) represent
        // temporary borrows and cannot be stored in struct fields.
        if (as<AggTypeDecl>(varDecl->parentDecl))
        {
            auto type = varDecl->type.type;
            if (as<ExplicitRefType>(type) || as<ParamPassingModeType>(type))
            {
                getSink()->diagnose(Diagnostics::ReferenceTypeAsStructField{
                    .type = type,
                    .location = varDecl->loc});
            }
        }

        // If this is an unsized array variable, then we first want to give
        // it a chance to infer an array size from its initializer
        //
        // TODO(tfoley): May need to extend this to handle the
        // multi-dimensional case...
        //
        if (isUnsizedArrayType(varDecl->type))
        {
            if (auto initExpr = varDecl->initExpr)
            {
                initExpr = CheckTerm(initExpr);
                initExpr =
                    coerce(CoercionSite::Initializer, varDecl->type.Ptr(), initExpr, getSink());
                varDecl->initExpr = initExpr;

                maybeInferArraySizeForVariable(varDecl);

                varDecl->setCheckState(DeclCheckState::DefinitionChecked);
            }
        }
        //
        // Next we want to make sure that the declared (or inferred)
        // size for the array meets whatever language-specific
        // constraints we want to enforce (e.g., disallow empty
        // arrays in specific cases)
        //
        validateArraySizeForVariable(varDecl);
    }

    // If there is a matrix layout modifier or texture format modifier, we will modify the type now.
    maybeApplyLayoutModifier(varDecl);

    if (varDecl->initExpr)
    {
        if (as<BasicExpressionType>(varDecl->type.type))
        {
            auto parentDecl = getParentDecl(varDecl);
            if (varDecl->findModifier<ConstModifier>() &&
                (as<NamespaceDeclBase>(parentDecl) || as<FileDecl>(parentDecl) ||
                 varDecl->findModifier<HLSLStaticModifier>()))
            {
                varDecl->val =
                    tryConstantFoldExpr(varDecl->initExpr, ConstantFoldingKind::LinkTime, nullptr);
            }
        }
    }

    checkMeshOutputDecl(varDecl);

    // The NVAPI library allows user code to express extended operations
    // (not supported natively by D3D HLSL) by communicating with
    // a specially identified shader parameter called `g_NvidiaExt`.
    //
    // By default, that shader parameter would look like an ordinary
    // global shader parameter to Slang, but we want to be able to
    // associate special behavior with it to make downstream compilation
    // work nicely (especially in the case where certain cross-platform
    // operations in the Slang core module need to use NVAPI).
    //
    // We will detect a global variable declaration that appears to
    // be declaring `g_NvidiaExt` from NVAPI, and mark it with a special
    // modifier to allow downstream steps to detect it whether or
    // not it has an associated name.
    //
    if (as<ModuleDecl>(varDecl->parentDecl) && varDecl->getName() &&
        varDecl->getName()->text == "g_NvidiaExt")
    {
        addModifier(varDecl, m_astBuilder->create<NVAPIMagicModifier>());
    }
    //
    // One thing that the `NVAPIMagicModifier` is going to do is ensure
    // that `g_NvidiaExt` always gets emitted with *exactly* that name,
    // whether or not obfuscation or other steps are enabled.
    //
    // The `g_NvidiaExt` variable is declared as a:
    //
    //      RWStructuredBuffer<NvShaderExtnStruct>
    //
    // and we also want to make sure that the fields of that struct
    // retain their original names in output code. We will detect
    // variable declarations that represent fields of that struct
    // and flag them as "magic" as well.
    //
    // Note: The goal here is to make it so that generated HLSL output
    // can either use these declarations as they have been preocessed
    // by the Slang front-end *or* they can use declarations directly
    // from the NVAPI header during downstream compilation.
    //
    // TODO: It would be nice if we had a way to identify *all* of the
    // declarations that come from the NVAPI header and mark them, so
    // that the Slang front-end doesn't have to take responsibility
    // for generating code from them (and can instead rely on the downstream
    // compiler alone).
    //
    // The NVAPI header doesn't put any kind of macro-defined modifier
    // (defaulting to an empty macro) in front of its declarations,
    // so the most plausible way to add a modifier to all the declarations
    // would be to tag the `nvHLSLExtns.h` header in a list of "magic"
    // headers which should get all their declarations flagged during
    // front-end processing, and then use the same header again during
    // downstream compilation.
    //
    // For now, the current hackery seems a bit less complicated.
    //
    if (auto structDecl = as<StructDecl>(varDecl->parentDecl))
    {
        if (structDecl->getName() && structDecl->getName()->text == "NvShaderExtnStruct")
        {
            addModifier(varDecl, m_astBuilder->create<NVAPIMagicModifier>());
        }
    }

    if (const auto interfaceDecl = as<InterfaceDecl>(varDecl->parentDecl); interfaceDecl)
    {
        if (auto basicType = as<BasicExpressionType>(varDecl->getType()))
        {
            switch (basicType->getBaseType())
            {
            case BaseType::Bool:
            case BaseType::Int8:
            case BaseType::Int16:
            case BaseType::Int:
            case BaseType::Int64:
            case BaseType::IntPtr:
            case BaseType::UInt8:
            case BaseType::UInt16:
            case BaseType::UInt:
            case BaseType::UInt64:
            case BaseType::UIntPtr:
                break;
            default:
                getSink()->diagnose(
                    Diagnostics::StaticConstRequirementMustBeIntOrBool{.decl = varDecl});
                break;
            }
        }
        if (!varDecl->findModifier<HLSLStaticModifier>() || !varDecl->findModifier<ConstModifier>())
        {
            getSink()->diagnose(
                Diagnostics::ValueRequirementMustBeCompileTimeConst{.decl = varDecl});
        }
    }

    // Check modifiers that can't be checked earlier during modifier checking stage.
    if (auto derivativeMemberAttr = varDecl->findModifier<DerivativeMemberAttribute>())
    {
        checkDerivativeMemberAttributeParent(varDecl, derivativeMemberAttr);
    }
    if (auto extensionExternAttr = varDecl->findModifier<ExtensionExternVarModifier>())
    {
        checkExtensionExternVarAttribute(varDecl, extensionExternAttr);
    }

    // If a var decl has no_diff type, move the no_diff modifier from the type to the var.
    if (auto modifiedType = as<ModifiedType>(varDecl->type.type))
    {
        if (auto nodiffModifier = modifiedType->findModifier<NoDiffModifierVal>())
        {
            varDecl->type.type = getRemovedModifierType(modifiedType, nodiffModifier);
            auto noDiffModifier = m_astBuilder->create<NoDiffModifier>();
            noDiffModifier->loc = varDecl->loc;
            addModifier(varDecl, noDiffModifier);
        }
    }

    if (as<NamespaceDeclBase>(varDecl->parentDecl))
    {
        if (getShared()->isGLSLSourceLanguage())
        {
            // If we are in GLSL compatiblity mode, we want to treat all global variables
            // without any `uniform` modifiers as true global variables by default.
            if (!varDecl->findModifier<HLSLUniformModifier>() &&
                !varDecl->findModifier<InModifier>() && !varDecl->findModifier<OutModifier>() &&
                !varDecl->findModifier<GLSLBufferModifier>() && !isSpecializationConstant(varDecl))
            {
                if (!isUniformParameterType(varDecl->type))
                {
                    auto staticModifier = m_astBuilder->create<HLSLStaticModifier>();
                    addModifier(varDecl, staticModifier);
                }
            }
        }
    }

    if (getOptionSet().getBoolOption(CompilerOptionName::NoMangle) && isGlobalDecl(varDecl))
    {
        // If -no-mangle option is set, we will add `ExternCpp` modifier to all
        // global variables and struct fields to prevent mangling.
        addModifier(varDecl, m_astBuilder->create<ExternCppModifier>());
    }

    // Not allowed a `globallycoherent T*` or related
    if (as<PtrType>(varDecl->type))
        if (auto memoryQualifierSet = varDecl->findModifier<MemoryQualifierSetModifier>())
            if (memoryQualifierSet->getMemoryQualifierBit() &
                MemoryQualifierSetModifier::Flags::kCoherent)
                getSink()->diagnose(Diagnostics::CoherentKeywordOnAPointer{.decl = varDecl});

    // Check for static const variables without initializers
    if (!varDecl->initExpr)
    {
        bool isStatic = false;
        bool isConst = false;
        bool isExtern = false;
        for (auto modifier : varDecl->modifiers)
        {
            if (as<HLSLStaticModifier>(modifier))
                isStatic = true;
            else if (as<ConstModifier>(modifier))
                isConst = true;
            else if (as<ExternModifier>(modifier))
                isExtern = true;

            if (isStatic && isConst && isExtern)
                break;
        }
        if (isStatic && isConst &&
            // Don't error for extern variables
            // Don't error for interface member variables
            !isExtern && !as<InterfaceDecl>(varDecl->parentDecl))
        {
            getSink()->diagnose(
                Diagnostics::StaticConstVariableRequiresInitializer{.decl = varDecl});
        }
    }

    checkVisibility(varDecl);

    // We finish ordinary `VarDecl` signatures here. Generic value-parameter visitors may
    // still change their declarations' types after this common routine returns.
    if (as<VarDecl>(varDecl))
    {
        // Array-element validation calls `getTypeTags`, which may encounter `varDecl` again
        // through a recursive struct. The type, array bound, and modifiers of `varDecl` are
        // now determined, so we publish its signature before validating the element type.
        if (!varDecl->isChecked(DeclCheckState::SignatureChecked))
            varDecl->setCheckState(DeclCheckState::SignatureChecked);
    }

    // Header checking advances declarations with inferred types or array bounds to
    // `DefinitionChecked`, so `SemanticsDeclBodyVisitor` will not run for them. We therefore
    // validate their array element type now that the header has finished adjusting the type.
    // Declarations that remain at `SignatureChecked` receive that check from the body visitor.
    if (varDecl->isChecked(DeclCheckState::DefinitionChecked))
    {
        validateArrayElementTypeForVariable(varDecl);

        // We require inferred mutable globals to meet the same storage policy as explicitly typed
        // globals. We do not apply that policy to inferred locals: `int copy[] = parameter;` is
        // valid when `parameter` is an unsized array parameter. The caller supplies the array's
        // length rather than the local declaration.
        if (_isMutableFileOrNamespaceScopeStaticVariable(varDecl))
            checkVariableStorageRequirements(this, varDecl, getTypeTags(varDecl->getType()));
    }
}

static void addAutoDiffModifiersToFunc(
    SemanticsDeclVisitorBase* visitor,
    ASTBuilder* m_astBuilder,
    FunctionDeclBase* func)
{
    if (visitor->isTypeDifferentiable(func->returnType.type))
    {
        addModifier(func, m_astBuilder->create<BackwardDifferentiableAttribute>());
        addModifier(func, m_astBuilder->create<ForwardDifferentiableAttribute>());
    }
}

ConstructorDecl* SemanticsDeclVisitorBase::createCtor(
    AggTypeDecl* decl,
    DeclVisibility ctorVisibility)
{
    auto ctor = m_astBuilder->create<ConstructorDecl>();
    addModifier(ctor, m_astBuilder->create<SynthesizedModifier>());
    auto ctorName = getName("$init");
    ctor->ownedScope = m_astBuilder->create<Scope>();
    ctor->ownedScope->containerDecl = ctor;
    ctor->ownedScope->parent = getScope(decl);
    ctor->parentDecl = decl;
    ctor->loc = decl->loc;
    ctor->closingSourceLoc = ctor->loc;
    ctor->nameAndLoc.name = ctorName;
    ctor->nameAndLoc.loc = ctor->loc;
    ctor->returnType.type = calcThisType(makeDeclRef(decl));
    auto body = m_astBuilder->create<BlockStmt>();
    body->scopeDecl = m_astBuilder->create<ScopeDecl>();
    body->scopeDecl->ownedScope = m_astBuilder->create<Scope>();
    body->scopeDecl->ownedScope->parent = getScope(ctor);
    body->scopeDecl->parentDecl = ctor;
    body->scopeDecl->loc = ctor->loc;
    body->scopeDecl->closingSourceLoc = ctor->loc;
    body->closingSourceLoc = ctor->closingSourceLoc;
    ctor->body = body;
    body->body = m_astBuilder->create<SeqStmt>();
    ctor->addFlavor(ConstructorDecl::ConstructorFlavor::SynthesizedDefault);
    decl->addMember(ctor);
    addAutoDiffModifiersToFunc(this, m_astBuilder, ctor);
    addVisibilityModifier(ctor, ctorVisibility);
    return ctor;
}

static inline bool _isDefaultCtor(ConstructorDecl* ctor)
{
    auto allParamHaveInitExpr = [](ConstructorDecl* ctor)
    {
        for (auto i : ctor->getParameters())
            if (!i->initExpr)
                return false;
        return true;
    };

    // 1. default ctor must have no parameters
    // 2. default ctor can have parameters, but all parameters have init expr (Because we won't
    // differentiate this case from 2.)
    if (ctor->getDirectMemberDeclCount() == 0 || allParamHaveInitExpr(ctor))
    {
        return true;
    }

    return false;
}

static ConstructorDecl* _getDefaultCtor(StructDecl* structDecl)
{
    for (auto ctor : structDecl->getMembersOfType<ConstructorDecl>())
    {
        if (_isDefaultCtor(ctor))
            return ctor;
    }
    return nullptr;
}


static List<ConstructorDecl*> _getCtorList(
    ASTBuilder* m_astBuilder,
    SemanticsVisitor* visitor,
    StructDecl* structDecl,
    ConstructorDecl** defaultCtorOut)
{
    List<ConstructorDecl*> ctorList;

    auto ctorLookupResult = lookUpMember(
        m_astBuilder,
        visitor,
        visitor->getName("$init"),
        DeclRefType::create(m_astBuilder, structDecl),
        structDecl->ownedScope,
        LookupMask::Function,
        (LookupOptions)((Index)LookupOptions::IgnoreInheritance | (Index)LookupOptions::NoDeref));

    if (!ctorLookupResult.isValid())
        return ctorList;

    auto lookupResultHandle = [&](LookupResultItem& item)
    {
        auto ctor = as<ConstructorDecl>(item.declRef.getDecl());
        if (!ctor || !ctor->body)
            return;
        ctorList.add(ctor);
        if (_isDefaultCtor(ctor))
            *defaultCtorOut = ctor;
    };
    if (ctorLookupResult.items.getCount() == 0)
    {
        lookupResultHandle(ctorLookupResult.item);
        return ctorList;
    }

    for (auto m : ctorLookupResult.items)
    {
        lookupResultHandle(m);
    }

    return ctorList;
}

void SemanticsDeclHeaderVisitor::visitStructDecl(StructDecl* structDecl)
{
    // As described above in `SemanticsDeclHeaderVisitor::checkVarDeclCommon`,
    // we want to identify and tag the "magic" declarations that make NVAPI
    // work, so that downstream passes can identify them and act accordingly.
    //
    // In this case, we are looking for the `NvShaderExtnStruct` type, which
    // is used by `g_NvidiaExt`.
    //
    if (structDecl->getName() && structDecl->getName()->text == "NvShaderExtnStruct")
    {
        addModifier(structDecl, m_astBuilder->create<NVAPIMagicModifier>());
    }

    if (structDecl->hasModifier<ExternModifier>())
    {
        structDecl->addTag(TypeTag::Incomplete);
    }

    // Slang supports a convenient syntax to create a link-time aliased type from
    // an existing type that implements a given interface. For example,
    // the user can write: struct FooWrapper:IFoo = Foo;
    // In this case we need to check the aliasedType expr.
    if (structDecl->aliasedType.exp)
    {
        SemanticsVisitor visitor(withDeclToExcludeFromLookup(structDecl));
        structDecl->aliasedType = visitor.CheckProperType(structDecl->aliasedType);
    }

    checkVisibility(structDecl);
}

void SemanticsDeclHeaderVisitor::visitClassDecl(ClassDecl* classDecl)
{
    if (classDecl->hasModifier<ExternModifier>())
    {
        classDecl->addTag(TypeTag::Incomplete);
    }
    checkVisibility(classDecl);
}

bool DiagnoseIsAllowedInitExpr(VarDeclBase* varDecl, DiagnosticSink* sink)
{
    // find groupshared modifier
    if (varDecl->findModifier<HLSLGroupSharedModifier>())
    {
        if (sink && varDecl->initExpr)
            sink->diagnose(
                Diagnostics::CannotHaveInitializer{.reason = "groupshared", .decl = varDecl});
        return false;
    }

    if (as<InterfaceDecl>(varDecl->parentDecl))
    {
        if (sink && varDecl->initExpr)
            sink->diagnose(Diagnostics::CannotHaveInitializer{
                .reason = "an interface requirement",
                .decl = varDecl});
        return false;
    }

    return true;
}

bool isDefaultInitializable(VarDeclBase* varDecl)
{
    if (!DiagnoseIsAllowedInitExpr(varDecl, nullptr))
        return false;

    // Find struct and modifiers associated with varDecl
    StructDecl* structDecl = as<StructDecl>(varDecl);
    if (auto declRefType = as<DeclRefType>(varDecl->getType()))
    {
        if (auto genericAppRefDecl = as<GenericAppDeclRef>(declRefType->getDeclRefBase()))
        {
            auto baseGenericRefType = genericAppRefDecl->getBase()->getDecl();
            if (auto baseTypeStruct = as<StructDecl>(baseGenericRefType))
            {
                structDecl = baseTypeStruct;
            }
            else if (auto genericDecl = as<GenericDecl>(baseGenericRefType))
            {
                if (auto innerTypeStruct = as<StructDecl>(genericDecl->inner))
                    structDecl = innerTypeStruct;
            }
        }
    }
    if (structDecl)
    {
        // find if a type is non-copyable
        if (structDecl->findModifier<NonCopyableTypeAttribute>())
            return false;
    }

    return true;
}

static Expr* constructDefaultConstructorForType(
    SemanticsVisitor* visitor,
    Type* type,
    SourceLoc loc)
{
    if (visitor->getDefaultCtorRecursionDepth() >= kMaxTypeNestingDepth)
    {
        if (visitor->getSink())
        {
            Diagnostics::MaximumTypeNestingLevelExceeded diag = {};
            diag.location = loc;
            visitor->getSink()->diagnose(diag);
        }
        return nullptr;
    }

    visitor->pushDefaultCtorRecursionDepth();
    SLANG_DEFER(visitor->popDefaultCtorRecursionDepth());

    ConstructorDecl* defaultCtor = nullptr;
    auto declRefType = as<DeclRefType>(type);
    if (declRefType)
    {
        if (auto structDecl = as<StructDecl>(declRefType->getDeclRef().getDecl()))
        {
            if (!structDecl->checkState.isBeingChecked())
                visitor->ensureDecl(structDecl, DeclCheckState::AttributesChecked);
            defaultCtor = _getDefaultCtor(structDecl);
        }
    }
    if (defaultCtor)
    {
        auto* invoke = visitor->getASTBuilder()->create<InvokeExpr>();
        auto member =
            visitor->getASTBuilder()->getMemberDeclRef(declRefType->getDeclRef(), defaultCtor);
        invoke->functionExpr = visitor->ConstructDeclRefExpr(
            member,
            nullptr,
            defaultCtor->getName(),
            defaultCtor->loc,
            nullptr);
        return invoke;
    }

    // At the last, we will check if the type is a C-style type, if it is, we will use empty
    // initializer list to construct the default constructor.
    HashSet<Type*> visitSet;
    if (visitor->isCStyleType(type, visitSet))
    {
        auto initListExpr = visitor->getASTBuilder()->create<InitializerListExpr>();
        initListExpr->loc = loc;
        initListExpr->type = visitor->getASTBuilder()->getInitializerListType();
        Expr* outExpr = nullptr;
        auto fromType = type;
        if (auto atomicType = as<AtomicType>(fromType))
        {
            fromType = atomicType->getElementType();
        }
        if (visitor->_coerceInitializerList(fromType, &outExpr, initListExpr))
            return outExpr;
    }

    return nullptr;
}

static Expr* constructDefaultInitExprForType(SemanticsVisitor* visitor, VarDeclBase* varDecl)
{
    if (!varDecl->type || !varDecl->type.type)
        return nullptr;

    if (!isDefaultInitializable(varDecl))
        return nullptr;

    if (auto defaultInitExpr = constructDefaultConstructorForType(
            visitor,
            varDecl->type.type,
            getDiagnosticPos(varDecl->type)))
    {
        return defaultInitExpr;
    }
    else
    {
        auto* defaultCall = visitor->getASTBuilder()->create<DefaultConstructExpr>();
        defaultCall->type = QualType(varDecl->type);
        return defaultCall;
    }
}

static Decl* findLegacyBwdDiffFunc(SemanticsVisitor* visitor, ExtensionDecl* extensionDecl)
{
    // Go through the extension's members and look for a function with the
    // "bwd_diff" name. Note: we won't use a lookup, since that could trigger the
    // synthesis again & lead to a cyclic invocation.
    //
    auto bwdDiffFuncName = visitor->getName("bwd_diff");
    Decl* foundLegacyBwdDiffFunc = nullptr;
    for (auto member : extensionDecl->getDirectMemberDecls())
    {
        if (auto funcDeclBase = as<FunctionDeclBase>(member))
        {
            if (funcDeclBase->nameAndLoc.name == bwdDiffFuncName)
            {
                if (as<FuncDecl>(funcDeclBase) || as<ConstructorDecl>(funcDeclBase))
                    foundLegacyBwdDiffFunc = funcDeclBase;
                else if (
                    as<SynthesizedFuncDecl>(funcDeclBase) &&
                    as<SynthesizedFuncDecl>(funcDeclBase)->irOp == kIROp_FunctionCopy)
                {
                    foundLegacyBwdDiffFunc = funcDeclBase;
                }
            }
        }
    }

    return foundLegacyBwdDiffFunc;
}

void validateStructuredBufferElementType(SemanticsVisitor* visitor, VarDeclBase* varDecl);

/// Returns true if `expr` is a runtime value that cannot be a compile-time constant.
/// This is called only after constant folding has already failed (`varDecl->val` is null),
/// so any surviving function call is known to be non-const-evaluable — if it were a
/// constant-foldable intrinsic applied to constant arguments, folding would have succeeded.
/// Used to distinguish "folding failed because of a runtime reference or call" from
/// "folding failed because the folder doesn't handle this form" (e.g. unsupported literal type).
static bool _initExprIsRuntimeValue(Expr* expr)
{
    if (!expr)
        return false;
    if (as<ErrorType>(expr->type.type))
        return false;
    if (auto memberExpr = as<MemberExpr>(expr))
        return _initExprIsRuntimeValue(memberExpr->baseExpression);
    if (auto derefExpr = as<DerefExpr>(expr))
        return _initExprIsRuntimeValue(derefExpr->base);
    if (auto builtinCastExpr = as<BuiltinCastExpr>(expr))
        return _initExprIsRuntimeValue(builtinCastExpr->base);
    if (auto swizzleExpr = as<SwizzleExpr>(expr))
        return _initExprIsRuntimeValue(swizzleExpr->base);
    if (auto matSwizzleExpr = as<MatrixSwizzleExpr>(expr))
        return _initExprIsRuntimeValue(matSwizzleExpr->base);
    if (auto indexExpr = as<IndexExpr>(expr))
    {
        if (_initExprIsRuntimeValue(indexExpr->baseExpression))
            return true;
        for (auto idx : indexExpr->indexExprs)
            if (_initExprIsRuntimeValue(idx))
                return true;
        return false;
    }
    if (auto declRefExpr = as<DeclRefExpr>(expr))
    {
        if (auto varDecl = as<VarDeclBase>(declRefExpr->declRef.getDecl()))
        {
            // References to static const globals are fine — compile-time constants.
            if (varDecl->hasModifier<HLSLStaticModifier>() && varDecl->hasModifier<ConstModifier>())
                return false;
            // Any other global variable (including plain `static float foo`) is mutable.
            if (isGlobalDecl(varDecl))
                return true;
        }
        return false;
    }
    if (auto builtinOpExpr = as<BuiltinOperatorExpr>(expr))
    {
        // A builtin-operator fast-path node is a pure builtin operation: it is a runtime
        // value only when one of its operands is.
        for (auto arg : builtinOpExpr->arguments)
            if (_initExprIsRuntimeValue(arg))
                return true;
        return false;
    }
    if (auto invokeExpr = as<InvokeExpr>(expr))
    {

        // Determine whether the callee is a "pure" callable whose result depends only
        // on its arguments and cannot read or write arbitrary runtime state. For pure
        // callables, the call is a runtime value only when one of its arguments is.
        // User-defined functions without an explicit purity annotation are treated
        // conservatively as runtime values (they could read buffers, globals, etc.).
        //
        // We check for purity explicitly rather than relying on constant-folding failure
        // because the AST constant folder does not handle all pure forms (e.g. min(1,2)).
        // IR-level folding will handle them; we only need to block user-defined calls.
        bool isPure = false;
        if (auto calleeDeclRef = as<DeclRefExpr>(invokeExpr->functionExpr))
        {
            if (auto callable = as<CallableDecl>(calleeDeclRef->declRef.getDecl()))
            {
                // Constructor calls (e.g. float2(x, y), MyStruct(val)) are always pure:
                // their result depends only on their arguments.
                if (as<ConstructorDecl>(callable))
                    isPure = true;
                // Builtin IR operations (e.g. integer arithmetic, vector ops).
                else if (callable->findModifier<IntrinsicOpModifier>())
                    isPure = true;
                // Target-specific intrinsics (__intrinsic_asm) are also pure.
                else if (callable->findModifier<TargetIntrinsicModifier>())
                    isPure = true;
                // Functions explicitly declared [__readNone] (e.g. min, max).
                else if (callable->findModifier<ReadNoneAttribute>())
                    isPure = true;
            }
        }
        if (isPure)
        {
            // Pure callable: runtime only when an argument is runtime.
            for (auto arg : invokeExpr->arguments)
                if (_initExprIsRuntimeValue(arg))
                    return true;
            return false;
        }
        // User-defined or unrecognized function call — always a runtime value.
        return true;
    }
    if (auto parenExpr = as<ParenExpr>(expr))
        return _initExprIsRuntimeValue(parenExpr->base);
    if (auto initListExpr = as<InitializerListExpr>(expr))
    {
        for (auto arg : initListExpr->args)
            if (_initExprIsRuntimeValue(arg))
                return true;
        return false;
    }
    return false;
}

void SemanticsDeclBodyVisitor::checkVarDeclCommon(VarDeclBase* varDecl)
{
    DiagnoseIsAllowedInitExpr(varDecl, getSink());

    // Check for arrays of non-addressable types
    validateArrayElementTypeForVariable(varDecl);

    // if zero initialize is true, set everything to a default
    if (getOptionSet().hasOption(CompilerOptionName::ZeroInitialize) && !varDecl->initExpr &&
        as<VarDecl>(varDecl))
    {
        varDecl->initExpr = constructDefaultInitExprForType(this, varDecl);
    }

    if (auto initExpr = varDecl->initExpr)
    {
        // Disable the short-circuiting for static const variable init expression
        bool isStaticConst =
            varDecl->hasModifier<HLSLStaticModifier>() && varDecl->hasModifier<ConstModifier>();

        auto subVisitor =
            isStaticConst ? SemanticsVisitor(disableShortCircuitLogicalExpr()) : *this;
        // If the variable has an explicit initial-value expression,
        // then we simply need to check that expression and coerce
        // it to the type of the variable.
        //
        // Capture the error count before checking the initializer so that errors from
        // CheckTerm or coerce (e.g. undefined identifier) suppress downstream diagnostics.
        auto errorCountBeforeInitCheck = getSink()->getErrorCount();
        initExpr = subVisitor.CheckTerm(initExpr);

        if (initExpr->type.isWriteOnly)
            getSink()->diagnose(Diagnostics::ReadingFromWriteOnly{.expr = initExpr});

        initExpr = coerce(CoercionSite::Initializer, varDecl->type.Ptr(), initExpr, getSink());
        varDecl->initExpr = initExpr;

        // We need to ensure that any variable doesn't introduce
        // a constant with a circular definition.
        //
        varDecl->setCheckState(DeclCheckState::DefinitionChecked);

        // Update constant value
        //
        if (!varDecl->val)
        {
            varDecl->val = _validateCircularVarDefinition(varDecl);
            // If this is a global `static const` variable and we still couldn't constant-fold
            // its initializer (and no new error was emitted during init checking, e.g. for an
            // undefined identifier, a circular definition, or a type error), check whether the
            // initializer is a runtime value (mutable global reference or function call). If so,
            // diagnose now rather than crashing or silently misbehaving in IR code generation.
            // Note: for non-integer types, _validateCircularVarDefinition always returns nullptr,
            // so !varDecl->val is expected for non-constant expressions; _initExprIsRuntimeValue
            // distinguishes the problematic cases from forms the constant folder simply doesn't
            // handle (e.g. unsupported literal types).
            if (isStaticConst && isGlobalDecl(varDecl) && !varDecl->val &&
                getSink()->getErrorCount() == errorCountBeforeInitCheck &&
                _initExprIsRuntimeValue(initExpr))
            {
                getSink()->diagnose(Diagnostics::StaticConstGlobalNonConstantInit{.decl = varDecl});
            }
        }
    }
    else
    {
        // If a variable doesn't have an explicit initial-value
        // expression, it is still possible that it should
        // be initialized implicitly, because the type of the
        // variable has a default (zero parameter) initializer.
        // That is, for types where it is possible, we will
        // treat a variable declared like this:
        //
        //      MyType myVar;
        //
        // as if it were declared as:
        //
        //      MyType myVar = MyType();
        //
        // Rather than try to code up an ad hoc search for an
        // appropriate initializer here, we will instead fall
        // back on the general-purpose overload-resolution
        // machinery, which can handle looking up initializers
        // and filtering them to ones that are applicable
        // to our "call site" with zero arguments.
        //
        OverloadResolveContext overloadContext;
        overloadContext.loc = varDecl->nameAndLoc.loc;
        overloadContext.mode = OverloadResolveContext::Mode::JustTrying;
        overloadContext.sourceScope = m_outerScope;

        // Overload resolution can give us a valid expression with >0 arguments when the type has
        // parameter pack arguments. This is primarily relevant for Tuple<>
        List<Expr*> argExprs;
        overloadContext.args = &argExprs;

        auto type = varDecl->getType();
        ImplicitCastMethodKey key = ImplicitCastMethodKey(QualType(), type, nullptr);
        auto ctorMethod = getShared()->tryGetImplicitCastMethod(key);
        if (ctorMethod)
        {
            overloadContext.bestCandidateStorage = ctorMethod->conversionFuncOverloadCandidate;
            overloadContext.bestCandidate = &overloadContext.bestCandidateStorage;
        }
        else
        {
            AddTypeOverloadCandidates(type, overloadContext);
        }

        if (overloadContext.bestCandidates.getCount() != 0)
        {
            // If there were multiple equally-good candidates to call,
            // then might have an ambiguity.
            //
            // Before issuing any kind of diagnostic we need to check
            // if any of those candidates are actually applicable,
            // because if they aren't then we actually just have
            // an uninitialized varaible.
            //
            if (overloadContext.bestCandidates[0].status != OverloadCandidate::Status::Applicable)
            {
                getShared()->cacheImplicitCastMethod(key, ImplicitCastMethod{});
            }
            else
            {
                getSink()->diagnose(
                    Diagnostics::AmbiguousDefaultInitializerForType{.type = type, .decl = varDecl});
            }
        }
        else if (overloadContext.bestCandidate)
        {
            // If we are in the single-candidate case, then we again
            // want to ignore the case where that candidate wasn't
            // actually applicable, because declaring a variable
            // of a type that *doesn't* have a default initializer
            // isn't actually an error.
            //
            if (overloadContext.bestCandidate->status != OverloadCandidate::Status::Applicable)
            {
                getShared()->cacheImplicitCastMethod(key, ImplicitCastMethod{});
            }
            else
            {
                // If we had a single best candidate *and* it was applicable,
                // then we use it to construct a new initial-value expression
                // for the variable, that will be used for all downstream
                // code generation.
                //
                auto constructorDecl =
                    as<ConstructorDecl>(overloadContext.bestCandidate->item.declRef).getDecl();
                // We don't allow implicit initialization of struct only have synthesized default
                // ctor.
                if ((constructorDecl &&
                     !constructorDecl->containsFlavor(
                         ConstructorDecl::ConstructorFlavor::SynthesizedDefault)) ||
                    !constructorDecl)
                {
                    varDecl->initExpr =
                        CompleteOverloadCandidate(overloadContext, *overloadContext.bestCandidate);
                    getShared()->cacheImplicitCastMethod(
                        key,
                        ImplicitCastMethod{*overloadContext.bestCandidate, 0});
                }
            }
        }
    }

    TypeTag varTypeTags = getTypeTags(varDecl->getType());

    auto parentDecl = as<AggTypeDecl>(getParentDecl(varDecl));
    if (parentDecl)
    {
        parentDecl->addTag(varTypeTags);
        auto unsizedMask = (int)TypeTag::Unsized;
        bool isUnknownSize = (((int)varTypeTags & unsizedMask) != 0);
        if (isUnknownSize)
        {
            // If an unsized variable declaration appears as a member of
            // an aggregate type (such as a `struct`), then it must be
            // the *last* non-`static` variable declaration in that type.
            //
            // We validate that here by iterating over the members in
            // reverse order, until we either run into the unsized variable
            // declaration in question (in which case things are fine),
            // or we encounter some *other* non-`static` variable declaration,
            // in which case the unsized declaration is invalid.
            //
            for (auto memberIdx = parentDecl->getDirectMemberDeclCount() - 1; memberIdx >= 0;
                 memberIdx--)
            {
                auto memberDecl = parentDecl->getDirectMemberDecl(memberIdx);

                // If we run into the unsized variable declaration before
                // hitting anything else, the declaration is in a valid
                // location.
                //
                if (memberDecl == varDecl)
                    break;

                // If we run into another declaration, but it isn't a
                // variable, then it doesn't impact validity.
                //
                auto memberVarDecl = as<VarDeclBase>(memberDecl);
                if (!memberVarDecl)
                    continue;

                // If we run into another variable declaration, but
                // it is a `static` variable, then it doesn't
                // impact the validity of the unsized declaration.
                //
                if (memberVarDecl->hasModifier<HLSLStaticModifier>())
                    continue;

                // At this point we've run into a non-`static` variable declaration
                // that comes *after* the unsized variable declaration, which
                // means the unsized variable declaration is invalid.
                //
                getSink()->diagnose(Diagnostics::UnsizedMemberMustAppearLast{.decl = varDecl});
                break;
            }
        }
    }

    validateStructuredBufferElementType(this, varDecl);

    // Declarations that reach body checking have not yet received the storage checks that the
    // header applies to declarations completed during type or array-bound inference.
    checkVariableStorageRequirements(this, varDecl, varTypeTags);

    if (auto elementType = getConstantBufferElementType(varDecl->getType()))
    {
        if (doesTypeHaveTag(elementType, TypeTag::Unsized))
        {
            // If the element type is unsized, it can only be an array of resource types that we can
            // legalize out. Ordinary unsized arrays are not allowed in a constant buffer since we
            // cannot translate it to valid HLSL or SPIRV.
            ArrayExpressionType* trailingArrayType = nullptr;
            VarDeclBase* trailingArrayField =
                getTrailingUnsizedArrayElement(elementType, varDecl, trailingArrayType);
            if (trailingArrayField && !isOpaqueHandleType(trailingArrayType->getElementType()))
            {
                getSink()->diagnose(Diagnostics::CannotUseUnsizedTypeInConstantBuffer{
                    .type = trailingArrayType,
                    .field = trailingArrayField});
                getSink()->diagnose(
                    Diagnostics::SeeConstantBufferDefinition{.location = varDecl->loc});
            }
        }
    }
    maybeRegisterDifferentiableType(getASTBuilder(), varDecl->getType());
}

// Fill in default substitutions for the 'subtype' part of a type constraint decl
void SemanticsVisitor::CheckConstraintSubType(TypeExp& typeExp)
{
    if (auto sharedTypeExpr = as<SharedTypeExpr>(typeExp.exp))
    {
        if (auto declRefType = as<DeclRefType>(sharedTypeExpr->base))
        {
            auto newDeclRef =
                createDefaultSubstitutionsIfNeeded(m_astBuilder, this, declRefType->getDeclRef());
            auto newType = DeclRefType::create(m_astBuilder, newDeclRef);
            sharedTypeExpr->base.type = newType;
            if (as<TypeType>(typeExp.exp->type))
                typeExp.exp->type = m_astBuilder->getTypeType(newType);
        }
    }
}

void SemanticsVisitor::addVisibilityModifier(Decl* decl, DeclVisibility vis)
{
    switch (vis)
    {
    case DeclVisibility::Public:
        addModifier(decl, m_astBuilder->create<PublicModifier>());
        break;
    case DeclVisibility::Internal:
        addModifier(decl, m_astBuilder->create<InternalModifier>());
        break;
    case DeclVisibility::Private:
        addModifier(decl, m_astBuilder->create<PrivateModifier>());
        break;
    default:
        break;
    }
}

bool SemanticsVisitor::trySynthesizeDiffContextTypeRequirementWitness(
    ConformanceCheckingContext* context,
    DeclRef<AssocTypeDecl> requirementDeclRef,
    RefPtr<WitnessTable> witnessTable,
    BuiltinRequirementKind requirementKind)
{
    // Can't synthesize for non-callable base types.
    if (!isDeclRefTypeOf<FunctionDeclBase>(context->conformingType))
        return false;

    auto targetFuncDeclRef =
        as<DeclRefType>(context->conformingType)->getDeclRef().as<FunctionDeclBase>();
    auto synthesizedLoc = getDiagnosticPos(requirementDeclRef.getDecl());

    // We currently support this type of synthesis only for extensions.
    SLANG_ASSERT(as<ExtensionDecl>(context->parentDecl));

    if (requirementKind == BuiltinRequirementKind::MinimalContextType)
    {
        // For MinimalContextType, synthesize a simple struct without any conformances.
        // Initially this will hold the same data as BwdCallable; the backward diff translation
        // pass will later determine exactly what goes in the minimal context.
        auto synStructDecl = getCurrentASTBuilder()->create<SynthesizedStructDecl>();
        synStructDecl->irOp = kIROp_BackwardDiffMinimalContextType;
        synStructDecl->loc = synthesizedLoc;
        synStructDecl->nameAndLoc.loc = synthesizedLoc;

        synStructDecl->parentDecl = context->parentDecl;
        synStructDecl->ownedScope = m_astBuilder->create<Scope>();

        SubstitutionSet substSet;
        auto newSynStructDeclRef = liftDeclFromGenericContainers(synStructDecl, substSet);

        synStructDecl->nameAndLoc.name = getNamePool()->getName(
            "$__syn_MinimalContext_" + getMangledName(getCurrentASTBuilder(), targetFuncDeclRef));

        synStructDecl->operands.add(
            substituteDeclRef(substSet, getCurrentASTBuilder(), targetFuncDeclRef)
                .as<FunctionDeclBase>());

        // No conformance needed for MinimalContext (unlike BwdCallable which needs IBwdCallable).

        witnessTable->add(requirementDeclRef.getDecl(), RequirementWitness(newSynStructDeclRef));
        getShared()->registerSynthesizedDeclRoot(_getSynthesizedDeclRoot(synStructDecl));
        return true;
    }
    else if (requirementKind == BuiltinRequirementKind::BwdCallableContextType)
    {
        auto synStructDecl = getCurrentASTBuilder()->create<SynthesizedStructDecl>();

        SLANG_ASSERT(requirementKind == BuiltinRequirementKind::BwdCallableContextType);
        synStructDecl->irOp = kIROp_BackwardDiffIntermediateContextType;
        synStructDecl->loc = synthesizedLoc;
        synStructDecl->nameAndLoc.loc = synthesizedLoc;

        // Put the synthesized struct in the same scope as the requirement.
        // This is technically improper since struct types shouldn't be defined
        // inside extensions (or other AggTypeDecl) in this way
        //
        synStructDecl->parentDecl = context->parentDecl;
        synStructDecl->ownedScope = m_astBuilder->create<Scope>();

        // Now, we'll "lift" the declaration out of the parent declarations,
        // and in the process, clone any necessary generic parents
        //
        SubstitutionSet substSet;
        auto newSynStructDeclRef = liftDeclFromGenericContainers(synStructDecl, substSet);

        synStructDecl->nameAndLoc.name = getNamePool()->getName(
            "$__syn_BwdCallable_" + getMangledName(getCurrentASTBuilder(), targetFuncDeclRef));

        // Substitute the target funcDeclRef to reference it from the
        // new generic context (if any)
        //
        synStructDecl->operands.add(
            substituteDeclRef(substSet, getCurrentASTBuilder(), targetFuncDeclRef)
                .as<FunctionDeclBase>());

        // Insert an InheritanceDecl for SynStruct : IBwdCallable<Self>
        auto ctxTypeInheritanceDecl = getCurrentASTBuilder()->create<InheritanceDecl>();
        ctxTypeInheritanceDecl->parentDecl = synStructDecl;
        ctxTypeInheritanceDecl->loc = synthesizedLoc;

        ctxTypeInheritanceDecl->base.type = getBwdCallableBaseType(DeclRefType::create(
            getCurrentASTBuilder(),
            as<DeclRefBase>(synStructDecl->operands[0])));

        synStructDecl->addDirectMemberDecl(ctxTypeInheritanceDecl);

        checkAggTypeConformance(synStructDecl);

        witnessTable->add(requirementDeclRef.getDecl(), RequirementWitness(newSynStructDeclRef));
        getShared()->registerSynthesizedDeclRoot(_getSynthesizedDeclRoot(synStructDecl));
        return true;
    }
    else
    {
        SLANG_UNEXPECTED("unexpected context type requirement kind");
    }
}

bool SemanticsVisitor::trySynthesizeDifferentialAssociatedTypeRequirementWitness(
    ConformanceCheckingContext* context,
    DeclRef<AssocTypeDecl> requirementDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    ASTSynthesizer synth(m_astBuilder, getNamePool());

    AggTypeDecl* aggTypeDecl = nullptr;
    if (auto existingDecl =
            context->parentDecl->findLastDirectMemberDeclOfName(requirementDeclRef.getName()))
    {
        // Remove the `ToBeSynthesizedModifier`.
        if (auto mod = existingDecl->modifiers.findModifier<ToBeSynthesizedModifier>())
        {
            removeModifier(existingDecl, mod);
        }
        else
        {
            // The user has defined an associatedtype explicitly but that we reach here because
            // that type failed to satisfy the `IDifferential` requirement.
            // We stop the synthesis and let the follow-up logic to report a diagnostic.
            return false;
        }

        aggTypeDecl = as<AggTypeDecl>(existingDecl);
        SLANG_RELEASE_ASSERT(aggTypeDecl);
        synth.pushContainerScope(aggTypeDecl);
    }

    // If we did not find an existing empty struct, we may need to synthesize one.
    // But first, we check if the parent type can be used as its own differential type.
    //
    if (!aggTypeDecl && as<AggTypeDecl>(context->parentDecl) &&
        canStructBeUsedAsSelfDifferentialType(as<AggTypeDecl>(context->parentDecl)))
    {
        // If the parent type can be used as its own differential type, we will create a typealias
        // to itself as the differential type.
        //
        auto assocTypeDef = m_astBuilder->create<TypeDefDecl>();
        assocTypeDef->nameAndLoc.name = getName("Differential");
        assocTypeDef->type.type = context->conformingType;
        context->parentDecl->addMember(assocTypeDef);
        assocTypeDef->setCheckState(DeclCheckState::DefinitionChecked);
        auto visibility = getDeclVisibility(context->parentDecl);
        addVisibilityModifier(assocTypeDef, visibility);

        markSelfDifferentialMembersOfType(
            as<AggTypeDecl>(context->parentDecl),
            context->conformingType);

        witnessTable->add(
            requirementDeclRef.getDecl(),
            RequirementWitness(context->conformingType));
        getShared()->registerSynthesizedDeclRoot(assocTypeDef);
        // Increase the epoch so that future calls to Type::getCanonicalType will return the
        // up-to-date folded types.
        m_astBuilder->incrementEpoch();
        return true;
    }

    if (!aggTypeDecl)
    {
        aggTypeDecl = m_astBuilder->create<StructDecl>();
        aggTypeDecl->nameAndLoc.name = requirementDeclRef.getName();
        aggTypeDecl->loc = context->parentDecl->nameAndLoc.loc;

        // The visibility of synthesized decl should be the same of the parent decl.
        auto thisVisibility = getDeclVisibility(context->parentDecl);
        addVisibilityModifier(aggTypeDecl, thisVisibility);

        context->parentDecl->addDirectMemberDecl(aggTypeDecl);
        synth.pushScopeForContainer(aggTypeDecl);
    }

    // If `This` is nested inside a generic, we need to form a complete declref type to the
    // newly synthesized aggTypeDecl here. This can be done by obtaining the this type witness
    // from requirementDeclRef to get the generic arguments for the outer generic, and
    // apply it to the newly synthesized decl.
    SubstitutionSet substSet;
    Type* thisType = nullptr;
    if (auto thisWitness = findThisTypeWitness(
            SubstitutionSet(requirementDeclRef),
            as<InterfaceDecl>(requirementDeclRef.getParent()).getDecl()))
    {
        thisType = thisWitness->getSub();
        if (auto declRefType = as<DeclRefType>(thisType))
        {
            substSet = SubstitutionSet(declRefType->getDeclRef());
        }
    }
    if (!substSet.declRef)
        return false;
    Type* satisfyingType = nullptr;
    if (substSet.declRef->getDecl() == context->parentDecl)
    {
        // The type we are synthesizing conformance for is direct inside a type itself.
        // We need to copy the outer generic arguments to the synthesized type.
        satisfyingType = DeclRefType::create(
            m_astBuilder,
            m_astBuilder->getMemberDeclRef(substSet.declRef, aggTypeDecl));
    }
    else if (auto parentExtDecl = as<ExtensionDecl>(context->parentDecl))
    {
        // The type is defined in an extension, we need to form a declref to the parent
        // extension from the requirementDeclRef.
        auto extDeclRef = applyExtensionToType(parentExtDecl, thisType);
        satisfyingType = DeclRefType::create(
            m_astBuilder,
            m_astBuilder->getMemberDeclRef(extDeclRef, aggTypeDecl));
    }
    if (!satisfyingType)
        return false;

    // Helper function to add a `diffType` field into the synthesized type for the original
    // `member`.
    auto differentialType =
        DeclRefType::create(m_astBuilder, DeclRef<Decl>(makeDeclRef(aggTypeDecl)));
    auto addDiffMember = [&](Decl* member, Type* diffMemberType)
    {
        // If the field is differentiable, add a corresponding field in the associated Differential
        // type.
        auto diffField = m_astBuilder->create<VarDecl>();
        diffField->nameAndLoc = member->nameAndLoc;
        diffField->type.type = diffMemberType;
        diffField->checkState = DeclCheckState::SignatureChecked;

        auto visibility = getDeclVisibility(member);
        addVisibilityModifier(diffField, visibility);

        aggTypeDecl->addDirectMemberDecl(diffField);

        // Inject a `DerivativeMember` modifier on the differential field to point to itself.
        {
            auto derivativeMemberModifier = m_astBuilder->create<DerivativeMemberAttribute>();
            auto fieldLookupExpr = m_astBuilder->create<StaticMemberExpr>();
            fieldLookupExpr->type.type = diffMemberType;
            auto baseTypeExpr = m_astBuilder->create<SharedTypeExpr>();
            baseTypeExpr->base.type = differentialType;
            auto baseTypeType = m_astBuilder->getOrCreate<TypeType>(differentialType);
            baseTypeExpr->type.type = baseTypeType;
            fieldLookupExpr->baseExpression = baseTypeExpr;
            fieldLookupExpr->declRef = makeDeclRef(diffField);
            derivativeMemberModifier->memberDeclRef = fieldLookupExpr;
            addModifier(diffField, derivativeMemberModifier);
        }

        // Inject a `DerivativeMember` modifier on the original decl.
        {
            auto derivativeMemberModifier = m_astBuilder->create<DerivativeMemberAttribute>();
            auto fieldLookupExpr = m_astBuilder->create<StaticMemberExpr>();
            fieldLookupExpr->type.type = diffMemberType;
            auto baseTypeExpr = m_astBuilder->create<SharedTypeExpr>();
            baseTypeExpr->base.type = differentialType;
            auto baseTypeType = m_astBuilder->getOrCreate<TypeType>(differentialType);
            baseTypeExpr->type.type = baseTypeType;
            fieldLookupExpr->baseExpression = baseTypeExpr;
            fieldLookupExpr->declRef = makeDeclRef(diffField);
            derivativeMemberModifier->memberDeclRef = fieldLookupExpr;
            addModifier(member, derivativeMemberModifier);
        }
    };

    // Make the Differential type itself conform to `IDifferential` interface.
    bool hasDifferentialConformance = false;
    for (auto inheritanceDecl : aggTypeDecl->getMembersOfType<InheritanceDecl>())
    {
        if (auto declRefType = as<DeclRefType>(inheritanceDecl->base.type))
        {
            if (declRefType->getDeclRef() == m_astBuilder->getDifferentiableInterfaceDecl())
            {
                hasDifferentialConformance = true;
                break;
            }
        }
    }
    if (!hasDifferentialConformance)
    {
        auto inheritanceIDiffernetiable = m_astBuilder->create<InheritanceDecl>();
        inheritanceIDiffernetiable->base.type = m_astBuilder->getDiffInterfaceType();
        aggTypeDecl->addMember(inheritanceIDiffernetiable);
    }

    // The `Differential` type of a `Differential` type is always itself.
    auto differentialName = getName("Differential");
    bool hasDifferentialTypeDef =
        aggTypeDecl->findLastDirectMemberDeclOfName(differentialName) != nullptr;
    if (!hasDifferentialTypeDef)
    {
        auto assocTypeDef = m_astBuilder->create<TypeDefDecl>();
        assocTypeDef->nameAndLoc.name = differentialName;
        assocTypeDef->type.type = satisfyingType;
        assocTypeDef->setCheckState(DeclCheckState::DefinitionChecked);
        auto visibility = getDeclVisibility(aggTypeDecl);
        addVisibilityModifier(assocTypeDef, visibility);
        aggTypeDecl->addDirectMemberDecl(assocTypeDef);
    }

    // Go through all members and collect their differential types.
    // Go through super types.
    for (auto inheritance : context->parentDecl->getMembersOfType<InheritanceDecl>())
    {
        if (auto baseDeclRefType = as<DeclRefType>(inheritance->base.type))
        {
            // Skip interface super types.
            if (baseDeclRefType->getDeclRef().as<InterfaceDecl>())
                continue;
            if (auto superDiffType = tryGetDifferentialType(m_astBuilder, baseDeclRefType))
            {
                addDiffMember(inheritance, superDiffType);
            }
        }
    }
    // Go through all var members.
    for (auto member : context->parentDecl->getMembersOfType<VarDeclBase>())
    {
        if (member->hasModifier<NoDiffModifier>())
            continue;
        auto diffType = tryGetDifferentialType(m_astBuilder, member->type.type);
        if (!diffType)
            continue;
        addDiffMember(member, diffType);
    }

    addModifier(aggTypeDecl, m_astBuilder->create<SynthesizedModifier>());


    // Synthesize the rest of IDifferential method conformances by recursively checking
    // conformance on the synthesized decl.
    checkAggTypeConformance(aggTypeDecl);

    witnessTable->add(requirementDeclRef.getDecl(), RequirementWitness(satisfyingType));
    getShared()->registerSynthesizedDeclRoot(_getSynthesizedDeclRoot(aggTypeDecl));
    return true;
}

bool isProperConstraineeType(Type* type)
{
    auto declRef = isDeclRefTypeOf<Decl>(type);
    if (!declRef)
        return false;
    if (as<InterfaceDecl>(declRef.getDecl()))
        return false;
    // TODO: `some` type and `dyn` types are also inproper constrainee types.

    return true;
}

static bool isKnownBuiltinDecl(Decl* decl, KnownBuiltinDeclName name)
{
    if (auto genericDecl = as<GenericDecl>(decl))
        decl = getInner(genericDecl);

    auto attr = decl ? decl->findModifier<KnownBuiltinAttribute>() : nullptr;
    auto constantName = attr ? as<ConstantIntVal>(attr->name) : nullptr;
    return constantName && constantName->getValue() == (IntegerLiteralValue)name;
}

bool SemanticsDeclHeaderVisitor::validateGenericConstraintSubType(
    GenericTypeConstraintDecl* decl,
    TypeExp type,
    DiagnosticSink* sink)
{
    auto diagnose = [&]()
    {
        if (sink)
        {
            if (decl->isEqualityConstraint)
            {
                sink->diagnose(Diagnostics::InvalidEqualityConstraintSubType{
                    .type = type.type,
                    .typeExp = type.exp});
            }
            else
            {
                sink->diagnose(
                    Diagnostics::InvalidConstraintSubType{.type = type.type, .typeExp = type.exp});
            }
        }
    };
    // Validate that the sub type of a constraint is in valid form.
    //
    if (auto subDeclRef = isDeclRefTypeOf<Decl>(type.type))
    {
        if (subDeclRef.getDecl()->parentDecl == decl->parentDecl)
        {
            // OK, sub type is one of the generic parameter type.
            return true;
        }
        if (as<GenericDecl>(decl->parentDecl))
        {
            // If the constraint is in a generic decl, then the sub type must be dependent on at
            // least one of the generic type parameters defined in the same generic decl. For
            // example, it is invalid to define a constraint like `void foo<T>() where int : float`
            // since `int` isn't dependent on any generic type parameter.
            auto dependentGeneric = getShared()->getDependentGenericParent(subDeclRef);
            if (dependentGeneric.getDecl() != decl->parentDecl)
            {
                diagnose();
                return false;
            }
        }
    }
    if (!isProperConstraineeType(type.type))
    {
        // It is meaningless for certain types to be used in type constraints.
        // For example, `IFoo<T>` should not appear as the left-hand-side of a generic constraint.
        diagnose();
        return false;
    }
    return true;
}

struct CollectReferencedDeclsVisitor
    : public SemanticsDeclReferenceVisitor<CollectReferencedDeclsVisitor>
{
    typedef SemanticsDeclReferenceVisitor<CollectReferencedDeclsVisitor> Base;

    HashSet<Decl*>* outDecls;

    CollectReferencedDeclsVisitor(HashSet<Decl*>& outDecls, SemanticsContext& outer)
        : Base(outer), outDecls(&outDecls)
    {
    }

    virtual void processReferencedDecl(Decl* decl) override { outDecls->add(decl); }

    virtual void processDeclModifiers(Decl*, SourceLoc) override {}
};

// General utility function to collect all referenced declarations from a syntax node
void collectReferencedDecls(SemanticsVisitor* context, NodeBase* node, HashSet<Decl*>& outDecls)
{
    if (!node)
        return;

    CollectReferencedDeclsVisitor visitor(outDecls, *context);

    if (auto val = as<Val>(node))
        visitor.dispatchIfNotNull(val);
    else if (auto stmt = as<Stmt>(node))
        visitor.dispatchIfNotNull(stmt);
    else if (auto expr = as<Expr>(node))
        visitor.dispatchIfNotNull(expr);
    else if (auto decl = as<Decl>(node))
        visitor.dispatchIfNotNull(decl);
}

void SemanticsDeclHeaderVisitor::checkForwardReferencesInGenericDecl(
    Decl* decl,
    Expr* expr,
    Val* val)
{
    // Check if this decl references type parameters that appear later in the
    // same GenericDecl's parameter list and report a forward reference error
    // if it does.

    // Only applies to constraints within GenericDecl contexts where declaration order matters.
    // If that's not the case, then early out.
    auto parentGeneric = as<GenericDecl>(decl->parentDecl);
    if (!parentGeneric)
        return;

    // Build a HashSet of all generic parameter declarations seen before the constraint.
    // After we collect the referenced declarations from the constraint's superior type,
    // we can do a quick check with the HashSet to see if a reference falls outside of
    // the set, indicating that we have a forward reference.
    HashSet<Decl*> declaredBeforeConstraint;
    bool foundConstraint = false;

    for (Index i = 0; i < parentGeneric->getDirectMemberDeclCount(); ++i)
    {
        auto member = parentGeneric->getDirectMemberDecl(i);

        if (member == decl)
        {
            foundConstraint = true;
            break;
        }

        // Add generic type parameters to our "declared so far" set
        if (auto typeParam = as<GenericTypeParamDeclBase>(member))
        {
            declaredBeforeConstraint.add(typeParam);
        }
        else if (auto valueParam = as<GenericValueParamDecl>(member))
        {
            declaredBeforeConstraint.add(valueParam);
        }
    }

    // This probably shouldn't happen, but if the constraint is not found in parent GenericDecl,
    // just early out as we can't check forward references.
    if (!foundConstraint)
        return;

    // Collect all referenced declarations from the constraint's superior type
    HashSet<Decl*> referencedDecls;
    collectReferencedDecls(this, val ? as<NodeBase>(val) : as<NodeBase>(expr), referencedDecls);

    // Check if any of the referenced declarations are forward references (not in our "declared so
    // far" set)
    for (auto referencedDecl : referencedDecls)
    {
        // If this type parameter doesn't belong to the same generic or is in
        // our "declared so far" set, it's OK.
        if (referencedDecl->parentDecl != parentGeneric ||
            declaredBeforeConstraint.contains(referencedDecl))
            continue;

        // Found a forward reference, report an error.
        if (as<GenericTypeParamDeclBase>(referencedDecl) ||
            as<GenericValueParamDecl>(referencedDecl))
        {
            if (auto typeConstraint = as<GenericTypeConstraintDecl>(decl))
            {
                getSink()->diagnose(Diagnostics::ForwardReferenceInGenericConstraint{
                    .param = typeConstraint->sub.type,
                    .referenced = referencedDecl,
                    .expr = expr});
            }
            else if (as<GenericTypeParamDeclBase>(decl) || as<GenericValueParamDecl>(decl))
            {
                getSink()->diagnose(Diagnostics::ForwardReferenceInGenericDefaultInitializer{
                    .param = decl,
                    .referenced = referencedDecl,
                    .expr = expr});
            }
        }
    }
}

void SemanticsDeclHeaderVisitor::visitTypeCoercionConstraintDecl(TypeCoercionConstraintDecl* decl)
{
    CheckConstraintSubType(decl->toType);

    if (!decl->fromType.type)
        decl->fromType = TranslateTypeNodeForced(decl->fromType);
    if (!decl->toType.type)
        decl->toType = TranslateTypeNodeForced(decl->toType);
}

void SemanticsDeclHeaderVisitor::visitNonEmptyPackConstraintDecl(NonEmptyPackConstraintDecl* decl)
{
    decl->packExpr = CheckTerm(decl->packExpr);
    auto packExpr = decl->packExpr;
    if (!packExpr)
        return;

    if (decl->hasModifier<OptionalConstraintModifier>())
    {
        getSink()->diagnose(Diagnostics::OptionalNonEmptyPackConstraintIsInvalid{.expr = packExpr});
    }

    if (auto declRefExpr = as<DeclRefExpr>(packExpr))
    {
        auto declRef = getDeclRef(m_astBuilder, declRefExpr);
        if (auto typePackDeclRef = declRef.as<GenericTypePackParamDecl>())
        {
            if (typePackDeclRef.getDecl()->parentDecl == decl->parentDecl)
                return;
            getSink()->diagnose(Diagnostics::NonEmptyPackConstraintTargetMustBeFromCurrentGeneric{
                .expr = packExpr});
            return;
        }
        if (auto valuePackDeclRef = declRef.as<GenericValuePackParamDecl>())
        {
            if (valuePackDeclRef.getDecl()->parentDecl == decl->parentDecl)
                return;
            getSink()->diagnose(Diagnostics::NonEmptyPackConstraintTargetMustBeFromCurrentGeneric{
                .expr = packExpr});
            return;
        }
    }

    getSink()->diagnose(Diagnostics::InvalidNonEmptyPackConstraintTarget{.expr = packExpr});
}

void SemanticsDeclHeaderVisitor::visitGenericVariadicPackCountConstraintDecl(
    GenericVariadicPackCountConstraintDecl* decl)
{
    // `maybeParseGenericConstraints` recognizes only the oriented
    // `countof(Pack) == CountExpr` spelling. The semantic invariant
    // established here is stricter: `Pack` must be a direct type/value pack
    // parameter of this generic and is stored in `packDeclRef`, `countof(Pack)`
    // is stored in `actualCountVal`, and `CountExpr` must fold to an `IntVal`
    // that can be canonicalized to `int` before witness matching.
    // Witness matching and default substitution rely on those checked fields
    // instead of reinterpreting arbitrary syntax or proving algebraically
    // equivalent forms.
    decl->packDeclRef = DeclRef<Decl>();
    decl->actualCountVal = nullptr;
    decl->packExpr = CheckTerm(decl->packExpr);
    decl->expectedCountExpr = CheckTerm(decl->expectedCountExpr);
    if (!decl->packExpr || !decl->expectedCountExpr)
        return;

    struct PackCountTargetInfo
    {
        DeclRef<Decl> packDeclRef;
        bool sawPackParam = false;
        bool isCurrentGenericPackParam = false;
    };

    auto getPackCountTargetInfo = [&](Expr* expr) -> PackCountTargetInfo
    {
        PackCountTargetInfo result;
        auto declRefExpr = as<DeclRefExpr>(expr);
        if (!declRefExpr)
            return result;

        auto declRef = getDeclRef(m_astBuilder, declRefExpr);
        if (auto typePackDeclRef = declRef.as<GenericTypePackParamDecl>())
        {
            result.packDeclRef = typePackDeclRef;
            result.sawPackParam = true;
            if (typePackDeclRef.getDecl()->parentDecl == decl->parentDecl)
                result.isCurrentGenericPackParam = true;
        }
        else if (auto valuePackDeclRef = declRef.as<GenericValuePackParamDecl>())
        {
            result.packDeclRef = valuePackDeclRef;
            result.sawPackParam = true;
            if (valuePackDeclRef.getDecl()->parentDecl == decl->parentDecl)
                result.isCurrentGenericPackParam = true;
        }
        return result;
    };

    auto packTargetInfo = getPackCountTargetInfo(decl->packExpr);
    auto packExpr = decl->packExpr;
    if (decl->hasModifier<OptionalConstraintModifier>())
    {
        getSink()->diagnose(
            Diagnostics::OptionalVariadicPackCountConstraintIsInvalid{.expr = packExpr});
    }

    if (!packTargetInfo.isCurrentGenericPackParam)
    {
        if (packTargetInfo.sawPackParam)
        {
            getSink()->diagnose(
                Diagnostics::VariadicPackCountConstraintTargetMustBeFromCurrentGeneric{
                    .expr = packExpr});
        }
        else
        {
            getSink()->diagnose(
                Diagnostics::InvalidVariadicPackCountConstraintTarget{.expr = packExpr});
        }
    }
    else
    {
        decl->packDeclRef = packTargetInfo.packDeclRef;
        Val* packVal = m_astBuilder->getDeclRefVal(packTargetInfo.packDeclRef);
        if (packVal)
        {
            decl->actualCountVal = as<IntVal>(
                CountOfIntVal::tryFold(m_astBuilder, m_astBuilder->getIntType(), packVal));
        }
    }

    auto countVal =
        tryConstantFoldExpr(decl->expectedCountExpr, ConstantFoldingKind::CompileTime, nullptr);
    decl->expectedCountVal = as<IntVal>(countVal);
    if (decl->expectedCountVal)
        decl->expectedCountVal =
            m_astBuilder->getTypeCastIntVal(m_astBuilder->getIntType(), decl->expectedCountVal);
    if (!decl->expectedCountVal)
    {
        getSink()->diagnose(
            Diagnostics::InvalidVariadicPackCountConstraintCount{.expr = decl->expectedCountExpr});
    }
}

void SemanticsDeclHeaderVisitor::visitHasDiffTypeInfoConstraintDecl(
    HasDiffTypeInfoConstraintDecl* decl)
{
    CheckConstraintSubType(decl->type);

    if (!decl->type.type)
        decl->type = TranslateTypeNodeForced(decl->type);
}

static void maybeFlattenConjunctionType(Type* type, List<Type*>& outTypes)
{
    if (auto andType = as<AndType>(type))
    {
        maybeFlattenConjunctionType(andType->getLeft(), outTypes);
        maybeFlattenConjunctionType(andType->getRight(), outTypes);
    }
    else
    {
        outTypes.add(type);
    }
}

void SemanticsDeclHeaderVisitor::visitGenericTypeConstraintDecl(GenericTypeConstraintDecl* decl)
{
    CheckConstraintSubType(decl->sub);

    if (!decl->sub.type)
        decl->sub = TranslateTypeNodeForced(decl->sub);

    // The subject of an interface `__constraint` must be one of the interface's
    // (possibly nested) associated types, e.g. `This.A` -- never the bare `This`
    // type. A constraint on `This` itself is what an inheritance clause expresses
    // (`interface IFoo : IBar`); written as a `__constraint` it is a checked
    // predicate over the very base set being computed, which is ill-formed (it
    // would otherwise surface as a cyclic-reference error). Reject it here, before
    // that cyclic inheritance query is ever attempted, and error the constraint so
    // it contributes nothing downstream.
    if (as<InterfaceDecl>(decl->parentDecl) && as<ThisType>(decl->sub.type))
    {
        getSink()->diagnose(
            Diagnostics::ConstraintSubjectCannotBeThisType{.typeExp = decl->sub.exp});
        decl->sub.type = m_astBuilder->getErrorType();
        decl->sup = TypeExp(m_astBuilder->getErrorType());
        return;
    }

    if (!decl->sup.type)
    {
        decl->sup = TranslateTypeNodeForced(decl->sup);
    }

    // If the super-type is an AndType (e.g. `T : A & B`), flatten it and create
    // individual GenericTypeConstraintDecls for each element in the conjunction.
    if (decl->sup.type && !decl->isEqualityConstraint)
    {
        List<Type*> flattenedTypes;
        maybeFlattenConjunctionType(decl->sup.type, flattenedTypes);
        if (flattenedTypes.getCount() > 1)
        {
            auto parentDecl = as<ContainerDecl>(decl->parentDecl);
            SLANG_ASSERT(parentDecl);

            // Update the current decl's sup to the first type in the flattened list.
            decl->sup = TypeExp(flattenedTypes[0]);

            // Create new constraint decls for the remaining types.
            for (Index i = 1; i < flattenedTypes.getCount(); i++)
            {
                auto newConstraint = m_astBuilder->create<GenericTypeConstraintDecl>();
                newConstraint->sub = decl->sub;
                newConstraint->sup = TypeExp(flattenedTypes[i]);
                newConstraint->loc = decl->loc;
                newConstraint->parentDecl = parentDecl;
                parentDecl->addDirectMemberDecl(newConstraint);
                ensureDecl(newConstraint, DeclCheckState::SignatureChecked);
            }
        }
    }

    // If the super-type is an AndType (e.g. `T : A & B`), flatten it and create
    // individual GenericTypeConstraintDecls for each element in the conjunction.
    if (decl->sup.type && !decl->isEqualityConstraint)
    {
        List<Type*> flattenedTypes;
        maybeFlattenConjunctionType(decl->sup.type, flattenedTypes);
        if (flattenedTypes.getCount() > 1)
        {
            auto parentDecl = as<ContainerDecl>(decl->parentDecl);
            SLANG_ASSERT(parentDecl);

            // Update the current decl's sup to the first type in the flattened list.
            decl->sup = TypeExp(flattenedTypes[0]);

            // Create new constraint decls for the remaining types.
            List<GenericTypeConstraintDecl*> newConstraints;
            for (Index i = 1; i < flattenedTypes.getCount(); i++)
            {
                auto newConstraint = m_astBuilder->create<GenericTypeConstraintDecl>();
                newConstraint->sub = decl->sub;
                newConstraint->sup = TypeExp(flattenedTypes[i]);
                newConstraint->loc = decl->loc;
                newConstraint->parentDecl = parentDecl;
                parentDecl->addDirectMemberDecl(newConstraint);
                newConstraints.add(newConstraint);
            }

            // Clear cached substitutions before proceeding with checking.
            if (auto genericParentDecl = as<GenericDecl>(parentDecl))
                genericParentDecl->_cachedArgsForDefaultSubstitution.clear();

            for (auto newConstraint : newConstraints)
            {
                ensureDecl(newConstraint, DeclCheckState::SignatureChecked);
            }
        }
    }

    if (getLinkage()->m_optionSet.shouldRunNonEssentialValidation())
    {
        // Check for forward references in generic constraints after type translation
        checkForwardReferencesInGenericDecl(decl, decl->sup.exp, decl->sup.type);

        if (decl->isEqualityConstraint)
        {
            checkGenericTypeEqualityConstraintSubType(decl);
            if (!isProperConstraineeType(decl->sup) && !as<ErrorType>(decl->sup.type))
            {
                getSink()->diagnose(Diagnostics::InvalidEqualityConstraintSupType{
                    .type = decl->sup.type,
                    .typeExp = decl->sup.exp});
            }
        }
        else
        {
            validateGenericConstraintSubType(decl, decl->sub, getSink());
            if (!isValidGenericConstraintType(decl->sup) && !as<ErrorType>(decl->sup.type))
            {
                getSink()->diagnose(Diagnostics::InvalidTypeForConstraint{
                    .type = decl->sup.type,
                    .typeExp = decl->sup.exp});
                if (isValidCompileTimeConstantType(decl->sup.type) &&
                    !decl->whereTokenLoc.isValid())
                {
                    if (auto subDeclRefType = as<DeclRefType>(decl->sub.type))
                    {
                        auto subDecl = subDeclRefType->getDeclRef().getDecl();
                        if (as<GenericTypePackParamDecl>(subDecl))
                        {
                            getSink()->diagnose(Diagnostics::UseLetEachForGenericValuePackParam{
                                .paramName = subDecl->getName(),
                                .type = decl->sup.type});
                        }
                        else if (as<GenericTypeParamDecl>(subDecl))
                        {
                            getSink()->diagnose(Diagnostics::UseLetForGenericValueParam{
                                .paramName = subDecl->getName(),
                                .type = decl->sup.type});
                        }
                    }
                }
            }
        }
    }

    if (decl->sub.type && decl->sup.type && decl->isEqualityConstraint)
    {
        // Invalidate the inheritance cache for the decls involved in the equality constraint.
        getShared()->invalidateInheritanceInfo(decl->sub.type);
        getShared()->invalidateInheritanceInfo(decl->sup.type);
    }
}

ContainerDecl* findDeclsLowestCommonAncestor(Decl*& a, Decl*& b);
int compareDecls(Decl* lhs, Decl* rhs);

void SemanticsDeclHeaderVisitor::checkGenericTypeEqualityConstraintSubType(
    GenericTypeConstraintDecl* decl)
{
    auto checkAndCompare = [&]() -> int
    {
        bool subOk = validateGenericConstraintSubType(decl, decl->sub);
        bool supOk = validateGenericConstraintSubType(decl, decl->sup);

        if (subOk != supOk) // Only one is qualified
        {
            return int(supOk) - int(subOk);
        }
        else if (!(subOk || supOk))
        {
            getSink()->diagnose(Diagnostics::NoValidEqualityConstraintSubType{.decl = decl});
            // Re-run the validation to emit the diagnostic this time
            validateGenericConstraintSubType(decl, decl->sub, getSink());
            validateGenericConstraintSubType(decl, decl->sup, getSink());
            return -1;
        }
        // Both sub and sup are qualified
        // For example:
        // __generic <A : IA, B : IB>
        // where A::T == B::T
        // Sort them by declaration order in the generic (A > B)

        Decl* subAncestor = as<DeclRefType>(decl->sub.type)->getDeclRef().getDecl();
        Decl* supAncestor = as<DeclRefType>(decl->sup.type)->getDeclRef().getDecl();
        if (subAncestor == supAncestor)
        {
            // If both side resolve to the same decl, there is no need to compare decl order,
            // because we cannot decide the order. Instead we will just compare the DeclRefType
            // itself.
            return compareVals(*decl->sub.type, *decl->sup.type);
        }

        auto ancestor = findDeclsLowestCommonAncestor(subAncestor, supAncestor);
        if (!ancestor)
        {
            return compareDecls(subAncestor, supAncestor);
        }

        auto subIndex = ancestor->getMembers().indexOf(subAncestor);
        auto supIndex = ancestor->getMembers().indexOf(supAncestor);

        return int(supIndex - subIndex);
    };

    int cmp = checkAndCompare();
    if (cmp > 0)
    {
        Swap(decl->sub, decl->sup);
    }
    else if (cmp == 0 && decl->sub != decl->sup)
    {
        // The comparison was not fully handled for this case.
        getSink()->diagnose(Diagnostics::FailedEqualityConstraintCanonicalOrder{.decl = decl});
    }
}

// Returns true if `paramDecl` is a generic parameter of an `extension` or a
// `__func_extension`. In both cases the generic parameters are always inferred
// from the target (the target type, or the target function expression), so a
// default value on one of them can never be selected and is meaningless.
static bool isExtensionGenericParam(Decl* paramDecl)
{
    auto genericDecl = as<GenericDecl>(paramDecl->parentDecl);
    if (!genericDecl)
        return false;
    return as<ExtensionDecl>(genericDecl->inner) || as<FuncExtensionDecl>(genericDecl->inner);
}

// If `paramDecl` is a generic parameter of an extension and `defaultValue` is a
// (non-null) default for it, diagnose the meaningless default. Returns true if a
// diagnostic was emitted, signalling that the caller should drop the default
// instead of type-checking it (which would otherwise cascade unrelated errors
// for an ill-formed default the compiler has just declared unused).
bool SemanticsDeclHeaderVisitor::diagnoseDefaultOnExtensionGenericParam(
    Decl* paramDecl,
    Expr* defaultValue)
{
    if (!defaultValue || !isExtensionGenericParam(paramDecl))
        return false;
    getSink()->diagnose(Diagnostics::DefaultValueOnExtensionGenericParam{
        .name = paramDecl->getName(),
        .location = defaultValue->loc});
    return true;
}

void SemanticsDeclHeaderVisitor::visitGenericTypeParamDecl(GenericTypeParamDecl* decl)
{
    // A default value on an extension's generic parameter is never used; reject it
    // and drop the default so it is not type-checked below.
    if (diagnoseDefaultOnExtensionGenericParam(decl, decl->initType.exp))
    {
        decl->initType = TypeExp();
        return;
    }

    // TODO: could probably push checking the default value
    // for a generic type parameter later.
    //
    decl->initType = CheckProperType(decl->initType);

    if (decl->initType && getLinkage()->m_optionSet.shouldRunNonEssentialValidation())
        checkForwardReferencesInGenericDecl(decl, decl->initType.exp, decl->initType.type);
}

void SemanticsDeclHeaderVisitor::visitGenericValueParamDecl(GenericValueParamDecl* decl)
{
    checkVarDeclCommon(decl);

    // Validate that the type is supported for generic value parameters
    if (decl->type.type)
    {
        if (!isValidCompileTimeConstantType(decl->type.type))
        {
            getSink()->diagnose(Diagnostics::GenericValueParameterTypeNotSupported{
                .type = decl->type.type,
                .decl = decl});
        }
    }

    // A default value on an extension's generic parameter is never used; reject it
    // and drop the default so it is not type-checked below.
    if (diagnoseDefaultOnExtensionGenericParam(decl, decl->initExpr))
    {
        decl->initExpr = nullptr;
        return;
    }

    if (decl->initExpr)
        decl->initExpr = CheckTerm(decl->initExpr);

    if (decl->initExpr && getLinkage()->m_optionSet.shouldRunNonEssentialValidation())
        checkForwardReferencesInGenericDecl(decl, decl->initExpr, nullptr);
}

void SemanticsDeclHeaderVisitor::visitGenericValuePackParamDecl(GenericValuePackParamDecl* decl)
{
    checkVarDeclCommon(decl);

    if (decl->type.type && !as<ValuePackType>(decl->type.type))
    {
        if (!isValidCompileTimeConstantType(decl->type.type))
        {
            getSink()->diagnose(Diagnostics::GenericValueParameterTypeNotSupported{
                .type = decl->type.type,
                .decl = decl});
            decl->type.type = m_astBuilder->getErrorType();
            return;
        }
        decl->type.type = m_astBuilder->getOrCreate<ValuePackType>(decl->type.type);
    }
}

void SemanticsDeclHeaderVisitor::visitGenericDecl(GenericDecl* genericDecl)
{
    genericDecl->setCheckState(DeclCheckState::ReadyForLookup);

    // NOTE! We purposefully do not iterate with the for(auto m : genericDecl->members) here,
    // because the visitor may add to `members` whilst iteration takes place, invalidating the
    // iterator and likely a crash.
    //
    // Accessing the members via index side steps the issue.

    int parameterIndex = 0;
    for (Index i = 0; i < genericDecl->getDirectMemberDeclCount(); ++i)
    {
        Decl* m = genericDecl->getDirectMemberDecl(i);

        if (auto typeParam = as<GenericTypeParamDeclBase>(m))
        {
            ensureDecl(typeParam, DeclCheckState::ReadyForReference);
            typeParam->parameterIndex = parameterIndex++;
        }
        else if (auto valPackParam = as<GenericValuePackParamDecl>(m))
        {
            ensureDecl(valPackParam, DeclCheckState::ReadyForReference);
            valPackParam->parameterIndex = parameterIndex++;
        }
        else if (auto valParam = as<GenericValueParamDecl>(m))
        {
            ensureDecl(valParam, DeclCheckState::ReadyForReference);
            valParam->parameterIndex = parameterIndex++;
        }
        else if (isConstraintDecl(m))
        {
            ensureDecl(m, DeclCheckState::ReadyForReference);
        }
    }

    // Check for generic type parameters that shadow outer generic parameters.
    for (Index i = 0; i < genericDecl->getDirectMemberDeclCount(); ++i)
    {
        Decl* m = genericDecl->getDirectMemberDecl(i);
        if (!as<GenericTypeParamDeclBase>(m))
            continue;
        auto paramName = m->getName();
        if (!paramName)
            continue;
        bool found = false;
        for (auto ancestor = genericDecl->parentDecl; ancestor && !found;
             ancestor = ancestor->parentDecl)
        {
            auto outerGeneric = as<GenericDecl>(ancestor);
            if (!outerGeneric)
                continue;
            for (auto outerMember : outerGeneric->getMembers())
            {
                if (!as<GenericTypeParamDeclBase>(outerMember))
                    continue;
                if (outerMember->getName() == paramName)
                {
                    getSink()->diagnose(Diagnostics::GenericParamShadowsOuterGeneric{
                        .param = m,
                        .outerParam = outerMember});
                    found = true;
                    break;
                }
            }
        }
    }

    // Validate that pack parameters only appear at the end of the parameter list.
    bool seenPack = false;
    for (Index i = 0; i < genericDecl->getDirectMemberDeclCount(); ++i)
    {
        Decl* m = genericDecl->getDirectMemberDecl(i);
        bool isPack = as<GenericTypePackParamDecl>(m) || as<GenericValuePackParamDecl>(m);
        if (isPack)
        {
            seenPack = true;
        }
        else if (seenPack && isGenericParam(m))
        {
            getSink()->diagnose(Diagnostics::PackParamMustBeLast{.param = m});
        }
    }
}

void SemanticsDeclBasesVisitor::visitInheritanceDecl(InheritanceDecl* inheritanceDecl)
{
    // check the type being inherited from
    auto base = inheritanceDecl->base;
    Decl* parent = getParentDecl(inheritanceDecl);
    // We exclude transparent members in the case that a circular reference is
    // possible. This is when a parent is also a transparent decl.
    SemanticsContext context(*this);
    if (parent->findModifier<TransparentModifier>())
        context = context.excludeTransparentMembersFromLookup();
    SemanticsDeclVisitorBase baseVisitor(context);

    if (auto extensionDecl = as<ExtensionDecl>(inheritanceDecl->parentDecl))
    {
        if (isDeclRefTypeOf<FuncDecl>(extensionDecl->targetType))
        {
            // Avoid circularity during checking for function extensions.
            baseVisitor = baseVisitor.allowStaticReferenceToNonStaticMember();
        }
    }

    baseVisitor.CheckConstraintSubType(base);
    base = baseVisitor.TranslateTypeNode(base);
    inheritanceDecl->base = base;

    // If the base type is an AndType (e.g. `struct Foo : IBar & IBaz`), flatten it
    // into individual InheritanceDecls for each element in the conjunction.
    if (base.type)
    {
        List<Type*> flattenedTypes;
        maybeFlattenConjunctionType(base.type, flattenedTypes);
        if (flattenedTypes.getCount() > 1)
        {
            auto parentDecl = as<ContainerDecl>(inheritanceDecl->parentDecl);
            SLANG_ASSERT(parentDecl);

            // Update the current decl's base to the first type in the flattened list.
            inheritanceDecl->base = TypeExp(flattenedTypes[0]);

            // Create new inheritance decls for the remaining types.
            for (Index i = 1; i < flattenedTypes.getCount(); i++)
            {
                auto newInheritance = m_astBuilder->create<InheritanceDecl>();
                newInheritance->base = TypeExp(flattenedTypes[i]);
                newInheritance->loc = inheritanceDecl->loc;
                newInheritance->parentDecl = parentDecl;
                parentDecl->addDirectMemberDecl(newInheritance);
                ensureDecl(newInheritance, DeclCheckState::ReadyForLookup);
            }
        }
    }

    // Note: we do not check whether the type being inherited from
    // is valid to use for inheritance here, because there could
    // be contextual factors that need to be taken into account
    // based on the declaration that is doing the inheriting.
}

void SemanticsDeclBasesVisitor::visitThisTypeConstraintDecl(
    ThisTypeConstraintDecl* thisTypeConstraintDecl)
{
    // Make sure IFoo<T>.This.ThisIsIFooConstraint.base.type is properly set
    // to DeclRefType(IFoo<T>) with default generic arguments.
    if (!thisTypeConstraintDecl->base.type)
    {
        auto parentTypeDecl = getParentDecl(getParentDecl(thisTypeConstraintDecl));
        thisTypeConstraintDecl->base.type = DeclRefType::create(
            m_astBuilder,
            createDefaultSubstitutionsIfNeeded(
                m_astBuilder,
                this,
                getDefaultDeclRef(parentTypeDecl)));
    }
}

// Concretize interface conformances so that we have witnesses as required for lookup.
// for lookup.
struct SemanticsDeclConformancesVisitor : public SemanticsDeclVisitorBase,
                                          public DeclVisitor<SemanticsDeclConformancesVisitor>
{
    SemanticsDeclConformancesVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }

    void visitDecl(Decl*) {}
    void visitDeclGroup(DeclGroup*) {}

    // Any user-defined type may have declared interface conformances,
    // which we should check.
    //
    void visitAggTypeDecl(AggTypeDecl* aggTypeDecl) { checkAggTypeConformance(aggTypeDecl); }

    // Conformances can also come via `extension` declarations, and
    // we should check them against the type(s) being extended.
    //
    void visitExtensionDecl(ExtensionDecl* extensionDecl)
    {
        // Ignore function extensions.
        if (auto targetType = as<DeclRefType>(extensionDecl->targetType))
        {
            if (targetType->getDeclRef().as<FunctionDeclBase>())
                return;
        }

        checkExtensionConformance(extensionDecl);
    }

    // Build witness tables for generic type constraints to establish canonical
    // inheritance paths for diamond conformance patterns.
    //
    void visitGenericDecl(GenericDecl* genericDecl)
    {
        checkGenericConstraintConformances(genericDecl);
    }
};

// Check that function extensions only conform to `[__FunctionInterface]` interfaces.
struct SemanticsDeclFunctionConformancesVisitor
    : public SemanticsDeclVisitorBase,
      public DeclVisitor<SemanticsDeclFunctionConformancesVisitor>
{
    SemanticsDeclFunctionConformancesVisitor(SemanticsContext const& outer)
        : SemanticsDeclVisitorBase(outer)
    {
    }
    void visitDecl(Decl*) {}
    void visitDeclGroup(DeclGroup*) {}

    void visitExtensionDecl(ExtensionDecl* extensionDecl)
    {
        // Only process extensions on functions.
        if (auto targetType = as<DeclRefType>(extensionDecl->targetType))
        {
            if (targetType->getDeclRef().as<FunctionDeclBase>())
            {
                // Check that all inherited interfaces have [__FunctionInterface].
                for (auto inheritanceDecl : extensionDecl->getMembersOfType<InheritanceDecl>())
                {
                    if (auto baseType = as<DeclRefType>(inheritanceDecl->base.type))
                    {
                        if (auto interfaceDecl = baseType->getDeclRef().as<InterfaceDecl>())
                        {
                            if (!interfaceDecl.getDecl()
                                     ->findModifier<FunctionInterfaceAttribute>())
                            {
                                getSink()->diagnose(
                                    Diagnostics::InterfaceMissingFunctionInterfaceAttribute{
                                        .decl = interfaceDecl.getDecl(),
                                        .location = extensionDecl->loc});
                            }
                        }
                    }
                }

                checkExtensionConformance(extensionDecl);
            }
        }
    }
};

void registerBuiltinDecl(SharedASTBuilder* sharedASTBuilder, Decl* decl)
{
    if (auto builtinMod = decl->findModifier<BuiltinTypeModifier>())
    {
        sharedASTBuilder->registerBuiltinDecl(decl, builtinMod);
    }
    if (auto magicMod = decl->findModifier<MagicTypeModifier>())
    {
        sharedASTBuilder->registerMagicDecl(decl, magicMod);
    }
    if (auto builtinRequirement = decl->findModifier<BuiltinRequirementModifier>())
    {
        sharedASTBuilder->registerBuiltinRequirementDecl(decl, builtinRequirement);
    }
}


void registerBuiltinDecl(ASTBuilder* astBuilder, Decl* decl)
{
    registerBuiltinDecl(astBuilder->getSharedASTBuilder(), decl);
}


/// Recursively register any builtin declarations that need to be attached to the `session`.
///
/// This function should only be needed for declarations in the core module.
///
static void _registerBuiltinDeclsRec(Session* session, Decl* decl)
{
    SharedASTBuilder* sharedASTBuilder = session->getSharedASTBuilder();

    registerBuiltinDecl(sharedASTBuilder, decl);

    if (auto containerDecl = as<ContainerDecl>(decl))
    {
        for (auto childDecl : containerDecl->getDirectMemberDecls())
        {
            if (as<ScopeDecl>(childDecl))
                continue;

            _registerBuiltinDeclsRec(session, childDecl);
        }
    }
    if (auto genericDecl = as<GenericDecl>(decl))
    {
        _registerBuiltinDeclsRec(session, genericDecl->inner);
    }
}

void registerBuiltinDecls(Session* session, Decl* decl)
{
    _registerBuiltinDeclsRec(session, decl);
}

void _collectBuiltinDeclsThatNeedRegistrationRec(Decl* decl, List<Decl*>& ioDecls)
{
    if (decl->findModifier<BuiltinTypeModifier>())
    {
        ioDecls.add(decl);
    }
    else if (decl->findModifier<MagicTypeModifier>())
    {
        ioDecls.add(decl);
    }
    else if (decl->findModifier<BuiltinRequirementModifier>())
    {
        ioDecls.add(decl);
    }

    if (auto containerDecl = as<ContainerDecl>(decl))
    {
        for (auto childDecl : containerDecl->getDirectMemberDecls())
        {
            if (as<ScopeDecl>(childDecl))
                continue;

            _collectBuiltinDeclsThatNeedRegistrationRec(childDecl, ioDecls);
        }
    }
    if (auto genericDecl = as<GenericDecl>(decl))
    {
        _collectBuiltinDeclsThatNeedRegistrationRec(genericDecl->inner, ioDecls);
    }
}

void collectBuiltinDeclsThatNeedRegistration(ModuleDecl* moduleDecl, List<Decl*>& outDecls)
{
    _collectBuiltinDeclsThatNeedRegistrationRec(moduleDecl, outDecls);
}

Type* unwrapArrayType(Type* type)
{
    for (;;)
    {
        if (auto arrayType = as<ArrayExpressionType>(type))
            type = arrayType->getElementType();
        else
            return type;
    }
}

Type* unwrapModifiedType(Type* type)
{
    for (;;)
    {
        if (auto modType = as<ModifiedType>(type))
            type = modType->getBase();
        else
            return type;
    }
}

void discoverExtensionDecls(List<ExtensionDecl*>& decls, Decl* parent)
{
    if (auto extDecl = as<ExtensionDecl>(parent))
        decls.add(extDecl);
    if (auto containerDecl = as<ContainerDecl>(parent))
    {
        for (auto child : containerDecl->getDirectMemberDecls())
        {
            discoverExtensionDecls(decls, child);
        }
    }
    if (auto genericDecl = as<GenericDecl>(parent))
    {
        discoverExtensionDecls(decls, genericDecl->inner);
    }
}

// Collect every `namespace` declaration rooted at `parent`. Only module, namespace, and file scopes
// can lexically contain a nested `namespace`, so recursion descends through exactly those
// (`NamespaceDeclBase` covers `ModuleDecl` + `NamespaceDecl`; a `FileDecl` carries the decls of an
// `__include`d/`implementing` module fragment) and not into struct/function/etc. bodies or generic
// wrappers, where a `namespace` can never appear.
void discoverNamespaceDecls(List<NamespaceDecl*>& decls, Decl* parent)
{
    if (auto namespaceDecl = as<NamespaceDecl>(parent))
        decls.add(namespaceDecl);
    // Only recurse into the scopes that can lexically contain a `namespace`:
    // module/namespace scopes (`NamespaceDeclBase`) and the decls of an
    // `__include`d/`implementing` fragment (`FileDecl`) -- not struct/function
    // bodies (also `ContainerDecl`s) or generic wrappers, where a `namespace`
    // never appears. Both of those gating types derive from `ContainerDecl`, so
    // the cast is total here.
    if (as<NamespaceDeclBase>(parent) || as<FileDecl>(parent))
    {
        for (auto child : as<ContainerDecl>(parent)->getDirectMemberDecls())
        {
            discoverNamespaceDecls(decls, child);
        }
    }
}

void SemanticsDeclVisitorBase::checkModule(ModuleDecl* moduleDecl)
{
    // When we are dealing with code from the core modules,
    // there is a potential problem where we might need to look
    // up built-in types like `Int` through the session (e.g.,
    // to determine the type for an integer literal), but those
    // types might not have been registered yet. We solve that
    // by doing a pre-process on the core module code to find
    // and register any built-in declarations.
    //
    // TODO: This could be factored into another visitor pass
    // that fits the more standard checking below, but that would
    // seemingly add overhead to checking things other than
    // the core module.
    //
    if (isFromCoreModule(moduleDecl))
    {
        _registerBuiltinDeclsRec(getSession(), moduleDecl);
    }

    if (auto firstDeclInModule = moduleDecl->getFirstDirectMemberDecl())
    {
        if (as<ImplementingDecl>(firstDeclInModule))
        {
            if (!getShared()->isInLanguageServer())
            {
                // A primary module file can't start with an "implementing" declaration.
                getSink()->diagnose(Diagnostics::PrimaryModuleFileCannotStartWithImplementingDecl{
                    .decl = firstDeclInModule});
            }
        }
        else if (!as<ModuleDeclarationDecl>(firstDeclInModule))
        {
            // A primary module file must start with a `module` declaration.
            // TODO: this warning is disabled for now to free users from massive change for now.
#if 0
                getSink()->diagnose(Diagnostics::PrimaryModuleFileMustStartWithModuleDecl{.decl = firstMember});
#endif
        }
    }

    if (moduleDecl->findModifier<PublicModifier>())
    {
        moduleDecl->defaultVisibility = DeclVisibility::Public;
    }

    // We need/want to visit any `import` declarations before
    // anything else, to make sure that scoping works.
    //
    // TODO: This could be factored into another visitor pass
    // that fits more with the standard checking below.
    //
    for (auto importDecl : moduleDecl->getMembersOfType<ImportDecl>())
    {
        ensureDecl(importDecl, DeclCheckState::DefinitionChecked);
    }

    // Next, make sure all `__include` decls are processed and the referenced
    // files are parsed.
    auto visitIncludeDecls = [&](ContainerDecl* fileDecl)
    {
        for (Index i = 0; i < fileDecl->getDirectMemberDeclCount(); i++)
        {
            auto decl = fileDecl->getDirectMemberDecl(i);
            if (auto includeDecl = as<IncludeDecl>(decl))
            {
                ensureDecl(includeDecl, DeclCheckState::DefinitionChecked);
            }
            else if (auto implementingDecl = as<ImplementingDecl>(decl))
            {
                ensureDecl(implementingDecl, DeclCheckState::DefinitionChecked);
            }
            else if (auto importDecl = as<ImportDecl>(decl))
            {
                ensureDecl(importDecl, DeclCheckState::DefinitionChecked);
            }
        }
    };
    visitIncludeDecls(moduleDecl);
    for (Index i = 0; i < moduleDecl->getDirectMemberDeclCount(); i++)
    {
        if (auto fileDecl = as<FileDecl>(moduleDecl->getDirectMemberDecl(i)))
            visitIncludeDecls(fileDecl);
    }

    // The entire goal of semantic checking is to get all of the
    // declarations in the module up to `DeclCheckState::DefinitionChecked`.
    //
    // The main catch is that checking one declaration A up to state M
    // may required that declaration B is checked up to state N.
    // A call to `ensureDecl(B, N)` can guarantee that things are checked
    // when and where we need them, but that runs the risk of creating
    // very deep recursion in the semantic checking.
    //
    // Instead, we would rather do more breadth-first checking,
    // where everything gets checked up to state 1, 2, ...
    // before anything gets too far ahead.
    // We will therefore enumerate the states/phases for checking,
    // and then iteratively try to update all declarations to each
    // state in turn.
    //
    // Note: for a simpler language we could eliminate `ensureDecl`
    // completely and *just* have these phases of checking.
    // Unfortunately, we have some circularity between the phases:
    //
    // * Checking an overloaded call requires knowing the parameter
    //   types of all candidate callees.
    //
    // * Checking the parameter type of a function requires being
    //   able to check type expressions.
    //
    // * A type expression like `vector<T, N>` may have an arbitary
    //   expression for `N`.
    //
    // * An arbitrary expression may include function calls, which
    //   may be to overloaded functions.
    //
    // Languages like C++ solve the apparent problem by making
    // restrictions on order of declaration/definition (and by
    // requiring forward declarations or the `template`/`typename`
    // keywrods in some cases).
    //
    // TODO: We could eventually eliminate the potential recursion
    // in checking by splitting each phase into a "requirements gathering"
    // step and an actual execution step.
    //
    // When checking a declaration D up to state S, the requirements
    // gathering step would produce a list of pairs `(someDecl, someState)`
    // indicating that `someDecl` must be in `someState` before the
    // actual execution of checking for `(D,S)` can proceeed. The checker
    // can then produce an elaborated dependency graph and select nodes
    // for execution in an order that satisfies all the dependencies.
    //
    // Such a more elaborate checking scheme will have to wait for another
    // day, but might be worth it (or even necessary) if/when we want to
    // support incremental compilation.
    //
    DeclCheckState states[] = {
        DeclCheckState::ScopesWired,
        DeclCheckState::ReadyForReference,
        DeclCheckState::ReadyForLookup,
        DeclCheckState::ReadyForConformances,
        DeclCheckState::DefinitionChecked,
        DeclCheckState::CapabilityChecked,
    };

    // Drive every namespace in the module to `ScopesWired` before the extension-first pass below.
    // That pass resolves each extension's target type (and generic signature) by unqualified name
    // lookup, which reads only the already-wired sibling-scope chain. A `namespace N` reopened
    // across sibling `__include`/`implementing` fragments is merged into that chain only when its
    // `NamespaceDecl` reaches `ScopesWired` (SemanticsDeclScopeWiringVisitor::visitNamespaceDecl ->
    // addSiblingScopeForContainerDecl); driving an extension to `ReadyForLookup` does not advance
    // any namespace, so without this the header resolves against an unwired scope: the unqualified
    // name fails to resolve (E30015 "undefined identifier"), which then cascades into E30855
    // ("generic parameter not referenced by extension target type") because the extension's target
    // type became `error`.
    //
    // Every namespace must be wired, not just each extension's lexically-enclosing one: an
    // extension's target type may live in a *different* namespace fragment than the extension
    // itself -- e.g. a file-scope `extension N::T` whose `T` is declared in another fragment's
    // reopened `namespace N` (#11532). Wiring only the enclosing namespace covers the case where
    // the extension is lexically inside the reopened namespace (#11531) but not the file-scope
    // case, so this all-namespaces pass subsumes that narrower walk.
    //
    // Restricted to namespaces -- NOT `ensureAllDeclsRec(moduleDecl, ScopesWired)` over every decl:
    // `ensureDecl` here advances only each `NamespaceDecl` itself (and, via `visitNamespaceDecl`,
    // the direct `using` decls needed for scope wiring), never its ordinary members or extensions.
    // The broad alternative regressed core-module checking by prematurely advancing the standard
    // library's non-namespaced texture extensions (`extension _Texture<...>`), resolving their
    // target types into `error`. `discoverNamespaceDecls` collects only `NamespaceDecl`s (not
    // `ModuleDecl`, also a `NamespaceDeclBase`), so the global module scope is left to the regular
    // pass. Fixes shader-slang/slang#11531 and shader-slang/slang#11532.
    List<NamespaceDecl*> namespaceDecls;
    discoverNamespaceDecls(namespaceDecls, moduleDecl);
    for (auto namespaceDecl : namespaceDecls)
    {
        ensureDecl(namespaceDecl, DeclCheckState::ScopesWired);
    }

    // Discover and check all extension decls (after the namespace pre-pass above, but before
    // general member checking).
    List<ExtensionDecl*> extensionDecls;
    discoverExtensionDecls(extensionDecls, moduleDecl);

    for (auto s : states)
    {
        for (auto extensionDecl : extensionDecls)
        {
            ensureDecl(extensionDecl, s);
        }
        // We only need to check extension decls up to ReadyForLookup
        // so they are properly registered in type inheritance infos.
        if (s == DeclCheckState::ReadyForLookup)
            break;
    }

    // With extensions taken care of, we can now check the remaining decls.
    for (auto s : states)
    {
        // When advancing to state `s` we will recursively
        // advance all declarations rooted in the module
        // up to `s`.
        //
        // TODO: In cases where a large module is split across files,
        // we could potentially parallelize front-end compilation by
        // having multiple instances of the front end where each is
        // only responsible for those declarations in a given file.
        //
        // Under that model, we might only apply later phases of
        // checking (notably the final push to `DeclState::Checked`)
        // to the subset of declarations coming from a given source
        // file.
        //
        ensureAllDeclsRec(moduleDecl, s);
        ensureRegisteredSynthesizedDecls(s);
    }

    // Once we have completed the above loop, all declarations not
    // nested in function bodies should be in `DeclState::Checked`.
    // Furthermore, because a fully checked function will have checked
    // its body, this also means that all function bodies and the
    // declarations they contain should be fully checked.
}

static bool _hasNoDiffReturnSignature(CallableDecl* decl, Type* type)
{
    return decl->findModifier<NoDiffModifier>() || doesTypeHaveNoDiffModifier(type);
}

static void _configureSynthesizedParamDecl(
    ASTBuilder* astBuilder,
    ParamDecl* paramDecl,
    ParamInfo const& paramInfo);

static void _configureSynthesizedEffectiveThisParam(
    ASTBuilder* astBuilder,
    CallableDecl* callableDecl,
    ThisExpr* thisExpr,
    ParamInfo const& paramInfo);

static bool _doParamInfosMatch(ParamInfo const& satisfyingInfo, ParamInfo const& requiredInfo)
{
    return satisfyingInfo.mode == requiredInfo.mode &&
           satisfyingInfo.type->equals(requiredInfo.type);
}

static bool _doEffectiveThisParamInfosMatch(
    std::optional<ParamInfo> const& satisfyingInfo,
    std::optional<ParamInfo> const& requiredInfo)
{
    if (satisfyingInfo.has_value() != requiredInfo.has_value())
        return false;
    if (!satisfyingInfo)
        return true;
    return _doParamInfosMatch(*satisfyingInfo, *requiredInfo);
}

bool SemanticsVisitor::doesSignatureMatchRequirement(
    DeclRef<CallableDecl> satisfyingMemberDeclRef,
    DeclRef<CallableDecl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable)
{

    // A direct witness must have exactly the receiver ABI promised by the requirement: either both
    // declarations have no effective `this` parameter, or both have one with the same substituted
    // type and parameter-passing mode. Some mismatches can be adapted semantically, but those must
    // take the existing wrapper-synthesis path instead of installing the implementation directly.
    auto satisfyingThisInfo = findEffectiveThisParamInfo(satisfyingMemberDeclRef);
    auto requiredThisInfo = findEffectiveThisParamInfo(requiredMemberDeclRef);
    if (!_doEffectiveThisParamInfosMatch(satisfyingThisInfo, requiredThisInfo))
        return false;

    if (auto aliasDecl = satisfyingMemberDeclRef.as<FuncAliasDecl>())
    {
        satisfyingMemberDeclRef = substituteDeclRef(
                                      SubstitutionSet(aliasDecl),
                                      getCurrentASTBuilder(),
                                      aliasDecl.getDecl()->targetDeclRef)
                                      .as<CallableDecl>();
    }

    if (auto funcType = requiredMemberDeclRef.getDecl()->funcType.type)
    {
        // If the requirement is defined using a funcType, we'll check the effective
        // func-types
        //
        auto resolvedFuncType = as<Type>(
            as<Type>(funcType->substitute(m_astBuilder, SubstitutionSet(requiredMemberDeclRef)))
                ->resolve());

        auto targetFuncType = getTypeForDeclRef(
            m_astBuilder,
            satisfyingMemberDeclRef,
            satisfyingMemberDeclRef.getLoc());

        if (!targetFuncType.type->getCanonicalType()->equals(resolvedFuncType->getCanonicalType()))
            return false;
    }
    else
    {
        // Test conformance by using signature induced by parameter declarations.
        // A signature matches the required one if it has the right number of parameters,
        // and those parameters have the right types, and also the result/return type
        // is the required one.
        //
        auto requiredParams = getParameters(m_astBuilder, requiredMemberDeclRef).toArray();
        auto satisfyingParams = getParameters(m_astBuilder, satisfyingMemberDeclRef).toArray();
        auto paramCount = requiredParams.getCount();
        if (satisfyingParams.getCount() != paramCount)
            return false;

        for (Index paramIndex = 0; paramIndex < paramCount; ++paramIndex)
        {
            auto requiredParam = requiredParams[paramIndex];
            auto satisfyingParam = satisfyingParams[paramIndex];
            auto requiredParamInfo = getParamInfo(m_astBuilder, requiredParam);
            auto satisfyingParamInfo = getParamInfo(m_astBuilder, satisfyingParam);
            if (!_doParamInfosMatch(satisfyingParamInfo, requiredParamInfo))
                return false;
        }

        auto requiredResultType = getResultType(m_astBuilder, requiredMemberDeclRef);
        auto satisfyingResultType = getResultType(m_astBuilder, satisfyingMemberDeclRef);
        if (!requiredResultType->equals(satisfyingResultType))
            return false;

        if (_hasNoDiffReturnSignature(requiredMemberDeclRef.getDecl(), requiredResultType) !=
            _hasNoDiffReturnSignature(satisfyingMemberDeclRef.getDecl(), satisfyingResultType))
        {
            return false;
        }

        auto requiredErrorType = getErrorCodeType(m_astBuilder, requiredMemberDeclRef);
        auto satisfyingErrorType = getErrorCodeType(m_astBuilder, satisfyingMemberDeclRef);
        if (!requiredErrorType->equals(satisfyingErrorType))
            return false;
    }

    _addMethodWitness(witnessTable, requiredMemberDeclRef, satisfyingMemberDeclRef);

    return true;
}

SubtypeWitness* SemanticsVisitor::isFuncForwardDifferentiable(DeclRef<CallableDecl> declRef)
{
    ensureDecl(declRef, DeclCheckState::ReadyForLookup);

    auto calleeType = DeclRefType::create(getASTBuilder(), declRef);
    auto forwardDifferentiableType = getForwardDiffFuncInterfaceType(calleeType);
    return tryGetSubtypeWitness(calleeType, forwardDifferentiableType);
}

SubtypeWitness* SemanticsVisitor::isFuncBackwardDifferentiable(DeclRef<CallableDecl> declRef)
{
    ensureDecl(declRef, DeclCheckState::ReadyForLookup);

    auto calleeType = DeclRefType::create(getASTBuilder(), declRef);
    auto backwardDifferentiableType = getBackwardDiffFuncInterfaceType(calleeType);
    return tryGetSubtypeWitness(calleeType, backwardDifferentiableType);
}

bool SemanticsVisitor::doesAccessorMatchRequirement(
    DeclRef<AccessorDecl> satisfyingMemberDeclRef,
    DeclRef<AccessorDecl> requiredMemberDeclRef)
{
    // We require the AST node class of the satisfying accessor
    // to be a subclass of the one from the required accessor.
    //
    // For our current accessor types, this amounts to requiring
    // an exact match, but using a subtype test means that if
    // we ever add an `ExtraSpecialGetDecl` that is a subclass
    // of `GetDecl`, then one of those would be able to satisfy
    // a `get` requirement.
    //
    auto satisfyingMemberClass = satisfyingMemberDeclRef.getDecl()->getClass();
    auto requiredMemberClass = requiredMemberDeclRef.getDecl()->getClass();
    if (!satisfyingMemberClass.isSubClassOf(requiredMemberClass))
        return false;

    // As with methods, an accessor can be entered directly in the witness table only when its
    // effective receiver parameters have the same ABI. Returning false here leaves adaptable
    // cases to the property/subscript accessor wrapper-synthesis path.
    auto satisfyingThisInfo = findEffectiveThisParamInfo(satisfyingMemberDeclRef);
    auto requiredThisInfo = findEffectiveThisParamInfo(requiredMemberDeclRef);
    if (!_doEffectiveThisParamInfosMatch(satisfyingThisInfo, requiredThisInfo))
        return false;

    // A setter's value parameter belongs to the accessor rather than its property/subscript
    // container. Compare its complete semantic encoding here so that modes and type modifiers such
    // as `no_diff` participate in direct-witness matching just as they do for method parameters.
    auto satisfyingParams = getParameters(m_astBuilder, satisfyingMemberDeclRef).toArray();
    auto requiredParams = getParameters(m_astBuilder, requiredMemberDeclRef).toArray();
    if (satisfyingParams.getCount() != requiredParams.getCount())
        return false;
    for (Index i = 0; i < requiredParams.getCount(); ++i)
    {
        auto satisfyingParamInfo = getParamInfo(m_astBuilder, satisfyingParams[i]);
        auto requiredParamInfo = getParamInfo(m_astBuilder, requiredParams[i]);
        if (!_doParamInfosMatch(satisfyingParamInfo, requiredParamInfo))
            return false;
    }

    // Accessor result types are fixed by the already-matched property/subscript storage type.

    return true;
}

bool SemanticsVisitor::doesPropertyMatchRequirement(
    DeclRef<PropertyDecl> satisfyingMemberDeclRef,
    DeclRef<PropertyDecl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    // The type of the satisfying member must match the type of the required member.
    //
    // Note: It is possible that a `get`-only property could be satisfied by
    // a declaration that uses a subtype of the requirement, but that would not
    // count as an "exact match" and we would rely on the logic to synthesize
    // a stub implementation in that case.
    //
    auto satisfyingType = getType(getASTBuilder(), satisfyingMemberDeclRef);
    auto requiredType = getType(getASTBuilder(), requiredMemberDeclRef);
    if (!requiredType->equals(satisfyingType))
        return false;

    // Each accessor in the requirement must be accounted for by an accessor
    // in the satisfying member.
    //
    // Note: it is fine for the satisfying member to provide *more* accessors
    // than the original declaration.
    //
    Dictionary<DeclRef<AccessorDecl>, DeclRef<AccessorDecl>> mapRequiredToSatisfyingAccessorDeclRef;
    for (auto requiredAccessorDeclRef :
         getMembersOfType<AccessorDecl>(m_astBuilder, requiredMemberDeclRef))
    {
        // We need to search for an accessor that can satisfy the requirement.
        //
        // For now we will do the simplest (and slowest) thing of a linear search,
        // which is mostly fine because the number of accessors is bounded.
        //
        bool found = false;
        for (auto satisfyingAccessorDeclRef :
             getMembersOfType<AccessorDecl>(m_astBuilder, satisfyingMemberDeclRef))
        {
            if (doesAccessorMatchRequirement(satisfyingAccessorDeclRef, requiredAccessorDeclRef))
            {
                // When we find a match on an accessor, we record it so that
                // we can set up the witness values later, but we do *not*
                // record it into the actual witness table yet, in case
                // a later accessor comes along that doesn't find a match.
                //
                mapRequiredToSatisfyingAccessorDeclRef.add(
                    requiredAccessorDeclRef,
                    satisfyingAccessorDeclRef);
                found = true;
                break;
            }
        }
        if (!found)
            return false;
    }

    // Once things are done, we will install the satisfying values
    // into the witness table for the requirements.
    //
    for (const auto& [key, value] : mapRequiredToSatisfyingAccessorDeclRef)
    {
        witnessTable->add(key.getDecl(), RequirementWitness(value));
    }

    // After setting the accessor entries in the witness table, we can then
    // go ahead and try to lower any type constraints on the accessors
    //
    for (const auto& [requirement, satisfying] : mapRequiredToSatisfyingAccessorDeclRef)
    {
        if (!doesTypeSatisfyConstraintRequirements(requirement, witnessTable))
        {
            // Diagnose.
            getSink()->diagnose(Diagnostics::AccessorDoesNotSatisfyTypeConstraintRequirements{
                .requirementDecl = requirement.getDecl(),
                .accessorDecl = satisfying.getDecl(),
            });
            return false;
        }
    }

    //
    // Note: the property declaration itself isn't something that
    // has a useful value/representation in downstream passes, so
    // we are mostly just installing it into the witness table
    // as a way to mark this requirement as being satisfied.
    //
    // TODO: It is possible that having a witness table entry that
    // doesn't actually map to any IR value could create a problem
    // in downstream passes. If such propblems arise, we should
    // probably create a new `RequirementWitness` case that
    // represents a witness value that is only needed by the front-end,
    // and that can be ignored by IR and emit logic.
    //
    witnessTable->add(requiredMemberDeclRef.getDecl(), RequirementWitness(satisfyingMemberDeclRef));
    return true;
}

bool SemanticsVisitor::doesSubscriptMatchRequirement(
    DeclRef<SubscriptDecl> satisfyingMemberDeclRef,
    DeclRef<SubscriptDecl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    // The result type and parameters of the satisfying member must match the type of the required
    // member.
    //
    auto requiredParams = getParameters(m_astBuilder, requiredMemberDeclRef).toArray();
    auto satisfyingParams = getParameters(m_astBuilder, satisfyingMemberDeclRef).toArray();
    auto paramCount = requiredParams.getCount();
    if (satisfyingParams.getCount() != paramCount)
        return false;

    for (Index paramIndex = 0; paramIndex < paramCount; ++paramIndex)
    {
        auto requiredParam = requiredParams[paramIndex];
        auto satisfyingParam = satisfyingParams[paramIndex];
        auto requiredParamInfo = getParamInfo(m_astBuilder, requiredParam);
        auto satisfyingParamInfo = getParamInfo(m_astBuilder, satisfyingParam);
        if (!_doParamInfosMatch(satisfyingParamInfo, requiredParamInfo))
            return false;
    }

    auto requiredResultType = getResultType(m_astBuilder, requiredMemberDeclRef);
    auto satisfyingResultType = getResultType(m_astBuilder, satisfyingMemberDeclRef);
    if (!requiredResultType->equals(satisfyingResultType))
        return false;

    // Each accessor in the requirement must be accounted for by an accessor
    // in the satisfying member.
    //
    // Note: it is fine for the satisfying member to provide *more* accessors
    // than the original declaration.
    //
    Dictionary<DeclRef<AccessorDecl>, DeclRef<AccessorDecl>> mapRequiredToSatisfyingAccessorDeclRef;
    for (auto requiredAccessorDeclRef :
         getMembersOfType<AccessorDecl>(m_astBuilder, requiredMemberDeclRef))
    {
        // We need to search for an accessor that can satisfy the requirement.
        //
        // For now we will do the simplest (and slowest) thing of a linear search,
        // which is mostly fine because the number of accessors is bounded.
        //
        bool found = false;
        for (auto satisfyingAccessorDeclRef :
             getMembersOfType<AccessorDecl>(m_astBuilder, satisfyingMemberDeclRef))
        {
            if (doesAccessorMatchRequirement(satisfyingAccessorDeclRef, requiredAccessorDeclRef))
            {
                // When we find a match on an accessor, we record it so that
                // we can set up the witness values later, but we do *not*
                // record it into the actual witness table yet, in case
                // a later accessor comes along that doesn't find a match.
                //
                mapRequiredToSatisfyingAccessorDeclRef.add(
                    requiredAccessorDeclRef,
                    satisfyingAccessorDeclRef);
                found = true;
                break;
            }
        }
        if (!found)
            return false;
    }

    // Once things are done, we will install the satisfying values
    // into the witness table for the requirements.
    //
    for (const auto& [key, value] : mapRequiredToSatisfyingAccessorDeclRef)
    {
        witnessTable->add(key.getDecl(), RequirementWitness(value));
    }

    // Once things are done, we will install the satisfying values
    // into the witness table for the requirements.
    //
    for (const auto& [requirement, satisfying] : mapRequiredToSatisfyingAccessorDeclRef)
    {
        if (!doesTypeSatisfyConstraintRequirements(requirement, witnessTable))
        {
            // Diagnose.
            getSink()->diagnose(Diagnostics::AccessorDoesNotSatisfyTypeConstraintRequirements{
                .requirementDecl = requirement.getDecl(),
                .accessorDecl = satisfying.getDecl(),
            });
            return false;
        }
    }

    //
    // Note: the subscript declaration itself isn't something that
    // has a useful value/representation in downstream passes, so
    // we are mostly just installing it into the witness table
    // as a way to mark this requirement as being satisfied.
    //
    witnessTable->add(requiredMemberDeclRef.getDecl(), RequirementWitness(satisfyingMemberDeclRef));
    return true;
}

bool SemanticsVisitor::doesVarMatchRequirement(
    DeclRef<VarDeclBase> satisfyingMemberDeclRef,
    DeclRef<VarDeclBase> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    // The type of the satisfying member must match the type of the required member.
    auto satisfyingType = getType(getASTBuilder(), satisfyingMemberDeclRef);
    auto requiredType = getType(getASTBuilder(), requiredMemberDeclRef);
    if (!satisfyingType->equals(requiredType))
        return false;

    for (auto modifier : requiredMemberDeclRef.getDecl()->modifiers)
    {
        bool found = false;
        for (auto satisfyingModifier : satisfyingMemberDeclRef.getDecl()->modifiers)
        {
            if (satisfyingModifier->astNodeType == modifier->astNodeType)
            {
                found = true;
                break;
            }
        }
        if (!found)
            return false;
    }

    IntVal* satisfyingVal = nullptr;
    if (isValidCompileTimeConstantType(satisfyingType))
    {
        satisfyingVal =
            tryConstantFoldDeclRef(satisfyingMemberDeclRef, ConstantFoldingKind::LinkTime, nullptr);
    }
    if (satisfyingVal)
    {
        witnessTable->add(requiredMemberDeclRef.getDecl(), RequirementWitness(satisfyingVal));
    }
    else
    {
        witnessTable->add(
            requiredMemberDeclRef.getDecl(),
            RequirementWitness(satisfyingMemberDeclRef));
    }
    return true;
}

bool SemanticsVisitor::doesGenericSignatureMatchRequirement(
    DeclRef<GenericDecl> satisfyingGenericDeclRef,
    DeclRef<GenericDecl> requiredGenericDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    // Ensure the satisfying generic's constraint decls are SignatureChecked before we count and
    // compare its members below -- that state populates each constraint's operands and flattens
    // `T : A & B` into separate members. This matcher is the single point that every generic
    // requirement match funnels through (module-scope, on-demand, and function-local), so the
    // invariant belongs here, not at any one producer (#12987). We advance the constraints
    // only (advancing the enclosing type would re-enter its in-progress conformance check), and
    // snapshot members first since flattening appends to the list.
    {
        List<Decl*> satisfyingDirectMembers;
        for (auto m : satisfyingGenericDeclRef.getDecl()->getDirectMemberDecls())
            satisfyingDirectMembers.add(m);
        for (auto m : satisfyingDirectMembers)
            if (isConstraintDecl(m))
                ensureDecl(m, DeclCheckState::SignatureChecked);
    }

    auto memberCount = requiredGenericDeclRef.getDecl()->getDirectMemberDeclCount();
    auto satisfyingMemberCount = satisfyingGenericDeclRef.getDecl()->getDirectMemberDeclCount();

    // We then want to check that the type/value parameters match in order,
    // and that the constraints match (but constraints can appear in any order,
    // interleaved with the type/value params).
    //
    auto requiredMemberDeclRefs = getMembers(m_astBuilder, requiredGenericDeclRef);
    auto satisfyingMemberDeclRefs = getMembers(m_astBuilder, satisfyingGenericDeclRef);

    // Separate type/value params from constraints for both required and satisfying generics.
    // Type/value params must appear in the same relative order, but constraints can be
    // interleaved freely among them.
    //

    auto getNonEmptyConstraintTargetDecl = [&](NonEmptyPackConstraintDecl* constraintDecl) -> Decl*
    {
        if (auto declRefExpr = as<DeclRefExpr>(constraintDecl->packExpr))
            return getDeclRef(m_astBuilder, declRefExpr).getDecl();
        return nullptr;
    };

    auto isParamDecl = [&](DeclRef<Decl> declRef) -> bool
    {
        if (as<GenericTypeParamDeclBase>(declRef))
            return true;
        if (as<GenericValueParamDecl>(declRef))
            return true;
        if (as<GenericValuePackParamDecl>(declRef))
            return true;
        return false;
    };

    List<DeclRef<Decl>> requiredParams;
    List<DeclRef<Decl>> requiredConstraints;
    for (Index i = 0; i < memberCount; i++)
    {
        auto m = requiredMemberDeclRefs[i];
        if (isConstraintDecl(m))
            requiredConstraints.add(m);
        else if (isParamDecl(m))
            requiredParams.add(m);
    }

    List<DeclRef<Decl>> satisfyingParams;
    List<DeclRef<Decl>> satisfyingConstraints;
    for (Index i = 0; i < satisfyingMemberCount; i++)
    {
        auto m = satisfyingMemberDeclRefs[i];
        if (isConstraintDecl(m))
            satisfyingConstraints.add(m);
        else if (isParamDecl(m))
            satisfyingParams.add(m);
    }

    // The number of type/value params and constraints must each match.
    if (requiredParams.getCount() != satisfyingParams.getCount())
        return false;
    if (requiredConstraints.getCount() != satisfyingConstraints.getCount())
        return false;

    //
    // We start by performing a superficial "structural" match of the type/value parameters
    // to ensure that the two generics have equivalent parameters in the same order.
    //
    // Note that in this step we do *not* make any checks on the actual types
    // involved in constraints, or on the types of value parameters. The reason
    // for this is that the types on those parameters could be dependent on
    // type parameters in the generic parameter list, and thus there could be
    // a mismatch at this point. For example, if we have:
    //
    //      interface IBase         { void doThing<T, U : IThing<T>>(); }
    //      struct Derived : IBase  { void doThing<X, Y : IThing<X>>(); }
    //
    // We clearly have a signature match here, but the constraint parameters for
    // `U : IThing<T>` and `Y : IThing<X>` have the problem that both the sub-type
    // and super-type they reference are not equivalent without substititions.
    //
    // We will deal with this issue after the structural matching is checked, at
    // which point we can actually verify things like types.
    //
    for (Index i = 0; i < requiredParams.getCount(); i++)
    {
        auto requiredMemberDeclRef = requiredParams[i];
        auto satisfyingMemberDeclRef = satisfyingParams[i];

        if (as<GenericTypeParamDeclBase>(requiredMemberDeclRef))
        {
            if (as<GenericTypeParamDeclBase>(satisfyingMemberDeclRef))
            {
                if ((requiredMemberDeclRef.as<GenericTypePackParamDecl>() != nullptr) !=
                    (satisfyingMemberDeclRef.as<GenericTypePackParamDecl>() != nullptr))
                    return false;
            }
            else
                return false;
        }
        else if (auto requiredValueParamDeclRef = requiredMemberDeclRef.as<GenericValueParamDecl>())
        {
            if (auto satisfyingValueParamDeclRef =
                    satisfyingMemberDeclRef.as<GenericValueParamDecl>())
            {
            }
            else
                return false;
        }
        else if (
            auto requiredValuePackParamDeclRef =
                requiredMemberDeclRef.as<GenericValuePackParamDecl>())
        {
            if (auto satisfyingValuePackParamDeclRef =
                    satisfyingMemberDeclRef.as<GenericValuePackParamDecl>())
            {
            }
            else
                return false;
        }
        else
            return false;
    }

    for (Index i = 0; i < requiredConstraints.getCount(); i++)
    {
        auto requiredMemberDeclRef = requiredConstraints[i];
        auto satisfyingMemberDeclRef = satisfyingConstraints[i];

        if (as<GenericTypeConstraintDecl>(requiredMemberDeclRef))
        {
            if (!as<GenericTypeConstraintDecl>(satisfyingMemberDeclRef))
                return false;
        }
        else if (
            auto requiredTypeCoercionConstraintDeclRef =
                requiredMemberDeclRef.as<TypeCoercionConstraintDecl>())
        {
            if (!satisfyingMemberDeclRef.as<TypeCoercionConstraintDecl>())
                return false;
        }
        else if (
            auto requiredNonEmptyConstraintDeclRef =
                requiredMemberDeclRef.as<NonEmptyPackConstraintDecl>())
        {
            if (!satisfyingMemberDeclRef.as<NonEmptyPackConstraintDecl>())
                return false;
        }
        else if (requiredMemberDeclRef.as<GenericVariadicPackCountConstraintDecl>())
        {
            if (!satisfyingMemberDeclRef.as<GenericVariadicPackCountConstraintDecl>())
                return false;
        }
        else if (
            auto requiredHasDiffTypeInfoConstraintDeclRef =
                requiredMemberDeclRef.as<HasDiffTypeInfoConstraintDecl>())
        {
            if (!satisfyingMemberDeclRef.as<HasDiffTypeInfoConstraintDecl>())
                return false;

            // The actual constrained type comparison depends on the specialized
            // substitution environment and is validated below.
        }
        else
            return false;
    }

    // In order to compare the inner declarations of the two generics, we need to
    // align them so that they are expressed in terms of consistent type parameters.
    //
    // For example, we might have:
    //
    //      interface IBase           { void doThing<T>(T val); }
    //      struct    Derived : IBase { void doThing<U>(U val); }
    //
    // If we directly compare the signatures of the inner `doThing` function declarations,
    // we'd find a mismatch between the `T` and `U` types of the `val` parameter.
    //
    // We can get around this mismatch by constructing a specialized reference and
    // then doing the comparison. For example `IBase::doThing<X>` and `Derived::doThing<X>`
    // should both have the signature `X -> void`.
    //
    // The one big detail that we need to be careful about here is that when we
    // recursively call `doesMemberSatisfyRequirement`, that will eventually store
    // the satisfying `DeclRef` as the value for the given requirement key, and we don't
    // want to store a specialized reference like `Derived::doThing<X>` - we need to
    // somehow store the original declaration.
    //
    // The solution here is to specialize the *required* declaration to the parameters
    // compare `Derived::doThing` against `IBase::doThing<U>` where the `U` there is
    // the parameter of `Dervived::doThing`.
    //
    List<Val*> requiredSubstArgs;

    // Build substitution args from the ordered type/value parameters.
    for (Index i = 0; i < requiredParams.getCount(); i++)
    {
        auto requiredMemberDeclRef = requiredParams[i];
        auto satisfyingMemberDeclRef = satisfyingParams[i];

        if (auto requiredTypeParamDeclRef = requiredMemberDeclRef.as<GenericTypeParamDeclBase>())
        {
            auto satisfyingTypeParamDeclRef =
                satisfyingMemberDeclRef.as<GenericTypeParamDeclBase>();
            SLANG_ASSERT(satisfyingTypeParamDeclRef);
            auto satisfyingType = DeclRefType::create(m_astBuilder, satisfyingTypeParamDeclRef);

            requiredSubstArgs.add(satisfyingType);
        }
        else if (auto requiredValueParamDeclRef = requiredMemberDeclRef.as<GenericValueParamDecl>())
        {
            auto satisfyingValueParamDeclRef = satisfyingMemberDeclRef.as<GenericValueParamDecl>();
            SLANG_ASSERT(satisfyingValueParamDeclRef);

            auto satisfyingVal = m_astBuilder->getOrCreate<DeclRefIntVal>(
                requiredValueParamDeclRef.getDecl()->getType(),
                satisfyingValueParamDeclRef);
            satisfyingVal->getDeclRef() = satisfyingValueParamDeclRef;

            requiredSubstArgs.add(satisfyingVal);
        }
        else if (
            auto requiredValuePackParamDeclRef =
                requiredMemberDeclRef.as<GenericValuePackParamDecl>())
        {
            auto satisfyingValuePackParamDeclRef =
                satisfyingMemberDeclRef.as<GenericValuePackParamDecl>();
            SLANG_ASSERT(satisfyingValuePackParamDeclRef);

            auto satisfyingVal = m_astBuilder->getOrCreate<DeclRefIntVal>(
                requiredValuePackParamDeclRef.getDecl()->getType(),
                satisfyingValuePackParamDeclRef);

            requiredSubstArgs.add(satisfyingVal);
        }
    }

    for (Index i = 0; i < requiredConstraints.getCount(); i++)
    {
        auto requiredMemberDeclRef = requiredConstraints[i];
        auto satisfyingMemberDeclRef = satisfyingConstraints[i];

        if (auto requiredTypeConstraintDeclRef =
                requiredMemberDeclRef.as<GenericTypeConstraintDecl>())
        {
            auto satisfyingConstraintDeclRef =
                satisfyingMemberDeclRef.as<GenericTypeConstraintDecl>();
            SLANG_ASSERT(satisfyingConstraintDeclRef);

            auto satisfyingSubType = getSub(m_astBuilder, satisfyingConstraintDeclRef);
            auto satisfyingSuperType = getSup(m_astBuilder, satisfyingConstraintDeclRef);
            // Fail loud rather than build a witness from a null type: a self-referential
            // constraint can still trip ensureDecl's cyclic-reference guard and leave these null.
            SLANG_RELEASE_ASSERT(satisfyingSubType && satisfyingSuperType);
            auto satisfyingWitness = m_astBuilder->getDeclaredSubtypeWitness(
                satisfyingSubType,
                satisfyingSuperType,
                satisfyingConstraintDeclRef);

            requiredSubstArgs.add(satisfyingWitness);
        }
        else if (
            auto requiredTypeCoercionConstraintDeclRef =
                requiredMemberDeclRef.as<TypeCoercionConstraintDecl>())
        {
            auto satisfyingConstraintDeclRef =
                satisfyingMemberDeclRef.as<TypeCoercionConstraintDecl>();
            SLANG_ASSERT(satisfyingConstraintDeclRef);

            auto satisfyingFromType = getFromType(m_astBuilder, satisfyingConstraintDeclRef);
            auto satisfyingToType = getToType(m_astBuilder, satisfyingConstraintDeclRef);
            SLANG_RELEASE_ASSERT(satisfyingFromType && satisfyingToType);
            auto satisfyingWitness =
                m_astBuilder->getBuiltinTypeCoercionWitness(satisfyingFromType, satisfyingToType);

            requiredSubstArgs.add(satisfyingWitness);
        }
        else if (
            auto requiredNonEmptyConstraintDeclRef =
                requiredMemberDeclRef.as<NonEmptyPackConstraintDecl>())
        {
            auto satisfyingConstraintDeclRef =
                satisfyingMemberDeclRef.as<NonEmptyPackConstraintDecl>();
            SLANG_ASSERT(satisfyingConstraintDeclRef);
            auto satisfyingPackVal =
                _getNonEmptyConstraintPackVal(m_astBuilder, satisfyingConstraintDeclRef);
            SLANG_ASSERT(satisfyingPackVal);
            if (!satisfyingPackVal)
                satisfyingPackVal = m_astBuilder->getErrorType();
            requiredSubstArgs.add(m_astBuilder->getNonEmptyPackWitness(satisfyingPackVal));
        }
        else if (
            auto requiredPackCountConstraintDeclRef =
                requiredMemberDeclRef.as<GenericVariadicPackCountConstraintDecl>())
        {
            // Requirement matching constructs substitution args for the
            // required signature from the satisfying signature. A pack-count
            // constraint contributes a declared witness here, just like
            // `nonempty(I)`, so the later specialized comparison can read the
            // required proof under the satisfying generic's parameters.
            auto satisfyingConstraintDeclRef =
                satisfyingMemberDeclRef.as<GenericVariadicPackCountConstraintDecl>();
            SLANG_ASSERT(satisfyingConstraintDeclRef);
            requiredSubstArgs.add(
                m_astBuilder->getDeclaredVariadicPackCountWitness(satisfyingConstraintDeclRef));
        }
        else if (
            auto requiredHasDiffTypeInfoConstraintDeclRef =
                requiredMemberDeclRef.as<HasDiffTypeInfoConstraintDecl>())
        {
            auto satisfyingConstraintDeclRef =
                satisfyingMemberDeclRef.as<HasDiffTypeInfoConstraintDecl>();
            SLANG_ASSERT(satisfyingConstraintDeclRef);
            requiredSubstArgs.add(
                m_astBuilder->getHasDiffTypeInfoWitness(satisfyingConstraintDeclRef));
        }
    }

    // Now that we have computed a set of specialization arguments that will
    // specialize the generic requirement at the type parameters of the satisfying
    // generic, we can construct a reference to that declaration and re-run some
    // of the earlier checking logic with more type information usable.
    //
    auto specializedRequiredGenericInnerDeclRef = m_astBuilder->getGenericAppDeclRef(
        requiredGenericDeclRef,
        requiredSubstArgs.getArrayView());

    // Check ordered type/value parameters in detail.
    for (Index i = 0; i < requiredParams.getCount(); i++)
    {
        auto requiredMemberDeclRef = requiredParams[i];
        auto satisfyingMemberDeclRef = satisfyingParams[i];

        if (auto requiredTypeParamDeclRef = requiredMemberDeclRef.as<GenericTypeParamDeclBase>())
        {
            [[maybe_unused]] auto satisfyingTypeParamDeclRef =
                satisfyingMemberDeclRef.as<GenericTypeParamDeclBase>();
            SLANG_ASSERT(satisfyingTypeParamDeclRef);

            // There are no additional checks we need to make on plain old
            // type parameters at this point.
            //
            // TODO: If we ever support having type parameters of higher kinds,
            // then this is possibly where we'd want to check that the kinds of
            // the two parameters match.
            //
        }
        else if (auto requiredValueParamDeclRef = requiredMemberDeclRef.as<GenericValueParamDecl>())
        {
            auto satisfyingValueParamDeclRef = satisfyingMemberDeclRef.as<GenericValueParamDecl>();
            SLANG_ASSERT(satisfyingValueParamDeclRef);

            auto requiredParamType = getType(m_astBuilder, requiredValueParamDeclRef);
            auto satisfyingParamType = getType(m_astBuilder, satisfyingValueParamDeclRef);
            if (!satisfyingParamType->equals(requiredParamType))
                return false;
        }
        else if (
            auto requiredValuePackParamDeclRef =
                requiredMemberDeclRef.as<GenericValuePackParamDecl>())
        {
            auto satisfyingValuePackParamDeclRef =
                satisfyingMemberDeclRef.as<GenericValuePackParamDecl>();
            SLANG_ASSERT(satisfyingValuePackParamDeclRef);

            auto requiredParamType = getType(m_astBuilder, requiredValuePackParamDeclRef);
            auto satisfyingParamType = getType(m_astBuilder, satisfyingValuePackParamDeclRef);
            if (!satisfyingParamType->equals(requiredParamType))
                return false;
        }
    }

    for (Index i = 0; i < requiredConstraints.getCount(); i++)
    {
        auto requiredMemberDeclRef = requiredConstraints[i];
        auto satisfyingMemberDeclRef = satisfyingConstraints[i];

        if (auto requiredTypeConstraintDeclRef =
                requiredMemberDeclRef.as<GenericTypeConstraintDecl>())
        {
            auto satisfyingConstraintDeclRef =
                satisfyingMemberDeclRef.as<GenericTypeConstraintDecl>();
            SLANG_ASSERT(satisfyingConstraintDeclRef);

            // For a generic constraint parameter, we need to check that the sub-type
            // and super-type in the constraint both match.
            //
            // In current code the sub type will always be one of the generic type parameters,
            // and the super-type will always be an interface, but there should be no
            // need to make use of those additional details here.
            auto specializedRequiredConstraintDeclRef =
                m_astBuilder
                    ->getGenericAppDeclRef(
                        requiredGenericDeclRef,
                        requiredSubstArgs.getArrayView(),
                        requiredTypeConstraintDeclRef.getDecl())
                    .as<GenericTypeConstraintDecl>();
            auto requiredSubType = getSub(m_astBuilder, specializedRequiredConstraintDeclRef);
            auto satisfyingSubType = getSub(m_astBuilder, satisfyingConstraintDeclRef);
            SLANG_RELEASE_ASSERT(satisfyingSubType);
            if (!satisfyingSubType->equals(requiredSubType))
                return false;

            auto requiredSuperType = getSup(m_astBuilder, specializedRequiredConstraintDeclRef);
            auto satisfyingSuperType = getSup(m_astBuilder, satisfyingConstraintDeclRef);
            SLANG_RELEASE_ASSERT(satisfyingSuperType);
            if (!satisfyingSuperType->equals(requiredSuperType))
                return false;
        }
        else if (
            auto requiredTypeCoercionConstraintDeclRef =
                requiredMemberDeclRef.as<TypeCoercionConstraintDecl>())
        {
            auto satisfyingConstraintDeclRef =
                satisfyingMemberDeclRef.as<TypeCoercionConstraintDecl>();
            SLANG_ASSERT(satisfyingConstraintDeclRef);

            auto specializedRequiredConstraintDeclRef =
                m_astBuilder
                    ->getGenericAppDeclRef(
                        requiredGenericDeclRef,
                        requiredSubstArgs.getArrayView(),
                        requiredTypeCoercionConstraintDeclRef.getDecl())
                    .as<TypeCoercionConstraintDecl>();
            auto requiredFromType = getFromType(m_astBuilder, specializedRequiredConstraintDeclRef);
            auto satisfyingFromType = getFromType(m_astBuilder, satisfyingConstraintDeclRef);
            SLANG_RELEASE_ASSERT(satisfyingFromType);
            if (!satisfyingFromType->equals(requiredFromType))
                return false;

            auto requiredToType = getToType(m_astBuilder, specializedRequiredConstraintDeclRef);
            auto satisfyingToType = getToType(m_astBuilder, satisfyingConstraintDeclRef);
            SLANG_RELEASE_ASSERT(satisfyingToType);
            if (!satisfyingToType->equals(requiredToType))
                return false;

            if (requiredTypeCoercionConstraintDeclRef.getDecl()
                    ->hasModifier<ImplicitConversionModifier>() !=
                satisfyingConstraintDeclRef.getDecl()->hasModifier<ImplicitConversionModifier>())
                return false;
        }
        else if (
            auto requiredNonEmptyConstraintDeclRef =
                requiredMemberDeclRef.as<NonEmptyPackConstraintDecl>())
        {
            auto satisfyingConstraintDeclRef =
                satisfyingMemberDeclRef.as<NonEmptyPackConstraintDecl>();
            SLANG_ASSERT(satisfyingConstraintDeclRef);

            auto specializedRequiredConstraintDeclRef =
                m_astBuilder
                    ->getGenericAppDeclRef(
                        requiredGenericDeclRef,
                        requiredSubstArgs.getArrayView(),
                        requiredNonEmptyConstraintDeclRef.getDecl())
                    .as<NonEmptyPackConstraintDecl>();
            if (!specializedRequiredConstraintDeclRef)
                return false;

            if (getNonEmptyConstraintTargetDecl(specializedRequiredConstraintDeclRef.getDecl()) !=
                getNonEmptyConstraintTargetDecl(satisfyingConstraintDeclRef.getDecl()))
                return false;
        }
        else if (
            auto requiredPackCountConstraintDeclRef =
                requiredMemberDeclRef.as<GenericVariadicPackCountConstraintDecl>())
        {
            auto satisfyingConstraintDeclRef =
                satisfyingMemberDeclRef.as<GenericVariadicPackCountConstraintDecl>();
            SLANG_ASSERT(satisfyingConstraintDeclRef);

            auto specializedRequiredConstraintDeclRef =
                m_astBuilder
                    ->getGenericAppDeclRef(
                        requiredGenericDeclRef,
                        requiredSubstArgs.getArrayView(),
                        requiredPackCountConstraintDeclRef.getDecl())
                    .as<GenericVariadicPackCountConstraintDecl>();
            if (!specializedRequiredConstraintDeclRef)
                return false;

            // A declared pack-count witness proves only the exact substituted
            // requirement. Both the checked `countof(pack)` value and the
            // expected count must match, so `countof(I) == N` cannot satisfy a
            // callee that requires `countof(I) == M`, even when both counts
            // are abstract.
            auto requiredActualCount = getPackCountConstraintActualCount(
                m_astBuilder,
                specializedRequiredConstraintDeclRef);
            auto satisfyingActualCount =
                getPackCountConstraintActualCount(m_astBuilder, satisfyingConstraintDeclRef);
            if (satisfyingActualCount != requiredActualCount)
                return false;

            auto requiredCount = getPackCountConstraintExpectedCount(
                m_astBuilder,
                specializedRequiredConstraintDeclRef);
            auto satisfyingCount =
                getPackCountConstraintExpectedCount(m_astBuilder, satisfyingConstraintDeclRef);
            if (satisfyingCount != requiredCount)
                return false;
        }
        else if (
            auto requiredHasDiffTypeInfoConstraintDeclRef =
                requiredMemberDeclRef.as<HasDiffTypeInfoConstraintDecl>())
        {
            auto satisfyingConstraintDeclRef =
                satisfyingMemberDeclRef.as<HasDiffTypeInfoConstraintDecl>();
            SLANG_ASSERT(satisfyingConstraintDeclRef);

            auto specializedRequiredConstraintDeclRef =
                m_astBuilder
                    ->getGenericAppDeclRef(
                        requiredGenericDeclRef,
                        requiredSubstArgs.getArrayView(),
                        requiredHasDiffTypeInfoConstraintDeclRef.getDecl())
                    .as<HasDiffTypeInfoConstraintDecl>();
            if (!specializedRequiredConstraintDeclRef)
                return false;

            auto requiredType = getBaseType(m_astBuilder, specializedRequiredConstraintDeclRef);
            auto satisfyingType = getBaseType(m_astBuilder, satisfyingConstraintDeclRef);
            if (!requiredType || !satisfyingType || !satisfyingType->equals(requiredType))
                return false;
        }
    }

    // Note: the above logic really only applies to the case of an exact match on signature,
    // even down to the way that constraints were declared. We could potentially be more
    // relaxed by taking advantage of the way that various different generic signatures will
    // actually lower to the same IR generic signature.
    //
    // In theory, all we really care about when it comes to constraints is that the constraints
    // on the required and satisfying declaration are *equivalent*.
    //
    // More generally, a satisfying generic could actually provide *looser* constraints and
    // still work; all that matters is that it can be instantiated at any argument values/types
    // that are valid for the requirement.
    //
    // We leave both of those issues up to the synthesis path: if we do not find a member that
    // provides an exact match, then the compiler should try to synthesize one that is an exact
    // match and makes use of existing declarations that might have require defaulting of arguments
    // or type conversations to fit.

    // Once we've validated that the generic signatures are in an exact match, and devised type
    // arguments for the requirement to make the two align, we can recursively check the inner
    // declaration (whatever it is) for an exact match.
    //
    return doesMemberSatisfyRequirement(
        m_astBuilder->getMemberDeclRef(
            satisfyingGenericDeclRef,
            getInner(satisfyingGenericDeclRef)),
        specializedRequiredGenericInnerDeclRef,
        witnessTable);
}

bool SemanticsVisitor::doesTypeSatisfyConstraintRequirements(
    DeclRef<ContainerDecl> requirementDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    // Some requirements own generic constraints that must be satisfied after
    // the primary witness has been installed in the witness table. Constraints
    // written on an associated type are not handled here: the parser records
    // them as sibling interface requirements, so the normal conformance loop
    // checks them by key.
    //
    bool conformance = true;
    Val* witness = nullptr;

    // Later constraints may depend on witnesses from earlier constraints.
    // Add witnesses as we discover them so lookup can see them during this
    // check, and remember which ones to remove if the overall check fails.
    List<Decl*> addedRequirementDecls;
    for (auto requiredConstraintDeclRef :
         getMembersOfType<GenericTypeConstraintDecl>(m_astBuilder, requirementDeclRef))
    {
        auto requirementDecl = requiredConstraintDeclRef.getDecl();

        // Grab the type we expect to conform to from the constraint.
        auto requiredSuperType = getSup(m_astBuilder, requiredConstraintDeclRef);

        auto subType = getSub(m_astBuilder, requiredConstraintDeclRef);
        witness = tryGetSubtypeWitness(subType, requiredSuperType);

        if (witness)
        {
            auto genConstraint = as<GenericTypeConstraintDecl>(requirementDecl);
            if (genConstraint && genConstraint->isEqualityConstraint &&
                !isTypeEqualityWitness(witness))
                witness = nullptr;
        }
        if (witness)
        {
            // If a subtype witness was found, then the conformance
            // appears to hold, and we can satisfy that requirement.
            // Skip if already present; this function can be called multiple times
            // for the same witness table (e.g., when re-checking conformance during
            // specialization), and we must not double-add entries.
            if (!witnessTable->m_requirementDictionary.containsKey(requirementDecl))
            {
                witnessTable->add(requirementDecl, RequirementWitness(witness));
                addedRequirementDecls.add(requirementDecl);
            }
        }
        else
        {
            // Is our constraint optional? If so, then our conformance is still fine.
            // We'll just use a NoneWitness.
            //
            if (requirementDecl->findModifier<OptionalConstraintModifier>())
            {
                if (!witnessTable->m_requirementDictionary.containsKey(requirementDecl))
                {
                    witnessTable->add(requirementDecl, m_astBuilder->getOrCreate<NoneWitness>());
                    addedRequirementDecls.add(requirementDecl);
                }
                continue;
            }

            // If a witness couldn't be found, then the conformance
            // seems like it will fail.
            conformance = false;
        }
    }
    if (!conformance)
    {
        for (auto requirementDecl : addedRequirementDecls)
            witnessTable->removeRequirement(InterfaceRequirementKey(requirementDecl));
    }
    return conformance;
}

bool SemanticsVisitor::doesTypeSatisfyAssociatedTypeRequirement(
    Type* satisfyingType,
    DeclRef<AssocTypeDecl> requiredAssociatedTypeDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    if (auto declRefType = as<DeclRefType>(satisfyingType))
    {
        // If we are seeing a placeholder that awaits synthesis, return false now to trigger
        // auto synthesis.
        if (declRefType->getDeclRef().getDecl()->hasModifier<ToBeSynthesizedModifier>())
            return false;
    }

    // Register the satisfying type to the witness table. Any constraints
    // written on this associated type are sibling interface requirements, and
    // the normal conformance loop checks them by looking up this entry.
    auto requirementWitness = RequirementWitness(satisfyingType->getCanonicalType());
    witnessTable->m_requirementDictionary[requiredAssociatedTypeDeclRef.getDecl()] =
        requirementWitness;

    return true;
}

bool SemanticsVisitor::doesMemberSatisfyRequirement(
    DeclRef<Decl> memberDeclRef,
    DeclRef<Decl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    // Sanity check: if are checking whether a type `T`
    // implements, say, `IFoo::bar` and lookup of `bar`
    // in type `T` yielded `IFoo::bar`, then that shouldn't
    // be treated as a valid satisfaction of the requirement.
    //
    // TODO: Ideally this check should be comparing the `DeclRef`s
    // and not just the `Decl`s, but we currently don't get exactly
    // the same substitutions when we see the inherited `IFoo::bar`.
    //
    if (memberDeclRef.getDecl() == requiredMemberDeclRef.getDecl())
        return false;

    // At a high level, we want to check that the
    // `memberDecl` and the `requiredMemberDeclRef`
    // have the same AST node class, and then also
    // check that their signatures match.
    //
    // There are a bunch of detailed decisions that
    // have to be made, though, because we might, e.g.,
    // allow a function with more general parameter
    // types to satisfy a requirement with more
    // specific parameter types.
    //
    // If we ever allow for "property" declarations,
    // then we would probably need to allow an
    // ordinary field to satisfy a property requirement.
    //
    // An associated type requirement should be allowed
    // to be satisfied by any type declaration:
    // a typedef, a `struct`, etc.
    //
    if (auto memberFuncDecl = memberDeclRef.as<FuncDecl>())
    {
        if (auto requiredFuncDeclRef = requiredMemberDeclRef.as<FuncDecl>())
        {
            // Check signature match.
            return doesSignatureMatchRequirement(memberFuncDecl, requiredFuncDeclRef, witnessTable);
        }
    }
    else if (auto memberFuncAliasDecl = memberDeclRef.as<FuncAliasDecl>())
    {
        if (auto requiredFuncDeclRef = requiredMemberDeclRef.as<FuncDecl>())
        {
            // Check signature match between the pointed to function and the requirement.
            return doesSignatureMatchRequirement(
                memberFuncAliasDecl,
                requiredFuncDeclRef,
                witnessTable);
        }
    }
    else if (auto synMemberFuncDecl = memberDeclRef.as<SynthesizedFuncDecl>())
    {
        if (auto requiredFuncDeclRef = requiredMemberDeclRef.as<FuncDecl>())
        {
            // Check signature match.
            return doesSignatureMatchRequirement(
                synMemberFuncDecl,
                requiredFuncDeclRef,
                witnessTable);
        }
    }
    else if (auto memberInitDecl = memberDeclRef.as<ConstructorDecl>())
    {
        if (auto requiredInitDecl = requiredMemberDeclRef.as<ConstructorDecl>())
        {
            // Check signature match.
            return doesSignatureMatchRequirement(memberInitDecl, requiredInitDecl, witnessTable);
        }
    }
    else if (auto genDecl = memberDeclRef.as<GenericDecl>())
    {
        // For a generic member, we will check if it can satisfy
        // a generic requirement in the interface.
        //
        // TODO: we could also conceivably check that the generic
        // could be *specialized* to satisfy the requirement,
        // and then install a specialization of the generic into
        // the witness table. Actually doing this would seem
        // to require performing something akin to overload
        // resolution as part of requirement satisfaction.
        //
        if (auto requiredGenDeclRef = requiredMemberDeclRef.as<GenericDecl>())
        {
            return doesGenericSignatureMatchRequirement(genDecl, requiredGenDeclRef, witnessTable);
        }
    }
    else if (auto subAggTypeDeclRef = memberDeclRef.as<AggTypeDecl>())
    {
        if (auto requiredTypeDeclRef = requiredMemberDeclRef.as<AssocTypeDecl>())
        {
            ensureDecl(subAggTypeDeclRef, DeclCheckState::CanUseAsType);

            auto satisfyingType = DeclRefType::create(m_astBuilder, subAggTypeDeclRef);
            return doesTypeSatisfyAssociatedTypeRequirement(
                satisfyingType,
                requiredTypeDeclRef,
                witnessTable);
        }
    }
    else if (auto typedefDeclRef = memberDeclRef.as<TypeDefDecl>())
    {
        // this is a type-def decl in an aggregate type
        // check if the specified type satisfies the constraints defined by the associated type
        if (auto requiredTypeDeclRef = requiredMemberDeclRef.as<AssocTypeDecl>())
        {
            ensureDecl(typedefDeclRef, DeclCheckState::ReadyForLookup);

            auto satisfyingType = getNamedType(m_astBuilder, typedefDeclRef);
            return doesTypeSatisfyAssociatedTypeRequirement(
                satisfyingType,
                requiredTypeDeclRef,
                witnessTable);
        }
    }
    else if (auto propertyDeclRef = memberDeclRef.as<PropertyDecl>())
    {
        if (auto requiredPropertyDeclRef = requiredMemberDeclRef.as<PropertyDecl>())
        {
            ensureDecl(propertyDeclRef, DeclCheckState::CanUseFuncSignature);
            return doesPropertyMatchRequirement(
                propertyDeclRef,
                requiredPropertyDeclRef,
                witnessTable);
        }
    }
    else if (auto varDeclRef = memberDeclRef.as<VarDeclBase>())
    {
        if (auto requiredVarDeclRef = requiredMemberDeclRef.as<VarDeclBase>())
        {
            ensureDecl(varDeclRef, DeclCheckState::SignatureChecked);
            return doesVarMatchRequirement(varDeclRef, requiredVarDeclRef, witnessTable);
        }
    }
    else if (auto subscriptDeclRef = memberDeclRef.as<SubscriptDecl>())
    {
        if (auto requiredSubscriptDeclRef = requiredMemberDeclRef.as<SubscriptDecl>())
        {
            ensureDecl(subscriptDeclRef, DeclCheckState::CanUseFuncSignature);
            return doesSubscriptMatchRequirement(
                subscriptDeclRef,
                requiredSubscriptDeclRef,
                witnessTable);
        }
    }
    // Default: just assume that thing aren't being satisfied.
    return false;
}

// Invalidates cached default-substitution arguments for `genericDecl`.
//
// Call this after adding cloned constraints because later default arguments may include newly
// cloned proof-bearing constraint members.
static void invalidateDefaultSubstitutionArgs(ASTBuilder* astBuilder, GenericDecl* genericDecl)
{
    astBuilder->m_cachedGenericDefaultArgs.remove(genericDecl);
    genericDecl->_cachedArgsForDefaultSubstitution.clear();
}

DeclRef<Decl> SemanticsVisitor::liftDeclFromGenericContainers(
    Decl* decl,
    SubstitutionSet& outSubstitutions,
    ContainerDecl* destinationParentDecl)
{
    List<GenericDecl*> sourceGenericDecls;
    List<GenericDecl*> clonedGenericDecls;

    auto destinationParent = destinationParentDecl ? destinationParentDecl : getModuleDecl(decl);
    for (auto cur = decl->parentDecl; cur && cur != destinationParent; cur = cur->parentDecl)
    {
        if (auto genericDecl = as<GenericDecl>(cur))
        {
            sourceGenericDecls.add(genericDecl);
        }
    }

    ContainerDecl* parentDecl = destinationParent;
    Scope* parentScope = getScope(parentDecl);

    auto currentDeclRef = decl->getDefaultDeclRef();
    currentDeclRef =
        createDefaultSubstitutionsIfNeeded(getCurrentASTBuilder(), this, currentDeclRef);

    // Move a synthesized declaration out of a nested generic context by giving it its own cloned
    // generic context.
    //
    // For example, given:
    //
    //     generic<T>
    //     func f()
    //     {
    //         struct Syn { T value; }
    //     }
    //
    // a plain move to module scope would be invalid:
    //
    //     struct Syn { T value; } // `T` is dangling.
    //
    // Instead, this operation creates a fresh generic context:
    //
    //     generic<T2>
    //     struct Syn { T2 value; }
    //
    // The cloned generic parameters and constraints form the standalone generic environment for
    // `Syn`, and references inside `Syn` are rewritten from the original generic binders/proofs to
    // the cloned ones. Proof-bearing constraints are cloned as part of that environment, so default
    // substitution arguments and witness references keep the same logical shape.
    sourceGenericDecls.reverse();
    ASTCloneContext outerCloneContext;
    outerCloneContext.astBuilder = m_astBuilder;
    outerCloneContext.semantics = this;

    for (auto sourceGenericDecl : sourceGenericDecls)
    {
        auto synGenericDecl = m_astBuilder->create<GenericDecl>();
        synGenericDecl->parentDecl = parentDecl;
        synGenericDecl->loc = decl->loc;
        synGenericDecl->ownedScope = m_astBuilder->create<Scope>();
        synGenericDecl->ownedScope->containerDecl = synGenericDecl;
        synGenericDecl->ownedScope->parent = parentScope;
        clonedGenericDecls.add(synGenericDecl);

        if (auto genericParentDecl = as<GenericDecl>(parentDecl))
            genericParentDecl->inner = synGenericDecl;

        GenericSignatureCloner cloner(m_astBuilder, this, sourceGenericDecl, synGenericDecl);
        for (auto const& kv : outerCloneContext.oldToNewDecls)
            cloner.getASTCloner().mapDecl(kv.first, kv.second);
        cloner.cloneParameterMembers();

        auto partiallySpecializedSourceDeclRef = getSpecializedDeclRefWithParamsFromGeneric(
            m_astBuilder,
            this,
            sourceGenericDecl,
            synGenericDecl);

        // Refine our current specialized decl-ref from src generic heirarchy to the new generic
        // heirarchy.
        //
        currentDeclRef = as<DeclRefBase>(currentDeclRef->substitute(
            getCurrentASTBuilder(),
            SubstitutionSet(partiallySpecializedSourceDeclRef)));

        for (auto member : sourceGenericDecl->getDirectMemberDecls())
        {
            if (!cloner.cloneConstraintMember(member, SubstitutionSet(currentDeclRef)))
                continue;

            // Future constraints in the same generic can depend on proof-bearing members that were
            // just cloned, so refresh default substitution arguments after each cloned constraint.
            invalidateDefaultSubstitutionArgs(m_astBuilder, synGenericDecl);
            auto partiallySpecializedSourceDeclRefAfterConstraint =
                getSpecializedDeclRefWithParamsFromGeneric(
                    m_astBuilder,
                    this,
                    sourceGenericDecl,
                    synGenericDecl);
            currentDeclRef = as<DeclRefBase>(currentDeclRef->substitute(
                getCurrentASTBuilder(),
                SubstitutionSet(partiallySpecializedSourceDeclRefAfterConstraint)));
        }

        // The cloner drops witness/path-resolution tables because they are tied to the original
        // declaration graph. Rebuild the derived tables after all cloned constraints are present.
        checkGenericConstraintConformances(synGenericDecl);

        // Override generic pointer to point to the original generic container.
        // This will create a substitution of the synthesized parameters for the
        // original parameters.
        //
        invalidateDefaultSubstitutionArgs(m_astBuilder, synGenericDecl);
        auto fullySpecializedDeclRef = getSpecializedDeclRefWithParamsFromGeneric(
            m_astBuilder,
            this,
            sourceGenericDecl,
            synGenericDecl);

        // Refine the current substituted decl-ref further (this will fill in the substitutions for
        // the constraints as well).
        //
        currentDeclRef = as<DeclRefBase>(currentDeclRef->substitute(
            getCurrentASTBuilder(),
            SubstitutionSet(fullySpecializedDeclRef)));

        // Update parent pointers.
        outerCloneContext = cloner.getASTCloner().getContext();
        parentDecl = synGenericDecl;
        parentScope = synGenericDecl->ownedScope;
    }

    decl->parentDecl = parentDecl;
    if (auto genericParentDecl = as<GenericDecl>(parentDecl))
        genericParentDecl->inner = decl;

    if (as<ContainerDecl>(decl) && as<ContainerDecl>(decl)->ownedScope)
        as<ContainerDecl>(decl)->ownedScope->parent = parentScope;

    outSubstitutions = SubstitutionSet(currentDeclRef);

    DeclRefBase* newDeclRef = nullptr;
    for (Index i = 0; i < (Index)clonedGenericDecls.getCount(); i++)
    {
        auto genericDecl = clonedGenericDecls[i];
        auto origGenericDecl = sourceGenericDecls[i];

        auto substArgs = getDefaultSubstitutionArgs(m_astBuilder, this, origGenericDecl);
        newDeclRef = getCurrentASTBuilder()->getGenericAppDeclRef(
            newDeclRef ? newDeclRef : genericDecl->getDefaultDeclRef(),
            substArgs.getArrayView(),
            genericDecl->inner);
    }

    return newDeclRef ? DeclRef<Decl>(newDeclRef) : DeclRef<Decl>(decl->getDefaultDeclRef());
}


static Type* _moveNoDiffFromTypeToParamDecl(
    ASTBuilder* astBuilder,
    Type* type,
    ParamDecl* paramDecl)
{
    if (auto modifiedType = as<ModifiedType>(type))
    {
        List<Val*> retainedModifiers;
        bool foundNoDiffModifier = false;
        for (Index i = 0; i < modifiedType->getModifierCount(); i++)
        {
            auto modifier = modifiedType->getModifier(i);
            if (as<NoDiffModifierVal>(modifier))
            {
                foundNoDiffModifier = true;
                continue;
            }
            retainedModifiers.add(modifier);
        }

        auto baseType =
            _moveNoDiffFromTypeToParamDecl(astBuilder, modifiedType->getBase(), paramDecl);
        if (foundNoDiffModifier && !paramDecl->findModifier<NoDiffModifier>())
            addModifier(paramDecl, astBuilder->create<NoDiffModifier>());

        if (retainedModifiers.getCount() == 0)
            return baseType;

        return astBuilder->getModifiedType(baseType, retainedModifiers);
    }

    return type;
}

static void _configureSynthesizedParamDecl(
    ASTBuilder* astBuilder,
    ParamDecl* paramDecl,
    ParamInfo const& paramInfo)
{
    SLANG_RELEASE_ASSERT(paramInfo.type);

    // `ParamInfo` keeps `no_diff` in its value type, while a checked `ParamDecl` stores the same
    // fact as a declaration modifier. Preserve that established AST representation without
    // deriving the mode again from the substituted value type.
    paramDecl->type.type = _moveNoDiffFromTypeToParamDecl(astBuilder, paramInfo.type, paramDecl);

    auto modeModifier = astBuilder->create<SynthesizedParamPassingModeModifier>();
    modeModifier->mode = paramInfo.mode;
    addModifier(paramDecl, modeModifier);
}

static void _configureSynthesizedEffectiveThisParam(
    ASTBuilder* astBuilder,
    CallableDecl* callableDecl,
    ThisExpr* thisExpr,
    ParamInfo const& paramInfo)
{
    SLANG_RELEASE_ASSERT(thisExpr);
    SLANG_RELEASE_ASSERT(paramInfo.type);

    // This modifier is an input to signature checking, not checked information itself. The normal
    // checker will compute the synthesized declaration's receiver type, combine it with this
    // declaration-owned mode and `no_diff` policy, and then attach the sole
    // `ThisParamInfoAttribute`. Keeping that order gives synthesized and source declarations the
    // same checked-data producer.
    auto modeModifier = astBuilder->create<SynthesizedParamPassingModeModifier>();
    modeModifier->mode = paramInfo.mode;
    addModifier(callableDecl, modeModifier);

    if (doesTypeHaveNoDiffModifier(paramInfo.type))
    {
        // Preserve the requirement's checked receiver ABI even when this wrapper does not carry a
        // differentiability header of its own. `NoDiffThisAttribute` is the declaration input by
        // which normal signature checking reconstructs that `no_diff` value type. The publication
        // step recognizes this existing marker and will not attach a second one.
        auto noDiffThisModifier = astBuilder->create<NoDiffThisAttribute>();
        noDiffThisModifier->isSynthesized = true;
        addModifier(callableDecl, noDiffThisModifier);
    }

    thisExpr->type.isLeftValue =
        isThisExprWritable(makeDeclRef(callableDecl).as<CallableDecl>(), paramInfo);
}

static void populateParams(
    ASTBuilder* astBuilder,
    CallableDecl* decl,
    FuncType* funcType,
    List<Expr*>& synArgs)
{
    auto synthesizedLoc = getDiagnosticPos(decl);

    // Insert synthesized param-decls.
    for (auto paramType : funcType->getParamTypes())
    {
        auto paramDecl = astBuilder->create<ParamDecl>();
        paramDecl->loc = synthesizedLoc;
        paramDecl->nameAndLoc.loc = synthesizedLoc;
        auto paramInfo = getParamInfoFromTypeWithModeWrapper(paramType);
        _configureSynthesizedParamDecl(astBuilder, paramDecl, paramInfo);
        decl->addMember(paramDecl);

        // Create an expression that references the parameter for use in arguments.
        auto synArg = astBuilder->create<VarExpr>();
        synArg->declRef = makeDeclRef(paramDecl);
        synArg->type.type = paramInfo.type;
        synArg->type.isLeftValue = doesParamPassingModeIndicateWritableStorage(paramInfo.mode);
        synArg->type.isReadOnlyMemoryLocation = paramInfo.mode == ParamPassingMode::RefReadOnly;
        synArg->loc = synthesizedLoc;
        synArgs.add(synArg);
    }
}

GenericDecl* SemanticsVisitor::synthesizeGenericSignatureForRequirementWitness(
    ConformanceCheckingContext* context,
    DeclRef<GenericDecl> requiredMemberDeclRef,
    List<Expr*>& synArgs,
    List<Expr*>& synGenericArgs,
    ThisExpr*& synThis)
{
    auto synGenericDecl = m_astBuilder->create<GenericDecl>();
    synGenericDecl->parentDecl = context->parentDecl;
    synGenericDecl->ownedScope = m_astBuilder->create<Scope>();
    synGenericDecl->ownedScope->containerDecl = synGenericDecl;
    synGenericDecl->ownedScope->parent = getScope(context->parentDecl);

    // For now our synthesized method will use the name and source
    // location of the requirement we are trying to satisfy.
    //
    // TODO: as it stands right now our syntesized method will
    // get a mangled name, which we don't actually want. Leaving
    // out the name here doesn't help matters, because then *all*
    // snthesized methods on a given type would share the same
    // mangled name!
    //
    synGenericDecl->nameAndLoc = requiredMemberDeclRef.getDecl()->nameAndLoc;
    if (synGenericDecl->nameAndLoc.name)
    {
        synGenericDecl->nameAndLoc.name =
            getSession()->getNameObj("$__syn_" + synGenericDecl->nameAndLoc.name->text);
    }

    // Dictionary to map from the original type parameters to the synthesized ones.
    Dictionary<Decl*, Decl*> mapOrigToSynTypeParams;

    // Our synthesized method will have parameters matching the names
    // and types of those on the requirement, and it will use expressions
    // that reference those parametesr as arguments for the call expresison
    // that makes up the body.
    //
    for (auto member : requiredMemberDeclRef.getDecl()->getDirectMemberDecls())
    {
        if (auto typeParamDeclBase = as<GenericTypeParamDeclBase>(member))
        {
            auto synTypeParamDeclBase = (GenericTypeParamDeclBase*)m_astBuilder->createByNodeType(
                typeParamDeclBase->astNodeType);
            synTypeParamDeclBase->nameAndLoc = typeParamDeclBase->getNameAndLoc();
            synTypeParamDeclBase->parameterIndex = typeParamDeclBase->parameterIndex;
            synGenericDecl->addMember(synTypeParamDeclBase);

            // Note: we intentionally do not copy GenericTypeParamDecl::initType here,
            // because initType maybe dependent on the original type parameters,
            // and if we copy we must also substitute all the original type parameters with the
            // synthesized ones. It shouldn't be required for the implementing declaration to define
            // initType anyways, so we'll just save ourselves from the trouble.
            //

            mapOrigToSynTypeParams.add(typeParamDeclBase, synTypeParamDeclBase);

            // Construct a DeclRefExpr from the type parameter.
            auto synTypeParamDeclRef = makeDeclRef(synTypeParamDeclBase);

            auto synTypeParamDeclRefExpr = m_astBuilder->create<VarExpr>();
            synTypeParamDeclRefExpr->declRef = synTypeParamDeclRef;
            synTypeParamDeclRefExpr->type =
                getTypeForDeclRef(m_astBuilder, synTypeParamDeclRef, SourceLoc());

            synGenericArgs.add(synTypeParamDeclRefExpr);
        }
        else if (auto valParamDecl = as<GenericValueParamDecl>(member))
        {
            auto synValParamDecl = m_astBuilder->create<GenericValueParamDecl>();
            synValParamDecl->nameAndLoc = valParamDecl->nameAndLoc;
            synGenericDecl->addMember(synValParamDecl);
            synValParamDecl->parameterIndex = valParamDecl->parameterIndex;
            synValParamDecl->type = valParamDecl->type;

            // Constraint cloning below uses this map for both the target pack
            // and the count expression in `where countof(I) == N`. Value
            // parameters therefore map to their synthesized value declarations,
            // so a cloned count expression references synthetic `N` rather than
            // the original requirement's `N`.
            mapOrigToSynTypeParams.add(valParamDecl, synValParamDecl);

            auto synValParamDeclRef = makeDeclRef(synValParamDecl);

            auto synValParamDeclRefExpr = m_astBuilder->create<VarExpr>();
            synValParamDeclRefExpr->declRef = synValParamDeclRef;
            synValParamDeclRefExpr->type = synValParamDecl->type.type;

            synGenericArgs.add(synValParamDeclRefExpr);
        }
        else if (auto valPackParamDecl = as<GenericValuePackParamDecl>(member))
        {
            auto synValPackParamDecl = m_astBuilder->create<GenericValuePackParamDecl>();
            synValPackParamDecl->nameAndLoc = valPackParamDecl->nameAndLoc;
            synGenericDecl->addMember(synValPackParamDecl);
            synValPackParamDecl->parameterIndex = valPackParamDecl->parameterIndex;
            synValPackParamDecl->type = valPackParamDecl->type;

            // The same map is used when cloning pack-count constraints. A value
            // pack target must map to the synthesized pack declaration so
            // `countof(I)` remains a current-generic constraint after cloning.
            mapOrigToSynTypeParams.add(valPackParamDecl, synValPackParamDecl);

            auto synValPackParamDeclRef = makeDeclRef(synValPackParamDecl);

            auto synValPackParamDeclRefExpr = m_astBuilder->create<VarExpr>();
            synValPackParamDeclRefExpr->declRef = synValPackParamDeclRef;
            synValPackParamDeclRefExpr->type = synValPackParamDecl->type.type;

            synGenericArgs.add(synValPackParamDeclRefExpr);
        }
    }

    // With all generic parameters in place, we can now form a partial substitution argument list
    // without taking into account all the generic constraints.

    // Given `requiredMemberDeclRef` that is `Lookup(ConcreteType:IFoo<int>, IFoo::bar)`, we can now
    // form a partial specialized declref to `IFoo<int>::bar` with substitution args comming
    // from the synthesized generic decl, i.e. we want to form:
    // `Lookup(ConcreteType:IFoo<int>, IFoo::bar)<UImpl>` where `UImpl` is a synthesized generic
    // parameter.
    //
    auto partialDefaultArgs = getDefaultSubstitutionArgs(m_astBuilder, this, synGenericDecl);
    DeclRef<CallableDecl> partiallySpecializedRequiredGenericDeclRef =
        m_astBuilder->getGenericAppDeclRef(requiredMemberDeclRef, partialDefaultArgs.getArrayView())
            .as<CallableDecl>();

    // With `partiallySpecializedRequiredGenericDeclRef`, we can obtain the right specialized types
    // from the original requirement decl. For example, we can simply apply declref substituion on
    // the original type constraint `U:IDerived` to get `UImpl : IDerived`.
    //
    for (auto constraintDecl : requiredMemberDeclRef.getDecl()->getDirectMemberDecls())
    {
        if (auto genericTypeConstraintDecl = as<GenericTypeConstraintDecl>(constraintDecl))
        {
            auto synConstraintDecl = m_astBuilder->create<GenericTypeConstraintDecl>();
            synConstraintDecl->nameAndLoc = genericTypeConstraintDecl->getNameAndLoc();
            synConstraintDecl->parentDecl = synGenericDecl;
            synConstraintDecl->isEqualityConstraint =
                genericTypeConstraintDecl->isEqualityConstraint;

            // For generic constraint Sub : Sup, we need to substitute them with
            // synthesized generic parameters.
            //
            synConstraintDecl->sub = TypeExp((Type*)genericTypeConstraintDecl->sub.type->substitute(
                m_astBuilder,
                SubstitutionSet(partiallySpecializedRequiredGenericDeclRef)));
            synConstraintDecl->sup = TypeExp((Type*)genericTypeConstraintDecl->sup.type->substitute(
                m_astBuilder,
                SubstitutionSet(partiallySpecializedRequiredGenericDeclRef)));

            synGenericDecl->addDirectMemberDecl(synConstraintDecl);
        }
        else if (auto typeCoercionConstraintDecl = as<TypeCoercionConstraintDecl>(constraintDecl))
        {
            auto synConstraintDecl = m_astBuilder->create<TypeCoercionConstraintDecl>();
            synConstraintDecl->nameAndLoc = typeCoercionConstraintDecl->getNameAndLoc();
            synConstraintDecl->parentDecl = synGenericDecl;
            synConstraintDecl->fromType =
                TypeExp((Type*)typeCoercionConstraintDecl->fromType.type->substitute(
                    m_astBuilder,
                    SubstitutionSet(partiallySpecializedRequiredGenericDeclRef)));
            synConstraintDecl->toType =
                TypeExp((Type*)typeCoercionConstraintDecl->toType.type->substitute(
                    m_astBuilder,
                    SubstitutionSet(partiallySpecializedRequiredGenericDeclRef)));

            synGenericDecl->addDirectMemberDecl(synConstraintDecl);
        }
        else if (
            auto hasDiffTypeInfoConstraintDecl = as<HasDiffTypeInfoConstraintDecl>(constraintDecl))
        {
            auto synConstraintDecl = m_astBuilder->create<HasDiffTypeInfoConstraintDecl>();
            synConstraintDecl->nameAndLoc = hasDiffTypeInfoConstraintDecl->getNameAndLoc();
            synConstraintDecl->parentDecl = synGenericDecl;
            synConstraintDecl->whereTokenLoc = hasDiffTypeInfoConstraintDecl->whereTokenLoc;
            synConstraintDecl->type =
                TypeExp((Type*)hasDiffTypeInfoConstraintDecl->type.type->substitute(
                    m_astBuilder,
                    SubstitutionSet(partiallySpecializedRequiredGenericDeclRef)));

            synGenericDecl->addDirectMemberDecl(synConstraintDecl);
        }
        else if (auto nonEmptyConstraintDecl = as<NonEmptyPackConstraintDecl>(constraintDecl))
        {
            auto synConstraintDecl = m_astBuilder->create<NonEmptyPackConstraintDecl>();
            synConstraintDecl->nameAndLoc = nonEmptyConstraintDecl->getNameAndLoc();
            synConstraintDecl->parentDecl = synGenericDecl;

            auto synPackDeclRefExpr = m_astBuilder->create<VarExpr>();
            if (auto declRefExpr = as<DeclRefExpr>(nonEmptyConstraintDecl->packExpr))
            {
                auto origPackDecl = getDeclRef(m_astBuilder, declRefExpr).getDecl();
                auto synPackDecl = mapOrigToSynTypeParams.tryGetValue(origPackDecl);
                SLANG_ASSERT(synPackDecl);
                synPackDeclRefExpr->declRef = makeDeclRef(*synPackDecl);
                synPackDeclRefExpr->type =
                    getTypeForDeclRef(m_astBuilder, synPackDeclRefExpr->declRef, SourceLoc());
            }
            else
            {
                SLANG_UNEXPECTED("nonempty constraint target must be a direct decl ref");
            }
            synConstraintDecl->packExpr = synPackDeclRefExpr;

            synGenericDecl->addDirectMemberDecl(synConstraintDecl);
        }
        else if (
            auto packCountConstraintDecl =
                as<GenericVariadicPackCountConstraintDecl>(constraintDecl))
        {
            // Header checking owns the diagnostics for an invalid pack target or a non-foldable
            // count expression. Requirement-witness synthesis can run during recovery too, so
            // preserve those diagnostics instead of trying to clone a proof with missing checked
            // values.
            SLANG_ASSERT(packCountConstraintDecl->actualCountVal);
            SLANG_ASSERT(packCountConstraintDecl->expectedCountVal);
            if (!packCountConstraintDecl->actualCountVal ||
                !packCountConstraintDecl->expectedCountVal)
                continue;

            auto synConstraintDecl = m_astBuilder->create<GenericVariadicPackCountConstraintDecl>();
            synConstraintDecl->nameAndLoc = packCountConstraintDecl->getNameAndLoc();
            synConstraintDecl->parentDecl = synGenericDecl;
            synConstraintDecl->whereTokenLoc = packCountConstraintDecl->whereTokenLoc;
            if (packCountConstraintDecl->findModifier<OptionalConstraintModifier>())
            {
                addModifier(synConstraintDecl, m_astBuilder->create<OptionalConstraintModifier>());
            }

            auto synPackDeclRefExpr = m_astBuilder->create<VarExpr>();
            if (packCountConstraintDecl->packDeclRef)
            {
                auto origPackDecl = packCountConstraintDecl->packDeclRef.getDecl();
                auto synPackDecl = mapOrigToSynTypeParams.tryGetValue(origPackDecl);
                SLANG_ASSERT(synPackDecl);
                auto synPackDeclRef = makeDeclRef(*synPackDecl);
                synPackDeclRefExpr->declRef = synPackDeclRef;
                synPackDeclRefExpr->type =
                    getTypeForDeclRef(m_astBuilder, synPackDeclRefExpr->declRef, SourceLoc());
                synConstraintDecl->packDeclRef = synPackDeclRef;
            }
            else
            {
                SLANG_UNEXPECTED("pack-count constraint target must have a checked decl ref");
            }
            synConstraintDecl->packExpr = synPackDeclRefExpr;

            // `GenericVariadicPackCountConstraintDecl` stores the checked
            // `countof(pack)` value in `actualCountVal`, keeps `packExpr` for
            // diagnostics/printing, and uses `expectedCountVal` for witness
            // matching. Consider this example:
            //
            //     interface ITensor<T, int D>
            //     {
            //         T load<each I>(I indices)
            //             where I == int
            //             where countof(I) == D;
            //     }
            //
            // `synthesizeGenericSignatureForRequirementWitness` creates a fresh generic signature
            // for a satisfying `load<each I2>` requirement. Rebuild the direct expected-count
            // expression `D` to reference the synthesized value parameter in that cloned signature;
            // `getDefaultSubstitutionArgs` then creates a declared witness for the synthesized
            // `countof(I2) == D2` proof, not for the original requirement proof.
            if (auto declRefExpr = as<DeclRefExpr>(packCountConstraintDecl->expectedCountExpr))
            {
                auto origExpectedCountDecl = getDeclRef(m_astBuilder, declRefExpr).getDecl();
                if (auto synExpectedCountDecl =
                        mapOrigToSynTypeParams.tryGetValue(origExpectedCountDecl))
                {
                    auto synExpectedCountExpr = m_astBuilder->create<VarExpr>();
                    synExpectedCountExpr->declRef = makeDeclRef(*synExpectedCountDecl);
                    synExpectedCountExpr->type =
                        getTypeForDeclRef(m_astBuilder, synExpectedCountExpr->declRef, SourceLoc());
                    synConstraintDecl->expectedCountExpr = synExpectedCountExpr;
                }
                else
                {
                    synConstraintDecl->expectedCountExpr =
                        packCountConstraintDecl->expectedCountExpr;
                }
            }
            else
            {
                synConstraintDecl->expectedCountExpr = packCountConstraintDecl->expectedCountExpr;
            }
            synConstraintDecl->actualCountVal =
                as<IntVal>(packCountConstraintDecl->actualCountVal->substitute(
                    m_astBuilder,
                    SubstitutionSet(partiallySpecializedRequiredGenericDeclRef)));

            synConstraintDecl->expectedCountVal =
                as<IntVal>(packCountConstraintDecl->expectedCountVal->substitute(
                    m_astBuilder,
                    SubstitutionSet(partiallySpecializedRequiredGenericDeclRef)));

            synGenericDecl->addDirectMemberDecl(synConstraintDecl);
        }
    }

    // Override generic pointer to point to the original generic container.
    // This will create a substitution of the synthesized parameters for the
    // original parameters.
    //
    // We'll also need to invalidate cached default substitution args, because
    // we've changed the generic decl after the last time
    // getDefaultSubstitutionArgs was called.
    synGenericDecl->_cachedArgsForDefaultSubstitution.clear();
    auto defaultArgs = getDefaultSubstitutionArgs(m_astBuilder, this, synGenericDecl);
    DeclRef<CallableDecl> requiredFuncDeclRef =
        m_astBuilder->getGenericAppDeclRef(requiredMemberDeclRef, defaultArgs.getArrayView())
            .as<CallableDecl>();

    SLANG_ASSERT(requiredFuncDeclRef);
    RefPtr<ConformanceCheckingContext> subContext = new ConformanceCheckingContext();
    subContext->conformingType = context->conformingType;
    subContext->conformingWitness = context->conformingWitness;
    subContext->parentDecl = synGenericDecl;
    subContext->rootInheritanceDecl = context->rootInheritanceDecl;
    subContext->mapInterfaceToWitnessTable = context->mapInterfaceToWitnessTable;

    synGenericDecl->inner = synthesizeMethodSignatureForRequirementWitnessInner(
        subContext,
        requiredFuncDeclRef,
        synArgs,
        synThis);
    return synGenericDecl;
}

void SemanticsVisitor::addModifiersToSynthesizedDecl(
    ConformanceCheckingContext* context,
    DeclRef<Decl> requiredMemberDeclRef,
    CallableDecl* synthesized,
    ThisExpr*& synThis)
{
    auto requiredThisInfo = findEffectiveThisParamInfo(requiredMemberDeclRef);
    auto requiredDecl = requiredMemberDeclRef.getDecl();

    // Staticness is copied directly from the requirement. It is independent of whether this
    // particular declaration owns an effective `this` parameter: constructors operate on a local
    // `this` value, and a non-static synthesized subscript supplies a `this` expression to its
    // accessors even though the subscript container itself is not a callable parameter owner.
    if (requiredDecl->hasModifier<HLSLStaticModifier>())
    {
        auto synStaticModifier = m_astBuilder->create<HLSLStaticModifier>();
        addModifier(synthesized, synStaticModifier);
    }
    else if (context)
    {
        synThis = m_astBuilder->create<ThisExpr>();
        synThis->scope = synthesized->ownedScope;

        // The type of `this` in our method will be the type for
        // which we are synthesizing a conformance.
        //
        synThis->type.type = context->conformingType;

        if (requiredThisInfo)
        {
            _configureSynthesizedEffectiveThisParam(
                m_astBuilder,
                synthesized,
                synThis,
                *requiredThisInfo);
        }
        else
        {
            synThis->type.isLeftValue = true;
        }
    }

    if (requiredMemberDeclRef.getDecl()->hasModifier<ForwardDifferentiableAttribute>())
    {
        auto forwardDifferentiableAttr = m_astBuilder->create<ForwardDifferentiableAttribute>();
        addModifier(synthesized, forwardDifferentiableAttr);
    }
    if (requiredMemberDeclRef.getDecl()->hasModifier<BackwardDifferentiableAttribute>())
    {
        auto backwardDifferentiableAttr = m_astBuilder->create<BackwardDifferentiableAttribute>();
        addModifier(synthesized, backwardDifferentiableAttr);
    }

    // For [MaybeDifferentiable], we'll handle in a slightly roundabout manner.
    // We'll add the forward and backward differentiable attributes during signature synthesis,
    // but we don't actually know if we should add them until we know the callee resolved from the
    // invoke. However, we currently cant' defer the attribute to after callee resolution, because
    // the resolution needs the attribute so it can store the associations on it.
    //
    // Thus, we'll add it here, and then remove it later as soon as the invoke expr has been
    // checked.
    //
    if (requiredMemberDeclRef.getDecl()->hasModifier<MaybeDifferentiableAttribute>())
    {
        auto backwardDiffAttr = m_astBuilder->create<BackwardDifferentiableAttribute>();
        addModifier(synthesized, backwardDiffAttr);
        auto forwardDiffAttr = m_astBuilder->create<ForwardDifferentiableAttribute>();
        addModifier(synthesized, forwardDiffAttr);
    }

    // The visibility of synthesized decl should be the min of the parent decl and the requirement.
    if (requiredMemberDeclRef.getDecl()->findModifier<VisibilityModifier>())
    {
        auto requirementVisibility = getDeclVisibility(requiredMemberDeclRef.getDecl());
        auto thisVisibility = getDeclVisibility(context->parentDecl);
        auto visibility = Math::Min(thisVisibility, requirementVisibility);
        addVisibilityModifier(synthesized, visibility);
    }
}

/// Add the modifiers that spell `mode` to `paramDecl`. A parameter built from a
/// function type has only its effective mode, and several spellings can produce the
/// same mode (for example, `__ref_readonly` and its legacy alias `const __ref`), so
/// we spell each mode one canonical way.
static void addModifiersForParamPassingMode(
    ASTBuilder* astBuilder,
    ParamDecl* paramDecl,
    ParamPassingMode mode)
{
    switch (mode)
    {
    case ParamPassingMode::In:
        break;
    case ParamPassingMode::Out:
        addModifier(paramDecl, astBuilder->create<OutModifier>());
        break;
    case ParamPassingMode::BorrowInOut:
        addModifier(paramDecl, astBuilder->create<InOutModifier>());
        break;
    case ParamPassingMode::BorrowIn:
        addModifier(paramDecl, astBuilder->create<BorrowModifier>());
        break;
    case ParamPassingMode::RefReadWrite:
        addModifier(paramDecl, astBuilder->create<RefModifier>());
        break;
    case ParamPassingMode::RefReadOnly:
        addModifier(paramDecl, astBuilder->create<RefReadOnlyModifier>());
        break;
    case ParamPassingMode::RefWriteOnly:
        addModifier(paramDecl, astBuilder->create<RefWriteOnlyModifier>());
        break;
    default:
        SLANG_UNEXPECTED("unhandled parameter-passing mode");
        break;
    }
}

void SemanticsVisitor::addRequiredParamsToSynthesizedDecl(
    DeclRef<CallableDecl> requirement,
    CallableDecl* synthesized,
    List<Expr*>& synArgs)
{
    if (hasDirectFuncType(requirement))
    {
        auto substFuncType = as<FuncType>(substituteType(
                                              SubstitutionSet(requirement),
                                              getCurrentASTBuilder(),
                                              requirement.getDecl()->funcType)
                                              ->resolve());
        populateParams(getCurrentASTBuilder(), synthesized, substFuncType, synArgs);
        return;
    }

    // Our synthesized method will have parameters matching the names
    // and types of those on the requirement, and it will use expressions
    // that reference those parameters as arguments for the call expresison
    // that makes up the body.
    //
    for (auto paramDeclRef : getParameters(m_astBuilder, requirement))
    {
        auto paramInfo = getParamInfo(m_astBuilder, paramDeclRef);
        auto paramType = QualType(paramInfo.type);

        // For each parameter of the requirement, we create a matching
        // parameter (same name and type) for the synthesized method.
        //
        auto synParamDecl = m_astBuilder->create<ParamDecl>();
        synParamDecl->nameAndLoc = paramDeclRef.getDecl()->nameAndLoc;
        _configureSynthesizedParamDecl(m_astBuilder, synParamDecl, paramInfo);

        // We need to add the parameter as a child declaration of
        // the method we are building.
        //
        synthesized->addMember(synParamDecl);

        // The parameter variable itself is usable as an l-value except when it is an immutable
        // borrow. This expression property describes uses inside the wrapper body; its ABI remains
        // the independently stored `paramInfo.mode`.
        paramType.isLeftValue = true;
        if (paramInfo.mode == ParamPassingMode::BorrowIn)
            paramType.isLeftValue = false;

        // Create an expression that references the parameter for use in arguments.
        auto synArg = m_astBuilder->create<VarExpr>();
        synArg->declRef = makeDeclRef(synParamDecl);
        synArg->type = paramType;

        if (auto typePack = as<ConcreteTypePack>(paramType))
        {
            // If paramType is a concrete type pack, we want to expand it out into
            // individual arguments.
            for (Index i = 0; i < typePack->getTypeCount(); i++)
            {
                auto elementType = typePack->getElementType(i);
                auto synMemberExpr = m_astBuilder->create<SwizzleExpr>();
                synMemberExpr->base = synArg;
                synMemberExpr->elementIndices.add((uint32_t)i);
                synMemberExpr->type = elementType;
                synMemberExpr->type.isLeftValue = paramType.isLeftValue;
                synMemberExpr->checked = true;
                synArgs.add(synMemberExpr);
            }
        }
        else
        {
            // For ordinary non-pack paramters, we will use synArg directly to
            // referencing the parameter for the call in the function body.
            //
            synArgs.add(synArg);
        }
    }
}

CallableDecl* SemanticsVisitor::synthesizeMethodSignatureForRequirementWitness(
    ConformanceCheckingContext* context,
    DeclRef<CallableDecl> requiredMemberDeclRef,
    List<Expr*>& synArgs,
    ThisExpr*& synThis)
{
    if (auto genericDeclRef = as<GenericDecl>(requiredMemberDeclRef.getParent()))
    {
        List<Expr*> synGenericArgs;
        auto genericDecl = synthesizeGenericSignatureForRequirementWitness(
            context,
            genericDeclRef,
            synArgs,
            synGenericArgs,
            synThis);
        return (CallableDecl*)genericDecl->inner;
    }
    return synthesizeMethodSignatureForRequirementWitnessInner(
        context,
        requiredMemberDeclRef,
        synArgs,
        synThis);
}

CallableDecl* SemanticsVisitor::synthesizeMethodSignatureForRequirementWitnessInner(
    ConformanceCheckingContext* context,
    DeclRef<CallableDecl> requiredMemberDeclRef,
    List<Expr*>& synArgs,
    ThisExpr*& synThis)
{
    CallableDecl* synFuncDecl = as<CallableDecl>(
        m_astBuilder->createByNodeType(requiredMemberDeclRef.getDecl()->astNodeType));
    SLANG_ASSERT(synFuncDecl);

    synFuncDecl->ownedScope = m_astBuilder->create<Scope>();
    synFuncDecl->ownedScope->containerDecl = synFuncDecl;
    synFuncDecl->ownedScope->parent = getScope(context->parentDecl);
    synFuncDecl->parentDecl = context->parentDecl;

    // For now our synthesized method will use the name and source
    // location of the requirement we are trying to satisfy.
    //
    // TODO: as it stands right now our syntesized method will
    // get a mangled name, which we don't actually want. Leaving
    // out the name here doesn't help matters, because then *all*
    // snthesized methods on a given type would share the same
    // mangled name!
    //
    synFuncDecl->nameAndLoc = requiredMemberDeclRef.getDecl()->nameAndLoc;
    if (synFuncDecl->nameAndLoc.name)
    {
        synFuncDecl->nameAndLoc.name =
            getSession()->getNameObj("$__syn_" + synFuncDecl->nameAndLoc.name->text);
    }

    // The result type of our synthesized method will be the expected
    // result type from the interface requirement.
    //
    // TODO: This logic can/will run into problems if the return type
    // is an associated type.
    //
    // The ideal solution is that we should be solving for interface
    // conformance in two phases: a first phase to solve for how
    // associated types are satisfied, and then a second phase to solve
    // for how other requirements are satisfied (where we can substitute
    // in the associated type witnesses for the abstract associated
    // types as part of `requiredMemberDeclRef`).
    //
    // TODO: We should also double-check that this logic will work
    // with a method that returns `This`.
    //
    auto resultType = getResultType(m_astBuilder, requiredMemberDeclRef);
    synFuncDecl->returnType.type = resultType;
    auto errorType = getErrorCodeType(m_astBuilder, requiredMemberDeclRef);
    synFuncDecl->errorType.type = errorType;

    addRequiredParamsToSynthesizedDecl(requiredMemberDeclRef, synFuncDecl, synArgs);
    addModifiersToSynthesizedDecl(context, requiredMemberDeclRef, synFuncDecl, synThis);

    return synFuncDecl;
}

void SemanticsVisitor::_addMethodWitness(
    WitnessTable* witnessTable,
    DeclRef<CallableDecl> requiredMemberDeclRef,
    DeclRef<CallableDecl> satisfyingMemberDeclRef)
{
    witnessTable->add(requiredMemberDeclRef.getDecl(), RequirementWitness(satisfyingMemberDeclRef));
}

// Is it allowed to have an interface method parameter whose direction is `reqDir`, and an
// implementing method parameter whose direction is `implDir`?
//
static bool matchParamDirection(ParamPassingMode implDir, ParamPassingMode reqDir)
{
    // If the parameter directions match exactly, then we are good.
    if (implDir == reqDir)
        return true;
    // Otherwise, we only allow the cases where reqDir is `InOut` and implDir is `In` or `Out`.
    if (implDir == ParamPassingMode::In && reqDir == ParamPassingMode::BorrowInOut)
        return true;
    if (implDir == ParamPassingMode::Out && reqDir == ParamPassingMode::BorrowInOut)
        return true;
    return false;
}

static void removeNonStaticLookupItems(LookupResult& lookupResult)
{
    List<LookupResultItem> newItems;
    for (auto item : lookupResult)
    {
        if (item.declRef.getDecl()->findModifier<HLSLStaticModifier>())
        {
            newItems.add(item);
        }
        else if (auto genericDecl = as<GenericDecl>(item.declRef.getDecl()))
        {
            if (getInner(genericDecl)->findModifier<HLSLStaticModifier>())
            {
                newItems.add(item);
            }
        }
    }

    lookupResult.items = newItems;
    lookupResult.item = LookupResultItem();
    if (lookupResult.items.getCount() > 0)
    {
        lookupResult.item = lookupResult.items[0];
    }
}

static void removeStaticLookupItems(LookupResult& lookupResult)
{
    List<LookupResultItem> newItems;
    for (auto item : lookupResult)
    {
        bool isStatic = true;

        if (!item.declRef.getDecl()->findModifier<HLSLStaticModifier>())
        {
            isStatic = false;
        }
        else if (auto genericDecl = as<GenericDecl>(item.declRef.getDecl()))
        {
            if (!getInner(genericDecl)->findModifier<HLSLStaticModifier>())
            {
                isStatic = false;
            }
        }

        if (!isStatic)
        {
            newItems.add(item);
        }
    }

    lookupResult.items = newItems;
    lookupResult.item = LookupResultItem();
    if (lookupResult.items.getCount() > 0)
    {
        lookupResult.item = lookupResult.items[0];
    }
}

// Returns true if declRef points to an interface method requirement that has a default
// implementation.
HasInterfaceDefaultImplModifier* hasDefaultImpl(DeclRef<Decl> declRef)
{
    if (auto modifier = declRef.getDecl()->findModifier<HasInterfaceDefaultImplModifier>())
        return modifier;
    if (auto genericParent = as<GenericDecl>(declRef.getDecl()->parentDecl))
        return genericParent->findModifier<HasInterfaceDefaultImplModifier>();
    return nullptr;
}

void SemanticsVisitor::markOverridingDecl(
    ConformanceCheckingContext* context,
    Decl* memberDecl,
    DeclRef<Decl> requiredMemberDeclRef)
{
    if (!memberDecl->isChildOf(context->parentDecl))
    {
        // If the member being checked isn't the child of the container decl containing
        // the inheritance decl that triggers the conformance check, don't modify/diagnose
        // anything since it should have already been diagnosed when checking its parent.
        // This can happen when we check for things like:
        //    extension float : IComparable{}
        // where the method used to satisfy IComparable comes from outside the extension decl.
        // we don't want to diagnose or check anything about the found memberDecl that doesn't
        // belong to this extension decl (context->parentDecl).
        //
        return;
    }

    memberDecl = maybeGetInner(memberDecl);
    if (hasDefaultImpl(requiredMemberDeclRef))
    {
        // If the required member has a default implementation,
        // we need to make sure the member we found is marked as 'override'.
        if (!memberDecl->hasModifier<OverrideModifier>())
        {
            getSink()->diagnose(Diagnostics::MissingOverride{.decl = memberDecl});
        }
    }
    auto overridingModifier = m_astBuilder->create<IsOverridingModifier>();
    overridingModifier->overridedDecl = requiredMemberDeclRef.getDecl();
    addModifier(memberDecl, overridingModifier);
}

// Decide whether the non-static-satisfies-static adaptation may bind `firstArg` (the static
// requirement's first synthesized argument) as the implicit `this` of a non-static method. The
// synthesized body attaches this argument as the base of candidates that were looked up in the
// conforming type; nothing downstream re-checks that the base's type actually has those members, so
// this predicate -- not the later overload resolution -- is what keeps the receiver well-typed.
//
// The argument can serve as the receiver when its type is the conforming type. Requirements
// declared with a direct function type (the `__associatedfunc` autodiff derivatives
// `fwd_diff`/`bwd_diff`/ `remat`) are also permitted: these conform a *function* to a function
// interface
// (`IForwardDifferentiable<FType>` and friends), so `context->conformingType` is that function and
// never equals the receiver's type even though `firstArg` is in fact the receiver -- the equality
// test cannot recognize the receiver here, and the adaptation is how those derivatives are wired.
static bool canBindFirstArgAsReceiver(
    ConformanceCheckingContext* context,
    DeclRef<FuncDecl> requiredMemberDeclRef,
    Expr* firstArg)
{
    if (hasDirectFuncType(requiredMemberDeclRef))
        return true;

    auto firstArgType = firstArg->type.type;
    SLANG_ASSERT(firstArgType);
    SLANG_ASSERT(context->conformingType);

    // Semantic value modifiers such as `no_diff` affect how autodiff processes the value, but do
    // not change whether the value's underlying type can supply the receiver for the adapted call.
    // Keep those modifiers on the synthesized argument and compare only the nominal value types.
    return unwrapModifiedType(firstArgType)
        ->getCanonicalType()
        ->equals(unwrapModifiedType(context->conformingType)->getCanonicalType());
}

bool SemanticsVisitor::trySynthesizeMethodRequirementWitness(
    ConformanceCheckingContext* context,
    LookupResult const& lookupResult,
    DeclRef<FuncDecl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable,
    MethodWitnessSynthesisFailureDetails* outFailureDetails)
{
    // The situation here is that the context of an inheritance
    // declaration didn't provide an exact match for a required
    // method. E.g.:
    //
    //      interface ICounter { [mutating] int increment(); }
    //      struct MyCounter : ICounter
    //      {
    //          [mutating] int increment(int val = 1) { ... }
    //      }
    //
    // It is clear in this case that the `MyCounter` type *can*
    // satisfy the signature required by `ICounter`, but it has
    // no explicit method declaration that is a perfect match.
    //
    // The approach in this function will be to construct a
    // synthesized method along the lines of:
    //
    //      struct MyCounter ...
    //      {
    //          ...
    //          [murtating] int synthesized()
    //          {
    //              return this.increment();
    //          }
    //      }
    //
    // That is, we construct a method with the exact signature
    // of the requirement (same parameter and result types),
    // and then provide it with a body that simple `return`s
    // the result of applying the desired requirement name
    // (`increment` in this case) to those parameters.
    //
    // If the synthesized method type-checks, then we can say
    // that the type must satisfy the requirement structurally,
    // even if there isn't an exact signature match. More
    // importantly, the method we just synthesized can be
    // used as a witness to the fact that the requirement is
    // satisfied.

    // With the big picture spelled out, we can settle into
    // the work of constructing our synthesized method.
    //

    ThisExpr* synThis = nullptr;
    List<Expr*> synArgs;
    auto synFuncDecl = as<FunctionDeclBase>(synthesizeMethodSignatureForRequirementWitness(
        context,
        requiredMemberDeclRef,
        synArgs,
        synThis));

    auto resultType = synFuncDecl->returnType.type;
    if (!resultType)
    {
        return false;
    }

    // The body of our synthesized method is going to try to
    // make a call using the name of the method requirement (e.g.,
    // the name `increment` in our example at the top of this function).
    //
    // The caller already passed in a `LookupResult` that represents
    // an attempt to look up the given name in the type of `this`,
    // and we really just need to wrap that result up as an overloaded
    // expression.
    //
    auto baseOverloadedExpr = m_astBuilder->create<OverloadedExpr>();
    baseOverloadedExpr->name = requiredMemberDeclRef.getDecl()->getName();

    baseOverloadedExpr->lookupResult2 = lookupResult;

    // Track whether we are using a non-static method to satisfy a static requirement by treating
    // the first parameter as the receiver argument.
    bool nonStaticSatisfiesStatic = false;

    // Non-static methods cannot implement static methods, remove them.
    if (requiredMemberDeclRef.getDecl()->hasModifier<HLSLStaticModifier>())
    {
        removeNonStaticLookupItems(baseOverloadedExpr->lookupResult2);

        // If no static candidates remain, a non-static method can still satisfy this static
        // requirement by treating the requirement's first parameter as the receiver:
        //
        //      interface IFoo { static int method(This val, int x); }
        //      struct MyStruct : IFoo { int method(int x) { ... } }
        // Synthesized:
        //      static int $__syn_method(MyStruct val, int x) { return val.method(x); }
        //
        if (!baseOverloadedExpr->lookupResult2.isValid() && synArgs.getCount() > 0 &&
            canBindFirstArgAsReceiver(context, requiredMemberDeclRef, synArgs[0]))
        {
            // Restore the full lookup result and keep only non-static items.
            baseOverloadedExpr->lookupResult2 = lookupResult;
            removeStaticLookupItems(baseOverloadedExpr->lookupResult2);
            if (baseOverloadedExpr->lookupResult2.isValid())
            {
                nonStaticSatisfiesStatic = true;
                // Use the first synArg (corresponding to the first parameter
                // of the static requirement) as the base expression for the
                // member method call.
                baseOverloadedExpr->base = synArgs[0];
                synArgs.removeAt(0);
            }
        }
    }

    // If `synThis` is non-null, then we will use it as the base of
    // the overloaded expression, so that we have an overloaded
    // member reference, and not just an overloaded reference to some
    // static definitions.
    //
    if (synThis)
    {
        baseOverloadedExpr->base = synThis;
    }


    // In order to know if our call is well-formed, we need to run
    // the semantic checking logic for overload resolution. If it
    // runs into an error, we don't want that being reported back
    // to the user as some kind of overload-resolution failure.
    //
    // In order to protect the user from whatever errors might
    // occur, we will perform the checking in the context of
    // a temporary diagnostic sink.
    //
    DiagnosticSink tempSink(getSourceManager(), nullptr);
    ExprLocalScope localScope;
    SemanticsVisitor subVisitor(withSink(&tempSink)
                                    .withParentFunc(synFuncDecl)
                                    .withExprLocalScope(&localScope)
                                    .withEnclosingTryClauseType(TryClauseType::Standard));


    Expr* synBase = baseOverloadedExpr;

    // If the requirement is a generic decl, fill in all generic arguments explicitly.
    if (auto genericDeclRef = as<GenericDecl>(synFuncDecl->parentDecl))
    {
        auto genericAppExpr = m_astBuilder->create<GenericAppExpr>();
        genericAppExpr->functionExpr = synBase;
        for (auto member : genericDeclRef->getDirectMemberDecls())
        {
            if (auto typeParamDecl = as<GenericTypeParamDeclBase>(member))
            {
                auto synTypeParamDeclRef = makeDeclRef(typeParamDecl);
                auto synTypeParamDeclRefExpr = m_astBuilder->create<VarExpr>();
                synTypeParamDeclRefExpr->declRef = synTypeParamDeclRef;
                synTypeParamDeclRefExpr->type =
                    getTypeForDeclRef(m_astBuilder, synTypeParamDeclRef, SourceLoc());
                genericAppExpr->arguments.add(synTypeParamDeclRefExpr);
            }
            else if (auto valParamDecl = as<GenericValueParamDecl>(member))
            {
                auto synValParamDeclRef = makeDeclRef(valParamDecl);
                auto synValParamDeclRefExpr = m_astBuilder->create<VarExpr>();
                synValParamDeclRefExpr->declRef = synValParamDeclRef;
                synValParamDeclRefExpr->type = getType(m_astBuilder, synValParamDeclRef);
                genericAppExpr->arguments.add(synValParamDeclRefExpr);
            }
            else if (auto valPackParamDecl = as<GenericValuePackParamDecl>(member))
            {
                auto synValPackParamDeclRef = makeDeclRef(valPackParamDecl);
                auto synValPackParamDeclRefExpr = m_astBuilder->create<VarExpr>();
                synValPackParamDeclRefExpr->declRef = synValPackParamDeclRef;
                synValPackParamDeclRefExpr->type = getType(m_astBuilder, synValPackParamDeclRef);
                genericAppExpr->arguments.add(synValPackParamDeclRefExpr);
            }
        }
        synBase = subVisitor.CheckExpr(genericAppExpr);

        // If checking the generic app failed, we can't synthesize the witness.
        //
        if (tempSink.getErrorCount() != 0)
        {
            if (outFailureDetails)
                outFailureDetails->reason = WitnessSynthesisFailureReason::GenericSignatureMismatch;
            return false;
        }
    }

    // We now have the reference to the overload group we plan to call,
    // and we already built up the argument list, so we can construct
    // an `InvokeExpr` that represents the call we want to make.
    //
    auto synCall = m_astBuilder->create<InvokeExpr>();
    synCall->functionExpr = synBase;
    synCall->arguments = synArgs;

    // With our temporary diagnostic sink soaking up any messages
    // from overload resolution, we can now try to resolve
    // the call to see what happens.
    //
    auto checkedCall = subVisitor.CheckExpr(synCall);
    auto checkedExpr = checkedCall;

    if (auto invokeExpr = as<InvokeExpr>(checkedCall))
    {
        if (auto funcType = as<FuncType>(invokeExpr->functionExpr->type))
        {
            if (!funcType->getErrorType()->equals(m_astBuilder->getBottomType()))
            {
                // Throws, so unless our interface requirement also does that,
                // we can't call it here.
                if (synFuncDecl->errorType->equals(m_astBuilder->getBottomType()))
                    return false;

                auto tryExpr = m_astBuilder->create<TryExpr>();
                tryExpr->tryClauseType = TryClauseType::Standard;
                tryExpr->base = checkedCall;
                checkedExpr = subVisitor.CheckExpr(tryExpr);
            }
        }
    }

    // Of course, it is possible that the call went through fine,
    // but the result isn't of the type we expect/require,
    // so we also need to coerce the result of the call to
    // the expected type.
    //
    SemanticsVisitor coercionContext = subVisitor.allowDroppingDerivatives();
    auto coercedCall =
        coercionContext.coerce(CoercionSite::Return, resultType, checkedExpr, &tempSink);

    // If our overload resolution or type coercion failed,
    // then we have not been able to synthesize a witness
    // for the requirement.
    //
    // Check if this was specifically a return type coercion failure
    // and provide a more specific diagnostic.
    //
    if (tempSink.getErrorCount() != 0)
    {
        if (outFailureDetails)
            outFailureDetails->reason = WitnessSynthesisFailureReason::General;

        // Check if the failure was due to return type coercion
        if (!IsErrorExpr(checkedExpr) && outFailureDetails)
        {
            // The call resolved - check if it's a return type mismatch
            auto actualReturnType = checkedExpr->type;
            if (!actualReturnType->equals(resultType))
            {
                // Find the actual implementation method that was called
                if (auto invokeExpr = as<InvokeExpr>(checkedCall))
                {
                    if (auto declRefExpr = as<DeclRefExpr>(invokeExpr->functionExpr))
                    {
                        // Store failure details instead of emitting diagnostic immediately
                        outFailureDetails->reason =
                            WitnessSynthesisFailureReason::MethodResultTypeMismatch;
                        outFailureDetails->candidateMethod = declRefExpr->declRef;
                        outFailureDetails->actualType = actualReturnType;
                        outFailureDetails->expectedType = resultType;
                    }
                }
            }
        }
        return false;
    }

    // If we were able to type-check the call, we also need to make
    // sure that the resolved callee member has consistent parameter
    // direction as the requirement method.
    //
    // For example, if there is a requirement:
    // ```
    // interface IFoo { void method(out int x); }
    // ```
    // and a type:
    // ```
    // struct X : IFoo { void method(int x) { ... } }
    // ```
    // After we synthesize:
    // ```
    // void X::synthesized_method(out int x) { this.method(x); }
    // ```
    // The synthesized method will pass all type check just fine,
    // but we don't want to allow this method to be used as a witness
    // for the requirement due to inconsistent parameter direction.
    // So let's check for this now.
    //
    if (auto checkedInvoke = as<InvokeExpr>(checkedCall))
    {
        if (auto declRefExpr = as<DeclRefExpr>(checkedInvoke->functionExpr))
        {
            if (auto callee = as<CallableDecl>(declRefExpr->declRef))
            {
                synFuncDecl->loc = callee.getDecl()->loc;
                auto synParams = synFuncDecl->getParameters();
                auto calleeParams = callee.getDecl()->getParameters();
                auto synParamIter = synParams.begin();
                // When a non-static method satisfies a static requirement, the first
                // parameter of the synthesized function was consumed as the base
                // expression for the member call, so skip it in the direction check.
                if (nonStaticSatisfiesStatic && synParamIter != synParams.end())
                    ++synParamIter;
                auto calleeParamIter = calleeParams.begin();
                for (; synParamIter != synParams.end() && calleeParamIter != calleeParams.end();
                     ++synParamIter, ++calleeParamIter)
                {
                    auto synParam = *synParamIter;
                    auto calleeParam = *calleeParamIter;
                    if (!matchParamDirection(
                            getParamPassingMode(calleeParam),
                            getParamPassingMode(synParam)))
                    {
                        if (outFailureDetails)
                        {
                            outFailureDetails->reason =
                                WitnessSynthesisFailureReason::ParameterDirMismatch;
                            outFailureDetails->candidateMethod = declRefExpr->declRef;
                            outFailureDetails->actualDir = getParamPassingMode(calleeParam);
                            outFailureDetails->expectedDir = getParamPassingMode(synParam);
                            outFailureDetails->paramDecl = calleeParam;
                        }
                        return false;
                    }
                }

                // The synthesized wrapper initially inherits differentiability modifiers from the
                // interface requirement, so overload resolution can build any derivative
                // associations it needs while checking the call.  If the resolved callee cannot
                // provide the same differentiability, a hard [ForwardDifferentiable] or
                // [Differentiable]/[BackwardDifferentiable] requirement cannot be satisfied by
                // this wrapper.  For [MaybeDifferentiable], however, the modifiers were only
                // provisional, so we can drop them and still use the wrapper as a
                // non-differentiable witness.
                //
                // More generally, this is the part where we are trying to derive synthesized
                // wrapper conformances from the callee's conformances. For now, it's
                // differentiability specific but can be generalized later if we add more function
                // conformance kinds.
                //
                if (!isFuncForwardDifferentiable(callee))
                {
                    if (auto fwdDiffModifier =
                            synFuncDecl->findModifier<ForwardDifferentiableAttribute>())
                    {
                        // A non-optional forward-differentiable requirement cannot be fulfilled
                        // by forwarding to a callee with no forward derivative.
                        if (requiredMemberDeclRef.getDecl()
                                ->findModifier<ForwardDifferentiableAttribute>())
                        {
                            if (outFailureDetails)
                            {
                                outFailureDetails->reason =
                                    WitnessSynthesisFailureReason::DifferentiabilityMismatch;
                                outFailureDetails->candidateMethod = declRefExpr->declRef;
                            }
                            return false;
                        }

                        // If the requirement has [ForwardDifferentiable], the wrapper will already
                        // have the same modifier. We'll remove it since we know we can't derive a
                        // forward derivative, but may still want to use this for a
                        // [MaybeDifferentiable] (i.e. optional) requirement.
                        //
                        removeModifier(synFuncDecl, fwdDiffModifier);
                    }
                }

                // Similar to the ForwardDifferentiable case, but for backward differentiability.
                if (!isFuncBackwardDifferentiable(callee))
                {
                    if (auto bwdDiffModifier =
                            synFuncDecl->findModifier<BackwardDifferentiableAttribute>())
                    {
                        if (requiredMemberDeclRef.getDecl()
                                ->findModifier<BackwardDifferentiableAttribute>())
                        {
                            if (outFailureDetails)
                            {
                                outFailureDetails->reason =
                                    WitnessSynthesisFailureReason::DifferentiabilityMismatch;
                                outFailureDetails->candidateMethod = declRefExpr->declRef;
                            }
                            return false;
                        }
                        removeModifier(synFuncDecl, bwdDiffModifier);
                    }
                }

                markOverridingDecl(context, callee.getDecl(), requiredMemberDeclRef);
            }
        }
    }


    // We've already created the outer declaration (including its
    // parameters), and the inner expression, so the main work
    // that is left is defining the body of the new function,
    // which comprises a single `return` statement.
    //
    auto synReturn = m_astBuilder->create<ReturnStmt>();
    synReturn->expression = coercedCall;

    synFuncDecl->body = synReturn;

    // Note: we set the parent of the synthesized declaration
    // to the parent of the inheritance declaration being
    // validated (which is either a type declaration or
    // an `extension`), but we do *not* add the syntehsized
    // declaration to the list of child declarations at
    // this point.
    //
    // The synthesized decl already has its parent set to
    // the current parent decl, so we don't need more actions
    // to wire it up to the AST hierarchy.
    //
    // By leaving the synthesized declaration off of the list
    // of members, we ensure that it doesn't get found
    // by lookup (e.g., in a module that `import`s this type).
    // Unfortunately, we may also break invariants in other parts
    // of the code if they assume that all declarations have
    // to appear in the parent/child hierarchy of the module.
    //
    // TODO: We may need to properly wire the synthesized
    // declaration into the hierarchy, but then attach a modifier
    // to it to indicate that it should be ignored by things like lookup.
    //

    // Once our synthesized declaration is complete, we need
    // to install it as the witness that satifies the given
    // requirement.
    //
    // Subsequent code generation should not be able to tell the
    // difference between our synthetic method and a hand-written
    // one with the same behavior.
    //
    auto containerDecl = getParentDecl(synFuncDecl);
    auto containerDeclRef = getDefaultDeclRef(containerDecl);
    auto synDeclRef = m_astBuilder->getMemberDeclRef(containerDeclRef, synFuncDecl);
    //_addMethodWitness(witnessTable, requiredMemberDeclRef, synDeclRef);

    if (requiredMemberDeclRef.getParent().as<GenericDecl>())
    {
        // Test signature and register in witness table.
        bool doesSignatureMatch = doesGenericSignatureMatchRequirement(
            synDeclRef.getParent().as<GenericDecl>(),
            requiredMemberDeclRef.getParent().as<GenericDecl>(),
            witnessTable);
        if (!doesSignatureMatch)
        {
            if (outFailureDetails)
                outFailureDetails->reason = WitnessSynthesisFailureReason::GenericSignatureMismatch;
            return false;
        }
    }
    else
    {
        // Test signature and register in witness table.
        bool doesSignatureMatch = doesSignatureMatchRequirement(
            synDeclRef.as<FuncDecl>(),
            requiredMemberDeclRef,
            witnessTable);
        if (!doesSignatureMatch)
        {
            return false;
        }
    }

    // The wrapper is intentionally absent from its parent's member list so that ordinary lookup
    // cannot expose it. Register only after signature validation has installed the final witness;
    // failed speculative wrappers must not participate in later semantic phases.
    getShared()->registerSynthesizedDeclRoot(_getSynthesizedDeclRoot(synFuncDecl));

    return true;
}

bool SemanticsVisitor::trySynthesizeConstructorRequirementWitness(
    ConformanceCheckingContext* context,
    LookupResult const& satisfyingMemberLookupResult,
    DeclRef<ConstructorDecl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    SLANG_UNUSED(satisfyingMemberLookupResult);

    if (as<EnumDecl>(context->parentDecl))
    {
        if (auto builtinRequirement =
                requiredMemberDeclRef.getDecl()->findModifier<BuiltinRequirementModifier>())
        {
            return trySynthesizeEnumTypeMethodRequirementWitness(
                context,
                requiredMemberDeclRef,
                witnessTable,
                builtinRequirement->kind);
        }
    }

    bool isDefaultInitializableType = requiredMemberDeclRef.getParent() ==
                                      getASTBuilder()->getDefaultInitializableTypeInterfaceDecl();
    if (!isDefaultInitializableType && !satisfyingMemberLookupResult.isValid())
    {
        return false;
    }

    List<Expr*> synArgs;
    ThisExpr* synThis = nullptr;

    auto ctorDecl = (ConstructorDecl*)synthesizeMethodSignatureForRequirementWitness(
        context,
        requiredMemberDeclRef,
        synArgs,
        synThis);
    ctorDecl->loc = context->parentDecl->loc;
    ctorDecl->closingSourceLoc = ctorDecl->loc;
    auto ctorName = getName("$init");
    ctorDecl->nameAndLoc.name = ctorName;
    ctorDecl->nameAndLoc.loc = context->parentDecl->loc;

    auto seqStmt = m_astBuilder->create<SeqStmt>();
    ctorDecl->body = seqStmt;

    if (synArgs.getCount())
    {
        // The body of our synthesized method is going to try to
        // make a ctor call with the specified arguments (e.g.,
        // the name `increment` in our example at the top of this function).
        //
        auto synBase = m_astBuilder->create<OverloadedExpr>();
        synBase->name = requiredMemberDeclRef.getDecl()->getName();

        synBase->lookupResult2 = satisfyingMemberLookupResult;

        // We now have the reference to the overload group we plan to call,
        // and we already built up the argument list, so we can construct
        // an `InvokeExpr` that represents the call we want to make.
        //
        auto synCall = m_astBuilder->create<InvokeExpr>();
        synCall->functionExpr = synBase;
        synCall->arguments = synArgs;

        // In order to know if our call is well-formed, we need to run
        // the semantic checking logic for overload resolution. If it
        // runs into an error, we don't want that being reported back
        // to the user as some kind of overload-resolution failure.
        //
        // In order to protect the user from whatever errors might
        // occur, we will perform the checking in the context of
        // a temporary diagnostic sink.
        //
        DiagnosticSink tempSink(getSourceManager(), nullptr);
        ExprLocalScope localScope;
        SemanticsVisitor subVisitor(
            withSink(&tempSink).withParentFunc(ctorDecl).withExprLocalScope(&localScope));

        // With our temporary diagnostic sink soaking up any messages
        // from overload resolution, we can now try to resolve
        // the call to see what happens.
        //
        auto checkedCall = subVisitor.ResolveInvoke(synCall);

        // If any error occurs during overload resolution, we can't synthesize the witness.
        if (tempSink.getErrorCount() != 0)
            return false;

        // If we were able to type-check the call, then we should
        // be able to finish construction of a suitable ctor witness,
        // by emitting `this = resolvedCtorCall()`.
        //
        AssignExpr* assignExpr = m_astBuilder->create<AssignExpr>();
        assignExpr->left = synThis;
        assignExpr->right = checkedCall;
        assignExpr->type = m_astBuilder->getVoidType();
        ExpressionStmt* exprStmt = m_astBuilder->create<ExpressionStmt>();
        exprStmt->expression = assignExpr;
        seqStmt->stmts.add(exprStmt);
    }

    if (isDefaultInitializableType)
        context->parentDecl->addMember(ctorDecl);

    auto containerDecl = getParentDecl(ctorDecl);
    auto containerDeclRef = getDefaultDeclRef(containerDecl);
    auto synDeclRef = m_astBuilder->getMemberDeclRef(containerDeclRef, ctorDecl);
    _addMethodWitness(witnessTable, requiredMemberDeclRef, synDeclRef);

    // Non-default constructor witnesses stay out of the member list, while default constructor
    // witnesses are published late during conformance checking. Register both shapes at their
    // common successful-publication point.
    getShared()->registerSynthesizedDeclRoot(_getSynthesizedDeclRoot(ctorDecl));

    return true;
}

bool SemanticsVisitor::trySynthesizePropertyRequirementWitness(
    ConformanceCheckingContext* context,
    LookupResult const& lookupResult,
    DeclRef<PropertyDecl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    // The situation here is that the context of an inheritance
    // declaration didn't provide an exact match for a required
    // property. E.g.:
    //
    //      interface ICell { property value : int { get; set; } }
    //      struct MyCell : ICell
    //      {
    //          int value;
    //      }
    //
    // It is clear in this case that the `MyCell` type *can*
    // satisfy the signature required by `ICell`, but it has
    // no explicit `property` declaration, and instead just
    // a field with the right name and type.
    //
    // The approach in this function will be to construct a
    // synthesized `preoperty` along the lines of:
    //
    //      struct MyCounter ...
    //      {
    //          ...
    //          property value_synthesized : int
    //          {
    //              get { return this.value; }
    //              set(newValue) { this.value = newValue; }
    //          }
    //      }
    //
    // That is, we construct a `property` with the correct type
    // and with an accessor for each requirement, where the accesors
    // all try to read or write `this.value`.
    //
    // If those synthesized accessors all type-check, then we can
    // say that the type must satisfy the requirement structurally,
    // even if there isn't an exact signature match. More
    // importantly, the `property` we just synthesized can be
    // used as a witness to the fact that the requirement is
    // satisfied.
    //
    // The big-picture flow of the logic here is similar to
    // `trySynthesizeMethodRequirementWitness()` above, and we
    // will not comment this code as exhaustively, under the
    // assumption that readers of the code don't benefit from
    // having the exact same information stated twice.

    // With the introduction out of the way, let's get started
    // constructing a synthesized `PropertyDecl`.
    //
    auto synPropertyDecl = m_astBuilder->create<PropertyDecl>();

    // Synthesize the property name with a prefix to avoid name clashing.
    synPropertyDecl->nameAndLoc = requiredMemberDeclRef.getDecl()->nameAndLoc;
    synPropertyDecl->nameAndLoc.name =
        getName(String("$syn_property_") + getText(requiredMemberDeclRef.getName()));
    synPropertyDecl->parentDecl = context->parentDecl;
    synPropertyDecl->ownedScope = m_astBuilder->create<Scope>();
    synPropertyDecl->ownedScope->containerDecl = synPropertyDecl;
    synPropertyDecl->ownedScope->parent = context->parentDecl->ownedScope;

    // The type of our synthesized property can be derived from the
    // specialized declref to the requirement decl.
    //
    auto propertyType = getType(m_astBuilder, requiredMemberDeclRef);
    synPropertyDecl->type.type = propertyType;


    List<Expr*> synthesizedContainerArgs;
    bool canSynAccessors = synthesizeAccessorRequirements(
        context,
        requiredMemberDeclRef,
        propertyType,
        lookupResult,
        synthesizedContainerArgs,
        synPropertyDecl,
        witnessTable);
    if (!canSynAccessors)
        return false;


    // The visibility of synthesized decl should be the min of the parent decl and the requirement.
    if (requiredMemberDeclRef.getDecl()->findModifier<VisibilityModifier>())
    {
        auto requirementVisibility = getDeclVisibility(requiredMemberDeclRef.getDecl());
        auto thisVisibility = getDeclVisibility(context->parentDecl);
        auto visibility = Math::Min(thisVisibility, requirementVisibility);
        addVisibilityModifier(synPropertyDecl, visibility);
    }

    // The property and its accessors are private witness implementation details and deliberately
    // stay out of ordinary lookup. Their witness-table entries are final at this point.
    getShared()->registerSynthesizedDeclRoot(_getSynthesizedDeclRoot(synPropertyDecl));
    return true;
}

/// Construct the storage expression for one synthesized property or subscript accessor.
///
/// Consider a field satisfying `property value : int { get; set; }`. The getter and setter need
/// distinct `this.value` expression trees whose `ThisExpr`s are scoped to their respective
/// accessors. Sharing a property-scoped tree would also share the value category computed from one
/// accessor's effective `this` parameter mode. Subscript wrappers follow the same rule and clone
/// their index argument expressions so that each accessor body owns its complete expression tree.
static Expr* _createSynthesizedAccessorStorageExpr(
    SemanticsVisitor* visitor,
    DeclRef<ContainerDecl> requiredMemberDeclRef,
    LookupResult const& lookupResult,
    List<Expr*> const& synthesizedContainerArgs,
    ThisExpr* synthesizedThisExpr)
{
    auto astBuilder = visitor->getASTBuilder();

    // Check only the accessor-local receiver syntax before materializing the selected lookup path.
    // `createLookupResultExpr()` constructs semantic AST from that path, including transparent-
    // member, dereference, and supertype breadcrumbs. Sending those constructed member nodes back
    // through ordinary expression checking would perform name lookup again and could select a
    // different path.
    auto checkedThisExpr = visitor->CheckTerm(synthesizedThisExpr);
    SLANG_RELEASE_ASSERT(checkedThisExpr == synthesizedThisExpr);

    if (requiredMemberDeclRef.as<PropertyDecl>())
    {
        auto storageExpr = visitor->createLookupResultExpr(
            requiredMemberDeclRef.getName(),
            lookupResult,
            synthesizedThisExpr,
            requiredMemberDeclRef.getLoc(),
            nullptr);
        storageExpr->loc = requiredMemberDeclRef.getLoc();

        // Treat the materialized lookup path as checked syntax, while still letting `CheckExpr`
        // disambiguate the overloaded-root case. Overload resolution can return a new semantic
        // root, so mark that result as checked as well.
        storageExpr->checked = true;
        storageExpr = visitor->CheckExpr(storageExpr);
        storageExpr->checked = true;

        // `visitVarDecl()` currently strips `no_diff` off a field's type and records it on the
        // declaration. Restore that modifier on the field reference observed by the wrapper.
        // TODO: Remove this special case once modified types no longer need that normalization.
        if (lookupResult.isValid() && !lookupResult.isOverloaded())
        {
            if (auto storageDeclRef = lookupResult.item.declRef.as<VarDeclBase>())
            {
                if (storageDeclRef.getDecl()->findModifier<NoDiffModifier>())
                {
                    storageExpr->type.type = getTypeWithModifier(
                        storageExpr->type.type,
                        astBuilder->getNoDiffModifierVal());
                }
            }
        }
        return storageExpr;
    }

    SLANG_RELEASE_ASSERT(requiredMemberDeclRef.as<SubscriptDecl>());

    // The argument expressions are syntax owned by the synthesized subscript signature. Clone
    // them for each accessor so delayed body checking cannot observe checked-state mutations from
    // a sibling accessor.
    List<Expr*> synthesizedArgs;
    ASTCloner cloner(astBuilder, visitor);
    for (auto arg : synthesizedContainerArgs)
        synthesizedArgs.add(cloner.cloneExpr(arg));

    if (lookupResult.isValid())
    {
        auto calleeExpr = astBuilder->create<OverloadedExpr>();
        calleeExpr->base = synthesizedThisExpr;
        calleeExpr->lookupResult2 = lookupResult;

        auto invokeExpr = astBuilder->create<InvokeExpr>();
        invokeExpr->functionExpr = calleeExpr;
        invokeExpr->arguments = _Move(synthesizedArgs);

        // Fully resolve the selected original subscript before publishing the wrapper. Leaving the
        // invocation unresolved could let later body checking bind it back to the wrapper itself.
        return visitor->CheckExpr(invokeExpr);
    }

    auto indexExpr = astBuilder->create<IndexExpr>();
    indexExpr->baseExpression = synthesizedThisExpr;
    indexExpr->indexExprs = _Move(synthesizedArgs);
    return visitor->CheckTerm(indexExpr);
}

bool SemanticsVisitor::synthesizeAccessorRequirements(
    ConformanceCheckingContext* context,
    DeclRef<ContainerDecl> requiredMemberDeclRef,
    Type* resultType,
    LookupResult const& lookupResult,
    List<Expr*> const& synthesizedContainerArgs,
    ContainerDecl* synthesizedAccessorContainer,
    RefPtr<WitnessTable> witnessTable)
{
    Dictionary<DeclRef<AccessorDecl>, AccessorDecl*> mapRequiredAccessorToSynAccessor;
    for (auto requiredAccessorDeclRef :
         getMembersOfType<AccessorDecl>(m_astBuilder, requiredMemberDeclRef))
    {
        // This synthesis path forwards through an instance expression rooted at `this`. An exact
        // static accessor witness is installed directly before reaching this path, but adapting a
        // mismatched static accessor would instead require a type-based lookup expression. Decline
        // that unsupported conversion rather than manufacturing a receiver for a declaration that
        // has no effective `this` parameter.
        auto requiredThisInfo = findEffectiveThisParamInfo(requiredAccessorDeclRef);
        if (!requiredThisInfo)
            return false;

        // The synthesized accessor will be an AST node of the same class as
        // the required accessor.
        //
        auto synAccessorDecl = (AccessorDecl*)m_astBuilder->createByNodeType(
            requiredAccessorDeclRef.getDecl()->astNodeType);
        synAccessorDecl->ownedScope = m_astBuilder->create<Scope>();
        synAccessorDecl->ownedScope->containerDecl = synAccessorDecl;
        synAccessorDecl->ownedScope->parent = getScope(context->parentDecl);

        // Whatever the required accessor returns, that is what our synthesized accessor will
        // return.
        //
        synAccessorDecl->returnType.type = resultType;

        // Similarly, our synthesized accessor will have parameters matching those of the
        // requirement.
        //
        // Note: in practice we expect that only `set` accessors will have any parameters,
        // and they will only have a single parameter.
        //
        List<Expr*> synArgs;
        for (auto requiredParamDeclRef : getParameters(m_astBuilder, requiredAccessorDeclRef))
        {
            auto paramInfo = getParamInfo(m_astBuilder, requiredParamDeclRef);

            auto synParamDecl = m_astBuilder->create<ParamDecl>();
            synParamDecl->nameAndLoc = requiredParamDeclRef.getDecl()->nameAndLoc;
            _configureSynthesizedParamDecl(m_astBuilder, synParamDecl, paramInfo);

            // We need to add the parameter as a child declaration of
            // the accessor we are building.
            //
            synAccessorDecl->addMember(synParamDecl);

            // For each paramter, we will create an argument expression
            // to represent it in the body of the accessor.
            //
            auto synArg = m_astBuilder->create<VarExpr>();
            synArg->declRef = makeDeclRef(synParamDecl);
            synArg->type.type = paramInfo.type;
            synArg->type.isLeftValue = doesParamPassingModeIndicateWritableStorage(paramInfo.mode);
            synArgs.add(synArg);
        }

        // We need to create a `this` expression to be used in the body of the synthesized
        // accessor. The receiver check above excludes static accessors from this instance-only
        // synthesis path.
        ThisExpr* synThis = m_astBuilder->create<ThisExpr>();
        synThis->scope = synAccessorDecl->ownedScope;

        // The type of `this` in our accessor will be the type for
        // which we are synthesizing a conformance.
        //
        synThis->type.type = context->conformingType;

        _configureSynthesizedEffectiveThisParam(
            m_astBuilder,
            synAccessorDecl,
            synThis,
            *requiredThisInfo);

        // Parent the accessor before checking its body. In particular, checking an accessor-local
        // `this` expression queries the accessor's effective `this` parameter information. That
        // information depends on the complete declaration path through the property or subscript
        // to the enclosing type. The container is still speculative and is not published as a
        // witness unless all of its accessors succeed.
        synthesizedAccessorContainer->addMember(synAccessorDecl);

        // We are going to synthesize an expression and then perform
        // semantic checking on it, but if there are semantic errors
        // we do *not* want to report them to the user as such, and
        // instead want the result to be a failure to synthesize
        // a valid witness.
        //
        // We will buffer up diagnostics into a temporary sink and
        // then throw them away when we are done.
        //
        // TODO: This behavior might be something we want to make
        // into a more fundamental capability of `DiagnosticSink` and/or
        // `SemanticsVisitor` so that code can push/pop the emission
        // of diagnostics more easily.
        //
        DiagnosticSink tempSink(getSourceManager(), nullptr);
        SemanticsVisitor subVisitor(withSink(&tempSink));
        auto synthesizedStorageExpr = _createSynthesizedAccessorStorageExpr(
            &subVisitor,
            requiredMemberDeclRef,
            lookupResult,
            synthesizedContainerArgs,
            synThis);
        if (tempSink.getErrorCount() != 0)
            return false;

        // The body of the accessor will depend on the class of the accessor
        // we are synthesizing (e.g., `get` vs. `set`).
        //
        Stmt* synBodyStmt = nullptr;
        if (as<GetterDecl>(requiredAccessorDeclRef))
        {
            // A `get` accessor will simply perform:
            //
            //      return this.name;
            //
            // which involves coercing the member access `this.name` to
            // the expected type of the property.
            //
            auto coercedMemberRef = subVisitor.coerce(
                CoercionSite::Return,
                resultType,
                synthesizedStorageExpr,
                &tempSink);
            auto synReturn = m_astBuilder->create<ReturnStmt>();
            synReturn->expression = coercedMemberRef;

            synBodyStmt = synReturn;
        }
        else if (as<SetterDecl>(requiredAccessorDeclRef))
        {
            // We expect all `set` accessors to have a single argument,
            // but we will defensively bail out if that is somehow
            // not the case.
            //
            SLANG_ASSERT(synArgs.getCount() == 1);
            if (synArgs.getCount() != 1)
                return false;

            // A `set` accessor will simply perform:
            //
            //      this.name = newValue;
            //
            // which involves creating and checking an assignment
            // expression.

            auto synAssign = m_astBuilder->create<AssignExpr>();
            synAssign->left = synthesizedStorageExpr;
            synAssign->right = synArgs[0];

            auto synCheckedAssign = subVisitor.checkAssignWithCheckedOperands(synAssign);

            auto synExprStmt = m_astBuilder->create<ExpressionStmt>();
            synExprStmt->expression = synCheckedAssign;

            synBodyStmt = synExprStmt;
        }
        else
        {
            // While there are other kinds of accessors than `get` and `set`,
            // those are currently only reserved for the internal use in the core module.
            // We will not bother with synthesis for those cases.
            //
            return false;
        }

        // We bail out if we ran into any errors (meaning that the synthesized
        // accessor is not usable).
        //
        // TODO: If there were *warnings* emitted to the sink, it would probably
        // be good to show those warnings to the user, since they might indicate
        // real issues. E.g., with the current logic a `float` field could
        // satisfying an `int` property requirement, but the user would probably
        // want to be warned when they do such a thing.
        //
        if (tempSink.getErrorCount() != 0)
            return false;

        synAccessorDecl->body = synBodyStmt;

        // TODO: This a slight workaround for accessor differentiability being tricky to handle
        addModifier(synAccessorDecl, m_astBuilder->create<ForceInlineAttribute>());

        // If synthesis of an accessor worked, then we will record it into
        // a local dictionary. We do *not* install the accessor into the
        // witness table yet, because it is possible that synthesis will
        // succeed for some accessors but not others, and we don't want
        // to leave the witness table in a state where a requirement is
        // "partially satisfied."
        //
        mapRequiredAccessorToSynAccessor.add(requiredAccessorDeclRef, synAccessorDecl);
    }

    // Once our synthesized declaration is complete, we need
    // to install it as the witness that satifies the given
    // requirement.
    //
    // Subsequent code generation should not be able to tell the
    // difference between our synthetic property and a hand-written
    // one with the same behavior.
    //
    auto containerDecl = getParentDecl(synthesizedAccessorContainer);
    auto containerDeclRef = getDefaultDeclRef(containerDecl);
    for (auto& [key, value] : mapRequiredAccessorToSynAccessor)
    {
        witnessTable->add(
            key.getDecl(),
            RequirementWitness(m_astBuilder->getMemberDeclRef(containerDeclRef, value)));
    }

    witnessTable->add(
        requiredMemberDeclRef.getDecl(),
        RequirementWitness(
            m_astBuilder->getMemberDeclRef(containerDeclRef, synthesizedAccessorContainer)));
    return true;
}

bool SemanticsVisitor::trySynthesizeSubscriptRequirementWitness(
    ConformanceCheckingContext* context,
    const LookupResult& lookupResult,
    DeclRef<SubscriptDecl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable)
{
    // The situation here is that the context of an inheritance
    // declaration didn't provide an exact match for a required
    // subscript. E.g.:
    //
    //      interface ICell { subscript(int index)->int {get;} }
    //      struct MyCell : ICell
    //      {
    //          subscript(uint index)->int {ref;}
    //      }
    //
    // It is clear in this case that the `MyCell` type *can*
    // satisfy the signature required by `ICell`, if we consider
    // all the allowed type coercion rules, and use `ref` accessor
    // to implement `get`.
    //
    // The approach in this function will be to construct a
    // synthesized `subscript` along the lines of:
    //
    //      struct MyCell ...
    //      {
    //          ...
    //          subscript(int index)->int {get;}
    //          {
    //              get { return this.origianl_subscript[index]; }
    //          }
    //      }
    //
    // That is, we construct a `subscript` with the correct type
    // and with an accessor for each requirement, where the accesors
    // all try to dispatch to the original subscript decl.
    //
    // If those synthesized accessors all type-check, then we can
    // say that the type must satisfy the requirement structurally,
    // even if there isn't an exact signature match. More
    // importantly, the `property` we just synthesized can be
    // used as a witness to the fact that the requirement is
    // satisfied.
    //
    // The big-picture flow of the logic here is similar to
    // `trySynthesizePropertyRequirementWitness()` above, and we
    // will not comment this code as exhaustively, under the
    // assumption that readers of the code don't benefit from
    // having the exact same information stated twice.
    //

    if (!lookupResult.isValid() && hasDefaultImpl(requiredMemberDeclRef))
    {
        // A missing concrete subscript should be satisfied by the interface
        // default implementation below. The no-lookup synthesis path is for
        // valid built-in indexing shapes, and applying it here would synthesize
        // `this[args...]` as the witness for the same requirement, producing a
        // recursive accessor wrapper.
        return false;
    }

    List<Expr*> synArgs;
    ThisExpr* synThis = nullptr;
    auto synSubscriptDecl = synthesizeMethodSignatureForRequirementWitness(
        context,
        requiredMemberDeclRef,
        synArgs,
        synThis);
    // Signature synthesis creates the subscript declaration's effective `this` parameter metadata
    // and a matching `this` expression together. The subscript has no body of its own, so that
    // expression is unused here. Each accessor below creates its own metadata and expression from
    // the corresponding accessor requirement.
    auto declType = getType(m_astBuilder, getDefaultDeclRef(synSubscriptDecl).as<SubscriptDecl>());
    SLANG_UNUSED(synThis);

    // Our synthesized subscript will have an accessor declaration for
    // each accessor of the requirement.
    //
    bool canSynAccessors = synthesizeAccessorRequirements(
        context,
        requiredMemberDeclRef,
        declType,
        lookupResult,
        synArgs,
        synSubscriptDecl,
        witnessTable);
    if (!canSynAccessors)
        return false;


    // The visibility of synthesized decl should be the min of the parent decl and the requirement.
    if (requiredMemberDeclRef.getDecl()->findModifier<VisibilityModifier>())
    {
        auto requirementVisibility = getDeclVisibility(requiredMemberDeclRef.getDecl());
        auto thisVisibility = getDeclVisibility(context->parentDecl);
        auto visibility = Math::Min(thisVisibility, requirementVisibility);
        addVisibilityModifier(synSubscriptDecl, visibility);
    }

    // As with a synthesized property, this container is reachable through the witness table but
    // deliberately absent from the parent's member list.
    getShared()->registerSynthesizedDeclRoot(_getSynthesizedDeclRoot(synSubscriptDecl));

    return true;
}

bool SemanticsVisitor::trySynthesizeRequirementWitness(
    ConformanceCheckingContext* context,
    LookupResult const& lookupResult,
    DeclRef<Decl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable,
    MethodWitnessSynthesisFailureDetails* outFailureDetails)
{
    SLANG_UNUSED(lookupResult);
    SLANG_UNUSED(requiredMemberDeclRef);
    SLANG_UNUSED(witnessTable);

    if (auto requiredFuncDeclRef = requiredMemberDeclRef.as<FuncDecl>())
    {
        // Check signature match.
        if (trySynthesizeMethodRequirementWitness(
                context,
                lookupResult,
                requiredFuncDeclRef,
                witnessTable,
                outFailureDetails))
            return true;

        if (auto builtinAttr =
                requiredFuncDeclRef.getDecl()->findModifier<BuiltinRequirementModifier>())
        {
            switch (builtinAttr->kind)
            {
            case BuiltinRequirementKind::DAddFunc:
            case BuiltinRequirementKind::DZeroFunc:
                // We'll only synthesize a new requirement, if there wasn't anything
                // of the same name available.
                //
                if (!lookupResult.isValid())
                    return trySynthesizeDifferentialMethodRequirementWitness(
                        context,
                        requiredFuncDeclRef,
                        witnessTable,
                        SynthesisPattern::AllInductive);
                break;
            case BuiltinRequirementKind::And:
            case BuiltinRequirementKind::Or:
            case BuiltinRequirementKind::Not:
            case BuiltinRequirementKind::BitAnd:
            case BuiltinRequirementKind::BitNot:
            case BuiltinRequirementKind::BitOr:
            case BuiltinRequirementKind::BitXor:
            case BuiltinRequirementKind::Shl:
            case BuiltinRequirementKind::Shr:
            case BuiltinRequirementKind::Equals:
            case BuiltinRequirementKind::LessThan:
            case BuiltinRequirementKind::LessThanOrEquals:
                if (isEnumType(context->conformingType))
                    return trySynthesizeEnumTypeMethodRequirementWitness(
                        context,
                        requiredFuncDeclRef,
                        witnessTable,
                        builtinAttr->kind);
                break;
            case BuiltinRequirementKind::ForwardDerivativeFunc:
            case BuiltinRequirementKind::BwdApplyFunc:
            case BuiltinRequirementKind::BwdCallablePropFunc:
            case BuiltinRequirementKind::BwdCallableRematFunc:
                if (!lookupResult.isValid())
                    return trySynthesizeDiffFuncRequirementWitness(
                        context,
                        requiredFuncDeclRef,
                        witnessTable,
                        builtinAttr->kind);
                break;
            case BuiltinRequirementKind::LegacyBackwardDerivativeFunc:
                // `bwd_diff` is the compatibility associated function synthesized from the
                // selected `apply_bwd`, `remat`, and `BwdCallable.operator()` entries. A callable
                // can have more than one differentiability conformance when interface
                // requirements ask for a different `DiffTypeInfoWitness` than the callable's
                // ambient `[Differentiable]` conformance. In that case lookup may find another
                // proof's synthesized `bwd_diff`; direct matching above rejects it by signature,
                // and this step synthesizes the `bwd_diff` for the current conformance from the
                // already-selected proof-specific entries. User-provided legacy `bwd_diff`
                // functions are still handled in `trySynthesizeDiffFuncRequirementWitness`.
                return trySynthesizeDiffFuncRequirementWitness(
                    context,
                    requiredFuncDeclRef,
                    witnessTable,
                    builtinAttr->kind);
            }
        }
        return false;
    }

    if (auto requiredGenericDeclRef = requiredMemberDeclRef.as<GenericDecl>())
    {
        auto inner = getInner(requiredGenericDeclRef);
        if (as<CallableDecl>(inner))
        {
            return trySynthesizeRequirementWitness(
                context,
                lookupResult,
                m_astBuilder->getMemberDeclRef(requiredGenericDeclRef, inner),
                witnessTable);
        }
        return false;
    }

    if (auto requiredPropertyDeclRef = requiredMemberDeclRef.as<PropertyDecl>())
    {
        return trySynthesizePropertyRequirementWitness(
            context,
            lookupResult,
            requiredPropertyDeclRef,
            witnessTable);
    }

    if (auto requiredSubscriptDeclRef = requiredMemberDeclRef.as<SubscriptDecl>())
    {
        return trySynthesizeSubscriptRequirementWitness(
            context,
            lookupResult,
            requiredSubscriptDeclRef,
            witnessTable);
    }

    if (auto requiredAssocTypeDeclRef = requiredMemberDeclRef.as<AssocTypeDecl>())
    {
        if (auto builtinAttr =
                requiredAssocTypeDeclRef.getDecl()->findModifier<BuiltinRequirementModifier>())
        {
            switch (builtinAttr->kind)
            {
            case BuiltinRequirementKind::DifferentialType:
                return trySynthesizeDifferentialAssociatedTypeRequirementWitness(
                    context,
                    requiredAssocTypeDeclRef,
                    witnessTable);
            case BuiltinRequirementKind::BwdCallableContextType:
            case BuiltinRequirementKind::MinimalContextType:
                return trySynthesizeDiffContextTypeRequirementWitness(
                    context,
                    requiredAssocTypeDeclRef,
                    witnessTable,
                    builtinAttr->kind);
                break;
            }
        }
        else
        {
            return false;
        }
    }

    if (auto requiredConstantDeclRef = requiredMemberDeclRef.as<VarDeclBase>())
    {
        return false;
    }

    if (auto requiredCtor = requiredMemberDeclRef.as<ConstructorDecl>())
    {
        return trySynthesizeConstructorRequirementWitness(
            context,
            lookupResult,
            requiredCtor,
            witnessTable);
    }

    // TODO: There are other kinds of requirements for which synthesis should
    // be possible:
    //
    // * It should be possible to synthesize required initializers
    //   using an approach similar to what is used for methods.
    //
    // * We should be able to synthesize subscripts with different
    //   signatures (taking into account default parameters).
    //
    // * For specific kinds of generic requirements, we should be able
    //   to wrap the synthesis of the inner declaration in synthesis
    //   of an outer generic with a matching signature.
    //
    // All of these cases can/should use similar logic to
    // `trySynthesizeMethodRequirementWitness` where they construct an AST
    // in the form of what the use site ought to look like, and then
    // apply existing semantic checking logic to generate the code.

    return false;
}

Stmt* _synthesizeMemberAssignMemberHelper(
    ASTSynthesizer& synth,
    Name* funcName,
    Type* leftType,
    Expr* leftValue,
    List<Expr*>&& args,
    List<Expr*>&& genericArgs,
    List<bool>&& inductiveArgMask,
    int nestingLevel = 0,
    SourceLoc sourceLoc = SourceLoc())
{
    if (nestingLevel > 16)
        return nullptr;

    // If field type is an array, assign each element individually.
    if (auto arrayType = as<ArrayExpressionType>(leftType))
    {
        VarDecl* indexVar = nullptr;
        auto forStmt =
            synth.emitFor(synth.emitIntConst(0), synth.emitGetArrayLengthExpr(leftValue), indexVar);
        addModifier(forStmt, synth.getBuilder()->create<ForceUnrollAttribute>());
        auto innerLeft = synth.emitIndexExpr(leftValue, synth.emitVarExpr(indexVar));

        for (auto ii = 0; ii < args.getCount(); ++ii)
        {
            auto& arg = args[ii];
            if (inductiveArgMask[ii])
                arg = synth.emitIndexExpr(arg, synth.emitVarExpr(indexVar));
        }

        auto assignStmt = _synthesizeMemberAssignMemberHelper(
            synth,
            funcName,
            arrayType->getElementType(),
            innerLeft,
            _Move(args),
            _Move(genericArgs),
            _Move(inductiveArgMask),
            nestingLevel + 1,
            sourceLoc);

        synth.popScope();
        if (!assignStmt)
            return nullptr;
        return forStmt;
    }

    auto callee = synth.emitMemberExpr(leftType, funcName);

    if (genericArgs.getCount() > 0)
        callee = synth.emitGenericAppExpr(callee, _Move(genericArgs));

    auto invokeExpr = synth.emitInvokeExpr(callee, _Move(args));
    if (sourceLoc.isValid())
        invokeExpr->loc = sourceLoc;
    auto stmt = synth.emitAssignStmt(leftValue, invokeExpr);
    if (sourceLoc.isValid())
        stmt->loc = sourceLoc;
    return stmt;
}


bool SemanticsVisitor::trySynthesizeEnumTypeMethodRequirementWitness(
    ConformanceCheckingContext* context,
    DeclRef<FunctionDeclBase> funcDeclRef,
    RefPtr<WitnessTable> witnessTable,
    BuiltinRequirementKind requirementKind)
{
    List<Expr*> synArgs;
    ThisExpr* synThis = nullptr;
    auto synFunc =
        synthesizeMethodSignatureForRequirementWitness(context, funcDeclRef, synArgs, synThis);
    auto intrinsicOpModifier = getASTBuilder()->create<IntrinsicOpModifier>();
    switch (requirementKind)
    {
    case BuiltinRequirementKind::And:
        intrinsicOpModifier->op = kIROp_And;
        break;
    case BuiltinRequirementKind::Or:
        intrinsicOpModifier->op = kIROp_Or;
        break;
    case BuiltinRequirementKind::Not:
        intrinsicOpModifier->op = kIROp_Not;
        break;
    case BuiltinRequirementKind::BitAnd:
        intrinsicOpModifier->op = kIROp_BitAnd;
        break;
    case BuiltinRequirementKind::BitNot:
        intrinsicOpModifier->op = kIROp_BitNot;
        break;
    case BuiltinRequirementKind::BitOr:
        intrinsicOpModifier->op = kIROp_BitOr;
        break;
    case BuiltinRequirementKind::BitXor:
        intrinsicOpModifier->op = kIROp_BitXor;
        break;
    case BuiltinRequirementKind::Shl:
        intrinsicOpModifier->op = kIROp_Lsh;
        break;
    case BuiltinRequirementKind::Shr:
        intrinsicOpModifier->op = kIROp_Rsh;
        break;
    case BuiltinRequirementKind::Equals:
        intrinsicOpModifier->op = kIROp_Eql;
        break;
    case BuiltinRequirementKind::LessThan:
        intrinsicOpModifier->op = kIROp_Less;
        break;
    case BuiltinRequirementKind::LessThanOrEquals:
        intrinsicOpModifier->op = kIROp_Leq;
        break;
    case BuiltinRequirementKind::InitLogicalFromInt:
        intrinsicOpModifier->op = kIROp_IntCast;
        break;
    default:
        SLANG_UNEXPECTED("unknown builtin requirement kind.");
    }
    synFunc->loc = context->parentDecl->closingSourceLoc;
    synFunc->nameAndLoc.loc = synFunc->loc;
    // synFunc already has its parent set
    SLANG_ASSERT(context->parentDecl == synFunc->parentDecl);

    context->parentDecl->addDirectMemberDecl(synFunc);

    addModifier(synFunc, intrinsicOpModifier);
    DeclRef<Decl> memberDeclRef = getDefaultDeclRef(synFunc);
    witnessTable->add(funcDeclRef.getDecl(), RequirementWitness(memberDeclRef));
    return true;
}

static DeclRef<ExtensionDecl> extendContainerDecl(
    SemanticsVisitor* visitor,
    ContainerDecl* decl,
    Type* targetType,
    SubstitutionSet& outSubstSet,
    DeclVisibility extensionVisibility,
    SourceLoc sourceLoc = SourceLoc(),
    IROp synthesisOp = kIROp_Nop,
    UCount extraArgCount = 0,
    Val* const* extraArgs = nullptr)
{
    auto astBuilder = getCurrentASTBuilder();
    auto synthesizedLoc = sourceLoc.isValid() ? sourceLoc : getDiagnosticPos(decl);

    auto funcAsType = DeclRefType::create(astBuilder, decl->getDefaultDeclRef());

    auto extensionDecl = astBuilder->create<ExtensionDecl>();
    extensionDecl->parentDecl = decl;
    extensionDecl->loc = synthesizedLoc;
    extensionDecl->nameAndLoc.loc = synthesizedLoc;
    visitor->addVisibilityModifier(extensionDecl, extensionVisibility);

    SubstitutionSet substSet;
    auto extDeclRef = visitor->liftDeclFromGenericContainers(extensionDecl, substSet);

    funcAsType = as<Type>(funcAsType->substitute(astBuilder, substSet));
    extensionDecl->targetType.type = funcAsType;
    extensionDecl->targetType.exp = astBuilder->create<SharedTypeExpr>();
    extensionDecl->targetType.exp->type = astBuilder->getOrCreate<TypeType>(funcAsType);

    auto fwdDiffInheritanceDecl = astBuilder->create<InheritanceDecl>();
    fwdDiffInheritanceDecl->loc = synthesizedLoc;
    fwdDiffInheritanceDecl->base.type = as<Type>(targetType->substitute(astBuilder, substSet));
    extensionDecl->addMember(fwdDiffInheritanceDecl);

    if (synthesisOp != kIROp_Nop)
    {
        auto synthesizedModifier = astBuilder->create<SynthesizedModifier>();
        synthesizedModifier->loc = synthesizedLoc;
        synthesizedModifier->op = synthesisOp;
        addModifier(fwdDiffInheritanceDecl, synthesizedModifier);
        for (UCount aa = 0; aa < extraArgCount; ++aa)
            synthesizedModifier->operands.add(extraArgs[aa]->substitute(astBuilder, substSet));
    }

    // Add the forward diff extension to the module.
    Decl* outermostDecl = extensionDecl;
    while (outermostDecl->parentDecl && !as<ModuleDecl>(outermostDecl->parentDecl))
    {
        outermostDecl = outermostDecl->parentDecl;
    }

    auto currentModuleDecl = visitor->getShared()->getModule()->getModuleDecl();
    currentModuleDecl->addMember(outermostDecl);

    outSubstSet = substSet;
    return extDeclRef.as<ExtensionDecl>();
}

struct SynthesizedExtensionVisibility
{
    DeclVisibility extensionVisibility = DeclVisibility::Default;
    DeclVisibility memberVisibility = DeclVisibility::Default;
};

static DeclVisibility getMoreRestrictiveVisibility(
    DeclVisibility leftVisibility,
    DeclVisibility rightVisibility)
{
    auto normalizeVisibility = [](DeclVisibility visibility)
    {
        if (visibility == DeclVisibility::Default)
            return DeclVisibility::Internal;

        switch (visibility)
        {
        case DeclVisibility::Private:
        case DeclVisibility::Internal:
        case DeclVisibility::Public:
            return visibility;
        default:
            SLANG_UNEXPECTED("unexpected visibility type");
        }
    };

    leftVisibility = normalizeVisibility(leftVisibility);
    rightVisibility = normalizeVisibility(rightVisibility);

    if (leftVisibility == DeclVisibility::Private || rightVisibility == DeclVisibility::Private)
        return DeclVisibility::Private;

    if (leftVisibility == DeclVisibility::Internal || rightVisibility == DeclVisibility::Internal)
        return DeclVisibility::Internal;

    return DeclVisibility::Public;
}

static SynthesizedExtensionVisibility getSynthesizedExtensionVisibility(
    DeclVisibility targetVisibility)
{
    SynthesizedExtensionVisibility result;
    switch (targetVisibility)
    {
    case DeclVisibility::Public:
        result.extensionVisibility = DeclVisibility::Public;
        result.memberVisibility = DeclVisibility::Public;
        break;
    case DeclVisibility::Internal:
        result.extensionVisibility = DeclVisibility::Internal;
        result.memberVisibility = DeclVisibility::Internal;
        break;
    case DeclVisibility::Private:
        // Extensions are hoisted to module scope, where `private` is not legal.
        // Keep the extension module-visible so synthesis can attach to it, while
        // the synthesized members stay private to preserve the callable's API.
        result.extensionVisibility = DeclVisibility::Internal;
        result.memberVisibility = DeclVisibility::Private;
        break;
    default:
        SLANG_UNEXPECTED("unexpected visibility type");
    }
    return result;
}

static bool isModuleReachableViaExportedImports(
    ModuleDecl* sourceModule,
    ModuleDecl* targetModule,
    HashSet<ModuleDecl*>& visitedModules)
{
    if (!sourceModule || !targetModule)
        return false;
    if (sourceModule == targetModule)
        return true;
    if (!visitedModules.add(sourceModule))
        return false;

    for (auto importDecl : sourceModule->getMembersOfType<ImportDecl>())
    {
        if (!importDecl->hasModifier<ExportedModifier>())
            continue;

        if (isModuleReachableViaExportedImports(
                importDecl->importedModuleDecl,
                targetModule,
                visitedModules))
        {
            return true;
        }
    }

    return false;
}

static bool isDeclReachableViaExportedImports(
    SemanticsVisitor* visitor,
    Decl* sourceDecl,
    Decl* targetDecl)
{
    auto sourceModule = getModuleDecl(sourceDecl);
    auto targetModule = getModuleDecl(targetDecl);
    if (!sourceModule || !targetModule || sourceModule == targetModule)
        return true;

    for (auto module : visitor->getSession()->coreModules)
    {
        if (module->getModuleDecl() == targetModule)
            return true;
    }

    HashSet<ModuleDecl*> visitedModules;
    return isModuleReachableViaExportedImports(sourceModule, targetModule, visitedModules);
}

static Decl* getDeclFromCallableOperand(Val* operand)
{
    if (auto declRef = as<DeclRefBase>(operand))
        return declRef->getDecl();
    if (auto declRefType = as<DeclRefType>(operand))
        return declRefType->getDeclRef().getDecl();
    return nullptr;
}

static bool validatePublicCallableOperandVisibility(SemanticsVisitor* visitor, CallableDecl* decl)
{
    if (!decl || getDeclVisibility(decl) != DeclVisibility::Public)
        return true;

    auto diagnoseHiddenOperand = [&](Decl* operandDecl)
    {
        visitor->getSink()->diagnose(Diagnostics::PublicCustomDerivativeUsesNonExportedImport{
            .derivative = operandDecl,
            .attr = getDiagnosticPos(decl)});
        return false;
    };

    if (auto funcAliasDecl = as<FuncAliasDecl>(decl))
    {
        auto targetDecl = funcAliasDecl->targetDeclRef.getDecl();
        if (!targetDecl)
            return true;

        if (getDeclVisibility(targetDecl) != DeclVisibility::Public)
            return diagnoseHiddenOperand(targetDecl);

        if (!isDeclReachableViaExportedImports(visitor, decl, targetDecl))
            return diagnoseHiddenOperand(targetDecl);

        return true;
    }

    auto synthesizedFuncDecl = as<SynthesizedFuncDecl>(decl);
    if (!synthesizedFuncDecl)
        return true;

    bool hasViolation = false;
    HashSet<Decl*> seenDecls;
    for (auto operand : synthesizedFuncDecl->operands)
    {
        auto operandDecl = getDeclFromCallableOperand(operand);
        if (!operandDecl || !seenDecls.add(operandDecl))
            continue;

        if (getDeclVisibility(operandDecl) != DeclVisibility::Public)
        {
            diagnoseHiddenOperand(operandDecl);
            hasViolation = true;
            continue;
        }

        if (!isDeclReachableViaExportedImports(visitor, decl, operandDecl))
        {
            diagnoseHiddenOperand(operandDecl);
            hasViolation = true;
        }
    }

    return !hasViolation;
}

bool SemanticsVisitor::trySynthesizeDiffFuncRequirementWitness(
    ConformanceCheckingContext* context,
    DeclRef<Decl> requirementDeclRef,
    RefPtr<WitnessTable> witnessTable,
    BuiltinRequirementKind kind)
{
    auto synthesizedLoc = getDiagnosticPos(requirementDeclRef.getDecl());
    auto synFunc = m_astBuilder->create<SynthesizedFuncDecl>();
    synFunc->nameAndLoc = requirementDeclRef.getDecl()->getNameAndLoc();
    synFunc->loc = synthesizedLoc;
    auto funcType = as<FuncType>(
        as<Type>(getTypeForDeclRef(m_astBuilder, requirementDeclRef, requirementDeclRef.getLoc()))
            ->resolve());

    switch (kind)
    {
    case BuiltinRequirementKind::ForwardDerivativeFunc:
        {
            // TODO: also handle func-decl parent & generics in the future.

            auto extensionDecl = as<ExtensionDecl>(context->parentDecl);

            if (!isDeclRefTypeOf<FunctionDeclBase>(extensionDecl->targetType))
                return false;

            auto declRefType = as<DeclRefType>(extensionDecl->targetType);
            auto targetCallableDeclRef = declRefType->getDeclRef().as<FunctionDeclBase>();
            SLANG_ASSERT(targetCallableDeclRef); // Expect a function-decl-base
            synFunc->operands.add(targetCallableDeclRef);
            synFunc->irOp = kIROp_ForwardDifferentiate;
            break;
        }
    case BuiltinRequirementKind::BwdApplyFunc:
        {
            auto extensionDecl = as<ExtensionDecl>(context->parentDecl);

            if (!isDeclRefTypeOf<FunctionDeclBase>(extensionDecl->targetType))
                return false;

            // Add the primal function as the first operand (for both cases).
            auto declRefType = as<DeclRefType>(extensionDecl->targetType);
            auto targetCallableDeclRef = declRefType->getDeclRef().as<FunctionDeclBase>();
            SLANG_ASSERT(targetCallableDeclRef); // Expect a function-decl-base
            synFunc->operands.add(targetCallableDeclRef);
            synFunc->irOp = kIROp_BackwardDifferentiatePrimal;
            break;
        }
    case BuiltinRequirementKind::BwdCallablePropFunc:
        {
            // Expect a SynthesizedStructDecl as the parent decl.
            // If we find a regular struct decl, we'll need to diagnose, since
            // either everything is synthesized, or everything is user defined.
            //
            auto synStructDecl = as<SynthesizedStructDecl>(context->parentDecl);
            if (!synStructDecl)
            {
                getSink()->diagnose(Diagnostics::Unexpected{
                    .message = "expected SynthesizedStructDecl as parent of BwdCallablePropFunc",
                    .location = context->parentDecl->loc});
                return false;
            }
            synFunc->operands.addRange(synStructDecl->operands);
            if (synStructDecl->irOp == kIROp_BackwardContextFromLegacyBwdDiffFunc)
            {
                synFunc->irOp = kIROp_BackwardPropagateFromLegacyBwdDiffFunc;
            }
            else if (synStructDecl->irOp == kIROp_BackwardDiffIntermediateContextType)
            {
                synFunc->irOp = kIROp_BackwardDifferentiatePropagate;
            }
            else if (synStructDecl->irOp == kIROp_TrivialBackwardDiffIntermediateContextType)
            {
                synFunc->irOp = kIROp_TrivialBackwardDifferentiatePropagate;
            }
            else
            {
                getSink()->diagnose(Diagnostics::Unexpected{
                    .message =
                        "unexpected synthesized struct IR op for backward callable propagation",
                    .location = context->parentDecl->loc});
                return false;
            }
            break;
        }
    case BuiltinRequirementKind::LegacyBackwardDerivativeFunc:
        {
            auto extensionDecl = as<ExtensionDecl>(context->parentDecl);
            if (!isDeclRefTypeOf<FunctionDeclBase>(extensionDecl->targetType))
                return false;

            if (findLegacyBwdDiffFunc(this, extensionDecl))
            {
                return false;
            }

            auto declRefType = as<DeclRefType>(extensionDecl->targetType);

            // Lookup an ".apply_bwd", ".BwdCallable" and ".BwdCallable.operator()" methods.
            // and pass them all together as operands.
            //

            // First, lookup the "apply_bwd" method.
            LookupResult applyBwdLookupResult = lookUpMember(
                m_astBuilder,
                this,
                getName("apply_bwd"),
                declRefType,
                getScope(extensionDecl));
            applyBwdLookupResult = resolveOverloadedLookup(applyBwdLookupResult);

            if (!applyBwdLookupResult.item.declRef) // Couldn't find an "apply_bwd", so fail early.
                return false;

            auto applyBwdDeclRef = applyBwdLookupResult.item.declRef.as<FunctionDeclBase>();

            // First, lookup the "remat" method.
            LookupResult rematFuncLookupResult = lookUpMember(
                m_astBuilder,
                this,
                getName("remat"),
                declRefType,
                getScope(extensionDecl));
            rematFuncLookupResult = resolveOverloadedLookup(rematFuncLookupResult);

            if (!rematFuncLookupResult.item.declRef) // Couldn't find a "remat", so fail early.
                return false;

            auto rematFuncDeclRef = rematFuncLookupResult.item.declRef.as<FunctionDeclBase>();

            // Next, lookup the "BwdCallable" type.
            LookupResult bwdCallableLookupResult = lookUpMember(
                m_astBuilder,
                this,
                getName("BwdCallable"),
                declRefType,
                getScope(extensionDecl));
            bwdCallableLookupResult = resolveOverloadedLookup(bwdCallableLookupResult);

            if (!bwdCallableLookupResult.item
                     .declRef) // Couldn't find a "BwdCallable", so fail early.
                return false;

            auto bwdCallableDeclRefType =
                DeclRefType::create(getCurrentASTBuilder(), bwdCallableLookupResult.item.declRef);

            // Finally, lookup the "BwdCallable.operator()" method.
            LookupResult bwdPropFnLookupResult = lookUpMember(
                m_astBuilder,
                this,
                getName("()"),
                bwdCallableDeclRefType,
                getScope(extensionDecl));

            bwdPropFnLookupResult = resolveOverloadedLookup(bwdPropFnLookupResult);
            if (!bwdPropFnLookupResult.item
                     .declRef) // Couldn't find a "BwdCallable.operator()", so fail early.
                return false;

            // NOTE: bwd_diff is now static in the interface, so this-type handling
            // (both differentiable and non-differentiable) is done by
            // BwdDiffFuncType::_resolveImplOverride. The funcType from the requirement
            // already includes the this-type as an explicit parameter. The static
            // modifier is applied below from the requirement's own modifier.

            auto bwdPropFnDeclRef = bwdPropFnLookupResult.item.declRef.as<FunctionDeclBase>();

            // Now we have all the necessary components, so we can add them to the synthesized
            // function.
            synFunc->irOp = kIROp_LegacyBackwardDifferentiate;
            synFunc->operands.add(applyBwdDeclRef);
            synFunc->operands.add(rematFuncDeclRef);
            synFunc->operands.add(bwdPropFnDeclRef);
            break;
        }
    case BuiltinRequirementKind::BwdCallableRematFunc:
        {
            auto extensionDecl = as<ExtensionDecl>(context->parentDecl);
            if (!isDeclRefTypeOf<FunctionDeclBase>(extensionDecl->targetType))
                return false;

            auto declRefType = as<DeclRefType>(extensionDecl->targetType);
            auto targetCallableDeclRef = declRefType->getDeclRef().as<FunctionDeclBase>();
            SLANG_ASSERT(targetCallableDeclRef); // Expect a function-decl-base
            synFunc->operands.add(targetCallableDeclRef);
            synFunc->irOp = kIROp_BackwardRemat;
            break;
        }
    default:
        SLANG_UNEXPECTED("unknown builtin requirement kind for diff func synthesis.");
    }

    // Match the synthesized function's visibility to the target function's visibility.
    DeclVisibility targetVis = getDeclVisibility(context->parentDecl);
    if (auto extDecl = as<ExtensionDecl>(context->parentDecl))
    {
        if (auto drt = as<DeclRefType>(extDecl->targetType))
            if (auto callable = drt->getDeclRef().as<FunctionDeclBase>())
                targetVis = getDeclVisibility(callable.getDecl());
    }
    addVisibilityModifier(synFunc, getSynthesizedExtensionVisibility(targetVis).memberVisibility);

    synFunc->parentDecl = context->parentDecl;

    List<Expr*> synArgs;
    populateParams(getCurrentASTBuilder(), synFunc, funcType, synArgs);

    synFunc->returnType.type = funcType->getResultType();

    // Add static modifier if necessary
    if (requirementDeclRef.getDecl()->hasModifier<HLSLStaticModifier>())
        addModifier(synFunc, m_astBuilder->create<HLSLStaticModifier>());

    context->parentDecl->addDirectMemberDecl(synFunc);

    if (kind == BuiltinRequirementKind::ForwardDerivativeFunc)
    {
        auto higherOrderVisibility =
            getSynthesizedExtensionVisibility(getDeclVisibility(context->parentDecl));

        // Add in a conformance for "fwdDiffFunc : IForwardDifferentiable<fwdDiffFunc>"
        // for higher-order differentiation.
        //
        {
            auto synFuncType =
                DeclRefType::create(getCurrentASTBuilder(), synFunc->getDefaultDeclRef());
            auto fwdDiffFuncAsType = getForwardDiffFuncInterfaceType(synFuncType);
            SubstitutionSet substSet;
            auto higherOrderFwdDiffExtension = extendContainerDecl(
                this,
                synFunc,
                fwdDiffFuncAsType,
                substSet,
                higherOrderVisibility.extensionVisibility,
                SourceLoc(),
                kIROp_SynthesizedForwardDerivativeWitnessTable);
            this->ensureDecl(higherOrderFwdDiffExtension, DeclCheckState::ReadyForLookup);
        }

        // Add in a conformance for "fwdDiffFunc : IBackwardDifferentiable<fwdDiffFunc>"
        // for higher-order differentiation.
        //
        {
            auto fwdDiffFuncAsType = getBackwardDiffFuncInterfaceType(
                DeclRefType::create(getCurrentASTBuilder(), synFunc->getDefaultDeclRef()));
            SubstitutionSet substSet;
            auto higherOrderBwdDiffExtension = extendContainerDecl(
                this,
                synFunc,
                fwdDiffFuncAsType,
                substSet,
                higherOrderVisibility.extensionVisibility,
                SourceLoc(),
                kIROp_SynthesizedBackwardDerivativeWitnessTable);
            this->ensureDecl(higherOrderBwdDiffExtension, DeclCheckState::ReadyForLookup);
        }
    }

    auto witnessDecl = synFunc;

    // Form a proper decl-ref to the synthesized witness:

    SubstitutionSet substSet;
    if (auto thisTypeWitness = findThisTypeWitness(
            SubstitutionSet(requirementDeclRef),
            as<InterfaceDecl>(requirementDeclRef.getDecl()->parentDecl)))
    {
        if (auto _declRefType = as<DeclRefType>(thisTypeWitness->getSub()))
        {
            substSet = SubstitutionSet(_declRefType->getDeclRef());
        }
    }
    if (!substSet.declRef)
        return false;
    DeclRef<Decl> synthesizedWitnessDeclRef;
    if (auto parentExtDecl = as<ExtensionDecl>(context->parentDecl))
    {
        // If the conformance is declared on an extension to ThisType,
        // we need to form a new proper decl ref to the parent extension decl
        // with the correct specialization arguments.
        //
        if (GetOuterGeneric(context->parentDecl))
        {

            auto extDeclRef = applyExtensionToType(parentExtDecl, context->conformingType);
            synthesizedWitnessDeclRef = m_astBuilder->getMemberDeclRef(extDeclRef, witnessDecl);
        }
    }
    else
    {
        synthesizedWitnessDeclRef = m_astBuilder->getMemberDeclRef(substSet.declRef, witnessDecl);
    }

    if (!synthesizedWitnessDeclRef)
        synthesizedWitnessDeclRef = m_astBuilder->getDirectDeclRef(witnessDecl);

    // TODO: We should get all kinds to go through signature matching,
    // but for now only fwd_diff and bwd_diff do.
    if (kind == BuiltinRequirementKind::ForwardDerivativeFunc ||
        kind == BuiltinRequirementKind::LegacyBackwardDerivativeFunc)
    {
        auto doesSignatureMatch = doesSignatureMatchRequirement(
            synthesizedWitnessDeclRef.as<CallableDecl>(),
            requirementDeclRef.as<CallableDecl>(),
            witnessTable);

        // If we synthesized this, then failing this match would be a
        // critical failure.
        SLANG_ASSERT(doesSignatureMatch);
    }
    else
    {
        witnessTable->add(
            requirementDeclRef.getDecl(),
            RequirementWitness(synthesizedWitnessDeclRef));
    }


    return true;
}

bool SemanticsVisitor::trySynthesizeDifferentialMethodRequirementWitness(
    ConformanceCheckingContext* context,
    DeclRef<Decl> requirementDeclRef,
    RefPtr<WitnessTable> witnessTable,
    SynthesisPattern pattern)
{
    // We support two cases of synthesis here.
    // Case 1 is that there the associated Differential type is defined to be `DifferentialBottom`.
    // In this case we just trivially return `DifferentialBottom` in all synthesized methods.
    // Case 2 is that the `Differential` type contains members corresponding to each primal member.
    // We will apply a general code synthesis pattern to reflect that structure.
    // For requirement of the form:
    // ```
    // static TResult requiredMethod(TParam1 p0, TParam2 p1, ...)
    // ```
    // Where TResult,TParam1, TParam2 is either `This` or `Differential`,
    // We synthesize a memberwise dispatch to compute each field of `TResult`.
    // Multiple patterns are supported (see SemanticsVisitor::SynthesisPattern for a full list)
    // For AllInductive, we synthesize an implementation of the form:
    // ```
    // [BackwardDifferentiable]
    // static TResult requiredMethod(TParam1 p0, TParam2 p1, ...)
    // {
    //     TResult result;
    //     result.member0 = decltype(result.member0).requiredMethod(p0.member0, p1.member0);
    //     result.member1 = decltype(result.member1).requiredMethod(p0.member1, p1.member1);
    //     ...
    //     return result;
    // }
    // ```

    // First we need to make sure the associated `Differential` type requirement is satisfied.
    bool hasDifferentialAssocType = false;
    bool typeIsSelfDifferential = false;
    bool differentialTypeIsSynthesized = false;
    bool differentialTypeHasDifferentiableField = false;
    for (auto& existingEntry : witnessTable->getRequirementDictionary())
    {
        if (auto builtinReqAttr = existingEntry.key->findModifier<BuiltinRequirementModifier>())
        {
            if (builtinReqAttr->kind == BuiltinRequirementKind::DifferentialType &&
                existingEntry.value.getFlavor() != RequirementWitness::Flavor::none)
            {
                if (existingEntry.value.getFlavor() == RequirementWitness::Flavor::val)
                {
                    if (existingEntry.value.m_val == context->conformingType)
                        typeIsSelfDifferential = true;
                    if (auto diffDeclRefType = as<DeclRefType>(existingEntry.value.m_val))
                    {
                        auto diffDecl = diffDeclRefType->getDeclRef().getDecl();
                        if (diffDecl->hasModifier<SynthesizedModifier>())
                            differentialTypeIsSynthesized = true;
                        if (auto diffAggDecl = as<AggTypeDecl>(diffDecl))
                        {
                            for (auto diffField :
                                 diffAggDecl->getDirectMemberDeclsOfType<VarDeclBase>())
                            {
                                if (diffField->hasModifier<NoDiffModifier>())
                                    continue;
                                if (tryGetDifferentialType(m_astBuilder, diffField->getType()))
                                {
                                    differentialTypeHasDifferentiableField = true;
                                    break;
                                }
                            }
                        }
                    }
                }

                hasDifferentialAssocType = true;
            }
        }
    }
    if (!hasDifferentialAssocType)
        return false;

    ASTSynthesizer synth(m_astBuilder, getNamePool());
    List<Expr*> synArgs;
    List<Expr*> synGenericArgs;
    ThisExpr* synThis = nullptr;
    FuncDecl* synFunc = nullptr;
    GenericDecl* synGeneric = nullptr;

    if (auto genericDeclRef = requirementDeclRef.as<GenericDecl>())
    {
        synGeneric = synthesizeGenericSignatureForRequirementWitness(
            context,
            genericDeclRef,
            synArgs,
            synGenericArgs,
            synThis);
        synFunc = as<FuncDecl>(synGeneric->inner);
    }
    else if (auto funcDeclRef = requirementDeclRef.as<FuncDecl>())
    {
        synFunc = as<FuncDecl>(
            synthesizeMethodSignatureForRequirementWitness(context, funcDeclRef, synArgs, synThis));
    }

    SLANG_ASSERT(synFunc);

    addModifier(synFunc, m_astBuilder->create<BackwardDifferentiableAttribute>());


    synth.pushContainerScope(synFunc);
    auto blockStmt = m_astBuilder->create<BlockStmt>();
    synFunc->body = blockStmt;
    auto seqStmt = synth.pushSeqStmtScope();
    blockStmt->body = seqStmt;

    // Create a variable for return value.
    synth.pushVarScope();
    auto varStmt = synth.emitVarDeclStmt(synFunc->returnType.type, getName("result"));
    auto resultVarExpr = synth.emitVarExpr(varStmt, synFunc->returnType.type);

    Index synthesizedFieldCount = 0;
    for (auto varMember : context->parentDecl->getDirectMemberDeclsOfType<VarDeclBase>())
    {
        auto derivativeAttr = varMember->findModifier<DerivativeMemberAttribute>();
        if (!derivativeAttr && !typeIsSelfDifferential)
            continue;

        ensureDecl(varMember, DeclCheckState::ReadyForReference);
        auto memberType = varMember->getType();
        auto diffMemberType = tryGetDifferentialType(m_astBuilder, memberType);
        if (!diffMemberType)
            continue;

        // Since the conformance checking happens before the decl body checking, the
        // DerivativeMemberAttribute might not have been checked yet. So we need to make sure
        // they are checked before we use them. `checkDerivativeMemberAttributeReferences`
        // already handles the case that the attribute has already been checked.
        Name* derivMemberName = nullptr;
        if (derivativeAttr)
        {
            checkDerivativeMemberAttributeReferences(varMember, derivativeAttr);

            // If there is anything wrong in the checking,
            // `checkDerivativeMemberAttributeReferences` will diagnose an error, and
            // `derivativeAttr->memberDeclRef` will be null. We will skip the remaining synthesis to
            // avoid crash.
            if (derivativeAttr->memberDeclRef)
            {
                // Pull up the derivative member name from the attribute
                derivMemberName = derivativeAttr->memberDeclRef->declRef.getName();
            }
        }
        else if (typeIsSelfDifferential)
        {
            derivMemberName = varMember->getName();
        }

        // Couldn't find a corresponding derivative member, so we'll skip.
        // If our checking is correct, then this member is not differentiable.
        //
        // If the member is differentiable, but we couldn't locate the corresponding
        // differential member name, then something went wrong in checking.
        //
        if (!derivMemberName)
            continue;

        // Construct reference exprs to the member's corresponding fields in each parameter.
        List<Expr*> paramFields;
        List<bool> inductiveArgMask;

        switch (pattern)
        {
        case SynthesisPattern::AllInductive:
            {
                for (auto arg : synArgs)
                {
                    auto memberExpr = m_astBuilder->create<MemberExpr>();
                    memberExpr->baseExpression = arg;
                    memberExpr->name = derivMemberName;
                    memberExpr->loc = varMember->loc;

                    paramFields.add(memberExpr);
                    inductiveArgMask.add(true);
                }
                break;
            }
        case SynthesisPattern::FixedFirstArg:
            {
                int paramIndex = 0;
                for (auto arg : synArgs)
                {
                    if (paramIndex == 0)
                    {
                        paramFields.add(arg);
                        inductiveArgMask.add(false);

                        paramIndex++;
                    }
                    else
                    {
                        auto memberExpr = m_astBuilder->create<MemberExpr>();
                        memberExpr->baseExpression = arg;
                        memberExpr->name = derivMemberName;
                        memberExpr->loc = varMember->loc;
                        paramFields.add(memberExpr);
                        inductiveArgMask.add(true);

                        paramIndex++;
                    }
                }
                break;
            }
        default:
            SLANG_UNIMPLEMENTED_X("unhandled synthesis pattern");
            break;
        }

        // Invoke the method for the field and assign the value to resultVar.
        auto leftVal = synth.emitMemberExpr(resultVarExpr, derivMemberName);
        leftVal->loc = varMember->loc;
        if (!_synthesizeMemberAssignMemberHelper(
                synth,
                requirementDeclRef.getName(),
                memberType,
                leftVal,
                _Move(paramFields),
                _Move(synGenericArgs),
                _Move(inductiveArgMask),
                0,
                varMember->loc))
            return false;
        synthesizedFieldCount++;
    }

    // Only warn when the user explicitly chose a `Differential` type whose own fields are all
    // non-differentiable. Auto-derived Differential aggregates, self-differential types, and
    // user-provided Differential types that do contain at least one differentiable field are all
    // well-formed; any mapping failure between the parent and its Differential is already reported
    // by `missing-field-in-differential-type` (E30102).
    if (synthesizedFieldCount == 0 && !typeIsSelfDifferential && !differentialTypeIsSynthesized &&
        !differentialTypeHasDifferentiableField)
    {
        getSink()->diagnose(Diagnostics::CannotSynthesizeDaddDzeroForCustomDifferential{
            .methodName = requirementDeclRef.getName(),
            .typeDecl = context->parentDecl,
        });
    }

    // TODO: synthesize assignments for inherited members here.

    // When IDifferentiable conformance is provided via extension, the loop above iterates
    // the extension's members (no fields), not the target struct's fields. Check if the
    // target struct has differentiable fields that won't be included in the synthesized method.
    if (as<ExtensionDecl>(context->parentDecl))
    {
        if (auto conformingDeclRefType = as<DeclRefType>(context->conformingType))
        {
            auto structDecl = as<AggTypeDecl>(conformingDeclRefType->getDeclRef().getDecl());
            if (structDecl)
            {
                auto substSet = SubstitutionSet(conformingDeclRefType->getDeclRef());
                for (auto field : structDecl->getMembersOfType<VarDeclBase>())
                {
                    if (field->findModifier<NoDiffModifier>())
                        continue;
                    if (field->findModifier<DerivativeMemberAttribute>())
                        continue;
                    ensureDecl(field, DeclCheckState::ReadyForReference);
                    auto fieldType = field->getType();

                    // If the field's raw type is already differentiable at the
                    // definition site, synthesis can handle it — no diagnostic needed.
                    if (tryGetDifferentialType(m_astBuilder, fieldType))
                        continue;

                    auto substitutedType = as<Type>(fieldType->substitute(m_astBuilder, substSet));
                    if (!substitutedType)
                        continue;
                    auto diffType = tryGetDifferentialType(m_astBuilder, substitutedType);
                    if (diffType)
                    {
                        getSink()->diagnose(Diagnostics::SynthesizedDifferentialMethodMissingField{
                            .fieldType = substitutedType,
                            .field = field});
                    }
                }
            }
        }
    }

    auto synReturn = m_astBuilder->create<ReturnStmt>();
    synReturn->expression = resultVarExpr;
    seqStmt->stmts.add(synReturn);

    Decl* witnessDecl = synGeneric ? (Decl*)synGeneric : synFunc;
    SLANG_ASSERT(context->parentDecl == witnessDecl->parentDecl);

    addModifier(synFunc, m_astBuilder->create<SynthesizedModifier>());

    // If `This` is nested inside a generic, we need to form a complete declref type to the
    // newly synthesized method here in order to fill into the witness table.
    // This can be done by obtaining the ThisType witness from requirementDeclRef to get the
    // generic substitution for outer generic parameters, and apply it here.
    SubstitutionSet substSet;
    if (auto thisTypeWitness = findThisTypeWitness(
            SubstitutionSet(requirementDeclRef),
            as<InterfaceDecl>(requirementDeclRef.getDecl()->parentDecl)))
    {
        if (auto declRefType = as<DeclRefType>(thisTypeWitness->getSub()))
        {
            substSet = SubstitutionSet(declRefType->getDeclRef());
        }
    }
    if (!substSet.declRef)
        return false;
    DeclRef<Decl> synthesizedWitnessDeclRef;
    if (auto parentExtDecl = as<ExtensionDecl>(context->parentDecl))
    {
        // If the conformance is declared on an extension to ThisType,
        // we need to form a new proper decl ref to the parent extension decl
        // with the correct specialization arguments.
        //
        if (GetOuterGeneric(context->parentDecl))
        {

            auto extDeclRef = applyExtensionToType(parentExtDecl, context->conformingType);
            synthesizedWitnessDeclRef = m_astBuilder->getMemberDeclRef(extDeclRef, witnessDecl);
        }
    }
    else
    {
        synthesizedWitnessDeclRef = m_astBuilder->getMemberDeclRef(substSet.declRef, witnessDecl);
    }
    if (!synthesizedWitnessDeclRef)
        synthesizedWitnessDeclRef = m_astBuilder->getDirectDeclRef(witnessDecl);

    auto synthesizedCallableDeclRef = synthesizedWitnessDeclRef.as<CallableDecl>();

    // Test signature and register in witness table.
    bool doesSignatureMatch = doesSignatureMatchRequirement(
        synthesizedCallableDeclRef,
        requirementDeclRef.as<CallableDecl>(),
        witnessTable);

    // If we decide that it is possible to synthesize this requirement, then we should
    // have produced one that is consistent with the expected signature.
    //
    SLANG_RELEASE_ASSERT(doesSignatureMatch);

    // Publish the synthesized method only after signature matching has installed its witness.
    // In particular, a candidate that could not form a specialized declaration reference above
    // must not enter the declaration tree or trigger autodiff side effects.
    context->parentDecl->addDirectMemberDecl(witnessDecl);
    getShared()->registerSynthesizedDeclRoot(_getSynthesizedDeclRoot(witnessDecl));

    return true;
}

bool SemanticsVisitor::findDefaultInterfaceImpl(
    ConformanceCheckingContext* context,
    DeclRef<Decl> requiredMemberDeclRef,
    SubtypeWitness* subTypeConformsToInterfaceWitness,
    RefPtr<WitnessTable> witnessTable)
{
    // Interface default implementations are represented as callable stubs over
    // `This : Interface`; methods and subscripts both use that representation.
    DeclRef<CallableDecl> requiredCallableDeclRef = requiredMemberDeclRef.as<CallableDecl>();
    if (!requiredCallableDeclRef)
    {
        // If requiredMember is a generic callable, form a direct declref to the inner callable.
        if (auto requiredGenericDeclRef = requiredMemberDeclRef.as<GenericDecl>())
        {
            auto inner = getInner(requiredGenericDeclRef);
            if (auto callable = as<CallableDecl>(inner))
            {
                requiredCallableDeclRef =
                    m_astBuilder->getMemberDeclRef(requiredGenericDeclRef, callable);
            }
        }
    }
    if (!requiredCallableDeclRef)
        return false;

    // If the interface requirement comes with a default impl, it should have a
    // HasInterfaceDefaultImplModifier.
    auto defaultModifier = hasDefaultImpl(requiredMemberDeclRef);
    if (!defaultModifier)
        return false;

    // If we have a default implementation, return a declref to the default stub decl directly.
    // We can grab a declref to the stub decl standing for the generic default impl from
    // the InterfaceDefaultImplModifier on the requiredMemberDeclRef, that should have been
    // created during checking of the required method decl.
    //
    // For example, given:
    //    ```
    //    interface IFoo { int bar() { return 1; } }
    //    struct Foo : IFoo { /*needing witness synthesis*/ }
    //    ```
    // After parsing `IFoo`, we will have a default impl stub decl for `bar`:
    //    ```
    //    interface IFoo {
    //        [HasInterfaceDefaultImpl(bar_defaultImpl)] // <-- `defaultModifier`
    //        int bar(); // this is the requirement.
    //
    //        // This is the default impl stub decl.
    //        __interface_default_impl_generic<This:IFoo>
    //        int bar_defaultImpl() { return 1; }
    //    }
    //    ```
    // Given this, we can simply form a GenericAppDeclRef to `IFoo::bar_defaultImpl`
    // with `This` being `context->conformingType` and `This:IFoo` being
    // `subTypeConformsToInterfaceWitness`.
    //
    // The following logic will create this declref, and register it to the witness table.
    //
    auto interfaceDeclRef = getParentDeclRef(requiredMemberDeclRef);
    if (!as<InterfaceDecl>(interfaceDeclRef.getDecl()))
        return false;

    auto genericDeclOfDefaultImplStub =
        as<InterfaceDefaultImplDecl>(defaultModifier->defaultImplDecl);
    if (!genericDeclOfDefaultImplStub)
        return false;

    // Form a declref to unspecialized `IFoo::bar_defaultImpl`.
    DeclRef<Decl> resultDeclRef =
        m_astBuilder->getMemberDeclRef(interfaceDeclRef, genericDeclOfDefaultImplStub);
    List<Val*> specArgs;
    specArgs.add(context->conformingType);
    specArgs.add(subTypeConformsToInterfaceWitness);

    // Form a declref to `IFoo::bar_defaultImpl<conformingType>`.
    resultDeclRef = m_astBuilder->getGenericAppDeclRef(
        resultDeclRef.as<GenericDecl>(),
        specArgs.getArrayView());

    // Test the signature and register the witness table entries. Going through
    // the general requirement matcher is important for subscript defaults,
    // because their accessor requirements need witness entries too.
    bool doesSignatureMatch =
        doesMemberSatisfyRequirement(resultDeclRef, requiredMemberDeclRef, witnessTable);

    // If we try to use a registered default decl and the signature _doesn't_
    // match here, then something went wrong well before this.
    SLANG_ASSERT(doesSignatureMatch);
    return doesSignatureMatch;
}

Type* SemanticsVisitor::getForwardDiffFuncInterfaceType(Type* baseType)
{
    auto diffTypeInfoWitness = getDiffTypeInfoWitness(baseType);
    return m_astBuilder->getForwardDiffFuncInterfaceType(baseType, diffTypeInfoWitness);
}

Type* SemanticsVisitor::getBackwardDiffFuncInterfaceType(Type* baseType)
{
    auto diffTypeInfoWitness = getDiffTypeInfoWitness(baseType);
    return m_astBuilder->getBackwardDiffFuncInterfaceType(baseType, diffTypeInfoWitness);
}

Type* SemanticsVisitor::getBwdCallableBaseType(Type* baseType)
{
    auto diffTypeInfoWitness = getDiffTypeInfoWitness(baseType);
    return m_astBuilder->getBwdCallableBaseType(baseType, diffTypeInfoWitness);
}

enum class DifferentiabilityConformanceKind
{
    None,
    Forward,
    Backward,
};

static DifferentiabilityConformanceKind getDifferentiabilityConformanceKind(
    Type* type,
    Type** outBaseFuncType,
    Witness** outTypeInfoWitness)
{
    if (outBaseFuncType)
        *outBaseFuncType = nullptr;
    if (outTypeInfoWitness)
        *outTypeInfoWitness = nullptr;

    auto declRefType = as<DeclRefType>(type);
    if (!declRefType)
        return DifferentiabilityConformanceKind::None;

    auto declRef = declRefType->getDeclRef();
    auto genericApp = as<GenericAppDeclRef>(declRef.declRefBase);
    if (!genericApp || genericApp->getArgCount() < 2)
        return DifferentiabilityConformanceKind::None;

    auto baseFuncType = as<Type>(genericApp->getArg(0));
    auto typeInfoWitness = as<Witness>(genericApp->getArg(1));
    if (!baseFuncType || !typeInfoWitness)
        return DifferentiabilityConformanceKind::None;

    if (outBaseFuncType)
        *outBaseFuncType = baseFuncType;
    if (outTypeInfoWitness)
        *outTypeInfoWitness = typeInfoWitness;

    auto interfaceDecl = declRef.getDecl();
    if (isKnownBuiltinDecl(interfaceDecl, KnownBuiltinDeclName::IForwardDifferentiable))
        return DifferentiabilityConformanceKind::Forward;
    if (isKnownBuiltinDecl(interfaceDecl, KnownBuiltinDeclName::IBackwardDifferentiable))
        return DifferentiabilityConformanceKind::Backward;

    return DifferentiabilityConformanceKind::None;
}

static String getDifferentiabilityConformanceKindText(DifferentiabilityConformanceKind kind)
{
    switch (kind)
    {
    case DifferentiabilityConformanceKind::Forward:
        return "forward-differentiable";
    case DifferentiabilityConformanceKind::Backward:
        return "backward-differentiable";
    default:
        return "differentiability";
    }
}

// Walk the witness chain to determine if `targetDecl` appears along the
// canonical lookup path.  This handles `LookupDeclRef` chains as well as
// `ExpandSubtypeWitness` / `EachSubtypeWitness` wrappers.
//
static bool doesWitnessLookupPathContainDecl(SubtypeWitness* witness, Decl* targetDecl)
{
    auto currentWitness = witness;
    for (;;)
    {
        if (auto declaredSubtypeWitness = as<DeclaredSubtypeWitness>(currentWitness))
        {

            if (auto memberDeclRef =
                    as<MemberDeclRef>(declaredSubtypeWitness->getDeclRef().declRefBase))
            {
                if (memberDeclRef->getDecl() == targetDecl)
                    return true;
            }

            if (auto lookupDeclRef =
                    SubstitutionSet(declaredSubtypeWitness->getDeclRef().declRefBase)
                        .findLookupDeclRef())
            {
                if (lookupDeclRef->getDecl() == targetDecl)
                    return true;

                currentWitness = lookupDeclRef->getWitness();
            }
            else
            {
                break;
            }
        }
        else if (auto expandWitness = as<ExpandSubtypeWitness>(currentWitness))
        {
            currentWitness = expandWitness->getPatternTypeWitness();
        }
        else if (auto eachWitness = as<EachSubtypeWitness>(currentWitness))
        {
            currentWitness = eachWitness->getPatternTypeWitness();
        }
        else
        {
            break;
        }
    }
    return false;
}

/// Returns whether `declRef` still identifies a requirement rather than its satisfying declaration.
///
/// Most projected requirements have the interface as their decl-ref parent. A synthesized generic
/// constraint requirement instead has its wrapping `GenericDecl` as the immediate parent while the
/// inner declaration retains interface-requirement identity.
static bool _doesDeclRefNameInterfaceRequirement(DeclRef<Decl> declRef)
{
    auto decl = declRef.getDecl();
    if (as<InterfaceDecl>(declRef.getParent().getDecl()))
        return true;
    return as<GenericTypeConstraintDecl>(decl) && isInterfaceRequirement(decl);
}

bool SemanticsVisitor::ensureInheritedInterfaceRequirement(
    ConformanceCheckingContext* context,
    Type* subType,
    DeclRef<InheritanceDecl> requiredInheritanceDeclRef,
    RefPtr<WitnessTable> witnessTable,
    InheritedInterfaceRequirementMode mode)
{
    auto requirementDecl = requiredInheritanceDeclRef.getDecl();
    InterfaceRequirementKey requirementKey(requirementDecl);
    auto reqType = getBaseType(m_astBuilder, requiredInheritanceDeclRef);
    auto subIsReqWitness = tryGetSubtypeWitness(subType, reqType);
    if (!subIsReqWitness)
    {
        // The current conformance can provide a path before the flattened inheritance cache has
        // observed it. Preserve the actual specialized inheritance requirement in that path.
        subIsReqWitness =
            m_astBuilder->getDeclaredSubtypeWitness(subType, reqType, requiredInheritanceDeclRef);
    }

    bool isOnCanonicalPath =
        doesWitnessLookupPathContainDecl(subIsReqWitness, requiredInheritanceDeclRef.getDecl());
    if (!isOnCanonicalPath)
    {
        if (!witnessTable->containsRequirement(requirementKey))
            witnessTable->add(requirementKey, RequirementWitness(subIsReqWitness));
        return true;
    }

    RefPtr<WitnessTable> satisfyingWitnessTable;
    RequirementWitness existingWitness;
    if (witnessTable->tryGetRequirementWitness(requirementKey, existingWitness))
    {
        // A canonical inherited-interface entry is created only by this branch, including its
        // `PrepareForLookup` mode, and is always a nested table. A non-canonical path stores a
        // `SubtypeWitness` value in the branch above and is finalized without re-entering this
        // canonical branch. Seeing that value here would mean the path classification or the
        // per-requirement checking state has changed underneath an already-published entry.
        SLANG_RELEASE_ASSERT(
            existingWitness.getFlavor() == RequirementWitness::Flavor::witnessTable);
        satisfyingWitnessTable = existingWitness.getWitnessTable();
    }
    else
    {
        satisfyingWitnessTable = new WitnessTable();
        satisfyingWitnessTable->witnessedType = subType;
        satisfyingWitnessTable->baseType = reqType;
        witnessTable->add(requirementKey, RequirementWitness(satisfyingWitnessTable));
    }

    auto reqInterfaceDeclRef = isDeclRefTypeOf<InterfaceDecl>(reqType);
    if (reqInterfaceDeclRef)
    {
        registerConformanceInterfaceCheckingState(
            context,
            subType,
            reqType,
            requirementDecl,
            reqInterfaceDeclRef,
            satisfyingWitnessTable,
            subIsReqWitness);
    }

    if (mode == InheritedInterfaceRequirementMode::PrepareForLookup)
        return true;

    return checkConformanceToType(
        context,
        subType,
        requirementDecl,
        reqType,
        subIsReqWitness,
        satisfyingWitnessTable);
}

bool SemanticsVisitor::findWitnessForInterfaceRequirement(
    ConformanceCheckingContext* context,
    Type* subType,
    Type* superInterfaceType,
    InheritanceDecl* inheritanceDecl,
    DeclRef<InterfaceDecl> superInterfaceDeclRef,
    DeclRef<Decl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable,
    SubtypeWitness* subTypeConformsToSuperInterfaceWitness)
{
    SLANG_UNUSED(superInterfaceDeclRef)
    SLANG_UNUSED(superInterfaceType);


    // The goal of this function is to find a suitable
    // value to satisfy the requirement.
    //
    // The 99% case is that the requirement is a named member
    // of the interface, and we need to search for a member
    // with the same name in the type declaration and
    // its (known) extensions.

    // The exception to that is when the requiredMemberDeclRef is already
    // resolved to the actual satisfying decl, in which case we simply return
    // true without any further lookup.
    // A generic-wrapped interface requirement has its `GenericDecl` as the immediate parent in the
    // decl-ref chain, even though the wrapped declaration is still an interface requirement.
    // Consider this example:
    //
    //     interface IFoo
    //     {
    //         [Differentiable]
    //         void f<T>(T value);
    //     }
    //
    // Header checking keeps `f<T>` as the callable requirement and creates a sibling
    // `GenericDecl { inner = FuncConstraintDecl(This.f<T> :
    // IBackwardDifferentiable<This.f<T>>) }`. Do not treat that wrapped constraint shape as
    // already resolved just because the decl-ref parent is the generic wrapper; it still needs its
    // own witness-table entry.
    if (!_doesDeclRefNameInterfaceRequirement(requiredMemberDeclRef))
    {
        return true;
    }

    // If `requiredMemberDeclRef` is a lookup decl ref for an interface requirement
    // we attempt to do the loopkup through witness tables.
    //
    // As a first pass, check whether the witness table already provides a
    // witness for this requirement, and if so reuse it and bail out early.
    //
    // This applies to *every* kind of requirement (methods, associated types,
    // constraints, ...). In particular it covers the cases where conformance
    // synthesis deliberately supplied a witness that a fresh re-derivation below
    // would reject -- e.g. an `enum`'s automatic `__EnumType` conformance
    // supplies the `__Tag : __BuiltinIntegerType` witness directly, including for
    // a `bool`-tagged `enum` where `bool` is a permitted tag type yet does not
    // actually conform to `__BuiltinIntegerType`. Respecting a synthesis-provided
    // witness here is therefore the contract, not a constraint-specific quirk.
    //
    if (witnessTable->containsRequirement(InterfaceRequirementKey(requiredMemberDeclRef.getDecl())))
    {
        return true;
    }

    // The ThisType requirement is always satisfied.
    if (as<ThisTypeDecl>(requiredMemberDeclRef.getDecl()))
    {
        return true;
    }

    // An interface-level constraint requirement (declared in an interface body
    // as `__constraint <type> == <type>` or `__constraint <type> : <type>`)
    // refines the implicit `This` type and/or its inherited associated types.
    // Such a requirement is not satisfied by a member of the conforming type;
    // instead, it is satisfied by verifying that the constraint holds once
    // `This` has been replaced by the conforming type (which the surrounding
    // `LookupDeclRef` substitution has already done in `requiredMemberDeclRef`).
    //
    if (auto requiredConstraintDeclRef = requiredMemberDeclRef.as<GenericTypeConstraintDecl>())
    {
        // Note: a witness already provided by conformance synthesis (e.g. an
        // `enum`'s `__Tag : __BuiltinIntegerType`, including the `bool`-tagged
        // case) is handled uniformly by the early-out at the top of this function
        // and never reaches here.
        auto constraintSub = getSub(m_astBuilder, requiredConstraintDeclRef);
        auto constraintSup = getSup(m_astBuilder, requiredConstraintDeclRef);
        SubtypeWitness* constraintWitness = nullptr;
        auto isOptionalConstraint =
            requiredConstraintDeclRef.getDecl()->findModifier<OptionalConstraintModifier>() !=
            nullptr;
        if (auto constraintSubDeclRefType = as<DeclRefType>(constraintSub))
        {
            if (auto constraintSubCallableDeclRef =
                    constraintSubDeclRefType->getDeclRef().as<CallableDecl>())
            {
                ensureDecl(constraintSubCallableDeclRef, DeclCheckState::ReadyForLookup);

                // `IForwardDifferentiable.fwd_diff` is `[MaybeDifferentiable]`, so a witness table
                // may omit the higher-order derivative of a synthesized forward derivative
                // function. If we eagerly chase that optional constraint while building the first
                // `IForwardDifferentiable` witness table, lookup can recurse through the same
                // synthesized `fwd_diff` conformance. Record absence here; explicit higher-order
                // differentiation still goes through the hard conformance paths. This uses the
                // same `NoneWitness` representation as the ordinary optional-constraint fallback
                // below and the generic solver's optional witness arguments; `visitNoneWitness`
                // lowers it to the sentinel witness table consumed by optional constraint checks.
                if (isOptionalConstraint &&
                    as<FuncConstraintDecl>(requiredConstraintDeclRef.getDecl()))
                {
                    if (auto synFuncDecl =
                            as<SynthesizedFuncDecl>(constraintSubCallableDeclRef.getDecl()))
                    {
                        if (synFuncDecl->irOp == kIROp_ForwardDifferentiate)
                        {
                            witnessTable->add(
                                requiredConstraintDeclRef.getDecl(),
                                m_astBuilder->getOrCreate<NoneWitness>());
                            return true;
                        }
                    }
                }
            }
        }
        if (constraintSub && constraintSup)
            constraintWitness = isSubtype(constraintSub, constraintSup, IsSubTypeOptions::None);

        // An equality constraint (`==`) must be satisfied by a type-equality
        // witness, not merely by a subtype relationship.
        if (constraintWitness && requiredConstraintDeclRef.getDecl()->isEqualityConstraint &&
            !isTypeEqualityWitness(constraintWitness))
        {
            constraintWitness = nullptr;
        }

        if (!constraintWitness)
        {
            if (isOptionalConstraint)
            {
                witnessTable->add(
                    requiredConstraintDeclRef.getDecl(),
                    m_astBuilder->getOrCreate<NoneWitness>());
                return true;
            }

            if (auto funcConstraintDecl =
                    as<FuncConstraintDecl>(requiredConstraintDeclRef.getDecl()))
            {
                Type* requiredBaseFuncType = nullptr;
                auto kind = getDifferentiabilityConformanceKind(
                    constraintSup,
                    &requiredBaseFuncType,
                    nullptr);
                auto constraintSubDeclRefType = as<DeclRefType>(constraintSub);
                if (kind != DifferentiabilityConformanceKind::None && requiredBaseFuncType &&
                    constraintSub && requiredBaseFuncType->equals(constraintSub) &&
                    constraintSubDeclRefType)
                {
                    auto callableDeclRef =
                        constraintSubDeclRefType->getDeclRef().as<CallableDecl>();
                    if (callableDeclRef)
                    {
                        auto callableRequirementDeclRef =
                            funcConstraintDecl->callableRequirementDeclRef;
                        Decl* callableRequirementDecl =
                            callableRequirementDeclRef
                                ? static_cast<Decl*>(callableRequirementDeclRef.getDecl())
                                : static_cast<Decl*>(requiredConstraintDeclRef.getDecl());

                        getSink()->diagnose(
                            Diagnostics::CallableDoesNotSatisfyDifferentiabilityRequirement{
                                .mode = getDifferentiabilityConformanceKindText(kind),
                                .requirement = callableRequirementDecl,
                                .member = callableDeclRef.getDecl()});
                        getSink()->diagnose(Diagnostics::SeeDeclarationOfInterfaceRequirement{
                            .decl = callableRequirementDecl});
                        return false;
                    }
                }
            }

            getSink()->diagnose(Diagnostics::TypeArgumentDoesNotConformToInterface{
                .typeArg = subType,
                .interface = superInterfaceType,
                .location = inheritanceDecl ? inheritanceDecl->loc
                                            : requiredConstraintDeclRef.getDecl()->loc});
            return false;
        }

        witnessTable->add(
            requiredConstraintDeclRef.getDecl(),
            RequirementWitness(constraintWitness));
        return true;
    }

    // An important exception to the above is that an
    // inheritance declaration in the interface is not going
    // to be satisfied by an inheritance declaration in the
    // conforming type, but rather by a full "witness table"
    // full of the satisfying values for each requirement
    // in the inherited-from interface.
    //
    if (auto requiredInheritanceDeclRef = requiredMemberDeclRef.as<InheritanceDecl>())
    {
        return ensureInheritedInterfaceRequirement(
            context,
            subType,
            requiredInheritanceDeclRef,
            witnessTable,
            InheritedInterfaceRequirementMode::CheckConformance);
    }

    // We will look up members with the same name,
    // since only same-name members will be able to
    // satisfy the requirement.
    //
    Name* name = requiredMemberDeclRef.getName();

    // We start by looking up members of the same
    // name, on the type that is claiming to conform.
    //
    // This lookup step could include members that
    // we might not actually want to consider:
    //
    // * Lookup through a type `Foo` where `Foo : IBar`
    //   will be able to find members of `IBar`, which
    //   somewhat obviously shouldn't apply when
    //   determining if `Foo` satisfies the requirements
    //   of `IBar`.
    //
    // * Lookup in the presence of `__transparent` members
    //   may produce references to declarations on a *field*
    //   of the type rather than the type. Conformance through
    //   transparent members could be supported in theory,
    //   but would require synthesizing proxy/forwarding
    //   implementations in the type itself.
    //
    // For the first issue, we will use a flag to influence
    // lookup so that it doesn't include results looked up
    // through interface inheritance clauses (but it *will*
    // look up result through inheritance clauses corresponding
    // to concrete types).
    //
    // The second issue of members that require us to proxy/forward
    // requests will be handled further down. For now we include
    // lookup results that might be usable, but not as-is.
    //
    LookupResult lookupResult;
    lookupResult = lookUpMember(
        m_astBuilder,
        this,
        name,
        subType,
        nullptr,
        LookupMask::Default,
        LookupOptions::IgnoreBaseInterfaces);

    if (!lookupResult.isValid())
    {
        // If we failed to look up a member with the name of the
        // implementation if this is one of the known builtin requirements,
        // or if the interface method contains a default impl.
        // Otherwise, report diagnostic now.

        if (requiredMemberDeclRef.getDecl()->hasModifier<BuiltinRequirementModifier>() ||
            (requiredMemberDeclRef.as<GenericDecl>() &&
             getInner(requiredMemberDeclRef.as<GenericDecl>())
                 ->hasModifier<BuiltinRequirementModifier>()))
        {
        }
        else if (
            requiredMemberDeclRef.as<SubscriptDecl>() &&
            (as<ArrayExpressionType>(context->conformingType) ||
             as<VectorExpressionType>(context->conformingType) ||
             as<MatrixExpressionType>(context->conformingType)))
        {
        }
        else if (hasDefaultImpl(requiredMemberDeclRef))
        {
        }
        else
        {
            getSink()->diagnose(Diagnostics::TypeDoesntImplementInterfaceRequirement{
                .type = subType,
                .member = requiredMemberDeclRef.getName() ? requiredMemberDeclRef.getName()->text
                                                          : String(),
                .location = inheritanceDecl->loc});
            getSink()->diagnose(
                Diagnostics::SeeDeclarationOf{.decl = requiredMemberDeclRef.getDecl()});
            return false;
        }
    }
    if (lookupResult.isOverloaded())
    {
        // If we found multiple members with the same name,
        // we want to move the declarations in the same parent as inheritanceDecl
        // to the front of the list, so that we always consider them first instead of
        // the members declared in other extension decls.
        //
        Index front = 0;
        auto parentOfInheritanceDecl = getParentAggTypeDeclBase(inheritanceDecl);
        for (Index i = 0; i < lookupResult.items.getCount(); i++)
        {
            if (getParentAggTypeDeclBase(lookupResult.items[i].declRef.getDecl()) ==
                parentOfInheritanceDecl)
            {
                lookupResult.items.swapElements(i, front);
                front++;
            }
        }
    }
    // Iterate over the members and look for one that matches
    // the expected signature for the requirement.
    for (auto member : lookupResult)
    {
        // To a first approximation, any lookup result that required a "breadcrumb"
        // will not be usable to directly satisfy an interface requirement, since
        // each breadcrumb will amount to a manipulation of `this` that is required
        // to make the declaration usable (e.g., casting to a base type).
        //
        if (member.breadcrumbs != nullptr)
            continue;

        if (doesMemberSatisfyRequirement(member.declRef, requiredMemberDeclRef, witnessTable))
        {
            // The member satisfies the requirement, so we should add an `IsOverriding`
            // modifier to the decl, to enable us to verify if a method with `override` keyword
            // is actually overriding something.
            markOverridingDecl(context, member.declRef.getDecl(), requiredMemberDeclRef);

            // Note: we do not impose any additional requirement on the visibility of the member.
            // Specifically, it is valid for a method with lower visibility to implement an
            // interface requirement that has higher visibility. It simply means the method is
            // only accessible externally from the interface and not directly from the concrete
            // type.
            //
            return true;
        }
    }

    // If we reach this point then there were no members suitable
    // for satisfying the interface requirement *diretly*.
    //
    // It is possible that one of the items in `lookupResult` could be
    // used to synthesize an exact-match witness, by generating the
    // code required to handle all the conversions that might be
    // required on `this`.
    //
    // We try synthesis before the interface default below: a member of the conforming type that can
    // satisfy the requirement takes precedence over an inherited default.
    // `trySynthesizeRequirementWitness` returning false therefore means "no member satisfies this",
    // which is what lets an inherited default (or, failing that, an unsatisfied-requirement
    // diagnostic) take over.
    //
    MethodWitnessSynthesisFailureDetails failureDetails = {};
    if (trySynthesizeRequirementWitness(
            context,
            lookupResult,
            requiredMemberDeclRef,
            witnessTable,
            &failureDetails))
    {
        return true;
    }

    // Finally, if there is a default implementation for the required member,
    // we can use that as a witness.
    //
    if (findDefaultInterfaceImpl(
            context,
            requiredMemberDeclRef,
            subTypeConformsToSuperInterfaceWitness,
            witnessTable))
        return true;

    // We failed to find a member of the type that can be used
    // to satisfy the requirement (even via synthesis), so we
    // need to report the failure to the user.
    //
    // TODO: Eventually we might want something akin to the current
    // overload resolution logic, where we keep track of a list
    // of "candidates" for satisfaction of the requirement,
    // and if nothing is found we print the candidates that made it
    // furthest in checking.
    //
    // Based on the failure reason, emit specific diagnostics
    if (failureDetails.reason == WitnessSynthesisFailureReason::MethodResultTypeMismatch)
    {
        // Emit specific return type mismatch diagnostic
        getSink()->diagnose(Diagnostics::MemberReturnTypeMismatch{
            .actualType = failureDetails.actualType,
            .expectedType = failureDetails.expectedType,
            .member = failureDetails.candidateMethod.getDecl()});
    }
    else if (failureDetails.reason == WitnessSynthesisFailureReason::ParameterDirMismatch)
    {
        getSink()->diagnose(Diagnostics::ParameterDirectionDoesNotMatchRequirement{
            .actualDirection = failureDetails.actualDir,
            .expectedDirection = failureDetails.expectedDir,
            .param = failureDetails.paramDecl});
    }
    else if (failureDetails.reason == WitnessSynthesisFailureReason::GenericSignatureMismatch)
    {
        getSink()->diagnose(Diagnostics::GenericSignatureDoesNotMatchRequirement{
            .member = requiredMemberDeclRef.getDecl()->getName()});
    }
    else if (failureDetails.reason == WitnessSynthesisFailureReason::DifferentiabilityMismatch)
    {
        getSink()->diagnose(Diagnostics::MemberDoesNotMatchRequirementSignature{
            .member = failureDetails.candidateMethod.getDecl()});
        getSink()->diagnose(Diagnostics::DifferentiableRequirementNeedsDifferentiableMember{
            .requirement = requiredMemberDeclRef.getDecl(),
            .member = failureDetails.candidateMethod.getDecl()});
    }
    else
    {
        // General failure - use existing logic
        if (!lookupResult.isOverloaded() && lookupResult.isValid())
        {
            getSink()->diagnose(Diagnostics::MemberDoesNotMatchRequirementSignature{
                .member = lookupResult.item.declRef.getDecl()});
        }
        else
        {
            getSink()->diagnose(Diagnostics::TypeDoesntImplementInterfaceRequirement{
                .type = subType,
                .member = requiredMemberDeclRef.getName() ? requiredMemberDeclRef.getName()->text
                                                          : String(),
                .location = inheritanceDecl->loc});

            for (auto& item : lookupResult)
            {
                getSink()->diagnose(
                    Diagnostics::SeeOverloadConsidered{.decl = item.declRef.getDecl()});
            }
        }
    }
    getSink()->diagnose(
        Diagnostics::SeeDeclarationOfInterfaceRequirement{.decl = requiredMemberDeclRef.getDecl()});
    return false;
}

SemanticsVisitor::ConformanceRequirementCheckResult SemanticsVisitor::ensureConformanceRequirement(
    ConformanceCheckingContext* context,
    Type* subType,
    Type* superInterfaceType,
    InheritanceDecl* inheritanceDecl,
    DeclRef<InterfaceDecl> superInterfaceDeclRef,
    DeclRef<Decl> requiredMemberDeclRef,
    RefPtr<WitnessTable> witnessTable,
    SubtypeWitness* subTypeConformsToSuperInterfaceWitness)
{
    auto requirementDecl = requiredMemberDeclRef.getDecl();

    // A resolved declaration reference already names the concrete satisfying declaration rather
    // than a key in this interface table. `ThisType` is likewise synthesized structurally by
    // requirement lookup. Neither case owns a table entry or per-entry checking state.
    if (as<ThisTypeDecl>(requirementDecl) ||
        !_doesDeclRefNameInterfaceRequirement(requiredMemberDeclRef))
    {
        return ConformanceRequirementCheckResult::Satisfied;
    }

    InterfaceRequirementKey requirementKey(requirementDecl);

    auto previousState = witnessTable->getRequirementCheckState(requirementKey);
    switch (previousState)
    {
    case RequirementCheckState::Succeeded:
        SLANG_RELEASE_ASSERT(witnessTable->containsRequirement(requirementKey));
        return ConformanceRequirementCheckResult::Satisfied;
    case RequirementCheckState::Failed:
        SLANG_RELEASE_ASSERT(!witnessTable->containsRequirement(requirementKey));
        return ConformanceRequirementCheckResult::Failed;
    case RequirementCheckState::Checking:
        // Consider this example:
        //
        //     interface IA { associatedtype A : IB; }
        //     interface IB { associatedtype B : IA; }
        //
        // Resolving one entry may legitimately request another entry that eventually reaches the
        // first. The outer request still owns the attempt and may make progress after this nested
        // request unwinds, so report the dependency instead of diagnosing a declaration cycle.
        return ConformanceRequirementCheckResult::InProgress;
    case RequirementCheckState::WitnessReady:
        {
            RequirementWitness preparedWitness;
            SLANG_RELEASE_ASSERT(
                witnessTable->tryGetRequirementWitness(requirementKey, preparedWitness));
            SLANG_RELEASE_ASSERT(
                preparedWitness.getFlavor() == RequirementWitness::Flavor::witnessTable);
            break;
        }
    case RequirementCheckState::Unchecked:
        break;
    }

    // Conformance synthesis can populate a final witness before ordinary requirement checking
    // reaches it. A witness deliberately marked `WitnessReady`, in contrast, is only a structural
    // answer published to break a recursive lookup path and still needs validation below.
    if (previousState == RequirementCheckState::Unchecked &&
        witnessTable->containsRequirement(requirementKey))
    {
        witnessTable->setRequirementCheckState(requirementKey, RequirementCheckState::Succeeded);
        return ConformanceRequirementCheckResult::Satisfied;
    }

    witnessTable->setRequirementCheckState(requirementKey, RequirementCheckState::Checking);
    bool requirementSatisfied = false;
    if (previousState == RequirementCheckState::WitnessReady)
    {
        // The forceful projection path currently publishes only inherited-interface tables. The
        // table is already present, so validate that nested conformance without treating mere
        // dictionary presence as success.
        if (auto requiredInheritanceDeclRef = requiredMemberDeclRef.as<InheritanceDecl>())
        {
            requirementSatisfied = ensureInheritedInterfaceRequirement(
                context,
                subType,
                requiredInheritanceDeclRef,
                witnessTable,
                InheritedInterfaceRequirementMode::CheckConformance);
        }
        else
        {
            SLANG_UNEXPECTED("only an inherited-interface requirement may be prepared");
        }
    }
    else
    {
        requirementSatisfied = findWitnessForInterfaceRequirement(
            context,
            subType,
            superInterfaceType,
            inheritanceDecl,
            superInterfaceDeclRef,
            requiredMemberDeclRef,
            witnessTable,
            subTypeConformsToSuperInterfaceWitness);
    }

    if (requirementSatisfied)
    {
        SLANG_RELEASE_ASSERT(witnessTable->containsRequirement(requirementKey));
        witnessTable->setRequirementCheckState(requirementKey, RequirementCheckState::Succeeded);
        return ConformanceRequirementCheckResult::Satisfied;
    }

    // A failed attempt must not leave a provisional structural answer visible to passive lookup.
    witnessTable->removeRequirement(requirementKey);
    witnessTable->setRequirementCheckState(requirementKey, RequirementCheckState::Failed);
    return ConformanceRequirementCheckResult::Failed;
}

static bool _doesTypeDeclHaveDefinition(ContainerDecl* decl);

SemanticsVisitor::ConformanceCheckingContext* SemanticsVisitor::
    getOrCreateConformanceCheckingContext(
        Type* conformingType,
        InheritanceDecl* inheritanceDecl,
        ContainerDecl* parentDecl)
{
    auto shared = getShared();
    if (auto existing =
            shared->m_mapInheritanceDeclToConformanceCheckingContext.tryGetValue(inheritanceDecl))
    {
        SLANG_RELEASE_ASSERT((*existing)->conformingType->equals(conformingType));
        SLANG_RELEASE_ASSERT((*existing)->parentDecl == parentDecl);
        SLANG_RELEASE_ASSERT((*existing)->rootInheritanceDecl == inheritanceDecl);
        return existing->Ptr();
    }

    RefPtr<ConformanceCheckingContext> context = new ConformanceCheckingContext();
    context->conformingType = conformingType;
    context->parentDecl = parentDecl;
    context->rootInheritanceDecl = inheritanceDecl;

    auto inheritanceDeclRef =
        createDefaultSubstitutionsIfNeeded(m_astBuilder, this, makeDeclRef(inheritanceDecl))
            .as<InheritanceDecl>();
    auto interfaceType = inheritanceDecl->base.type;
    context->conformingWitness =
        m_astBuilder->getDeclaredSubtypeWitness(conformingType, interfaceType, inheritanceDeclRef);

    RefPtr<WitnessTable> witnessTable = inheritanceDecl->witnessTable;
    if (!witnessTable)
    {
        witnessTable = new WitnessTable();
        witnessTable->baseType = interfaceType;
        witnessTable->witnessedType = conformingType;
        witnessTable->isExtern =
            (!_doesTypeDeclHaveDefinition(parentDecl) && parentDecl->hasModifier<ExternModifier>());
        inheritanceDecl->witnessTable = witnessTable;
    }

    shared->m_mapInheritanceDeclToConformanceCheckingContext.add(inheritanceDecl, context);

    if (auto interfaceDeclRef = isDeclRefTypeOf<InterfaceDecl>(interfaceType))
    {
        registerConformanceInterfaceCheckingState(
            context,
            conformingType,
            interfaceType,
            inheritanceDecl,
            interfaceDeclRef,
            witnessTable,
            context->conformingWitness);
    }
    return context.Ptr();
}

SemanticsVisitor::ConformanceInterfaceCheckingState* SemanticsVisitor::
    registerConformanceInterfaceCheckingState(
        ConformanceCheckingContext* context,
        Type* conformingType,
        Type* interfaceType,
        InheritanceDecl* inheritanceDecl,
        DeclRef<InterfaceDecl> interfaceDeclRef,
        RefPtr<WitnessTable> witnessTable,
        SubtypeWitness* conformingWitness)
{
    auto shared = getShared();
    if (auto existing =
            shared->m_mapWitnessTableToConformanceInterfaceCheckingState.tryGetValue(witnessTable))
    {
        // Synthesizing a generic requirement can use an ephemeral child context with a different
        // parent declaration while referring to the same conformance table. The table's original
        // persistent owner remains authoritative. Every other input describes the table itself and
        // must agree with that original registration.
        auto state = existing->Ptr();
        SLANG_RELEASE_ASSERT(state->conformingType->equals(conformingType));
        SLANG_RELEASE_ASSERT(state->interfaceType->equals(interfaceType));
        SLANG_RELEASE_ASSERT(state->inheritanceDecl == inheritanceDecl);
        SLANG_RELEASE_ASSERT(state->interfaceDeclRef == interfaceDeclRef);
        SLANG_RELEASE_ASSERT(state->witnessTable.Ptr() == witnessTable.Ptr());
        SLANG_RELEASE_ASSERT(state->conformingWitness->equals(conformingWitness));
        return state;
    }

    RefPtr<ConformanceInterfaceCheckingState> state = new ConformanceInterfaceCheckingState();
    state->owner = context;
    state->conformingType = conformingType;
    state->interfaceType = interfaceType;
    state->inheritanceDecl = inheritanceDecl;
    state->interfaceDeclRef = interfaceDeclRef;
    state->witnessTable = witnessTable;
    state->conformingWitness = conformingWitness;

    if (auto existingTable = context->mapInterfaceToWitnessTable.tryGetValue(interfaceDeclRef))
        SLANG_RELEASE_ASSERT(existingTable->Ptr() == witnessTable.Ptr());
    else
        context->mapInterfaceToWitnessTable.add(interfaceDeclRef, witnessTable);

    shared->m_mapWitnessTableToConformanceInterfaceCheckingState.add(witnessTable, state);
    return state.Ptr();
}

SemanticsVisitor::ConformanceRequirementCheckResult SemanticsVisitor::ensureConformanceRequirement(
    WitnessTable* witnessTable,
    DeclRef<Decl> requiredMemberDeclRef)
{
    auto state =
        getShared()->m_mapWitnessTableToConformanceInterfaceCheckingState.tryGetValue(witnessTable);
    SLANG_RELEASE_ASSERT(state);

    auto interfaceState = state->Ptr();
    return ensureConformanceRequirement(
        interfaceState->owner.Ptr(),
        interfaceState->conformingType,
        interfaceState->interfaceType,
        interfaceState->inheritanceDecl,
        interfaceState->interfaceDeclRef,
        requiredMemberDeclRef,
        interfaceState->witnessTable,
        interfaceState->conformingWitness);
}

SemanticsVisitor::RequirementLookupResult SemanticsVisitor::ensureAndLookupRequirementWitness(
    SubtypeWitness* conformanceWitness,
    DeclRef<Decl> requirementDeclRef)
{
    RequirementLookupResult result;
    if (!conformanceWitness || !requirementDeclRef)
        return result;

    // `locateNextRequirementWitnessLookupFrontier` returns the first missing structural step, not
    // necessarily the originally requested leaf. Each successful mutation therefore restarts the
    // passive lookup from the original witness and requirement. Every path that reaches the bottom
    // of the loop must set `madeProgress` after publishing the table or entry named by its
    // frontier; the release assertion makes that restart contract structural rather than merely
    // documentary. Both publication and the next lookup normalize an entry through
    // `InterfaceRequirementKey`, so the next traversal must observe the newly inserted key and
    // advance beyond that frontier. `gh-12822-multistep-inheritance.slang` exercises multiple such
    // restarts. Encountering an entry already owned by an outer request returns `Recursive` instead
    // of spinning, and every finite witness path therefore either advances to a later missing step
    // or returns a terminal result.
    for (;;)
    {
        bool madeProgress = false;
        auto frontier = locateNextRequirementWitnessLookupFrontier(
            m_astBuilder,
            conformanceWitness,
            requirementDeclRef);
        switch (frontier.getStatus())
        {
        case RequirementWitnessLookupFrontierStatus::Found:
            result.status = RequirementLookupStatus::Found;
            result.witness = frontier.getWitness();
            return result;

        case RequirementWitnessLookupFrontierStatus::Indeterminate:
            return result;

        case RequirementWitnessLookupFrontierStatus::NeedsConcreteConformance:
            return ensureAndLookupRequirementWitnessThroughProjectedConformance(
                frontier.getProjectedConformanceWitness(),
                requirementDeclRef);

        case RequirementWitnessLookupFrontierStatus::MissingConcreteTable:
            {
                auto inheritanceDeclRef = frontier.getConcreteConformanceDeclRef();
                auto inheritanceDecl = inheritanceDeclRef.getDecl();
                auto conformanceParent = as<ContainerDecl>(inheritanceDecl->parentDecl);
                SLANG_RELEASE_ASSERT(
                    conformanceParent && !as<InterfaceDecl>(conformanceParent) &&
                    !as<AssocTypeDecl>(conformanceParent));

                // Witness tables contain declaration-context answers. Reconstruct the default
                // declaration context rather than writing a specialized answer into the shared
                // table for a generic conformance.
                auto declarationInheritanceDeclRef = createDefaultSubstitutionsIfNeeded(
                                                         m_astBuilder,
                                                         this,
                                                         makeDeclRef(inheritanceDecl))
                                                         .as<InheritanceDecl>();
                auto conformanceSubType =
                    calcThisType(DeclRef<Decl>(declarationInheritanceDeclRef).getParent());
                auto superInterfaceType = getBaseType(m_astBuilder, declarationInheritanceDeclRef);
                if (!conformanceSubType || !isDeclRefTypeOf<InterfaceDecl>(superInterfaceType))
                    return result;

                getOrCreateConformanceCheckingContext(
                    conformanceSubType,
                    inheritanceDecl,
                    conformanceParent);
                SLANG_RELEASE_ASSERT(inheritanceDecl->witnessTable);
                // Publishing the root table can change how a nested `LookupDeclRef` resolves. Make
                // that change visible before restarting the lookup from its original value.
                m_astBuilder->incrementEpoch();
                madeProgress = true;
                break;
            }

        case RequirementWitnessLookupFrontierStatus::MissingEntry:
            {
                auto witnessTable = frontier.getWitnessTable();
                // Extern conformances accept the interface relationship without providing local
                // satisfying declarations, so no structural entry can be forced here.
                if (!witnessTable || witnessTable->isExtern)
                    return result;

                auto registeredState =
                    getShared()->m_mapWitnessTableToConformanceInterfaceCheckingState.tryGetValue(
                        witnessTable);
                // Abstract generic constraints own path-resolution tables rather than declared
                // conformances, and serialized or synthesized tables may likewise have no live
                // declaration-context checker. Passive lookup may traverse such a table, but there
                // is no concrete conformance state from which this operation could synthesize a
                // missing entry, so leave the projection symbolic.
                if (!registeredState)
                    return result;
                auto interfaceState = registeredState->Ptr();

                auto frontierRequirementDeclRef = frontier.getRequirementDeclRef();
                ensureDecl(frontierRequirementDeclRef, DeclCheckState::ReadyForReference);
                auto declarationRequirementDeclRef = m_astBuilder->getLookupDeclRef(
                    interfaceState->conformingWitness,
                    frontierRequirementDeclRef.getDecl());

                // A canonical inherited-interface entry is itself the table needed to continue
                // toward a deeper leaf; a non-canonical entry instead points at the canonical
                // conformance path. Publish either form without conflating structural progress on
                // the canonical table with validation of all of its requirements.
                if (auto requiredInheritanceDeclRef =
                        declarationRequirementDeclRef.as<InheritanceDecl>())
                {
                    auto requirementDecl = requiredInheritanceDeclRef.getDecl();
                    InterfaceRequirementKey requirementKey(requirementDecl);
                    switch (witnessTable->getRequirementCheckState(requirementKey))
                    {
                    case RequirementCheckState::Checking:
                        result.status = RequirementLookupStatus::Recursive;
                        return result;
                    case RequirementCheckState::Failed:
                        result.status = RequirementLookupStatus::Failed;
                        return result;
                    case RequirementCheckState::Succeeded:
                    case RequirementCheckState::WitnessReady:
                        // Both states require a dictionary entry. `removeRequirement` clears the
                        // entry and its state together, while failure paths set `Failed` only after
                        // removing the entry, so the frontier could not have reported it missing.
                        SLANG_UNEXPECTED("checked requirement has no structural witness");
                    case RequirementCheckState::Unchecked:
                        break;
                    }

                    // Preparation only publishes the canonical nested table (or its existing
                    // non-canonical conformance witness); validation is deliberately deferred.
                    // It therefore cannot fail for a well-formed inherited-interface requirement.
                    SLANG_RELEASE_ASSERT(ensureInheritedInterfaceRequirement(
                        interfaceState->owner.Ptr(),
                        interfaceState->conformingType,
                        requiredInheritanceDeclRef,
                        witnessTable,
                        InheritedInterfaceRequirementMode::PrepareForLookup));
                    RequirementWitness preparedWitness;
                    SLANG_RELEASE_ASSERT(
                        witnessTable->tryGetRequirementWitness(requirementKey, preparedWitness));
                    switch (preparedWitness.getFlavor())
                    {
                    case RequirementWitness::Flavor::witnessTable:
                        witnessTable->setRequirementCheckState(
                            requirementKey,
                            RequirementCheckState::WitnessReady);
                        break;
                    case RequirementWitness::Flavor::val:
                        witnessTable->setRequirementCheckState(
                            requirementKey,
                            RequirementCheckState::Succeeded);
                        break;
                    default:
                        SLANG_UNEXPECTED("inherited-interface requirement has invalid witness");
                    }
                    // The next lookup step may need to resolve the newly published conformance
                    // witness before it can identify another concrete table.
                    m_astBuilder->incrementEpoch();
                    madeProgress = true;
                    break;
                }

                auto checkResult =
                    ensureConformanceRequirement(witnessTable, declarationRequirementDeclRef);
                switch (checkResult)
                {
                case ConformanceRequirementCheckResult::InProgress:
                    result.status = RequirementLookupStatus::Recursive;
                    return result;
                case ConformanceRequirementCheckResult::Failed:
                    result.status = RequirementLookupStatus::Failed;
                    return result;
                case ConformanceRequirementCheckResult::Satisfied:
                    SLANG_RELEASE_ASSERT(witnessTable->containsRequirement(
                        InterfaceRequirementKey(declarationRequirementDeclRef.getDecl())));
                    m_astBuilder->incrementEpoch();
                    madeProgress = true;
                    break;
                }
                break;
            }
        }
        SLANG_RELEASE_ASSERT(madeProgress);
    }
}

SemanticsVisitor::RequirementLookupResult SemanticsVisitor::
    ensureAndLookupRequirementWitnessThroughProjectedConformance(
        SubtypeWitness* projectedConformanceWitness,
        DeclRef<Decl> requirementDeclRef)
{
    RequirementLookupResult result;

    // Consider `T.Element.Value` where `T : IOuter`, `IOuter.Element : IInner`, and `Value` is an
    // `IInner` requirement. The outer table stores a symbolic witness for
    // `T.Element : IInner`. Resolve `T.Element` first, recover the ordinary concrete conformance
    // witness for that type, and continue the original `Value` lookup through it.
    Type* concreteSubType = nullptr;
    Type* concreteSuperType = nullptr;
    result.status =
        ensureConcreteConformanceEndpoint(projectedConformanceWitness->getSub(), concreteSubType);
    if (result.status != RequirementLookupStatus::Found)
        return result;
    result.status =
        ensureConcreteConformanceEndpoint(projectedConformanceWitness->getSup(), concreteSuperType);
    if (result.status != RequirementLookupStatus::Found)
        return result;

    auto concreteConformanceWitness = tryGetSubtypeWitness(concreteSubType, concreteSuperType);
    if (!concreteConformanceWitness)
    {
        result.status = RequirementLookupStatus::Failed;
        return result;
    }
    if (concreteConformanceWitness->equals(projectedConformanceWitness))
    {
        // Resolving the endpoints reproduced the same symbolic relation, so recursing through it
        // cannot make progress. Leave the projection unavailable to the forceful caller instead of
        // claiming to have found an empty requirement witness.
        result.status = RequirementLookupStatus::Unavailable;
        return result;
    }

    return ensureAndLookupRequirementWitness(concreteConformanceWitness, requirementDeclRef);
}

SemanticsVisitor::RequirementLookupStatus SemanticsVisitor::ensureConcreteConformanceEndpoint(
    Type* type,
    Type*& outType)
{
    auto resolution = ensureAndResolveRequirementProjection(type);
    switch (resolution.status)
    {
    case RequirementProjectionResolutionStatus::Resolved:
        outType = as<Type>(resolution.value);
        SLANG_RELEASE_ASSERT(outType);
        return RequirementLookupStatus::Found;
    case RequirementProjectionResolutionStatus::Unchanged:
        return RequirementLookupStatus::Unavailable;
    case RequirementProjectionResolutionStatus::Failed:
        return RequirementLookupStatus::Failed;
    }
    SLANG_UNREACHABLE("unhandled requirement projection resolution result");
}

SemanticsVisitor::RequirementProjectionResolutionResult SemanticsVisitor::
    ensureAndResolveRequirementProjection(Val* value)
{
    RequirementProjectionResolutionResult result;
    result.value = value;
    if (!value)
        return result;

    auto resolvedValue = value->resolve();
    result.value = resolvedValue;

    SubtypeWitness* conformanceWitness = nullptr;
    DeclRef<Decl> requirementDeclRef;
    bool resultMustBeType = false;

    if (auto declRefType = as<DeclRefType>(resolvedValue))
    {
        resultMustBeType = true;
        if (auto lookupDeclRef = SubstitutionSet(declRefType->getDeclRef()).findLookupDeclRef())
        {
            conformanceWitness = lookupDeclRef->getWitness();
            requirementDeclRef = DeclRef<Decl>(lookupDeclRef);
        }
    }
    else if (auto declRef = as<DeclRefBase>(resolvedValue))
    {
        if (auto lookupDeclRef = SubstitutionSet(declRef).findLookupDeclRef())
        {
            conformanceWitness = lookupDeclRef->getWitness();
            requirementDeclRef = DeclRef<Decl>(lookupDeclRef);
        }
    }
    else if (auto witnessLookupValue = as<WitnessLookupIntVal>(resolvedValue))
    {
        conformanceWitness = witnessLookupValue->getWitness();
        requirementDeclRef = makeDeclRef(witnessLookupValue->getKey());
    }

    // The value is already as structurally resolved as ordinary canonicalization requires. This
    // includes aliases and every value that is not a conformance-requirement projection.
    if (!conformanceWitness || !requirementDeclRef)
    {
        result.status = RequirementProjectionResolutionStatus::Resolved;
        return result;
    }

    auto lookupResult = ensureAndLookupRequirementWitness(conformanceWitness, requirementDeclRef);
    switch (lookupResult.status)
    {
    case RequirementLookupStatus::Unavailable:
    case RequirementLookupStatus::Recursive:
        // Neither result provides a concrete value: the former path is not forceable here, while
        // the latter is owned by an enclosing request. Both must remain symbolic for the caller.
        return result;
    case RequirementLookupStatus::Failed:
        result.status = RequirementProjectionResolutionStatus::Failed;
        return result;
    case RequirementLookupStatus::Found:
        break;
    }

    // A successful force invalidates the ordinary resolution cache, so first let the existing
    // `Val` machinery rebuild any enclosing `MemberDeclRef` or `GenericAppDeclRef`. Direct
    // projections fall back to extracting the value from `RequirementWitness` below.
    auto resolvedAfterLookup = resolvedValue->resolve();
    if (resolvedAfterLookup != resolvedValue)
    {
        // Each recursive step removes at least one alias, member, or generic wrapper that ordinary
        // resolution could not simplify before the witness was published. `Val::resolve()` caches
        // one canonical result per epoch, so a wrapper cannot reappear or alternate with an earlier
        // representation.
        return ensureAndResolveRequirementProjection(resolvedAfterLookup);
    }

    Val* satisfyingValue = nullptr;
    switch (lookupResult.witness.getFlavor())
    {
    case RequirementWitness::Flavor::none:
    case RequirementWitness::Flavor::witnessTable:
        // Optional and inherited-interface requirements can be found structurally without naming
        // a satisfying value. They are not value projections, so leave the input symbolic.
        return result;
    case RequirementWitness::Flavor::declRef:
        satisfyingValue = lookupResult.witness.getDeclRef().declRefBase;
        break;
    case RequirementWitness::Flavor::val:
        satisfyingValue = lookupResult.witness.getVal();
        break;
    default:
        SLANG_UNEXPECTED("unknown requirement witness flavor");
    }

    if (resultMustBeType)
    {
        if (auto satisfyingType = as<Type>(satisfyingValue))
            result.value = satisfyingType;
        else if (auto satisfyingDeclRef = as<DeclRefBase>(satisfyingValue))
            result.value = DeclRefType::create(m_astBuilder, DeclRef<Decl>(satisfyingDeclRef));
        else
            SLANG_UNEXPECTED("associated-type requirement did not produce a type");
    }
    else
    {
        result.value = satisfyingValue;
    }
    result.status = RequirementProjectionResolutionStatus::Resolved;
    return result;
}

RefPtr<WitnessTable> SemanticsVisitor::checkInterfaceConformance(
    ConformanceCheckingContext* context,
    Type* subType,
    Type* superInterfaceType,
    InheritanceDecl* inheritanceDecl,
    DeclRef<InterfaceDecl> superInterfaceDeclRef,
    SubtypeWitness* subTypeConformsToSuperInterfaceWitness)
{
    // A table is registered before its members are checked so recursive interface paths can reuse
    // it. Registration alone is not completion: on-demand projection lookup may have prepared a
    // nested table whose requirements still need to be checked here.
    RefPtr<WitnessTable> witnessTable;
    if (context->mapInterfaceToWitnessTable.tryGetValue(superInterfaceDeclRef, witnessTable))
    {
        auto registeredState =
            getShared()->m_mapWitnessTableToConformanceInterfaceCheckingState.tryGetValue(
                witnessTable);
        SLANG_RELEASE_ASSERT(registeredState);
        switch ((*registeredState)->status)
        {
        case ConformanceInterfaceCheckStatus::Checking:
        case ConformanceInterfaceCheckStatus::Succeeded:
            return witnessTable;
        case ConformanceInterfaceCheckStatus::Failed:
            return nullptr;
        case ConformanceInterfaceCheckStatus::Unchecked:
            break;
        }
    }

    // We need to check the declaration of the interface
    // before we can check that we conform to it.
    //
    ensureDecl(superInterfaceDeclRef, DeclCheckState::CanReadInterfaceRequirements);

    // We will construct the witness table, and register it
    // *before* we go about checking fine-grained requirements,
    // in order to short-circuit any potential for infinite recursion.

    // Reuse a table already registered for this interface first. Otherwise, use a table attached
    // to the inheritance declaration when earlier semantic work has synthesized entries there,
    // and allocate a new table only when neither source exists.
    //
    if (!witnessTable)
    {
        witnessTable = inheritanceDecl->witnessTable;
        if (!witnessTable)
        {
            witnessTable = new WitnessTable();
            witnessTable->baseType = DeclRefType::create(m_astBuilder, superInterfaceDeclRef);
            witnessTable->witnessedType = subType;
        }
        context->mapInterfaceToWitnessTable.add(superInterfaceDeclRef, witnessTable);
    }

    auto interfaceState = registerConformanceInterfaceCheckingState(
        context,
        subType,
        superInterfaceType,
        inheritanceDecl,
        superInterfaceDeclRef,
        witnessTable,
        subTypeConformsToSuperInterfaceWitness);
    SLANG_RELEASE_ASSERT(interfaceState->status == ConformanceInterfaceCheckStatus::Unchecked);
    interfaceState->status = ConformanceInterfaceCheckStatus::Checking;

    if (!checkInterfaceConformance(
            context,
            subType,
            superInterfaceType,
            inheritanceDecl,
            superInterfaceDeclRef,
            subTypeConformsToSuperInterfaceWitness,
            witnessTable))
    {
        interfaceState->status = ConformanceInterfaceCheckStatus::Failed;
        return nullptr;
    }

    interfaceState->status = ConformanceInterfaceCheckStatus::Succeeded;
    return witnessTable;
}

bool SemanticsVisitor::checkInterfaceConformance(
    ConformanceCheckingContext* context,
    Type* subType,
    Type* superInterfaceType,
    InheritanceDecl* inheritanceDecl,
    DeclRef<InterfaceDecl> superInterfaceDeclRef,
    SubtypeWitness* subTypeConformsToSuperInterfaceWitness,
    WitnessTable* witnessTable)
{
    registerConformanceInterfaceCheckingState(
        context,
        subType,
        superInterfaceType,
        inheritanceDecl,
        superInterfaceDeclRef,
        witnessTable,
        subTypeConformsToSuperInterfaceWitness);

    // We need to check the declaration of the interface
    // before we can check that we conform to it.
    //
    ensureDecl(superInterfaceDeclRef, DeclCheckState::CanReadInterfaceRequirements);

    // When comparing things like signatures, we need to do so in the context
    // of a LookupDeclRef that aligns the signatures in the interface
    // with those in the concrete type. For example, we need to treat any uses
    // of `This` in the interface as equivalent to the concrete type for the
    // purpose of signature matching (and similarly for associated types).
    //
    auto thisTypeDeclRef = m_astBuilder->getLookupDeclRef(
        subTypeConformsToSuperInterfaceWitness,
        superInterfaceDeclRef.getDecl()->getThisTypeDecl());

    auto asGenericTypeConstraintRequirement = [](Decl* decl) -> GenericTypeConstraintDecl*
    {
        while (auto genericDecl = as<GenericDecl>(decl))
            decl = genericDecl->inner;
        return as<GenericTypeConstraintDecl>(decl);
    };

    auto doesTypeNameAssociatedTypeRequirement = [](Type* type) -> bool
    {
        if (auto declRefType = as<DeclRefType>(type))
        {
            for (auto declRef = declRefType->getDeclRef().declRefBase; declRef;
                 declRef = declRef->getBase())
            {
                if (isAssociatedTypeDecl(declRef->getDecl()))
                    return true;
            }
        }
        return false;
    };

    auto doesConstraintRefineAssociatedTypeRequirement =
        [&](GenericTypeConstraintDecl* constraintDecl) -> bool
    {
        return doesTypeNameAssociatedTypeRequirement(constraintDecl->sub.type) ||
               doesTypeNameAssociatedTypeRequirement(constraintDecl->sup.type);
    };

    bool result = true;

    auto ensureRequirement = [&](DeclRef<Decl> requiredMemberDeclRef) -> bool
    {
        auto checkResult = ensureConformanceRequirement(
            context,
            subType,
            superInterfaceType,
            inheritanceDecl,
            superInterfaceDeclRef,
            requiredMemberDeclRef,
            witnessTable,
            subTypeConformsToSuperInterfaceWitness);

        // An in-progress result means that an outer request still owns this entry. Existing
        // conformance checking already handles recursive interface paths coinductively by reusing
        // an in-progress witness table, so preserve that policy here. The owning request will
        // eventually record success or failure on the entry.
        return checkResult != ConformanceRequirementCheckResult::Failed;
    };

    auto checkGenericTypeConstraintRequirement = [&](Decl* requiredMemberDecl) -> bool
    {
        ensureDecl(requiredMemberDecl, DeclCheckState::ReadyForReference);
        DeclRef<Decl> requiredMemberDeclRef;
        if (auto genericDecl = as<GenericDecl>(requiredMemberDecl))
        {
            requiredMemberDeclRef =
                m_astBuilder->getLookupDeclRef(subTypeConformsToSuperInterfaceWitness, genericDecl);

            // Generic interface constraints are requirements, while their direct sibling
            // constraints are signature proofs. Specialize through the wrapper chain until the
            // decl-ref names the inner `GenericTypeConstraintDecl`, so
            // `findWitnessForInterfaceRequirement` records the witness under the real key.
            while (auto genericRequirementDeclRef = requiredMemberDeclRef.as<GenericDecl>())
            {
                auto defaultArgs = getDefaultSubstitutionArgs(
                    m_astBuilder,
                    this,
                    genericRequirementDeclRef.getDecl());
                auto genericRequirementSubst = SubstitutionSet(genericRequirementDeclRef);
                List<Val*> substitutedDefaultArgs;
                for (auto defaultArg : defaultArgs)
                {
                    substitutedDefaultArgs.add(
                        defaultArg->substitute(m_astBuilder, genericRequirementSubst));
                }
                auto specializedRequirementDeclRef = m_astBuilder->getGenericAppDeclRef(
                    genericRequirementDeclRef,
                    substitutedDefaultArgs.getArrayView());
                requiredMemberDeclRef = specializedRequirementDeclRef;
            }
        }
        else
        {
            requiredMemberDeclRef = m_astBuilder->getLookupDeclRef(
                subTypeConformsToSuperInterfaceWitness,
                requiredMemberDecl);
        }

        return ensureRequirement(requiredMemberDeclRef);
    };

    // TODO: If we ever allow for implementation inheritance,
    // then we will need to consider the case where a type
    // declares that it conforms to an interface, but one of
    // its (non-interface) base types already conforms to
    // that interface, so that all of the requirements are
    // already satisfied with inherited implementations...

    // On-demand checking makes correctness less dependent on this sequence: a later requirement
    // may force an earlier or later entry whenever it needs to inspect that entry structurally.
    // Keeping a regular order still acts as a heuristic topological sort. It minimizes the depth of
    // re-entrant checking and therefore the risk of reaching a valid fixpoint only after deeply
    // nesting the native call stack.
    //
    // Associated types currently come before inherited-interface tables because their identities
    // are used broadly by member-signature and conformance checks. If an inherited-interface table
    // needs one of those identities to become resolvable, it can force the individual associated-
    // type entry. Reversing these first two stages is now possible, but should be motivated by
    // examples or measurements that show it yields a shallower dependency traversal.
    //
    // TODO: There could in theory be subtle cases involving
    // circular or recursive dependency chains that make such
    // a simple ordering impractical (e.g., associated type `A`
    // is constrained to `IThing<This>` where `IThing<T>` requires
    // that `T : IOtherThing where T.B == int` for another associated
    // type `B`).
    //
    // The only robust solution long-term is probably to treat this
    // as a type-inference problem by creating type variables to
    // stand in for the associated-type requirements and then to discover
    // constraints and solve for those type variables as part of the
    // conformance-checking process.
    //
    for (auto requiredMemberDecl : getMembers(m_astBuilder, superInterfaceDeclRef))
    {
        if (!isAssociatedTypeDecl(requiredMemberDecl.getDecl()))
            continue;
        ensureDecl(requiredMemberDecl, DeclCheckState::ReadyForReference);
        auto requiredMemberDeclRef = m_astBuilder->getLookupDeclRef(
            subTypeConformsToSuperInterfaceWitness,
            requiredMemberDecl.getDecl());
        auto requirementSatisfied = ensureRequirement(requiredMemberDeclRef);

        result = result && requirementSatisfied;
    }
    // Inherited-interface entries are witness-table entries too, and constraints can refer to
    // requirements inherited through those entries. Consider this example:
    //
    //     interface IBase
    //     {
    //         associatedtype DataType;
    //     }
    //
    //     interface IDerived : IBase
    //     {
    //         __constraint DataType == This;
    //     }
    //
    // A concrete `S : IDerived` table needs a nested `S : IBase` witness-table entry before
    // `getSub`/`getSup` can resolve `DataType` in the `IDerived` equality constraint.
    for (auto requiredMemberDecl : getMembers(m_astBuilder, superInterfaceDeclRef))
    {
        auto requiredInheritanceDecl = as<InheritanceDecl>(requiredMemberDecl.getDecl());
        if (!requiredInheritanceDecl)
            continue;

        ensureDecl(requiredMemberDecl, DeclCheckState::ReadyForReference);
        auto requiredMemberDeclRef = m_astBuilder->getLookupDeclRef(
            subTypeConformsToSuperInterfaceWitness,
            requiredInheritanceDecl);
        auto requirementSatisfied = ensureRequirement(requiredMemberDeclRef);

        result = result && requirementSatisfied;
    }
    // Constraints that refine associated-type requirements must be checked before ordinary member
    // signatures. Consider this example:
    //
    //     interface IBase
    //     {
    //         associatedtype V;
    //     }
    //
    //     interface ISimple
    //     {
    //         associatedtype U : IBase;
    //         U.V add(U left, U right);
    //     }
    //
    // If a concrete type maps `ISimple.U -> Val`, this loop checks `Val : IBase` before the
    // ordinary method loop compares `add`. Resolving the substituted method result `Val.V` then
    // has a completed `Val : IBase` witness table to query.
    for (auto requiredMemberDecl : getMembers(m_astBuilder, superInterfaceDeclRef))
    {
        auto constraintDecl = asGenericTypeConstraintRequirement(requiredMemberDecl.getDecl());
        if (!constraintDecl)
            continue;
        if (!doesConstraintRefineAssociatedTypeRequirement(constraintDecl))
            continue;

        result = result && checkGenericTypeConstraintRequirement(requiredMemberDecl.getDecl());
    }
    for (auto requiredMemberDecl : getMembers(m_astBuilder, superInterfaceDeclRef))
    {
        if (isAssociatedTypeDecl(requiredMemberDecl.getDecl()))
            continue;
        if (asGenericTypeConstraintRequirement(requiredMemberDecl.getDecl()))
            continue;
        if (as<InheritanceDecl>(requiredMemberDecl.getDecl()))
            continue;
        if (as<InterfaceDefaultImplDecl>(requiredMemberDecl.getDecl()))
            continue;
        ensureDecl(requiredMemberDecl, DeclCheckState::ReadyForReference);
        // Validate attributes on empty declarations before skipping them as requirements.
        if (as<EmptyDecl>(requiredMemberDecl.getDecl()))
            continue;
        auto requiredMemberDeclRef = m_astBuilder->getLookupDeclRef(
            subTypeConformsToSuperInterfaceWitness,
            requiredMemberDecl.getDecl());
        auto requirementSatisfied = ensureRequirement(requiredMemberDeclRef);

        result = result && requirementSatisfied;
    }
    // Interface-level constraints may refer to other requirements through `This`. Check them after
    // ordinary members so `getSub`/`getSup` can resolve through the witness-table entries installed
    // above.
    for (auto requiredMemberDecl : getMembers(m_astBuilder, superInterfaceDeclRef))
    {
        auto constraintDecl = asGenericTypeConstraintRequirement(requiredMemberDecl.getDecl());
        if (!constraintDecl)
            continue;
        if (doesConstraintRefineAssociatedTypeRequirement(constraintDecl))
            continue;

        result = result && checkGenericTypeConstraintRequirement(requiredMemberDecl.getDecl());
    }

    // Extensions that apply to the interface type can create new conformances
    // for the concrete types that inherit from the interface.
    //
    // These new conformances should not be able to introduce new *requirements*
    // for an implementing interface (although they currently can), but we
    // still need to go through this logic to find the appropriate value
    // that will satisfy the requirement in these cases, and also to put
    // the required entry into the witness table for the interface itself.
    //
    // TODO: This logic is a bit slippery, and we need to figure out what
    // it means in the context of separate compilation. If module A defines
    // an interface IA, module B defines a type C that conforms to IA, and then
    // module C defines an extension that makes IA conform to IC, then it is
    // unreasonable to expect the {B:IA} witness table to contain an entry
    // corresponding to {IA:IC}.
    //
    // The simple answer then would be that the {IA:IC} conformance should be
    // fixed, with a single witness table for {IA:IC}, but then what should
    // happen in B explicitly conformed to IC already?
    //
    // For now we will just walk through the extensions that are known at
    // the time we are compiling and handle those, and punt on the larger issue
    // for a bit longer.
    //
    auto candidateExtensions = getCandidateExtensions(superInterfaceDeclRef, this);
    for (const auto& candidateExt : candidateExtensions)
    {
        // We need to apply the extension to the interface type that our
        // concrete type is inheriting from.
        //
        Type* targetType = DeclRefType::create(m_astBuilder, thisTypeDeclRef);
        auto parentDeclRef = applyExtensionToType(candidateExt, targetType);
        if (!parentDeclRef)
            continue;

        // Only inheritance clauses from the extension matter right now.
        for (auto requiredInheritanceDecl :
             getMembersOfType<InheritanceDecl>(m_astBuilder, candidateExt))
        {
            auto requiredInheritanceDeclRef = m_astBuilder->getLookupDeclRef(
                subTypeConformsToSuperInterfaceWitness,
                requiredInheritanceDecl.getDecl());
            auto requirementSatisfied = ensureRequirement(requiredInheritanceDeclRef);

            result = result && requirementSatisfied;
        }
    }

    // The conformance was satisfied if all the requirements were satisfied.
    //
    return result;
}

void SemanticsVisitor::_checkDifferentialConformance(
    ConformanceCheckingContext* context,
    Type* subType,
    InheritanceDecl* inheritanceDecl,
    DeclRef<InterfaceDecl> superInterfaceDeclRef,
    WitnessTable* witnessTable)
{
    SLANG_UNUSED(subType);
    // Only perform this check if the super type is IDifferentiable.
    if (superInterfaceDeclRef.getDecl() !=
            m_astBuilder->getDifferentiableInterfaceDecl().getDecl() &&
        superInterfaceDeclRef.getDecl() !=
            m_astBuilder->getDifferentiableRefInterfaceDecl().getDecl())
        return;

    // Don't check for interface decls (they declare requirements, not conformances).
    if (as<InterfaceDecl>(context->parentDecl))
        return;

    // Look up the DifferentialType requirement witness.
    RequirementWitness witnessValue;
    Decl* requirementDecl = nullptr;
    if (superInterfaceDeclRef.getDecl() == m_astBuilder->getDifferentiableInterfaceDecl().getDecl())
    {
        requirementDecl = m_astBuilder->getSharedASTBuilder()->findBuiltinRequirementDecl(
            BuiltinRequirementKind::DifferentialType);
    }
    else if (
        superInterfaceDeclRef.getDecl() ==
        m_astBuilder->getDifferentiableRefInterfaceDecl().getDecl())
    {
        requirementDecl = m_astBuilder->getSharedASTBuilder()->findBuiltinRequirementDecl(
            BuiltinRequirementKind::DifferentialPtrType);
    }

    SLANG_ASSERT(requirementDecl);

    if (!witnessTable->getRequirementDictionary().tryGetValue(requirementDecl, witnessValue))
        return;

    if (witnessValue.getFlavor() != RequirementWitness::Flavor::val)
        return;
    auto differentialType = as<DeclRefType>(witnessValue.getVal());
    if (!differentialType)
        return;

    // Check that the type used as differential type must have itself as its own differential
    // type.
    auto diffDiffType = tryGetDifferentialType(m_astBuilder, differentialType);
    if (!differentialType->equals(diffDiffType))
    {
        getSink()->diagnose(Diagnostics::DifferentialTypeShouldServeAsItsOwnDifferentialType{
            .type = differentialType,
            .diffType = diffDiffType,
            .inheritance = inheritanceDecl});
        getSink()->diagnose(
            Diagnostics::SeeDefinitionOf{.decl = differentialType->getDeclRef().getDecl()});
    }

    // Check that all [DerivativeMember(...)] attributes have their references checked.
    for (auto member : context->parentDecl->getMembersOfType<VarDeclBase>())
    {
        if (member->findModifier<NoDiffModifier>())
            continue;
        auto derivativeMemberAttr = member->findModifier<DerivativeMemberAttribute>();
        if (!derivativeMemberAttr)
            continue;
        checkDerivativeMemberAttributeReferences(member, derivativeMemberAttr);
    }

    // Check that either the differential type is the same as the base type, or all fields of
    // the base type that are differentiable have a corresponding field in the differential type
    // through the [DerivativeMember(...)] attribute.
    //
    // We only need to check the fields of the base type that are differentiable.
    auto baseDecl = as<AggTypeDecl>(context->parentDecl);
    if (!baseDecl)
        return;

    auto thisType = calcThisType(getDefaultDeclRef(baseDecl));

    bool typeIsSelfDifferential = thisType->equals(differentialType);

    for (auto member : baseDecl->getMembersOfType<VarDeclBase>())
    {
        if (member->findModifier<NoDiffModifier>())
            continue;
        auto diffType = tryGetDifferentialType(m_astBuilder, member->type.type);
        if (!diffType)
            continue;

        if (member->findModifier<DerivativeMemberAttribute>())
            continue;
        else if (!typeIsSelfDifferential)
            getSink()->diagnose(
                Diagnostics::DifferentiableMemberShouldHaveCorrespondingFieldInDiffType{
                    .member = member->nameAndLoc.name,
                    .diffType = differentialType,
                    .location = member->loc});
        else
        {
            // If the type is its own differential type, we can infer the differential
            // members from the original type.
            //
            // Add a derivative member attribute referencing itself.
            //
            auto derivativeMemberModifier = m_astBuilder->create<DerivativeMemberAttribute>();
            auto fieldLookupExpr = m_astBuilder->create<StaticMemberExpr>();
            fieldLookupExpr->type.type = diffType;
            auto baseTypeExpr = m_astBuilder->create<SharedTypeExpr>();
            baseTypeExpr->base.type = differentialType;
            auto baseTypeType = m_astBuilder->getOrCreate<TypeType>(differentialType);
            baseTypeExpr->type.type = baseTypeType;
            fieldLookupExpr->baseExpression = baseTypeExpr;
            fieldLookupExpr->declRef = makeDeclRef(member);
            derivativeMemberModifier->memberDeclRef = fieldLookupExpr;
            addModifier(member, derivativeMemberModifier);
        }
    }
}

bool SemanticsVisitor::checkConformanceToType(
    ConformanceCheckingContext* context,
    Type* subType,
    InheritanceDecl* inheritanceDecl,
    Type* superType,
    SubtypeWitness* subIsSuperWitness,
    WitnessTable* witnessTable)
{
    if (witnessTable->isExtern)
        return true;

    if (auto supereclRefType = as<DeclRefType>(superType))
    {
        auto superTypeDeclRef = supereclRefType->getDeclRef();
        if (auto superInterfaceDeclRef = superTypeDeclRef.as<InterfaceDecl>())
        {
            if (isNonCopyableType(subType))
            {
                getSink()->diagnose(Diagnostics::NonCopyableTypeCannotConformToInterface{
                    .type = subType,
                    .interface = superInterfaceDeclRef.getDecl(),
                    .inheritance = inheritanceDecl});
                // Fall through — let conformance checking proceed so the witness table
                // is populated. The warning already informed the user.
            }

            // The type is stating that it conforms to an interface.
            // We need to check that it provides all of the members
            // required by that interface.
            auto conformanceWitnessTable = checkInterfaceConformance(
                context,
                subType,
                superType,
                inheritanceDecl,
                superInterfaceDeclRef,
                subIsSuperWitness);

            // The caller supplies the declaration-context table associated with this conformance.
            // The status-owning overload above must either validate that same table or report
            // failure; silently replacing it would split one conformance across two tables.
            SLANG_RELEASE_ASSERT(
                !conformanceWitnessTable || conformanceWitnessTable.Ptr() == witnessTable);

            // If the interface is IDifferentiable, perform additional
            // derivative member checking now that the associated types
            // (including .Differential) have been resolved.
            if (conformanceWitnessTable)
            {
                _checkDifferentialConformance(
                    context,
                    subType,
                    inheritanceDecl,
                    superInterfaceDeclRef,
                    conformanceWitnessTable);
            }

            return conformanceWitnessTable != nullptr;
        }
        else if (auto superStructDeclRef = superTypeDeclRef.as<StructDecl>())
        {
            // The type is saying it inherits from a `struct`,
            // which doesn't require any checking at present
            return true;
        }
    }
    if (!as<ErrorType>(superType))
    {
        getSink()->diagnose(Diagnostics::InvalidTypeForInheritance{
            .type = superType,
            .inheritanceDecl = inheritanceDecl});
    }
    return false;
}

static bool _doesTypeDeclHaveDefinition(ContainerDecl* decl)
{
    if (auto aggTypeDecl = as<AggTypeDecl>(decl))
        return aggTypeDecl->hasBody;
    return false;
}

bool SemanticsVisitor::checkConformance(
    Type* subType,
    InheritanceDecl* inheritanceDecl,
    ContainerDecl* parentDecl)
{
    auto superType = inheritanceDecl->base.type;

    if (auto declRefType = as<DeclRefType>(subType))
    {
        auto declRef = declRefType->getDeclRef();

        if (auto superDeclRefType = as<DeclRefType>(superType))
        {
            auto superTypeDecl = superDeclRefType->getDeclRef().getDecl();
            if (superTypeDecl->findModifier<ComInterfaceAttribute>())
            {
                auto subTypeDecl = declRef.getDecl();
                if (auto classDecl = as<ClassDecl>(subTypeDecl); classDecl)
                {
                    // Classes can implement COM interfaces.
                }
                else if (auto subInterfaceDecl = as<InterfaceDecl>(subTypeDecl))
                {
                    if (!subInterfaceDecl->findModifier<ComInterfaceAttribute>())
                    {
                        getSink()->diagnose(
                            Diagnostics::InterfaceInheritingComMustBeCom{.decl = inheritanceDecl});
                    }
                }
                else if (const auto structDecl = as<StructDecl>(subTypeDecl); structDecl)
                {
                    getSink()->diagnose(
                        Diagnostics::StructCannotImplementComInterface{.decl = inheritanceDecl});
                }
            }
        }

        // Don't check conformances for abstract types that
        // are being used to express *required* conformances.
        if (auto assocTypeDeclRef = declRef.as<AssocTypeDecl>())
        {
            // An associated type declaration represents a requirement
            // in an outer interface declaration. Bounds on the associated
            // type are represented as sibling interface requirements.
            return true;
        }
        else if (auto interfaceDeclRef = declRef.as<InterfaceDecl>())
        {
            // HACK: Our semantics as they stand today are that an
            // `extension` of an interface that adds a new inheritance
            // clause acts *as if* that inheritnace clause had been
            // attached to the original `interface` decl: that is,
            // it adds additional requirements.
            //
            // This is *not* a reasonable semantic to keep long-term,
            // but it is required for some of our current example
            // code to work.
            return true;
        }

        // If sub type is a link-time-resolved wrapper type (e.g. `extern struct Foo : IFoo =
        // FooImpl;`), fill in `inheritanceDecl->witnessVal` with a Witness val that shows `FooImpl
        // : IFoo`.
        auto aggTypeDecl = as<AggTypeDecl>(declRef.getDecl());

        if (aggTypeDecl && aggTypeDecl->aliasedType)
        {
            auto witness = tryGetSubtypeWitness(aggTypeDecl->aliasedType, superType);
            if (witness)
            {
                inheritanceDecl->witnessVal = witness;
            }
            else
            {
                if (!as<ErrorType>(aggTypeDecl->aliasedType))
                {
                    getSink()->diagnose(Diagnostics::TypeArgumentDoesNotConformToInterface{
                        .typeArg = aggTypeDecl->aliasedType,
                        .interface = superType,
                        .location = inheritanceDecl->loc});
                }
            }
            return witness != nullptr;
        }
    }

    auto context = getOrCreateConformanceCheckingContext(subType, inheritanceDecl, parentDecl);
    RefPtr<WitnessTable> witnessTable = inheritanceDecl->witnessTable;

    if (!checkConformanceToType(
            context,
            subType,
            inheritanceDecl,
            superType,
            context->conformingWitness,
            witnessTable))
    {
        return false;
    }

    return true;
}

void SemanticsVisitor::checkExtensionConformance(ExtensionDecl* decl)
{
    auto declRef = createDefaultSubstitutionsIfNeeded(m_astBuilder, this, makeDeclRef(decl))
                       .as<ExtensionDecl>();
    auto targetType = getTargetType(m_astBuilder, declRef);

    // Make a copy of inhertanceDecls first since `checkConformance` may modify decl->members.
    auto inheritanceDecls = decl->getMembersOfType<InheritanceDecl>().toList();
    for (auto inheritanceDecl : inheritanceDecls)
    {
        // We skip checking conformance for synthesized inheritance decls.
        //
        // Synthesized inheritance decls should currently only be added to synthesized parent
        // declarations (or targets), in which case the witness table will be generated at the
        // IR level.
        //
        if (inheritanceDecl->findModifier<SynthesizedModifier>())
            continue;

        checkConformance(targetType, inheritanceDecl, decl);
    }
}

void SemanticsVisitor::checkDifferentiableMembersInType(AggTypeDecl* decl)
{
    for (auto member : decl->getMembersOfType<VarDeclBase>())
    {
        if (auto derivativeAttr = member->findModifier<DerivativeMemberAttribute>())
        {
            checkDerivativeMemberAttributeReferences(member, derivativeAttr);
        }
    }
}

void SemanticsVisitor::checkAggTypeConformance(AggTypeDecl* decl)
{
    // After we've checked members, we need to go through
    // any inheritance clauses on the type itself, and
    // confirm that the type actually provides whatever
    // those clauses require.

    if (const auto interfaceDecl = as<InterfaceDecl>(decl); interfaceDecl)
    {
        // Don't check that an interface conforms to the
        // things it inherits from.
    }
    else if (const auto assocTypeDecl = as<AssocTypeDecl>(decl); assocTypeDecl)
    {
        // Don't check that an associated type decl conforms to the
        // things it inherits from.
    }
    else
    {
        // For non-interface types we need to check conformance.
        //

        auto astBuilder = getASTBuilder();

        auto declRef = createDefaultSubstitutionsIfNeeded(astBuilder, this, makeDeclRef(decl))
                           .as<AggTypeDeclBase>();
        auto type = DeclRefType::create(astBuilder, declRef);

        // TODO: Need to figure out what this should do for
        // `abstract` types if we ever add them. Should they
        // be required to implement all interface requirements,
        // just with `abstract` methods that replicate things?
        // (That's what C# does).

        // Make a copy of inhertanceDecls first since `checkConformance` may modify decl->members.
        auto inheritanceDecls = decl->getMembersOfType<InheritanceDecl>().toList();
        for (auto inheritanceDecl : inheritanceDecls)
        {
            checkConformance(type, inheritanceDecl, decl);
        }

        // Successful conformance checking may have created new witness tables.
        // Increment epoch to invalidate the cache, so subsequent canonical types are
        // re-calculated.
        //
        // TODO: Is it really necessary to invalidate globally? Maybe there's a way to invalidate
        // only the types that are affected by these interface decls.
        //
        astBuilder->incrementEpoch();

        // For all members marked as `override`, we need to ensure they are actually
        // overriding something.
        for (auto member : decl->getMembers())
        {
            auto innerMember = maybeGetInner(member);
            bool hasOverride = false;
            bool isOverriding = false;
            for (auto modifier : innerMember->modifiers)
            {
                if (as<OverrideModifier>(modifier))
                {
                    hasOverride = true;
                }
                else if (as<IsOverridingModifier>(modifier))
                {
                    isOverriding = true;
                }
            }
            if (hasOverride && !isOverriding)
            {
                getSink()->diagnose(
                    Diagnostics::OverrideModifierNotOverridingBaseDecl{.decl = innerMember});

                if (getShared()->isInLanguageServer() &&
                    member->getName() == getShared()->getSession()->getCompletionRequestTokenName())
                {
                    // If we encountered a completion request for a decl name where an 'override'
                    // keyword is specified, we should suggest all the base decls that can be
                    // overridden, but have not been overridden yet.
                    //
                    calcOverridableCompletionCandidates(type, decl, member);
                }
            }
        }
    }
}


void SemanticsVisitor::calcOverridableCompletionCandidates(
    Type* aggType,
    ContainerDecl* aggTypeDecl,
    Decl* memberDecl)
{
    // We are in language server and the user requested to list
    // all base interface methods that can be overrided in a conforming type.
    // Collect all base interfaces methods that hasn't been overridden and
    // suggest them as completion candidates.
    if (as<InterfaceDecl>(aggTypeDecl))
    {
        // If the aggType is an interface, we don't have any base methods to suggest.
        return;
    }
    auto inheritanceInfo = getShared()->getInheritanceInfo(aggType);
    HashSet<Decl*> overridenDecls;
    for (auto member : aggTypeDecl->getMembers())
    {
        member = maybeGetInner(member);
        if (!as<FuncDecl>(member))
            continue;
        if (auto overridedDeclModifier = member->findModifier<IsOverridingModifier>())
        {
            overridenDecls.add(overridedDeclModifier->overridedDecl);
        }
    }
    auto& contentAssistInfo = getShared()->getLinkage()->contentAssistInfo;
    contentAssistInfo.completionSuggestions.scopeKind = CompletionSuggestions::ScopeKind::Decl;
    auto varDeclBase = as<VarDeclBase>(memberDecl);
    contentAssistInfo.completionSuggestions.formatMode =
        varDeclBase ? CompletionSuggestions::FormatMode::FuncSignatureWithoutReturnType
                    : CompletionSuggestions::FormatMode::FullSignature;
    contentAssistInfo.completionSuggestions.currentPartialDecl = memberDecl;
    List<LookupResultItem> candidateItems;
    for (auto facet : inheritanceInfo.facets)
    {
        // Extensions don't contribute overridable members.
        if (facet->kind == Facet::Kind::Extension)
            continue;

        auto interfaceDecl = facet->getDeclRef().as<InterfaceDecl>();
        if (!interfaceDecl)
            continue;
        for (auto requirement : interfaceDecl.getDecl()->getMembers())
        {
            requirement = maybeGetInner(requirement);
            if (!as<FuncDecl>(requirement))
                continue;
            if (!overridenDecls.contains(requirement))
            {
                auto requirementDeclRef = DeclRef<Decl>(requirement);
                requirementDeclRef =
                    createDefaultSubstitutionsIfNeeded(m_astBuilder, this, requirementDeclRef);
                candidateItems.add(LookupResultItem(requirementDeclRef));
            }
        }
    }
    // Insert overridable candidates at the front of the list, so they are preferred over
    // the completion results from checking ordinary type exprs.
    contentAssistInfo.completionSuggestions.candidateItems.insertRange(0, candidateItems);
}

// Helper function to recursively fill in witness table entries for inheritance requirements
// on generic type constraints. This establishes canonical paths for diamond conformance patterns.
void SemanticsVisitor::_fillInGenericConstraintPathResolutionTableForInheritance(
    Type* subType,
    Type* interfaceType,
    WitnessTable* pathResolutionTable)
{
    auto interfaceDeclRefType = as<DeclRefType>(interfaceType);
    if (!interfaceDeclRefType)
        return;

    auto interfaceDecl = interfaceDeclRefType->getDeclRef().as<InterfaceDecl>();
    if (!interfaceDecl)
        return;

    // For each inheritance requirement in the interface,
    // determine the canonical path from subType to that inherited interface.
    for (auto inheritanceDecl : interfaceDecl.getDecl()->getMembersOfType<InheritanceDecl>())
    {
        auto reqType = inheritanceDecl->base.type;
        if (!reqType)
            continue;

        // Try to get the witness that shows subType conforms to reqType
        auto subIsReqWitness = tryGetSubtypeWitness(subType, reqType);
        if (!subIsReqWitness)
            continue;

        bool isOnCanonicalPath = doesWitnessLookupPathContainDecl(subIsReqWitness, inheritanceDecl);
        if (isOnCanonicalPath)
        {
            // Create a nested witness table if we are on the canonical path.
            RefPtr<WitnessTable> nestedWitnessTable = new WitnessTable();
            nestedWitnessTable->witnessedType = subType;
            nestedWitnessTable->baseType = reqType;

            pathResolutionTable->add(inheritanceDecl, RequirementWitness(nestedWitnessTable));

            // Recursively fill in the nested path resolution table
            _fillInGenericConstraintPathResolutionTableForInheritance(
                subType,
                reqType,
                nestedWitnessTable);
        }
        else
        {
            // Otherwise, store a reference to the canonical path instead.
            pathResolutionTable->add(inheritanceDecl, RequirementWitness(subIsReqWitness));
        }
    }
}

void SemanticsVisitor::checkGenericConstraintConformances(GenericDecl* genericDecl)
{
    // For each generic type constraint like `T : IFoo` where `IFoo` is an interface,
    // we need to build a witness table that establishes canonical inheritance paths
    // for diamond conformance patterns.
    //
    // This is similar to what we do in `findWitnessForInterfaceRequirement` when
    // handling `InheritanceDecl` requirements, but here we apply it to generic
    // type constraints.

    for (auto constraintDecl : genericDecl->getMembersOfType<GenericTypeConstraintDecl>())
    {
        // Skip equality constraints
        if (constraintDecl->isEqualityConstraint)
            continue;

        auto subType = constraintDecl->sub.type;
        auto superType = constraintDecl->sup.type;

        if (!subType || !superType)
            continue;

        // We only care about constraints where the super-type is an interface
        auto superDeclRefType = as<DeclRefType>(superType);
        if (!superDeclRefType)
            continue;

        auto superInterfaceDecl = superDeclRefType->getDeclRef().as<InterfaceDecl>();
        if (!superInterfaceDecl)
            continue;

        // The path-resolution table is derived from the constraint's current sub/super types.
        // `GenericSignatureCloner` drops the source table when cloning a generic signature, so the
        // first check of the cloned constraint rebuilds it here. Later visits through the normal
        // declaration-checking pipeline reuse that table instead of appending duplicate inherited
        // interface entries.
        RefPtr<WitnessTable> pathResolutionTable = constraintDecl->pathResolutionTable;
        if (pathResolutionTable)
            continue;

        pathResolutionTable = new WitnessTable();
        pathResolutionTable->witnessedType = subType;
        pathResolutionTable->baseType = superType;
        constraintDecl->pathResolutionTable = pathResolutionTable;

        // Recursively fill in the path resolution table for inheritance requirements
        _fillInGenericConstraintPathResolutionTableForInheritance(
            subType,
            superType,
            pathResolutionTable);
    }
}

void SemanticsDeclBasesVisitor::_validateCrossModuleInheritance(
    AggTypeDeclBase* decl,
    InheritanceDecl* inheritanceDecl)
{
    // Within a single module, users should be allowed to inherit
    // one type from another more or less freely, so long as they
    // don't violate fundamental validity conditions around
    // inheritance.
    //
    // When an inheritance relationship is declared in one module,
    // and the base type is in another module, we may want to
    // enforce more restrictions. As a strong example, we probably
    // don't want people to declare their own subtype of `int`
    // or `Texture2D<float4>`.
    //
    // We start by checking if the type being inherited from is
    // a decl-ref type, since that means it refers to a declaration
    // that can be localized to its original module.
    //
    auto baseType = inheritanceDecl->base.type;
    auto baseDeclRefType = as<DeclRefType>(baseType);
    if (!baseDeclRefType)
    {
        return;
    }
    auto baseDecl = baseDeclRefType->getDeclRef().getDecl();

    // Using the parent/child hierarchy baked into `Decl`s we
    // can find the modules that contain both the `decl` doing
    // the inheriting, and the `baseDeclRefType` that is being
    // inherited from.
    //
    // If those modules are the same, then we aren't seeing any
    // kind of cross-module inheritance here, and there is nothing
    // that needs enforcing.
    //
    auto moduleWithInheritance = getModule(decl);
    auto moduleWithBaseType = getModule(baseDecl);
    if (moduleWithInheritance == moduleWithBaseType)
    {
        return;
    }

    if (baseDecl->hasModifier<SealedAttribute>())
    {
        // If the original declaration had the `[sealed]` attribute on it,
        // then it explicitly does *not* allow inheritance from other
        // modules.
        //
        getSink()->diagnose(
            Diagnostics::CannotInheritFromExplicitlySealedDeclarationInAnotherModule{
                .baseType = baseType,
                .moduleName = moduleWithBaseType->getModuleDecl()->getName(),
                .inheritanceDecl = inheritanceDecl});
        return;
    }
    else if (baseDecl->hasModifier<OpenAttribute>())
    {
        // Conversely, if the original declaration had the `[open]` attribute
        // on it, then it explicit *does* allow inheritance from other
        // modules.
        //
        // In this case we don't need to check anything: the inheritance
        // is allowed.
    }
    else if (as<InterfaceDecl>(baseDecl))
    {
        // If an interface isn't explicitly marked `[open]` or `[sealed]`,
        // then the default behavior is to treat it as `[open]`, since
        // interfaces are most often used to define protocols that
        // users of a module can opt into.
    }
    else
    {
        // For any non-interface type, if the declaration didn't specify
        // `[open]` or `[sealed]` then we assume `[sealed]` is the default.
        //
        getSink()->diagnose(
            Diagnostics::CannotInheritFromImplicitlySealedDeclarationInAnotherModule{
                .baseType = baseType,
                .moduleName = moduleWithBaseType->getModuleDecl()->getName(),
                .inheritanceDecl = inheritanceDecl});
        return;
    }
}

void SemanticsDeclBasesVisitor::visitInterfaceDecl(InterfaceDecl* decl)
{
    SLANG_OUTER_SCOPE_CONTEXT_DECL_RAII(this, decl);
    checkVisibility(decl);
    for (auto inheritanceDecl : decl->getMembersOfType<InheritanceDecl>())
    {
        ensureDecl(inheritanceDecl, DeclCheckState::CanUseBaseOfInheritanceDecl);
        auto baseType = inheritanceDecl->base.type;

        // It is possible that there was an error in checking the base type
        // expression, and in such a case we shouldn't emit a cascading error.
        //
        if (const auto baseErrorType = as<ErrorType>(baseType); baseErrorType)
        {
            continue;
        }

        // An `interface` type can only inherit from other `interface` types.
        //
        // TODO: In the long run it might make sense for an interface to support
        // an inheritance clause naming a non-interface type, with the meaning
        // that any type that implements the interface must be a sub-type of the
        // type named in the inheritance clause.
        //
        auto baseDeclRefType = as<DeclRefType>(baseType);
        if (!baseDeclRefType)
        {
            getSink()->diagnose(Diagnostics::BaseOfInterfaceMustBeInterface{
                .decl = decl,
                .baseType = baseType,
                .inheritanceDecl = inheritanceDecl});
            continue;
        }

        auto baseDeclRef = baseDeclRefType->getDeclRef();
        auto baseInterfaceDeclRef = baseDeclRef.as<InterfaceDecl>();
        if (!baseInterfaceDeclRef)
        {
            getSink()->diagnose(Diagnostics::BaseOfInterfaceMustBeInterface{
                .decl = decl,
                .baseType = baseType,
                .inheritanceDecl = inheritanceDecl});
            continue;
        }

        // TODO: At this point we have the `baseInterfaceDeclRef`
        // and could use it to perform further validity checks,
        // and/or to build up a more refined representation of
        // the inheritance graph for this type (e.g., a "class
        // precedence list").
        //
        // E.g., we can/should check that we aren't introducing
        // a circular inheritance relationship.

        _validateCrossModuleInheritance(decl, inheritanceDecl);

        if (baseInterfaceDeclRef.getDecl()->findModifier<ComInterfaceAttribute>())
        {
            if (!decl->findModifier<ComInterfaceAttribute>())
            {
                getSink()->diagnose(
                    Diagnostics::InterfaceInheritingComMustBeCom{.decl = inheritanceDecl});
            }
        }
    }

    if (decl->findModifier<ComInterfaceAttribute>())
    {
        // `associatedtype` declaration is not allowed in a COM interface declaration.
        for (auto associatedType : decl->getMembersOfType<AssocTypeDecl>())
        {
            getSink()->diagnose(
                Diagnostics::AssociatedTypeNotAllowedInComInterface{.decl = associatedType});
        }
    }
}

void SemanticsDeclBasesVisitor::visitCallableDecl(CallableDecl* decl)
{
    // A 'callable' can inherit from interfaces but not structs, etc..
    SLANG_OUTER_SCOPE_CONTEXT_DECL_RAII(this, decl);

    Index inheritanceClauseCounter = 0;
    for (auto inheritanceDecl : decl->getMembersOfType<InheritanceDecl>())
    {
        inheritanceClauseCounter++;
        SLANG_UNUSED(inheritanceClauseCounter);

        ensureDecl(inheritanceDecl, DeclCheckState::CanUseBaseOfInheritanceDecl);
        auto baseType = inheritanceDecl->base.type;

        // It is possible that there was an error in checking the base type
        // expression, and in such a case we shouldn't emit a cascading error.
        //
        if (const auto baseErrorType = as<ErrorType>(baseType); baseErrorType)
        {
            continue;
        }

        auto baseDeclRefType = as<DeclRefType>(baseType);
        if (!baseDeclRefType)
        {
            // TODO: Figure out what diagnostic should go here.
            getSink()->diagnose(
                Diagnostics::InternalCompilerError{.location = inheritanceDecl->loc});
            continue;
        }

        auto baseDeclRef = baseDeclRefType->getDeclRef();
        if (auto baseInterfaceDeclRef = baseDeclRef.as<InterfaceDecl>())
        {
            // Check that the interface has the [__FunctionInterface] attribute,
            // since only interfaces explicitly marked as function interfaces
            // can be used as constraints on functions.
            //
            if (!baseInterfaceDeclRef.getDecl()->findModifier<FunctionInterfaceAttribute>())
            {
                getSink()->diagnose(Diagnostics::InterfaceMissingFunctionInterfaceAttribute{
                    .decl = inheritanceDecl,
                    .location = decl->loc});
            }
        }
        else
        {
            // TODO: Figure out what diagnostic should go here.
            getSink()->diagnose(
                Diagnostics::InternalCompilerError{.location = inheritanceDecl->loc});
            continue;
        }

        // TODO: At this point we have the `baseDeclRef`
        // and could use it to perform further validity checks,
        // and/or to build up a more refined representation of
        // the inheritance graph for this type (e.g., a "class
        // precedence list").
        //
        // E.g., we can/should check that we aren't introducing
        // a circular inheritance relationship.
    }
}

void SemanticsDeclBasesVisitor::visitStructDecl(StructDecl* decl)
{
    // A `struct` type can only inherit from `struct` or `interface` types.
    //
    // Furthermore, only the first inheritance clause (in source
    // order) is allowed to declare a base `struct` type.
    //
    SLANG_OUTER_SCOPE_CONTEXT_DECL_RAII(this, decl);

    Index inheritanceClauseCounter = 0;
    for (auto inheritanceDecl : decl->getMembersOfType<InheritanceDecl>())
    {
        Index inheritanceClauseIndex = inheritanceClauseCounter++;

        ensureDecl(inheritanceDecl, DeclCheckState::CanUseBaseOfInheritanceDecl);
        auto baseType = inheritanceDecl->base.type;

        // It is possible that there was an error in checking the base type
        // expression, and in such a case we shouldn't emit a cascading error.
        //
        if (const auto baseErrorType = as<ErrorType>(baseType); baseErrorType)
        {
            continue;
        }

        auto baseDeclRefType = as<DeclRefType>(baseType);
        if (!baseDeclRefType)
        {
            getSink()->diagnose(Diagnostics::BaseOfStructMustBeInterface{
                .decl = decl,
                .baseType = baseType,
                .inheritanceDecl = inheritanceDecl});
            continue;
        }

        auto baseDeclRef = baseDeclRefType->getDeclRef();
        if (auto baseInterfaceDeclRef = baseDeclRef.as<InterfaceDecl>())
        {
        }
        else if (auto baseStructDeclRef = baseDeclRef.as<StructDecl>())
        {
            if (!isFromCoreModule(decl))
            {
                // In Slang 2026, we no longer allow structs to inherit from other structs.
                if (isSlang2026OrLater(this))
                {
                    getSink()->diagnose(Diagnostics::BaseOfStructMustBeInterface{
                        .decl = decl,
                        .baseType = baseType,
                        .inheritanceDecl = inheritanceDecl});
                }
                else
                {
                    // For legacy language versions, we still allow struct inheritance to avoid
                    // breaking existing code, but we will emit a warning to inform the user
                    // that this feature is unstable and may be removed in the future.
                    getSink()->diagnose(
                        Diagnostics::InheritanceUnstable{.inheritanceDecl = inheritanceDecl});
                }
            }

            // To simplify the task of reading and maintaining code,
            // we require that when a `struct` inherits from another
            // `struct`, the base `struct` is the first item in
            // the list of bases (before any interfaces).
            //
            // This constraint also has the secondary effect of restricting
            // it so that a `struct` cannot multiply inherit from other
            // `struct` types.
            //
            if (inheritanceClauseIndex != 0)
            {
                getSink()->diagnose(
                    Diagnostics::BaseStructMustBeListedFirst{.inheritanceDecl = inheritanceDecl});
            }
        }
        else
        {
            getSink()->diagnose(Diagnostics::BaseOfStructMustBeInterface{
                .decl = decl,
                .baseType = baseType,
                .inheritanceDecl = inheritanceDecl});
            continue;
        }

        // `visitLambdaExpr` synthesizes `LambdaDecl` closure structs and constructs them with
        // captured values. Forcing `IDefaultInitializable` onto those implementation-detail structs
        // makes the closure construction resolve against the zero-argument default constructor.
        if (this->getOptionSet().getBoolOption(CompilerOptionName::ZeroInitialize) &&
            !isFromCoreModule(decl) && !as<LambdaDecl>(decl))
        {
            // Force add IDefaultInitializable to any struct missing (transitively)
            // `IDefaultInitializable`.
            auto* defaultInitializableType = m_astBuilder->getDefaultInitializableType();
            if (!isSubtype(
                    DeclRefType::create(m_astBuilder, decl),
                    defaultInitializableType,
                    IsSubTypeOptions::NoCaching))
            {
                InheritanceDecl* conformanceDecl = m_astBuilder->create<InheritanceDecl>();
                conformanceDecl->loc = decl->loc;
                conformanceDecl->base.type = defaultInitializableType;
                conformanceDecl->nameAndLoc.name = getName("$inheritance");
                decl->addMember(conformanceDecl);
            }
        }

        // TODO: At this point we have the `baseDeclRef`
        // and could use it to perform further validity checks,
        // and/or to build up a more refined representation of
        // the inheritance graph for this type (e.g., a "class
        // precedence list").
        //
        // E.g., we can/should check that we aren't introducing
        // a circular inheritance relationship.

        _validateCrossModuleInheritance(decl, inheritanceDecl);
    }
}

void SemanticsDeclBasesVisitor::visitClassDecl(ClassDecl* decl)
{
    // A `class` type can only inherit from `class` or `interface` types.
    //
    // Furthermore, only the first inheritance clause (in source
    // order) is allowed to declare a base `class` type.
    //
    SLANG_OUTER_SCOPE_CONTEXT_DECL_RAII(this, decl);

    Index inheritanceClauseCounter = 0;
    for (auto inheritanceDecl : decl->getMembersOfType<InheritanceDecl>())
    {
        Index inheritanceClauseIndex = inheritanceClauseCounter++;

        ensureDecl(inheritanceDecl, DeclCheckState::CanUseBaseOfInheritanceDecl);
        auto baseType = inheritanceDecl->base.type;

        // It is possible that there was an error in checking the base type
        // expression, and in such a case we shouldn't emit a cascading error.
        //
        if (const auto baseErrorType = as<ErrorType>(baseType); baseErrorType)
        {
            continue;
        }

        auto baseDeclRefType = as<DeclRefType>(baseType);
        if (!baseDeclRefType)
        {
            getSink()->diagnose(Diagnostics::BaseOfClassMustBeClassOrInterface{
                .decl = decl,
                .baseType = baseType,
                .inheritanceDecl = inheritanceDecl});
            continue;
        }

        auto baseDeclRef = baseDeclRefType->getDeclRef();
        if (auto baseInterfaceDeclRef = baseDeclRef.as<InterfaceDecl>())
        {
        }
        else if (auto baseStructDeclRef = baseDeclRef.as<ClassDecl>())
        {
            // To simplify the task of reading and maintaining code,
            // we require that when a `class` inherits from another
            // `class`, the base `class` is the first item in
            // the list of bases (before any interfaces).
            //
            // This constraint also has the secondary effect of restricting
            // it so that a `struct` cannot multiply inherit from other
            // `struct` types.
            //
            if (inheritanceClauseIndex != 0)
            {
                getSink()->diagnose(
                    Diagnostics::BaseClassMustBeListedFirst{.inheritanceDecl = inheritanceDecl});
            }
        }
        else
        {
            getSink()->diagnose(Diagnostics::BaseOfClassMustBeClassOrInterface{
                .decl = decl,
                .baseType = baseType,
                .inheritanceDecl = inheritanceDecl});
            continue;
        }

        // TODO: At this point we have the `baseDeclRef`
        // and could use it to perform further validity checks,
        // and/or to build up a more refined representation of
        // the inheritance graph for this type (e.g., a "class
        // precedence list").
        //
        // E.g., we can/should check that we aren't introducing
        // a circular inheritance relationship.

        _validateCrossModuleInheritance(decl, inheritanceDecl);
    }
}

bool SemanticsVisitor::isIntegerBaseType(BaseType baseType)
{
    return (BaseTypeInfo::getInfo(baseType).flags & BaseTypeInfo::Flag::Integer) != 0;
}

bool SemanticsVisitor::isScalarIntegerType(Type* type)
{
    auto basicType = as<BasicExpressionType>(unwrapModifiedType(type));
    if (!basicType)
        return false;
    auto baseType = basicType->getBaseType();
    return isIntegerBaseType(baseType) || baseType == BaseType::Bool;
}

Type* SemanticsVisitor::getMatchingIntType(Type* type)
{
    if (isScalarIntegerType(type))
        return type;
    if (auto enumTypeDecl = isDeclRefTypeOf<EnumDecl>(type))
        if (enumTypeDecl.getDecl()->tagType)
            return getMatchingIntType(enumTypeDecl.getDecl()->tagType);
    return m_astBuilder->getIntType();
}

bool SemanticsVisitor::isHalfType(Type* type)
{
    auto basicType = as<BasicExpressionType>(type);
    if (!basicType)
        return false;
    auto baseType = basicType->getBaseType();
    return baseType == BaseType::Half;
}

bool SemanticsVisitor::isValidSpecializationConstantType(Type* type)
{
    return as<BasicExpressionType>(type) || isEnumType(type);
}

bool SemanticsVisitor::isValidCompileTimeConstantType(Type* type)
{
    return isScalarIntegerType(type) || isEnumType(type);
}

bool SemanticsVisitor::isIntValueInRangeOfType(IntegerLiteralValue value, Type* type)
{
    auto basicType = as<BasicExpressionType>(type);
    if (!basicType)
        return false;

    switch (basicType->getBaseType())
    {
    case BaseType::UInt8:
        return (value >= 0 && value <= std::numeric_limits<uint8_t>::max()) || (value == -1);
    case BaseType::UInt16:
        return (value >= 0 && value <= std::numeric_limits<uint16_t>::max()) || (value == -1);
    case BaseType::UInt:
        return (value >= 0 && value <= std::numeric_limits<uint32_t>::max()) || (value == -1);
    case BaseType::UInt64:
        // IntPtr & UIntPtr are assumed to be 64-bit, because we don't want
        // spurious warnings from assuming a smaller size than what's possible
        // at this point during compilation.
    case BaseType::UIntPtr:
        return true;
    case BaseType::Int8:
        return value >= std::numeric_limits<int8_t>::min() &&
               value <= std::numeric_limits<int8_t>::max();
    case BaseType::Int16:
        return value >= std::numeric_limits<int16_t>::min() &&
               value <= std::numeric_limits<int16_t>::max();
    case BaseType::Int:
        return value >= std::numeric_limits<int32_t>::min() &&
               value <= std::numeric_limits<int32_t>::max();
    case BaseType::Int64:
    case BaseType::IntPtr:
        return value >= std::numeric_limits<int64_t>::min() &&
               value <= std::numeric_limits<int64_t>::max();

    case BaseType::Half:
        return value >= -2048 && value <= 2048;
    default:
        return false;
    }
}

void SemanticsVisitor::validateEnumTagType(Type* type, SourceLoc const& loc)
{
    // Allow the built-in integer types.
    //
    if (isScalarIntegerType(type))
        return;

    // By default, don't allow other types to be used
    // as an `enum` tag type.
    //
    getSink()->diagnose(Diagnostics::InvalidEnumTagType{.type = type, .location = loc});
}

bool SemanticsVisitor::_hasExplicitConstructor(StructDecl* structDecl, bool checkBaseType)
{
    if (!structDecl)
        return false;

    auto _hasExplicitCtor = [](AggTypeDecl* aggDecl) -> bool
    {
        // First check if the extension of this struct defines an explicit constructor.
        for (auto ctor : aggDecl->getMembersOfType<ConstructorDecl>())
        {
            // constructor that is not synthesized must be user defined.
            if (ctor->findModifier<SynthesizedModifier>() == nullptr)
            {
                return true;
            }
        }
        return false;
    };

    if (_hasExplicitCtor(structDecl))
        return true;

    if (!checkBaseType)
        return false;

    for (auto inheritanceMember : structDecl->getMembersOfType<InheritanceDecl>())
    {
        auto baseTypeDecl = isDeclRefTypeOf<AggTypeDecl>(inheritanceMember->base.type);
        if (baseTypeDecl && !as<InterfaceDecl>(baseTypeDecl))
        {
            if (_hasExplicitCtor(baseTypeDecl.getDecl()))
                return true;
        }
    }
    return false;
}

void SemanticsDeclBasesVisitor::visitEnumDecl(EnumDecl* decl)
{
    SLANG_OUTER_SCOPE_CONTEXT_DECL_RAII(this, decl);
    checkVisibility(decl);

    // An `enum` type can inherit from interfaces, and also
    // from a single "tag" type that must:
    //
    // * be a built-in integer type
    // * come first in the list of base types
    //
    Index inheritanceClauseCounter = 0;
    Type* tagType = nullptr;
    InheritanceDecl* tagTypeInheritanceDecl = nullptr;
    bool hasBaseError = false;
    for (auto inheritanceDecl : decl->getMembersOfType<InheritanceDecl>())
    {
        Index inheritanceClauseIndex = inheritanceClauseCounter++;

        ensureDecl(inheritanceDecl, DeclCheckState::CanUseBaseOfInheritanceDecl);
        auto baseType = inheritanceDecl->base.type;

        // It is possible that there was an error in checking the base type
        // expression, and in such a case we shouldn't emit a cascading error.
        //
        if (const auto baseErrorType = as<ErrorType>(baseType); baseErrorType)
        {
            continue;
        }

        auto baseDeclRefType = as<DeclRefType>(baseType);
        if (!baseDeclRefType)
        {
            getSink()->diagnose(Diagnostics::BaseOfEnumMustBeIntegerOrInterface{
                .decl = decl,
                .baseType = baseType,
                .inheritanceDecl = inheritanceDecl});
            hasBaseError = true;
            continue;
        }

        auto baseDeclRef = baseDeclRefType->getDeclRef();
        if (auto baseInterfaceDeclRef = baseDeclRef.as<InterfaceDecl>())
        {
            _validateCrossModuleInheritance(decl, inheritanceDecl);
        }
        else if (auto baseStructDeclRef = baseDeclRef.as<StructDecl>())
        {
            // To simplify the task of reading and maintaining code,
            // we require that when an `enum` declares an explicit
            // underlying tag type using an inheritance clause, that
            // type must be the first item in the list of bases.
            //
            // This constraint also has the secondary effect of restricting
            // it so that an `enum` can't possibly have multiple tag
            // types declared.
            //
            if (inheritanceClauseIndex != 0)
            {
                getSink()->diagnose(
                    Diagnostics::TagTypeMustBeListedFirst{.inheritanceDecl = inheritanceDecl});
            }
            else
            {
                tagType = baseType;
                tagTypeInheritanceDecl = inheritanceDecl;
            }

            // Note: we do *not* apply the code that validates
            // cross-module inheritance to a base that represnts
            // a tag type, because declaring a tag type for an
            // `enum` doesn't actually make it into a subtype
            // of the tag type, and thus doesn't violate the
            // rules when the tag type is `sealed`.
        }
        else
        {
            getSink()->diagnose(Diagnostics::BaseOfEnumMustBeIntegerOrInterface{
                .decl = decl,
                .baseType = baseType,
                .inheritanceDecl = inheritanceDecl});
            hasBaseError = true;
            continue;
        }
    }

    if (hasBaseError)
    {
        decl->tagType = m_astBuilder->getErrorType();
        return;
    }

    // If a tag type has not been set, then we
    // default it to the built-in `int` type.
    //
    // TODO: In the far-flung future we may want to distinguish
    // `enum` types that have a "raw representation" like this from
    // ones that are purely abstract and don't expose their
    // type of their tag.
    //
    if (!tagType)
    {
        tagType = m_astBuilder->getIntType();
    }
    else
    {
        // TODO: Need to establish that the tag
        // type is suitable. (e.g., if we are going
        // to allow raw values for case tags to be
        // derived automatically, then the tag
        // type needs to be some kind of integer type...)
        //
        // For now we will just be harsh and require it
        // to be one of a few builtin types.
        validateEnumTagType(tagType, tagTypeInheritanceDecl->loc);

        // Note: The `InheritanceDecl` that introduces a tag
        // type isn't actually representing a super-type of
        // the `enum`, and things like name lookup need to
        // know to ignore that "inheritance" relationship.
        //
        // We add a modifier to the `InheritanceDecl` to ensure
        // that it can be detected and ignored by such steps.
        //
        addModifier(tagTypeInheritanceDecl, m_astBuilder->create<IgnoreForLookupModifier>());
    }
    decl->tagType = tagType;


    // An `enum` type should automatically conform to the `__EnumType` interface.
    // The compiler needs to insert this conformance behind the scenes, and this
    // seems like the best place to do it.
    {
        // First, look up the type of the `__EnumType` interface.
        Type* enumTypeType = getASTBuilder()->getEnumTypeType();

        InheritanceDecl* enumConformanceDecl = m_astBuilder->create<InheritanceDecl>();
        enumConformanceDecl->loc = decl->loc;
        enumConformanceDecl->base.type = getASTBuilder()->getEnumTypeType();
        decl->addMember(enumConformanceDecl);

        // The `__EnumType` interface has one required member, the `__Tag` type.
        // We need to satisfy this requirement automatically, rather than require
        // the user to actually declare a member with this name (otherwise we wouldn't
        // let them define a tag value with the name `__Tag`).
        //
        RefPtr<WitnessTable> witnessTable = new WitnessTable();
        witnessTable->baseType = enumConformanceDecl->base.type;
        witnessTable->witnessedType = enumTypeType;
        enumConformanceDecl->witnessTable = witnessTable;

        Name* tagAssociatedTypeName = getSession()->getNameObj("__Tag");
        Decl* tagAssociatedTypeDecl = nullptr;
        if (auto enumTypeTypeDeclRefType = dynamicCast<DeclRefType>(enumTypeType))
        {
            if (auto enumTypeTypeInterfaceDecl =
                    as<InterfaceDecl>(enumTypeTypeDeclRefType->getDeclRef().getDecl()))
            {
                if (auto foundMemberDecl =
                        enumTypeTypeInterfaceDecl->findLastDirectMemberDeclOfName(
                            tagAssociatedTypeName))
                {
                    tagAssociatedTypeDecl = foundMemberDecl;
                }
            }
        }
        if (!tagAssociatedTypeDecl)
        {
            SLANG_DIAGNOSE_UNEXPECTED(
                getSink(),
                decl,
                "failed to find built-in declaration '__Tag'");
        }

        // Okay, add the conformance witness for `__Tag` being satisfied by `tagType`
        witnessTable->add(tagAssociatedTypeDecl, RequirementWitness(tagType));

        // `__EnumType` constrains its `__Tag` associated type with
        // `__Tag : __BuiltinIntegerType`. In the unified representation that bound is a
        // constraint requirement of the `__EnumType` interface (a sibling of `__Tag`),
        // so this compiler-synthesized conformance must supply its witness too --
        // otherwise the conformance check would re-derive it and reject permitted tag
        // types. For an integer tag type the witness is the real subtype witness; for
        // `bool` -- a permitted tag type that does not conform to `__BuiltinIntegerType`
        // -- no such witness exists, so we record a `NoneWitness` to mark the
        // (compiler-trusted) constraint as satisfied. (This addresses a long-standing
        // TODO that became load-bearing once the bound is modeled as a requirement.)
        if (auto enumInterfaceDecl = as<InterfaceDecl>(tagAssociatedTypeDecl->parentDecl))
        {
            for (auto constraintDecl :
                 enumInterfaceDecl->getDirectMemberDeclsOfType<GenericTypeConstraintDecl>())
            {
                auto subDeclRefType = as<DeclRefType>(constraintDecl->sub.type);
                if (!subDeclRefType ||
                    subDeclRefType->getDeclRef().getDecl() != tagAssociatedTypeDecl)
                    continue;

                Val* constraintWitness = tryGetSubtypeWitness(tagType, constraintDecl->sup.type);
                if (!constraintWitness)
                    constraintWitness = m_astBuilder->getOrCreate<NoneWitness>();
                witnessTable->add(constraintDecl, RequirementWitness(constraintWitness));
            }
        }

        // TODO: eventually we should consider synthesizing other requirements for
        // the min/max tag values, or the total number of tags, so that people don't
        // have to declare these as additional cases.

        enumConformanceDecl->setCheckState(DeclCheckState::DefinitionChecked);
    }
}

// Increments an enumerator value and returns true if there was a wrap-around
static bool _incrementEnumerator(IntegerLiteralValue& value, BaseType baseType, bool isFlags)
{
    const BaseTypeInfo& info = BaseTypeInfo::getInfo(baseType);

    // calculate the mask of significant bits for the type
    uint64_t mask;
    unsigned significantBits;

    if (baseType == BaseType::Bool)
    {
        significantBits = 1U;
    }
    else
    {
        // generic numeric types
        significantBits = (8U * info.sizeInBytes);
    }

    mask = std::numeric_limits<uint64_t>::max();
    mask >>= 64U - significantBits;

    if (isFlags)
    {
        // zero increments to 1, never overflows
        if (value == 0)
        {
            value = 1;
            return false;
        }

        // now shift left and detect overflow (note: correctness requires C++20)
        value = (value << 1) & mask;
        if (value == 0)
        {
            value = 1;
            return true;
        }

        return false;
    }
    else
    {
        // detect overflow
        if (info.flags & BaseTypeInfo::Flag::Signed)
        {
            unsigned excessBits = 64U - significantBits;
            int64_t currentValue = value;

            // do sign extension (note: correctness requires C++20)
            currentValue <<= excessBits;
            currentValue >>= excessBits;

            // increment and do sign extension (note: correctness requires C++20)
            int64_t nextValue = static_cast<uint64_t>(currentValue) + 1;
            nextValue <<= excessBits;
            nextValue >>= excessBits;

            value = nextValue;
            return currentValue > nextValue;
        }
        else
        {
            const uint64_t currentValue = static_cast<uint64_t>(value) & mask;
            const uint64_t nextValue = (currentValue + 1U) & mask;

            value = nextValue;
            return currentValue > nextValue;
        }
    }
}

void SemanticsDeclBodyVisitor::visitEnumDecl(EnumDecl* decl)
{
    SLANG_OUTER_SCOPE_CONTEXT_DECL_RAII(this, decl);

    auto enumType = DeclRefType::create(m_astBuilder, makeDeclRef(decl));

    auto tagType = decl->tagType;

    if (as<ErrorType>(tagType))
        return;

    auto isEnumFlags = decl->hasModifier<FlagsAttribute>();

    // Resolve the underlying integer kind
    BaseType tagBaseType;
    if (auto basicTagType = as<BasicExpressionType>(unwrapModifiedType(tagType)))
        tagBaseType = basicTagType->getBaseType();
    else
    {
        getSink()->diagnose(Diagnostics::Unexpected{
            .message = "Unexpected enumeration tag type",
            .location = decl->getNameLoc()});
        return;
    }

    // Check the enum cases in order.
    for (auto caseDecl : decl->getMembersOfType<EnumCaseDecl>())
    {
        // Each case defines a value of the enum's type.
        //
        // TODO: If we ever support enum cases with payloads,
        // then they would probably have a type that is a
        // `FunctionType` from the payload types to the
        // enum type.
        //
        // TODO(tfoley): the case should grab its type  when
        // doing its own header checking, rather than rely on this...
        caseDecl->type.type = enumType;

        ensureDecl(caseDecl, DeclCheckState::DefinitionChecked);
    }

    // For any enum case that didn't provide an explicit
    // tag value, derived an appropriate tag value.
    IntegerLiteralValue defaultTag = isEnumFlags ? 1 : 0;
    bool defaultTagWrappedAround = false;
    for (auto caseDecl : decl->getMembersOfType<EnumCaseDecl>())
    {
        if (auto explicitTagValExpr = caseDecl->tagExpr)
        {
            // This tag has an initializer, so it should establish
            // the tag value for a successor case that doesn't
            // provide an explicit tag.

            IntVal* explicitTagVal =
                tryConstantFoldExpr(explicitTagValExpr, ConstantFoldingKind::CompileTime, nullptr);
            if (explicitTagVal)
            {
                caseDecl->tagVal = explicitTagVal;
                if (auto constIntVal = as<ConstantIntVal>(explicitTagVal))
                {
                    defaultTag = constIntVal->getValue();
                }
                else
                {
                    // TODO: need to handle other possibilities here
                    getSink()->diagnose(
                        Diagnostics::UnexpectedEnumTagExpr{.expr = explicitTagValExpr});
                }
            }
            else
            {
                // If this happens, then the explicit tag value expression
                // doesn't seem to be a constant after all.
                getSink()->diagnose(Diagnostics::ExpectedIntegerConstantNotConstant{
                    .location = explicitTagValExpr->loc});
            }
        }
        else
        {
            // This tag has no initializer, so it should use
            // the default tag value we are tracking. If the implicit
            // counter wrapped around past the underlying tag type's
            // range on the previous step, this is the case that ends
            // up consuming the wrapped value, so warn here.
            if (defaultTagWrappedAround)
            {
                getSink()->diagnose(Diagnostics::EnumCaseImplicitTagValueOverflow{
                    .tagType = tagType,
                    .decl = caseDecl});
            }

            IntegerLiteralExpr* tagValExpr = m_astBuilder->create<IntegerLiteralExpr>();
            tagValExpr->loc = caseDecl->loc;
            tagValExpr->type = QualType(tagType);
            tagValExpr->value = defaultTag;
            caseDecl->tagExpr = tagValExpr;
            caseDecl->tagVal = m_astBuilder->getIntVal(enumType, defaultTag);
        }

        // compute the next default tag value with the info whether it overflowed
        defaultTagWrappedAround = _incrementEnumerator(defaultTag, tagBaseType, isEnumFlags);
    }
}

void SemanticsDeclBodyVisitor::visitEnumCaseDecl(EnumCaseDecl* decl)
{
    // An enum case had better appear inside an enum!
    //
    // TODO: Do we need/want to support generic cases some day?
    auto parentEnumDecl = as<EnumDecl>(decl->parentDecl);
    SLANG_ASSERT(parentEnumDecl);

    ensureDecl(parentEnumDecl, DeclCheckState::ReadyForLookup);

    decl->type.type = DeclRefType::create(m_astBuilder, makeDeclRef(parentEnumDecl));

    // The tag type should have already been set by
    // the surrounding `enum` declaration.
    auto tagType = parentEnumDecl->tagType;
    SLANG_ASSERT(tagType);

    if (as<ErrorType>(tagType))
        return;

    // Need to check the init expression, if present, since
    // that represents the explicit tag for this case.
    if (auto initExpr = decl->tagExpr)
    {
        initExpr = CheckTerm(initExpr);

        if (initExpr->type != decl->type.type)
            initExpr = coerce(CoercionSite::General, tagType, initExpr, getSink());

        decl->tagExpr = initExpr;
    }
}

void SemanticsVisitor::ensureDeclBase(
    DeclBase* declBase,
    DeclCheckState state,
    SemanticsContext* baseContext)
{
    if (auto decl = as<Decl>(declBase))
    {
        ensureDecl(decl, state, baseContext);
    }
    else if (auto declGroup = as<DeclGroup>(declBase))
    {
        for (auto dd : declGroup->decls)
        {
            ensureDecl(dd, state, baseContext);
        }
    }
    else
    {
        SLANG_UNEXPECTED("unknown case for declaration");
    }
}

void SemanticsDeclHeaderVisitor::visitTypeDefDecl(TypeDefDecl* decl)
{
    SemanticsVisitor visitor(withDeclToExcludeFromLookup(decl));
    decl->type = visitor.CheckProperType(decl->type);
    checkVisibility(decl);
    propagateOptionalConstraintsThroughTypealias(decl);
}

void SemanticsDeclHeaderVisitor::propagateOptionalConstraintsThroughTypealias(TypeDefDecl* decl)
{
    // If this is a generic typealias (e.g., `typealias Baz<T> = Foo<T>`), the body
    // type may have optional-constraint args resolved to NoneWitness because the
    // alias's type params are unconstrained at this point.
    //
    // Propagate such optional constraints to this generic's own param list so that
    // instantiation with a concrete type (e.g., `Baz<float>`) can satisfy them.
    // Also replace the NoneWitness entries in the body type's DeclRef with
    // DeclaredSubtypeWitnesses referencing the newly added constraints, so that
    // the IR generic for Baz correctly threads the witness through to Foo.
    //
    auto parentGenericDecl = as<GenericDecl>(decl->parentDecl);
    if (!parentGenericDecl)
        return;

    auto bodyDeclRefType = as<DeclRefType>(decl->type.type);
    if (!bodyDeclRefType)
        return;

    auto genericAppDeclRef = SubstitutionSet(bodyDeclRefType->getDeclRef()).findGenericAppDeclRef();
    if (!genericAppDeclRef)
        return;

    // Use getGenericParams to enumerate the body generic's params and constraints in
    // the same order used by DeclaredSubtypeWitness::_substituteImplOverride so that
    // constraint-slot indices map directly to arg-vector positions.
    auto bodyGenericDecl = genericAppDeclRef->getGenericDecl();
    List<Decl*> bodyParams;
    List<Decl*> bodyConstraints;
    getGenericParams(bodyGenericDecl, bodyParams, bodyConstraints);

    Index ordinaryParamCount = bodyParams.getCount();

    // Build a replacement args list, substituting NoneWitness entries with
    // DeclaredSubtypeWitnesses backed by new optional constraints on parentGenericDecl.
    List<Val*> newArgs;
    for (Index i = 0; i < genericAppDeclRef->getArgCount(); i++)
        newArgs.add(genericAppDeclRef->getArg(i));

    bool modified = false;
    auto bodyGenericDeclRef = DeclRef<GenericDecl>(genericAppDeclRef->getGenericDeclRef());

    for (Index constraintIdx = 0; constraintIdx < bodyConstraints.getCount(); constraintIdx++)
    {
        // Only GenericTypeConstraintDecl with an optional modifier needs the NoneWitness
        // replacement; other constraint types (TypeCoercionConstraintDecl, pack-count, etc.)
        // are left as-is.  NoneWitness is only ever produced for GenericTypeConstraintDecl
        // optional slots (see slang-check-overload.cpp TryCheckOverloadCandidateConstraints).
        auto constraintDecl = as<GenericTypeConstraintDecl>(bodyConstraints[constraintIdx]);
        if (!constraintDecl || !constraintDecl->hasModifier<OptionalConstraintModifier>())
            continue;

        Index argIdx = ordinaryParamCount + constraintIdx;
        if (argIdx >= newArgs.getCount() || !as<NoneWitness>(newArgs[argIdx]))
            continue;

        // Compute the substituted sub/sup types for this constraint by applying
        // the body type's generic substitution to the constraint's declaration.
        auto substConstraintDeclRef = m_astBuilder
                                          ->getGenericAppDeclRef(
                                              bodyGenericDeclRef,
                                              genericAppDeclRef->getArgs(),
                                              constraintDecl)
                                          .as<GenericTypeConstraintDecl>();
        auto subType = getSub(m_astBuilder, substConstraintDeclRef);
        auto supType = getSup(m_astBuilder, substConstraintDeclRef);

        // getSub/getSup must always succeed on a fully-checked optional constraint.
        SLANG_RELEASE_ASSERT(subType && supType);

        // Only propagate when the substituted sub type is a bare type variable that belongs
        // directly to the alias's own generic.  If it is a concrete type (e.g. `int` in
        // `typealias Half<T> = Pair<T, int>`) or a compound type (e.g. `Bar<T>` in
        // `typealias Baz<T> = Foo<Bar<T>>`), the constraint cannot be satisfied through
        // the alias's type params and the NoneWitness is the correct permanent result.
        auto subTypeDeclRefType = as<DeclRefType>(subType);
        if (!subTypeDeclRefType ||
            subTypeDeclRefType->getDeclRef().getDecl()->parentDecl != parentGenericDecl)
            continue;

        // Add an equivalent optional constraint to the alias's own generic
        // so that `Baz<float>` can resolve it against float's conformances.
        auto synConstraintDecl = m_astBuilder->create<GenericTypeConstraintDecl>();
        synConstraintDecl->nameAndLoc = constraintDecl->getNameAndLoc();
        synConstraintDecl->loc = constraintDecl->loc;
        synConstraintDecl->parentDecl = parentGenericDecl;
        synConstraintDecl->isEqualityConstraint = constraintDecl->isEqualityConstraint;
        synConstraintDecl->sub = TypeExp(subType);
        synConstraintDecl->sup = TypeExp(supType);
        addModifier(synConstraintDecl, m_astBuilder->create<OptionalConstraintModifier>());
        parentGenericDecl->addDirectMemberDecl(synConstraintDecl);

        // Pre-check the constraint now, while sub.type/sup.type are known-good.
        // Without this, getDefaultSubstitutionArgs would drive it through
        // visitGenericTypeConstraintDecl in an uncontrolled context, which could
        // trigger AndType flattening on the sup type.
        ensureDecl(synConstraintDecl, DeclCheckState::SignatureChecked);

        // Invalidate cached default substitution args since we just added a member.
        m_astBuilder->m_cachedGenericDefaultArgs.remove(parentGenericDecl);
        parentGenericDecl->_cachedArgsForDefaultSubstitution.clear();

        // Replace the NoneWitness with a DeclaredSubtypeWitness that references
        // the new constraint.  DeclaredSubtypeWitness::_substituteImplOverride
        // will exchange this for the real witness when Baz is specialized.
        auto newWitness = m_astBuilder->getDeclaredSubtypeWitness(
            subType,
            supType,
            m_astBuilder->getDirectDeclRef(synConstraintDecl));
        newArgs[argIdx] = newWitness;
        modified = true;
    }

    if (modified)
    {
        // Rebuild the body type with the updated constraint witness args.
        auto newGenericAppDeclRef = m_astBuilder->getGenericAppDeclRef(
            bodyGenericDeclRef,
            makeConstArrayView(newArgs.getBuffer(), newArgs.getCount()));
        decl->type.type = DeclRefType::create(m_astBuilder, newGenericAppDeclRef);
    }
}

void SemanticsDeclHeaderVisitor::visitGlobalGenericParamDecl(GlobalGenericParamDecl* decl)
{
    // global generic param only allowed in global scope
    auto program = as<ModuleDecl>(decl->parentDecl);
    if (!program)
        getSink()->diagnose(Diagnostics::GlobalGenParamInGlobalScopeOnly{.decl = decl});
}

void SemanticsDeclHeaderVisitor::visitAssocTypeDecl(AssocTypeDecl* decl)
{
    // validateDeclNesting enforces that associatedtype only appears inside
    // an interface; assert to catch regressions if that check is ever bypassed.
    SLANG_ASSERT(as<InterfaceDecl>(decl->parentDecl) || getSink()->getErrorCount() > 0);
    checkVisibility(decl);
}

SemanticsContext SemanticsDeclBodyVisitor::registerDifferentiableTypesForFunc(
    FunctionDeclBase* decl)
{
    auto newContext = withParentFunc(decl);
    if (newContext.getParentDifferentiableAttribute())
    {
        // Register additional types outside the function body first.
        auto oldAttr = m_parentDifferentiableAttr;
        m_parentDifferentiableAttr = newContext.getParentDifferentiableAttribute();
        for (auto paramDeclRef :
             getParametersForCallableSignature(m_astBuilder, makeDeclRef(decl).as<CallableDecl>()))
        {
            auto param = paramDeclRef.getDecl();
            maybeRegisterDifferentiableType(
                m_astBuilder,
                param->type.type,
                getDiagnosticPos(param->type));
        }
        maybeRegisterDifferentiableType(
            m_astBuilder,
            decl->returnType.type,
            getDiagnosticPos(decl->returnType));
        if (as<ConstructorDecl>(decl))
        {
            auto parentDecl = getParentDecl(decl);
            auto parentDeclRef =
                createDefaultSubstitutionsIfNeeded(m_astBuilder, this, makeDeclRef(parentDecl));
            auto thisType = calcThisType(parentDeclRef);
            maybeRegisterDifferentiableType(m_astBuilder, thisType, parentDeclRef.getLoc());
        }
        else
        {
            auto declRef =
                createDefaultSubstitutionsIfNeeded(m_astBuilder, this, decl->getDefaultDeclRef())
                    .as<FunctionDeclBase>();
            if (auto thisParamInfo = findEffectiveThisParamInfo(declRef))
            {
                maybeRegisterDifferentiableType(
                    m_astBuilder,
                    thisParamInfo->type,
                    declRef.getLoc());
            }
        }
        m_parentDifferentiableAttr = oldAttr;
    }
    else
    {
        // If we're not in a differentiable context, ignore any no_diff
        // modifiers (or anything related to auto-diff, really..)
        //
        newContext = newContext.allowDroppingDerivatives();
    }

    return newContext;
}

void SemanticsDeclBodyVisitor::visitFunctionDeclBase(FunctionDeclBase* decl)
{
    auto newContext = registerDifferentiableTypesForFunc(decl);

    // TODO: Move to a different function.
    if (newContext.getParentDifferentiableAttribute())
    {
        if (auto pyBindAttr = decl->findModifier<AutoPyBindCudaAttribute>())
        {
            // TODO: Use helpers.. too much replication

            // Register fn.fwd_diff
            {
                auto lookupResult = lookUpMember(
                    getCurrentASTBuilder(),
                    this,
                    getName("fwd_diff"),
                    DeclRefType::create(getCurrentASTBuilder(), decl->getDefaultDeclRef()),
                    getOuterScope(),
                    LookupMask::Default);
                lookupResult = resolveOverloadedLookup(lookupResult);

                if (!lookupResult.isOverloaded() && lookupResult.isValid())
                {
                    pyBindAttr->fwdDiffFuncDeclRef = as<DeclRefExpr>(ConstructLookupResultExpr(
                        lookupResult.item,
                        nullptr,
                        getName("fwd_diff"),
                        pyBindAttr->loc,
                        nullptr));
                }
            }

            // Register fn.bwd_diff
            {
                auto lookupResult = lookUpMember(
                    getCurrentASTBuilder(),
                    this,
                    getName("bwd_diff"),
                    DeclRefType::create(getCurrentASTBuilder(), decl->getDefaultDeclRef()),
                    getOuterScope(),
                    LookupMask::Default);
                lookupResult = resolveOverloadedLookup(lookupResult);

                if (!lookupResult.isOverloaded() && lookupResult.isValid())
                {
                    pyBindAttr->bwdDiffFuncDeclRef = as<DeclRefExpr>(ConstructLookupResultExpr(
                        lookupResult.item,
                        nullptr,
                        getName("bwd_diff"),
                        pyBindAttr->loc,
                        nullptr));
                }
            }
        }
    }

    decl->body = maybeParseStmt(decl->body, newContext);
    if (const auto body = decl->body)
    {
        auto parentDecl = decl->parentDecl;
        bool isSynthesizedMethod =
            decl->findModifier<SynthesizedModifier>() && as<AggTypeDeclBase>(parentDecl);
        auto errorCountBefore = isSynthesizedMethod ? getSink()->getErrorCount() : 0;

        checkStmt(body, newContext);

        if (isSynthesizedMethod && getSink()->getErrorCount() > errorCountBefore)
        {
            getSink()->diagnose(Diagnostics::NoteSynthesizingMethod{
                .methodName = decl->getName(),
                .typeName = parentDecl->getName(),
                .location = parentDecl->loc});
        }
    }
}

void SemanticsVisitor::getGenericParams(
    GenericDecl* decl,
    List<Decl*>& outParams,
    List<Decl*>& outConstraints)
{
    for (auto dd : decl->getDirectMemberDecls())
    {
        if (dd == decl->inner)
            continue;

        if (auto typeParamDecl = as<GenericTypeParamDeclBase>(dd))
            outParams.add(typeParamDecl);
        else if (auto valueParamDecl = as<GenericValueParamDecl>(dd))
            outParams.add(valueParamDecl);
        else if (auto valuePackParamDecl = as<GenericValuePackParamDecl>(dd))
            outParams.add(valuePackParamDecl);
        else if (isConstraintDecl(dd))
            outConstraints.add(dd);
    }
}

bool SemanticsVisitor::doGenericSignaturesMatch(
    GenericDecl* left,
    GenericDecl* right,
    DeclRef<Decl>* outSpecializedRightInner)
{
    // Our first goal here is to determine if `left` and
    // `right` have equivalent lists of explicit
    // generic parameters.
    //
    // Once we have determined that the explicit generic
    // parameters match, we will look at the constraints
    // placed on those parameters to see if they are
    // equivalent.
    //
    // We thus start by extracting the explicit parameters
    // and the constraints from each declaration.
    //
    List<Decl*> leftParams;
    List<Decl*> leftConstraints;
    getGenericParams(left, leftParams, leftConstraints);

    List<Decl*> rightParams;
    List<Decl*> rightConstraints;
    getGenericParams(right, rightParams, rightConstraints);

    // For there to be any hope of a match, the two decls
    // need to have the same number of explicit parameters.
    //
    Index paramCount = leftParams.getCount();
    if (paramCount != rightParams.getCount())
        return false;

    // Next we will walk through the parameters and look
    // for a pair-wise match.
    //
    for (Index pp = 0; pp < paramCount; ++pp)
    {
        Decl* leftParam = leftParams[pp];
        Decl* rightParam = rightParams[pp];

        if (const auto leftTypeParam = as<GenericTypeParamDeclBase>(leftParam))
        {
            if (const auto rightTypeParam = as<GenericTypeParamDeclBase>(rightParam))
            {
                if ((as<GenericTypePackParamDecl>(leftTypeParam) != nullptr) !=
                    (as<GenericTypePackParamDecl>(rightTypeParam) != nullptr))
                {
                    return false;
                }

                // Right now any two type parameters are a match.
                // Names are irrelevant to matching, and any constraints
                // on the type parameters are represented as implicit
                // extra parameters of the generic.
                //
                // TODO: If we ever supported type parameters with
                // higher kinds we might need to make a check here
                // that the kind of each parameter matches (which
                // would in a sense be a kind of recursive check
                // of the generic signature of the parameter).
                //
                continue;
            }
        }
        else if (auto leftValueParam = as<GenericValueParamDecl>(leftParam))
        {
            if (auto rightValueParam = as<GenericValueParamDecl>(rightParam))
            {
                if (!leftValueParam->getType()->equals(rightValueParam->getType()))
                    return false;
                continue;
            }
        }
        else if (auto leftValuePackParam = as<GenericValuePackParamDecl>(leftParam))
        {
            if (auto rightValuePackParam = as<GenericValuePackParamDecl>(rightParam))
            {
                if (!leftValuePackParam->getType()->equals(rightValuePackParam->getType()))
                    return false;
                continue;
            }
        }

        // If we get to this point, then we have two parameters that
        // were of different syntatic categories (e.g., one type parameter
        // and one value parameter), so the signatures clearly don't match.
        //
        return false;
    }

    // At this point we know that the explicit generic parameters
    // of `left` and `right` are aligned, but we need to check
    // that the constraints that each declaration places on
    // its parameters match.
    //
    // A first challenge that arises is that `left` and `right`
    // will each express the constraints in terms of their
    // own parameters. For example, consider the following
    // declarations:
    //
    //      void foo1<T : IFoo>(T value);
    //      void foo2<U : IFoo>(U value);
    //
    // It is "obvious" to a human that the signatures here
    // match, but `foo1` has a constraint `T : IFoo` while
    // `foo2` has a constraint `U : IFoo`, and since `T`
    // and `U` are distinct `Decl`s, those constraints
    // are not obviously equivalent.
    //
    // We will work around this first issue by creating
    // a substitution taht lists all the parameters of
    // `left`, which we can use to specialize `right`
    // so that it aligns.
    //
    // In terms of the example above, this is like constructing
    // `foo2<T>` so that its constraint, after specialization,
    // looks like `T : IFoo`.
    //
    auto& substInnerRightToLeft = *outSpecializedRightInner;
    List<Val*> leftArgs = getDefaultSubstitutionArgs(m_astBuilder, this, left);
    substInnerRightToLeft =
        m_astBuilder->getGenericAppDeclRef(makeDeclRef(right), leftArgs.getArrayView());

    auto getNonEmptyConstraintTargetDecl = [&](NonEmptyPackConstraintDecl* constraintDecl) -> Decl*
    {
        if (auto declRefExpr = as<DeclRefExpr>(constraintDecl->packExpr))
            return getDeclRef(m_astBuilder, declRefExpr).getDecl();
        return nullptr;
    };

    // We should now be able to enumerate the constraints
    // on `right` in a way that uses the same type parameters
    // as `left`, using `rightDeclRef`.
    //
    // At this point a second problem arises: if/when we support
    // more flexibility in how generic parameter constraints are
    // specified, it will be possible for two declarations to
    // list the "same" constraints in very different ways.
    //
    // For example, if we support a `where` clause for separating
    // the constraints from the parameters, then the following
    // two declarations should have equivalent signatures:
    //
    //      void foo1<T>(T value)
    //          where T : IFoo
    //      { ... }
    //
    //      void foo2<T : IFoo>(T value)
    //      { ... }
    //
    // Similarly, if we allow for general compositions of interfaces
    // to be used as constraints, then there can be more than one
    // way to specify the same constraints:
    //
    //      void foo1<T : IFoo&IBar>(T value);
    //      void foo2<T : IBar&IFoo>(T value);
    //
    // Adding support for equality constraints in `where` clauses
    // also creates opportunities for multiple equivalent expressions:
    //
    //      void foo1<T,U>(...) where T.A == U.A;
    //      void foo2<T,U>(...) where U.A == T.A;
    //
    // A robsut version of the checking logic here should attempt
    // to *canonicalize* all of the constraints. Canonicalization
    // should involve putting constraints into a deterministic
    // order (e.g., for a generic with `<T,U>` all the constraints
    // on `T` should come before those on `U`), rewriting individual
    // constraints into a canonical form (e.g., `T : IFoo & IBar`
    // should turn into two constraints: `T : IFoo` and `T : IBar`),
    // etc.
    //
    // Once the constraints are in a canonical form we should be able
    // to test them for pairwise equivalent. As a safety measure we
    // could also try to test whether one set of constraints implies
    // the other (since implication in both directions should imply
    // equivalence, in which case our canonicalization had better
    // have produced the same result).
    //
    // For now we are taking a simpler short-cut by assuming
    // that constraints are already in a canonical form, which
    // is reasonable for now as the syntax only allows a single
    // constraint per parameter, specified on the parameter itself.
    //
    // Under the assumption of canonical constraints, we can
    // assume that different numbers of constraints must indicate
    // a signature mismatch.
    //
    Index constraintCount = leftConstraints.getCount();
    if (constraintCount != rightConstraints.getCount())
        return false;

    for (Index cc = 0; cc < constraintCount; ++cc)
    {
        // Note that we use a plain `Decl` pointer for the left
        // constraint, but need to use a `DeclRef` for the right
        // constraint so that we can take the substitution
        // arguments into account.
        //
        if (auto leftTypeConstraint = as<GenericTypeConstraintDecl>(leftConstraints[cc]))
        {
            auto unspecializedRightConstarintDeclRef = createDefaultSubstitutionsIfNeeded(
                m_astBuilder,
                this,
                makeDeclRef(rightConstraints[cc]));
            DeclRef<GenericTypeConstraintDecl> rightConstraint =
                substInnerRightToLeft.substitute(m_astBuilder, unspecializedRightConstarintDeclRef)
                    .as<GenericTypeConstraintDecl>();
            if (!rightConstraint)
                return false;

            if (leftTypeConstraint->isEqualityConstraint !=
                rightConstraint.getDecl()->isEqualityConstraint)
                return false;
            if (leftTypeConstraint->hasModifier<OptionalConstraintModifier>() !=
                rightConstraint.getDecl()->hasModifier<OptionalConstraintModifier>())
            {
                return false;
            }

            auto leftSub = leftTypeConstraint->sub.type;
            auto rightSub =
                substInnerRightToLeft.substitute(m_astBuilder, rightConstraint.getDecl()->sub.type);
            if (!leftSub->equals(rightSub))
                return false;

            auto leftSup = leftTypeConstraint->sup.type;
            auto rightSup =
                substInnerRightToLeft.substitute(m_astBuilder, rightConstraint.getDecl()->sup.type);
            if (!leftSup->equals(rightSup))
                return false;
        }
        else if (
            auto leftTypeCoercionConstraint = as<TypeCoercionConstraintDecl>(leftConstraints[cc]))
        {
            auto unspecializedRightConstraintDeclRef = createDefaultSubstitutionsIfNeeded(
                m_astBuilder,
                this,
                makeDeclRef(rightConstraints[cc]));
            auto rightConstraint =
                substInnerRightToLeft.substitute(m_astBuilder, unspecializedRightConstraintDeclRef)
                    .as<TypeCoercionConstraintDecl>();
            if (!rightConstraint)
                return false;

            auto leftFromType = leftTypeCoercionConstraint->fromType.type;
            auto rightFromType = substInnerRightToLeft.substitute(
                m_astBuilder,
                rightConstraint.getDecl()->fromType.type);
            if (!leftFromType->equals(rightFromType))
                return false;

            auto leftToType = leftTypeCoercionConstraint->toType.type;
            auto rightToType = substInnerRightToLeft.substitute(
                m_astBuilder,
                rightConstraint.getDecl()->toType.type);
            if (!leftToType->equals(rightToType))
                return false;

            if (leftTypeCoercionConstraint->hasModifier<ImplicitConversionModifier>() !=
                rightConstraint.getDecl()->hasModifier<ImplicitConversionModifier>())
            {
                return false;
            }
        }
        else if (auto leftNonEmptyConstraint = as<NonEmptyPackConstraintDecl>(leftConstraints[cc]))
        {
            auto unspecializedRightConstraintDeclRef = createDefaultSubstitutionsIfNeeded(
                m_astBuilder,
                this,
                makeDeclRef(rightConstraints[cc]));
            auto rightConstraint =
                substInnerRightToLeft.substitute(m_astBuilder, unspecializedRightConstraintDeclRef)
                    .as<NonEmptyPackConstraintDecl>();
            if (!rightConstraint)
                return false;
            if (getNonEmptyConstraintTargetDecl(leftNonEmptyConstraint) !=
                getNonEmptyConstraintTargetDecl(rightConstraint.getDecl()))
            {
                return false;
            }
        }
        else if (
            auto leftPackCountConstraint =
                as<GenericVariadicPackCountConstraintDecl>(leftConstraints[cc]))
        {
            // Generic signature equality uses the same exact proof identity as
            // witness forwarding: after substituting `right` into `left`'s
            // parameter space, both the checked `countof(pack)` value and the
            // expected count `IntVal` must match.
            auto unspecializedRightConstraintDeclRef = createDefaultSubstitutionsIfNeeded(
                m_astBuilder,
                this,
                makeDeclRef(rightConstraints[cc]));
            auto rightConstraint =
                substInnerRightToLeft.substitute(m_astBuilder, unspecializedRightConstraintDeclRef)
                    .as<GenericVariadicPackCountConstraintDecl>();
            if (!rightConstraint)
                return false;

            auto leftConstraintRef =
                m_astBuilder->getDirectDeclRef<GenericVariadicPackCountConstraintDecl>(
                    leftPackCountConstraint);
            auto leftActualCount =
                getPackCountConstraintActualCount(m_astBuilder, leftConstraintRef);
            auto rightActualCount =
                getPackCountConstraintActualCount(m_astBuilder, rightConstraint);
            if (leftActualCount != rightActualCount)
            {
                return false;
            }

            auto leftCount = getPackCountConstraintExpectedCount(m_astBuilder, leftConstraintRef);
            auto rightCount = getPackCountConstraintExpectedCount(m_astBuilder, rightConstraint);
            if (leftCount != rightCount)
                return false;
        }
        else if (
            auto leftHasDiffTypeInfoConstraint =
                as<HasDiffTypeInfoConstraintDecl>(leftConstraints[cc]))
        {
            auto unspecializedRightConstraintDeclRef = createDefaultSubstitutionsIfNeeded(
                m_astBuilder,
                this,
                makeDeclRef(rightConstraints[cc]));
            auto rightConstraint =
                substInnerRightToLeft.substitute(m_astBuilder, unspecializedRightConstraintDeclRef)
                    .as<HasDiffTypeInfoConstraintDecl>();
            if (!rightConstraint)
                return false;

            auto leftType = leftHasDiffTypeInfoConstraint->type.type;
            auto rightType = getBaseType(m_astBuilder, rightConstraint);
            if (!leftType || !rightType || !leftType->equals(rightType))
                return false;
        }
        else
        {
            return false;
        }
    }

    // If we have checked all of the (canonicalized) constraints
    // and found them to be pairwise equivalent then the two
    // generic signatures seem to match.
    //
    return true;
}

static bool _doParamPassingModesMatchForOverload(ParamPassingMode first, ParamPassingMode second)
{
    if (first == second)
        return true;

    // Calls cannot select between an output-only and an input/output overload, so those two modes
    // have historically shared an overload-signature category. The immutable-borrow and `ref`
    // modes remain distinct from that category and from ordinary `in`.
    auto isOutOrInOut = [](ParamPassingMode mode)
    { return mode == ParamPassingMode::Out || mode == ParamPassingMode::BorrowInOut; };
    return isOutOrInOut(first) && isOutOrInOut(second);
}

bool SemanticsVisitor::doFunctionSignaturesMatch(DeclRef<FuncDecl> fst, DeclRef<FuncDecl> snd)
{

    // TODO(tfoley): This copies the parameter array, which is bad for performance.
    auto fstParams = getParameters(m_astBuilder, fst).toArray();
    auto sndParams = getParameters(m_astBuilder, snd).toArray();

    // If the functions have different numbers of parameters, then
    // their signatures trivially don't match.
    auto fstParamCount = fstParams.getCount();
    auto sndParamCount = sndParams.getCount();
    if (fstParamCount != sndParamCount)
        return false;

    for (Index ii = 0; ii < fstParamCount; ++ii)
    {
        auto fstParam = fstParams[ii];
        auto sndParam = sndParams[ii];

        // If a given parameter type doesn't match, then signatures don't match
        if (!getType(m_astBuilder, fstParam)->equals(getType(m_astBuilder, sndParam)))
            return false;

        if (!_doParamPassingModesMatchForOverload(
                getParamPassingMode(fstParam.getDecl()),
                getParamPassingMode(sndParam.getDecl())))
            return false;
    }

    // Note(tfoley): return type doesn't enter into it, because we can't take
    // calling context into account during overload resolution.

    return true;
}

static Val* _getNonEmptyConstraintPackVal(
    ASTBuilder* astBuilder,
    DeclRef<NonEmptyPackConstraintDecl> const& constraintDeclRef)
{
    auto packExpr = constraintDeclRef.substitute(astBuilder, constraintDeclRef.getDecl()->packExpr);
    if (auto declRefExpr = packExpr.as<DeclRefExpr>())
    {
        auto packDeclRef = getDeclRef(astBuilder, declRefExpr);
        return astBuilder->getDeclRefVal(packDeclRef);
    }
    return nullptr;
}

List<Val*> getDefaultSubstitutionArgs(
    ASTBuilder* astBuilder,
    SemanticsVisitor* semantics,
    GenericDecl* genericDecl)
{
    if (genericDecl->_cachedArgsForDefaultSubstitution.getCount() != 0)
        return genericDecl->_cachedArgsForDefaultSubstitution;

    List<Val*> args;
    for (auto mm : genericDecl->getDirectMemberDecls())
    {
        if (auto genericTypeParamDecl = as<GenericTypeParamDecl>(mm))
        {
            args.add(DeclRefType::create(
                astBuilder,
                astBuilder->getDirectDeclRef(genericTypeParamDecl)));
        }
        else if (auto genericTypePackParamDecl = as<GenericTypePackParamDecl>(mm))
        {
            auto packType = DeclRefType::create(
                astBuilder,
                astBuilder->getDirectDeclRef(genericTypePackParamDecl));
            args.add(packType);
        }
        else if (auto genericValuePackParamDecl = as<GenericValuePackParamDecl>(mm))
        {
            if (semantics)
                semantics->ensureDecl(genericValuePackParamDecl, DeclCheckState::ReadyForLookup);

            args.add(astBuilder->getOrCreate<DeclRefIntVal>(
                genericValuePackParamDecl->getType(),
                astBuilder->getDirectDeclRef(genericValuePackParamDecl)));
        }
        else if (auto genericValueParamDecl = as<GenericValueParamDecl>(mm))
        {
            if (semantics)
                semantics->ensureDecl(genericValueParamDecl, DeclCheckState::ReadyForLookup);

            args.add(astBuilder->getOrCreate<DeclRefIntVal>(
                genericValueParamDecl->getType(),
                astBuilder->getDirectDeclRef(genericValueParamDecl)));
        }
    }

    bool shouldCache = true;

    // check all constraints. It is possible that checking the constraint can split it
    // into multiple constraints, so we will check all the constraints first, and then proceed with
    // constructing the args list.
    //
    if (semantics)
    {
        for (auto member : genericDecl->getDirectMemberDecls())
        {
            if (!isGenericConstraintParameterDecl(member))
                continue;

            if (auto genericTypeConstraintDecl = as<GenericTypeConstraintDecl>(member))
            {
                semantics->ensureDecl(genericTypeConstraintDecl, DeclCheckState::ReadyForReference);
            }
            else if (auto typeCoercionConstraintDecl = as<TypeCoercionConstraintDecl>(member))
            {
                semantics->ensureDecl(
                    typeCoercionConstraintDecl,
                    DeclCheckState::ReadyForReference);
            }
            else if (auto nonEmptyConstraintDecl = as<NonEmptyPackConstraintDecl>(member))
            {
                semantics->ensureDecl(nonEmptyConstraintDecl, DeclCheckState::ReadyForReference);
            }
            else if (
                auto packCountConstraintDecl = as<GenericVariadicPackCountConstraintDecl>(member))
            {
                semantics->ensureDecl(packCountConstraintDecl, DeclCheckState::ReadyForReference);
            }
            else if (auto hasDiffTypeInfoConstraintDecl = as<HasDiffTypeInfoConstraintDecl>(member))
            {
                semantics->ensureDecl(
                    hasDiffTypeInfoConstraintDecl,
                    DeclCheckState::ReadyForReference);
            }
        }
    }

    // create default substitution arguments for constraints
    for (auto decl : genericDecl->getDirectMemberDecls())
    {
        if (!isGenericConstraintParameterDecl(decl))
            continue;

        if (auto genericTypeConstraintDecl = as<GenericTypeConstraintDecl>(decl))
        {
            if (semantics)
                semantics->ensureDecl(genericTypeConstraintDecl, DeclCheckState::ReadyForReference);
            auto constraintDeclRef = createDefaultSubstitutionsIfNeeded(
                                         astBuilder,
                                         semantics,
                                         genericTypeConstraintDecl->getDefaultDeclRef())
                                         .as<GenericTypeConstraintDecl>();
            auto supType = getSup(astBuilder, constraintDeclRef);
            if (!supType)
            {
                args.add(astBuilder->getErrorType());
                shouldCache = false;
                continue;
            }
            auto witness = astBuilder->getDeclaredSubtypeWitness(
                getSub(astBuilder, constraintDeclRef),
                getSup(astBuilder, constraintDeclRef),
                constraintDeclRef);
            // TODO: this is an ugly hack to prevent crashing.
            // In early stages of compilation witness->sub and witness->sup may not be checked yet.
            // When semanticVisitor is present we have used that to ensure the type is checked.
            // However due to how the code is written we cannot guarantee semanticVisitor is always
            // available here, and if we can't get the checked sup/sub type this subst is incomplete
            // and should not be cached.
            if (!witness->getSub())
                shouldCache = false;
            args.add(witness);
        }
        else if (auto typeCoercionConstraintDecl = as<TypeCoercionConstraintDecl>(decl))
        {
            if (semantics)
                semantics->ensureDecl(
                    typeCoercionConstraintDecl,
                    DeclCheckState::ReadyForReference);

            auto constraintDeclRef = createDefaultSubstitutionsIfNeeded(
                                         astBuilder,
                                         semantics,
                                         typeCoercionConstraintDecl->getDefaultDeclRef())
                                         .as<TypeCoercionConstraintDecl>();

            auto fromType = getFromType(astBuilder, constraintDeclRef);
            auto toType = getToType(astBuilder, constraintDeclRef);

            if (!fromType || !toType)
            {
                args.add(astBuilder->getErrorType());
                shouldCache = false;
                continue;
            }
            args.add(astBuilder->getBuiltinTypeCoercionWitness(fromType, toType));
        }
        else if (auto nonEmptyConstraintDecl = as<NonEmptyPackConstraintDecl>(decl))
        {
            auto constraintDeclRef =
                astBuilder->getDirectDeclRef<NonEmptyPackConstraintDecl>(nonEmptyConstraintDecl);
            auto packVal = _getNonEmptyConstraintPackVal(astBuilder, constraintDeclRef);
            if (!packVal)
            {
                args.add(astBuilder->getErrorType());
                shouldCache = false;
                continue;
            }
            args.add(astBuilder->getNonEmptyPackWitness(packVal));
        }
        else if (auto packCountConstraintDecl = as<GenericVariadicPackCountConstraintDecl>(decl))
        {
            if (semantics)
                semantics->ensureDecl(packCountConstraintDecl, DeclCheckState::ReadyForReference);
            // Default substitution args represent a generic body before any
            // concrete specialization. For
            // `foo<let N, each I>() where countof(I) == N { bar<N, I>(); }`,
            // this declared witness is the proof that `bar` receives while
            // checking `foo`'s body with abstract `N` and `I`.
            auto constraintDeclRef = createDefaultSubstitutionsIfNeeded(
                                         astBuilder,
                                         semantics,
                                         packCountConstraintDecl->getDefaultDeclRef())
                                         .as<GenericVariadicPackCountConstraintDecl>();
            args.add(astBuilder->getDeclaredVariadicPackCountWitness(constraintDeclRef));
        }
        else if (auto hasDiffTypeInfoConstraintDecl = as<HasDiffTypeInfoConstraintDecl>(decl))
        {
            if (semantics)
                semantics->ensureDecl(
                    hasDiffTypeInfoConstraintDecl,
                    DeclCheckState::ReadyForReference);
            auto constraintDeclRef = createDefaultSubstitutionsIfNeeded(
                                         astBuilder,
                                         semantics,
                                         hasDiffTypeInfoConstraintDecl->getDefaultDeclRef())
                                         .as<HasDiffTypeInfoConstraintDecl>();
            args.add(astBuilder->getHasDiffTypeInfoWitness(constraintDeclRef));
        }
    }

    if (shouldCache)
        genericDecl->_cachedArgsForDefaultSubstitution = args;

    return args;
}

typedef Dictionary<Name*, CallableDecl*> TargetDeclDictionary;

static void _addTargetModifiers(CallableDecl* decl, TargetDeclDictionary& ioDict)
{
    if (auto specializedModifier = decl->findModifier<SpecializedForTargetModifier>())
    {
        // If it's specialized for target it should have a body...
        if (auto funcDecl = as<FunctionDeclBase>(decl))
        {
            // Normally if we have specialization for target it must have a body.
            if (funcDecl->body == nullptr)
            {
                // If it doesn't have a body but does have a target intrinsic/SPIRVInstructionOp
                // it's probably ok

                SLANG_ASSERT(
                    funcDecl->findModifier<SPIRVInstructionOpAttribute>() ||
                    funcDecl->findModifier<TargetIntrinsicModifier>());
            }
        }
        Name* targetName = specializedModifier->targetToken.getName();

        ioDict.addIfNotExists(targetName, decl);
    }
    else
    {
        for (auto modifier : decl->getModifiersOfType<TargetIntrinsicModifier>())
        {
            Name* targetName = modifier->targetToken.getName();
            ioDict.addIfNotExists(targetName, decl);
        }

        auto funcDecl = as<FunctionDeclBase>(decl);
        if (funcDecl && funcDecl->body)
        {
            // Should only be one body if it isn't specialized for target.
            // Use nullptr for this scenario
            ioDict.addIfNotExists(nullptr, decl);
        }
    }
}

Result SemanticsVisitor::checkFuncRedeclaration(FuncDecl* newDecl, FuncDecl* oldDecl)
{
    // There are a few different cases that this function needs
    // to check for:
    //
    // * If `newDecl` and `oldDecl` have different signatures such
    //   that they can always be distinguished at call sites, then
    //   they don't conflict and don't count as redeclarations.
    //
    // * If `newDecl` and `oldDecl` have matching signatures, but
    //   differ in return type (or other details that would affect
    //   compatibility), then the declarations conflict and an
    //   error needs to be diagnosed.
    //
    // * If `newDecl` and `oldDecl` have matching/compatible sigantures,
    //   but differ when it comes to target-specific overloading,
    //   then they can co-exist.
    //
    // * If `newDecl` and `oldDecl` have matching/compatible signatures
    //   and are specialized for the same target(s), then only
    //   one can have a body (in which case the other is a forward declaration),
    //   or else we have a redefinition error.

    auto newGenericDecl = as<GenericDecl>(newDecl->parentDecl);
    auto oldGenericDecl = as<GenericDecl>(oldDecl->parentDecl);

    // If one declaration is a prefix/postfix operator, and the
    // other is not a matching operator, then don't consider these
    // to be re-declarations.
    //
    // Note(tfoley): Any attempt to call such an operator using
    // ordinary function-call syntax (if we decided to allow it)
    // would be ambiguous in such a case, of course.
    //
    if (newDecl->hasModifier<PrefixModifier>() != oldDecl->hasModifier<PrefixModifier>())
        return SLANG_OK;
    if (newDecl->hasModifier<PostfixModifier>() != oldDecl->hasModifier<PostfixModifier>())
        return SLANG_OK;

    // If one is generic and the other isn't, then there is no match.
    if ((newGenericDecl != nullptr) != (oldGenericDecl != nullptr))
        return SLANG_OK;

    // We are going to be comparing the signatures of the
    // two functions, but if they are *generic* functions
    // then we will need to compare them with consistent
    // specializations in place.
    //
    // We'll go ahead and create some (unspecialized) declaration
    // references here, just to be prepared.
    //
    DeclRef<FuncDecl> newDeclRef(newDecl);
    DeclRef<FuncDecl> oldDeclRef(oldDecl);

    // If we are working with generic functions, then we need to
    // consider if their generic signatures match.
    //
    if (newGenericDecl)
    {
        // If one declaration is generic, the other must be.
        // (This condition was already checked above)
        //
        SLANG_ASSERT(oldGenericDecl);

        // As part of checking if the generic signatures match,
        // we will produce a substitution that can be used to
        // reference `oldGenericDecl` with the generic parameters
        // substituted for those of `newDecl`.
        //
        // One way to think about it is that if we have these
        // declarations (ignore the name differences...):
        //
        //     // oldDecl:
        //     void foo1<T>(T x);
        //
        //     // newDecl:
        //     void foo2<U>(U x);
        //
        // Then we will compare the parameter types of `foo2`
        // against the specialization `foo1<U>`.
        //
        DeclRef<Decl> specializedOldDeclInner;
        if (!doGenericSignaturesMatch(newGenericDecl, oldGenericDecl, &specializedOldDeclInner))
            return SLANG_OK;

        oldDeclRef = specializedOldDeclInner.as<FuncDecl>();
    }

    // If the parameter signatures don't match, then don't worry
    if (!doFunctionSignaturesMatch(newDeclRef, oldDeclRef))
        return SLANG_OK;

    // If the declatation is declared by 'extern', and new definition is with 'export', then
    // we should let overload resolution to handle it.
    if (oldDecl->hasModifier<ExternModifier>() && newDecl->hasModifier<HLSLExportModifier>())
    {
        return SLANG_OK;
    }

    // If we get this far, then we've got two declarations in the same
    // scope, with the same name and signature, so they appear
    // to be redeclarations.
    //
    // We will track that redeclaration occured, so that we can
    // take it into account for overload resolution.
    //
    // A huge complication that we'll need to deal with is that
    // multiple declarations might introduce default values for
    // (different) parameters, and we might need to merge across
    // all of them (which could get complicated if defaults for
    // parameters can reference earlier parameters).

    // If the previous declaration wasn't already recorded
    // as being part of a redeclaration family, then make
    // it the primary declaration of a new family.
    if (!oldDecl->primaryDecl)
    {
        oldDecl->primaryDecl = oldDecl;
    }

    // The new declaration will belong to the family of
    // the previous one, and so it will share the same
    // primary declaration.
    newDecl->primaryDecl = oldDecl->primaryDecl;
    newDecl->nextDecl = nullptr;

    // Next we want to chain the new declaration onto
    // the linked list of redeclarations.
    auto link = &oldDecl->nextDecl;
    while (*link)
        link = &(*link)->nextDecl;
    *link = newDecl;

    // Now that we've added things to a group of redeclarations,
    // we can do some additional validation.

    // First, we will ensure that the return types match
    // between the declarations, so that they are truly
    // interchangeable.
    //
    // Note(tfoley): If we ever decide to add a beefier type
    // system to Slang, we might allow overloads like this,
    // so long as the desired result type can be disambiguated
    // based on context at the call type. In that case we would
    // consider result types earlier, as part of the signature
    // matching step.
    //
    auto resultType = getResultType(m_astBuilder, newDeclRef);
    auto prevResultType = getResultType(m_astBuilder, oldDeclRef);
    if (!resultType->equals(prevResultType))
    {
        // Bad redeclaration
        getSink()->diagnose(Diagnostics::FunctionRedeclarationWithDifferentReturnType{
            .newReturnType = resultType,
            .prevReturnType = prevResultType,
            .decl = newDecl});
        getSink()->diagnose(Diagnostics::SeePreviousDeclarationOf{.decl = oldDecl});

        // Don't bother emitting other errors at this point
        return SLANG_FAIL;
    }

    // TODO: Enforce that the new declaration had better
    // not specify a default value for any parameter that
    // already had a default value in a prior declaration.

    // We are going to want to enforce that we cannot have
    // two declarations of a function both specify bodies.
    // Before we make that check, however, we need to deal
    // with the case where the two function declarations
    // might represent different target-specific versions
    // of a function.

    // If both of the declarations have a body, then there
    // is trouble, because we wouldn't know which one to
    // use during code generation.

    // Here to cover the 'bodies'/target_intrinsics, we find all the targets that
    // that are previously defined, and make sure the new definition
    // doesn't try and define what is already defined.
    {
        TargetDeclDictionary currentTargets;
        {
            CallableDecl* curDecl = newDecl->primaryDecl;
            while (curDecl)
            {
                if (curDecl != newDecl)
                {
                    _addTargetModifiers(curDecl, currentTargets);
                }
                curDecl = curDecl->nextDecl;
            }
        }

        // Add the targets for this new decl
        TargetDeclDictionary newTargets;
        _addTargetModifiers(newDecl, newTargets);

        bool hasConflict = false;

        // Build up the FunctionRedefinition diagnostic struct and emit it at the end
        Diagnostics::FunctionRedefinition diagnostic;

        for (auto& [target, value] : newTargets)
        {
            auto found = currentTargets.tryGetValue(target);
            if (found)
            {
                if (!hasConflict)
                {
                    diagnostic = Diagnostics::FunctionRedefinition{.function = newDecl};
                }
                auto prevDecl = *found;
                diagnostic.original = prevDecl;

                hasConflict = true;
            }
        }

        if (hasConflict)
        {
            getSink()->diagnose(diagnostic);
            return SLANG_FAIL;
        }
    }

    // At this point we've processed the redeclaration and
    // put it into a group, so there is no reason to keep
    // looping and looking at prior declarations.
    //
    // While no diagnostics have been emitted, we return
    // a failure result from the operation to indicate
    // to the caller that they should stop looping over
    // declarations at this point.
    //
    return SLANG_FAIL;
}

Result SemanticsVisitor::checkRedeclaration(
    Decl* newDecl,
    Decl* oldDecl,
    RedeclarationSeverity severity)
{
    // If either of the declarations being looked at is generic, then
    // we want to consider the "inner" declaration instead when
    // making decisions about what to allow or not.
    //
    if (auto newGenericDecl = as<GenericDecl>(newDecl))
        newDecl = newGenericDecl->inner;
    if (auto oldGenericDecl = as<GenericDecl>(oldDecl))
        oldDecl = oldGenericDecl->inner;

    // Functions are special in that we can have many declarations
    // with the same name in a given scope, and it is possible
    // for them to co-exist as overloads, or even just be multiple
    // declarations of the same function (thanks to the inherited
    // legacy of C forward declarations).
    //
    // If both declarations are functions, we will check that
    // they are allowed to co-exist using these more nuanced rules.
    //
    if (auto newFuncDecl = as<FuncDecl>(newDecl))
    {
        if (auto oldFuncDecl = as<FuncDecl>(oldDecl))
        {
            // Both new and old declarations are functions,
            // so redeclaration may be valid.
            return checkFuncRedeclaration(newFuncDecl, oldFuncDecl);
        }
    }

    if (as<ModuleDeclarationDecl>(oldDecl) || as<ModuleDeclarationDecl>(newDecl))
    {
        // It is allowed to have a decl whose name is the same as the module.
        return SLANG_OK;
    }

    // Consider `[UnscopedEnum] enum Mode { Mode, Other }`. The alias `Mode` that the parser adds
    // for the case conflicts with the enum, but lookup tells the type and the value apart by where
    // the name is used, and DXC and earlier Slang releases accept the code, so we warn; Slang 202c
    // may make it an error (shader-slang/slang#13956). The failure result stops the caller's loop,
    // so a conflict with an older declaration is reported at the enum. The case is null when user
    // code attaches the modifier through `syntax`.
    if (auto aliasModifier = newDecl->findModifier<UnscopedEnumCaseAliasModifier>())
    {
        auto caseDecl = aliasModifier->enumCaseDecl;
        if (caseDecl && caseDecl->parentDecl == oldDecl)
        {
            getSink()->diagnose(Diagnostics::UnscopedEnumCaseNamedLikeEnum{.decl = newDecl});
            return SLANG_FAIL;
        }
    }


    // For all other flavors of declaration, we do not
    // allow duplicate declarations with the same name.
    //
    // TODO: We might consider allowing some other cases
    // of overloading that can be safely disambiguated:
    //
    // * A type and a value (function/variable/etc.) of the same name can usually
    //   co-exist because we can distinguish which is needed by context.
    //
    // * Multiple generic types with the same name can co-exist
    //   if their generic parameter lists are sufficient to
    //   tell them apart at a use site.

    // We will diagnose a redeclaration at the new declaration,
    // and point to the old declaration for context.
    //
    if (severity == RedeclarationSeverity::Warning)
        getSink()->diagnose(Diagnostics::RedeclarationCompatibilityWarning{.decl = newDecl});
    else
        getSink()->diagnose(Diagnostics::Redeclaration{.decl = newDecl});
    getSink()->diagnose(Diagnostics::SeePreviousDeclarationOf{.decl = oldDecl});
    return SLANG_FAIL;
}


void SemanticsVisitor::checkForRedeclaration(Decl* decl, RedeclarationSeverity severity)
{
    // We want to consider a "new" declaration in the context
    // of some parent/container declaration, and compare it
    // to pre-existing "old" declarations of the same name
    // in the same container.
    //
    auto newDecl = decl;
    auto parentDecl = decl->parentDecl;

    // Sanity check: there should always be a parent declaration.
    //
    if (!parentDecl)
        SLANG_ABORT_COMPILATION("decl has no parent.");

    // If the declaration is the "inner" declaration of a generic,
    // then we actually want to look one level up, because the
    // peers/siblings of the declaration will belong to the same
    // parent as the generic, not to the generic.
    //
    if (auto genericParentDecl = as<GenericDecl>(parentDecl))
    {
        // Note: we need to check here to be sure `newDecl`
        // is the "inner" declaration and not one of the
        // generic parameters, or else we will end up
        // checking them at the wrong scope.
        //
        if (newDecl == genericParentDecl->inner)
        {
            newDecl = parentDecl;
            parentDecl = genericParentDecl->parentDecl;
        }
    }

    // We will now look for other declarations with
    // the same name in the same parent/container.
    //

    for (auto oldDecl = parentDecl->getPrevDirectMemberDeclWithSameName(newDecl); oldDecl;
         oldDecl = parentDecl->getPrevDirectMemberDeclWithSameName(oldDecl))
    {
        // For each matching declaration, we will check
        // whether the redeclaration should be allowed,
        // and emit an appropriate diagnostic if not.
        //
        Result checkResult = checkRedeclaration(newDecl, oldDecl, severity);

        // The `checkRedeclaration` function will return a failure
        // status (whether or not it actually emitted a diagnostic)
        // if we should stop checking further redeclarations, because
        // the declaration in question has been dealt with fully.
        //
        if (SLANG_FAILED(checkResult))
            break;
    }
}

/// Return whether `decl` has an earlier declaration of the same name in `containerDecl` other
/// than the module's own `module` declaration. `checkForRedeclaration` compares `decl` with
/// each such declaration.
///
static bool hasEarlierSameNameNonModuleSibling(ContainerDecl* containerDecl, Decl* decl)
{
    for (auto prevDecl = containerDecl->getPrevDirectMemberDeclWithSameName(decl); prevDecl;
         prevDecl = containerDecl->getPrevDirectMemberDeclWithSameName(prevDecl))
    {
        if (!as<ModuleDeclarationDecl>(prevDecl))
            return true;
    }
    return false;
}

/// Return the aggregate type whose members lookup finds through the transparent variable
/// `varDecl`, or null if its type names none. As for any member lookup, lookup takes the
/// variable's checked type and looks through a pointer-like type such as `ConstantBuffer<T>`
/// (see `_lookUpMembersInValue` and `_lookUpMembersInSuperTypeImpl`).
///
static AggTypeDecl* getAggTypeDeclVisibleThroughTransparentVar(VarDeclBase* varDecl)
{
    Type* type = varDecl->getType();
    if (auto pointedToType = getPointedToTypeIfCanImplicitDeref(type))
        type = pointedToType;
    return isDeclRefTypeOf<AggTypeDecl>(type).getDecl();
}

/// Compare `decl` with the nearest earlier declaration of its name in `visibleDecls`, unless
/// `checkForRedeclaration` compares it with an earlier sibling, and record `decl` as visible.
///
static void compareWithNearestVisibleDecl(
    SemanticsVisitor* visitor,
    Dictionary<Name*, Decl*>& visibleDecls,
    Decl* decl,
    bool hasEarlierSiblingOfSameName)
{
    Decl* prevDecl = nullptr;
    if (!hasEarlierSiblingOfSameName && visibleDecls.tryGetValue(decl->getName(), prevDecl) &&
        prevDecl != decl)
    {
        visitor->checkRedeclaration(decl, prevDecl, RedeclarationSeverity::Warning);
    }
    visibleDecls[decl->getName()] = decl;
}

/// Check the declarations that lookup in `containerDecl` finds through its transparent
/// variables against the other declarations that lookup finds there.
///
/// Consider this example:
///
///     static const int x = 1;
///     cbuffer CB { int x; }
///
/// Lookup of `x` finds both declarations, but the member `x` is not a direct member of the
/// scope, so `checkForRedeclaration` does not compare them. We treat the members of the type
/// of each transparent variable as declared at that variable, and compare each declaration
/// with the nearest earlier one of its name. Earlier compiler releases did not compare these
/// pairs, so a conflict is a warning; Slang 202c may make it an error (shader-slang/slang#13956).
///
void SemanticsVisitor::checkForRedeclarationOfTransparentMembers(ContainerDecl* containerDecl)
{
    if (containerDecl->getTransparentDirectMemberDecls().getCount() == 0)
        return;

    // For each name, the most recent declaration so far that lookup in `containerDecl` finds.
    Dictionary<Name*, Decl*> visibleDecls;
    for (auto memberDecl : containerDecl->getDirectMemberDecls())
    {
        if (memberDecl->getName() && !as<ModuleDeclarationDecl>(memberDecl) &&
            DeclPassesLookupMask(memberDecl, LookupMask::Default))
        {
            compareWithNearestVisibleDecl(
                this,
                visibleDecls,
                memberDecl,
                hasEarlierSameNameNonModuleSibling(containerDecl, memberDecl));
        }

        auto varDecl = as<VarDeclBase>(memberDecl);
        if (!varDecl || !varDecl->hasModifier<TransparentModifier>())
            continue;
        ensureDecl(varDecl, DeclCheckState::CanUseTypeOfValueDecl);
        auto aggTypeDecl = getAggTypeDeclVisibleThroughTransparentVar(varDecl);
        if (!aggTypeDecl)
            continue;
        for (auto aggMemberDecl : aggTypeDecl->getDirectMemberDeclsOfType<VarDeclBase>())
        {
            compareWithNearestVisibleDecl(
                this,
                visibleDecls,
                aggMemberDecl,
                aggTypeDecl->getPrevDirectMemberDeclWithSameName(aggMemberDecl) != nullptr);
        }
    }
}


void SemanticsDeclHeaderVisitor::visitParamDecl(ParamDecl* paramDecl)
{
    auto typeExpr = paramDecl->type;
    if (typeExpr.exp)
    {
        SemanticsVisitor subVisitor(withDeclToExcludeFromLookup(paramDecl));
        typeExpr = subVisitor.CheckUsableType(typeExpr, paramDecl);
        paramDecl->type = typeExpr;
        checkMeshOutputDecl(paramDecl);
    }

    if (!paramDecl->type && paramDecl->initExpr)
    {
        // If paramDecl doesn't have a type but have an initExpr, derive the type
        // from the expr.
        deriveVarTypeFromInitExpr(paramDecl);
    }

    if (!paramDecl->type && !as<AttributeDecl>(getParentDecl(paramDecl)))
    {
        getSink()->diagnose(Diagnostics::ParamWithoutTypeMustHaveInitializer{.decl = paramDecl});
    }

    if (paramDecl->type.type)
    {
        auto hadNoDiffModifier = paramDecl->findModifier<NoDiffModifier>() != nullptr;
        paramDecl->type.type =
            _moveNoDiffFromTypeToParamDecl(m_astBuilder, paramDecl->type.type, paramDecl);
        if (!hadNoDiffModifier)
        {
            if (auto noDiffModifier = paramDecl->findModifier<NoDiffModifier>())
            {
                noDiffModifier->loc = paramDecl->loc;
                noDiffModifier->keywordName = getSession()->getNameObj("no_diff");
            }
        }
    }

    // An `out` or `inout` parameter is meant to be written by its function, so `const` on one
    // contradicts its passing mode. We reject it even though DXC accepts it. The check precedes
    // the parameter-pack handling below, which adds `const` to every pack parameter.
    if (auto constModifier = paramDecl->findModifier<ConstModifier>())
    {
        const auto mode = getParamPassingMode(paramDecl);
        if (mode == ParamPassingMode::Out || mode == ParamPassingMode::BorrowInOut)
        {
            getSink()->diagnose(Diagnostics::ConstOnWritableParameter{
                .mode = mode,
                .param = paramDecl,
                .modifier = constModifier});
        }
    }

    if (isTypePack(paramDecl->type.type))
    {
        // For now, we only allow parameter packs to be `const`.
        bool hasConstModifier = false;
        for (auto modifier : paramDecl->modifiers)
        {
            if (as<OutModifier>(modifier) || as<InOutModifier>(modifier) ||
                as<RefModifier>(modifier) || as<RefReadOnlyModifier>(modifier) ||
                as<RefWriteOnlyModifier>(modifier) || as<BorrowModifier>(modifier))
            {
                // TODO(tfoley): The diagnostic in this case should probably not refer
                // to the `const` modifier at all (since that is not actually what is
                // required), and should instead note that a parameter pack may only
                // be declared as a pure input parameter to a function (`in` or
                // `borrow`).
                //
                if (!as<SynthesizedFuncDecl>(getParentDecl(paramDecl)))
                    getSink()->diagnose(
                        Diagnostics::ParameterPackMustBeConst{.modifier = modifier});
            }
            else if (as<ConstModifier>(modifier))
            {
                hasConstModifier = true;
            }
        }

        // TODO(tfoley): Rather than actually changing the modifiers
        // on the parameter itself, this kind of logic should probably
        // be folded into whatever logic computes the `QualType` for a
        // parameter, and ensure that parameter packs are never treated
        // as l-values.
        //
        if (!hasConstModifier)
        {
            auto constModifier = this->getASTBuilder()->create<ConstModifier>();
            addModifier(paramDecl, constModifier);
        }
    }

    maybeApplyLayoutModifier(paramDecl);

    // Only texture types are allowed to have memory qualifiers on parameters
    if (!paramDecl->type || paramDecl->type->astNodeType != ASTNodeType::TextureType)
    {
        auto MemoryQualifierSet = paramDecl->findModifier<MemoryQualifierSetModifier>();
        if (!MemoryQualifierSet)
            return;
        for (auto mod : MemoryQualifierSet->getModifiers())
            getSink()->diagnose(Diagnostics::MemoryQualifierNotAllowedOnANonImageTypeParameter{
                .modifier = mod,
                .param = paramDecl});
    }
}

// This checks that the declaration is marked as "out" and changes the hlsl
// modifier based syntax into a proper type.
void SemanticsDeclHeaderVisitor::checkMeshOutputDecl(VarDeclBase* varDecl)
{
    auto modifier = varDecl->findModifier<HLSLMeshShaderOutputModifier>();
    auto meshOutputType = as<MeshOutputType>(varDecl->type.type);
    bool isMeshOutput = modifier || meshOutputType;

    if (!isMeshOutput)
    {
        return;
    }
    // HLSL requires an 'out' modifier here, but since we don't operate
    // under such strict compatability we can just not warn here.
    if (!varDecl->findModifier<OutModifier>() && modifier)
    {
        getSink()->diagnose(
            Diagnostics::MeshOutputMustBeOut{.location = getDiagnosticPos(varDecl)});
    }

    //
    // If necessary, convert to our typed representation
    //
    if (!modifier)
    {
        return;
    }
    if (meshOutputType)
    {
        getSink()->diagnose(
            Diagnostics::UnnecessaryHlslMeshOutputModifier{.location = modifier->loc});
        varDecl->type.type = m_astBuilder->getErrorType();
        return;
    }
    auto indexExpr = as<IndexExpr>(varDecl->type.exp);
    if (!indexExpr)
    {
        getSink()->diagnose(
            Diagnostics::MeshOutputMustBeArray{.location = getDiagnosticPos(varDecl)});
        varDecl->type.type = m_astBuilder->getErrorType();
        return;
    }
    if (indexExpr->indexExprs.getCount() != 1)
    {
        getSink()->diagnose(
            Diagnostics::MeshOutputArrayMustHaveSize{.location = getDiagnosticPos(varDecl)});
        varDecl->type.type = m_astBuilder->getErrorType();
        return;
    }
    auto base = ExpectAType(indexExpr->baseExpression);
    auto index = CheckIntegerConstantExpression(
        indexExpr->indexExprs[0],
        IntegerConstantExpressionCoercionType::AnyInteger,
        nullptr,
        ConstantFoldingKind::LinkTime,
        getSink());
    if (!index)
        return;
    Type* d = m_astBuilder->getMeshOutputTypeFromModifier(modifier, base, index);
    varDecl->type.type = d;
}

void SemanticsDeclBodyVisitor::visitParamDecl(ParamDecl* paramDecl)
{
    auto typeExpr = paramDecl->type;

    if (!as<ArrayExpressionType>(paramDecl->type) &&
        doesTypeHaveTag(paramDecl->type, TypeTag::Unsized))
    {
        getSink()->diagnose(Diagnostics::ParamCannotBeUnsized{.decl = paramDecl});
    }

    // The "initializer" expression for a parameter represents
    // a default argument value to use if an explicit one is
    // not supplied.
    if (auto initExpr = paramDecl->initExpr)
    {
        // We must check the expression and coerce it to the
        // actual type of the parameter.
        //
        initExpr = CheckTerm(initExpr);
        initExpr = coerce(CoercionSite::Initializer, typeExpr.type, initExpr, getSink());
        paramDecl->initExpr = initExpr;

        // TODO: a default argument expression needs to
        // conform to other constraints to be valid.
        // For example, it should not be allowed to refer
        // to other parameters of the same function (or maybe
        // only the parameters to its left...).

        // A default argument value should not be allowed on an
        // `out` or `inout` parameter.
        //
        // TODO: we could relax this by requiring the expression
        // to yield an lvalue, but that seems like a feature
        // with limited practical utility (and an easy source
        // of confusing behavior).
        //
        // Note: the `InOutModifier` class inherits from `OutModifier`,
        // so we only need to check for the base case.
        //
        if (paramDecl->findModifier<OutModifier>())
        {
            getSink()->diagnose(
                Diagnostics::OutputParameterCannotHaveDefaultValue{.initExpr = initExpr});
        }
    }
}


static SeqStmt* _ensureCtorBodyIsSeqStmt(ASTBuilder* m_astBuilder, ConstructorDecl* decl)
{
    // It is possible BlockStmt has a child with the type of
    // `ExpressionStmt` if an existing constructor has only 1
    // expression. This would be a senario we need to
    // put the `ExpressionStmt` inside a `SeqStmt`.
    auto stmt = as<BlockStmt>(decl->body);
    if (!stmt)
    {
        auto tmpExpr = decl->body;
        auto blockStmt = m_astBuilder->create<BlockStmt>();
        blockStmt->body = tmpExpr;
        decl->body = blockStmt;
        stmt = blockStmt;
    }
    if (!as<SeqStmt>(stmt->body))
    {
        auto tmpExpr = stmt->body;
        auto seqStmt = m_astBuilder->create<SeqStmt>();
        seqStmt->stmts.add(tmpExpr);
        stmt->body = seqStmt;
        return seqStmt;
    }
    return as<SeqStmt>(stmt->body);
}

AssignExpr* SemanticsDeclBodyVisitor::createMemberAssignmentExpr(
    ThisExpr* thisExpr,
    Scope* scope,
    Decl* member,
    Expr* rightHandSideExpr)
{
    MemberExpr* memberExpr = m_astBuilder->create<MemberExpr>();
    memberExpr->baseExpression = thisExpr;
    memberExpr->declRef = member->getDefaultDeclRef();
    memberExpr->scope = scope;
    memberExpr->loc = member->loc;
    memberExpr->name = member->getName();
    memberExpr->type = GetTypeForDeclRef(member->getDefaultDeclRef(), member->loc);

    if (!memberExpr->type.isLeftValue)
        return nullptr;

    auto assign = m_astBuilder->create<AssignExpr>();
    assign->left = memberExpr;
    assign->right = rightHandSideExpr;
    assign->loc = member->loc;

    return assign;
}

Expr* SemanticsDeclBodyVisitor::createCtorParamExpr(ConstructorDecl* ctor, Index paramIndex)
{
    if (paramIndex >= ctor->getDirectMemberDeclCount())
        return nullptr;

    auto param = as<ParamDecl>(ctor->getDirectMemberDecl(paramIndex));
    if (!param)
        return nullptr;

    auto paramType = param->getType();
    auto paramExpr = m_astBuilder->create<VarExpr>();
    paramExpr->scope = ctor->ownedScope;
    paramExpr->declRef = param;
    paramExpr->type = paramType;
    paramExpr->loc = param->loc;
    return paramExpr;
}

void SemanticsDeclBodyVisitor::synthesizeCtorBodyForBases(
    ConstructorDecl* ctor,
    List<DeclAndCtorInfo>& inheritanceDefaultCtorList,
    ThisExpr* thisExpr,
    SeqStmt* seqStmtChild,
    bool isMemberInitCtor,
    Index& ioParamIndex)
{
    for (auto& declInfo : inheritanceDefaultCtorList)
    {
        ConstructorDecl* baseCtor = nullptr;
        List<Expr*> argumentList;

        if (isMemberInitCtor)
        {
            // Pick the parameters from the member initialize ctor, and use them to invoke the
            // base's member initialize ctor. e.g. base->init(...);
            baseCtor = _getSynthesizedConstructor(
                declInfo.parent,
                ConstructorDecl::ConstructorFlavor::SynthesizedMemberInit);
            if (baseCtor)
            {
                Index idx = 0;
                for (; idx < baseCtor->getParameters().getCount(); idx++)
                {
                    auto paramExpr = createCtorParamExpr(ctor, idx);
                    argumentList.add(paramExpr);
                }
                ioParamIndex += idx;
            }
        }

        // It's possible that the base type doesn't have a member initialize ctor, in this case, we
        // should use the default ctor.
        if (!baseCtor)
        {
            // If the base type has no default constructor, it means that it's not default
            // initializable, e.g. unsized array, resource type, etc. We will not synthesize code to
            // initialize it.
            if (!declInfo.defaultCtor)
                continue;
            baseCtor = declInfo.defaultCtor;
        }

        auto declRefType = as<DeclRefType>(declInfo.type);

        auto ctorToInvoke = m_astBuilder->create<VarExpr>();
        ctorToInvoke->declRef = declRefType->getDeclRef();
        ctorToInvoke->name = baseCtor->getName();
        ctorToInvoke->loc = baseCtor->loc;
        ctorToInvoke->type = m_astBuilder->getFuncType(ArrayView<Type*>(), declRefType);

        auto invoke = m_astBuilder->create<InvokeExpr>();
        invoke->functionExpr = ctorToInvoke;
        invoke->arguments.addRange(argumentList);

        auto assign = m_astBuilder->create<AssignExpr>();
        assign->left = coerce(CoercionSite::Initializer, declRefType, thisExpr, getSink());
        assign->right = invoke;

        auto stmt = m_astBuilder->create<ExpressionStmt>();
        stmt->expression = assign;
        stmt->loc = ctor->loc;

        seqStmtChild->stmts.add(stmt);
    }
}

void SemanticsDeclBodyVisitor::synthesizeCtorBodyForMemberVar(
    ConstructorDecl* ctor,
    VarDeclBase* varDeclBase,
    ThisExpr* thisExpr,
    Dictionary<Decl*, Expr*>& cachedDeclToCheckedVar,
    SeqStmt* seqStmtChild,
    bool isMemberInitCtor,
    Index& paramIndex)
{
    // Static variables are initialized at start of runtime, not inside a constructor
    // Once thing to notice is that if a member variable doesn't have name, it must be synthesized
    // instead of defined by user, we should not put it into the constructor because it's not a real
    // member.
    if (varDeclBase->hasModifier<HLSLStaticModifier>() || varDeclBase->getName() == nullptr)
        return;

    Expr* initExpr = nullptr;
    auto structDecl = as<StructDecl>(varDeclBase->parentDecl);
    bool useParamList = isMemberInitCtor;
    useParamList = isMemberInitCtor && structDecl->m_membersVisibleInCtor.contains(varDeclBase);

    if (!useParamList)
    {
        // If this is not a synthesized constructor (e.g. explicit ctor), or
        // the member has no visibility, we can only use it's init expression to initialize it.
        if (!varDeclBase->initExpr)
            return;
        initExpr = varDeclBase->initExpr;
    }
    else
    {
        // Find the corresponding parameter, if we can't find it, there
        // must be something wrong, it indicates that the ctor signature
        // is incorrect that the parameter list doesn't match the member list.
        initExpr = createCtorParamExpr(ctor, paramIndex++);
        if (!initExpr)
        {
            const char* structName =
                (structDecl->getName() ? structDecl->getName()->text.begin() : "unknown");
            StringBuilder msg;
            msg << "Fail to synthesize the member initialize constructor for struct '" << structName
                << "', the parameter list doesn't match the member list.";
            SLANG_ABORT_COMPILATION(msg.produceString().begin());
        }
    }

    auto assign = createMemberAssignmentExpr(thisExpr, ctor->ownedScope, varDeclBase, initExpr);
    if (!assign)
        return;

    auto stmt = m_astBuilder->create<ExpressionStmt>();
    stmt->expression = assign;
    stmt->loc = varDeclBase->loc;

    Expr* checkedMemberVarExpr;
    if (cachedDeclToCheckedVar.containsKey(varDeclBase))
        checkedMemberVarExpr = cachedDeclToCheckedVar[varDeclBase];
    else
    {
        checkedMemberVarExpr = CheckTerm(assign->left);
        cachedDeclToCheckedVar.add({varDeclBase, checkedMemberVarExpr});
    }

    seqStmtChild->stmts.add(stmt);
}

void SemanticsDeclBodyVisitor::synthesizeCtorBody(
    DeclAndCtorInfo& structDeclInfo,
    List<DeclAndCtorInfo>& inheritanceDefaultCtorList,
    StructDecl* structDecl)
{
    Dictionary<Decl*, Expr*> cachedDeclToCheckedVar;
    for (auto ctor : structDeclInfo.ctorList)
    {
        auto seqStmt = _ensureCtorBodyIsSeqStmt(m_astBuilder, ctor);
        auto seqStmtChild = m_astBuilder->create<SeqStmt>();

        ThisExpr* thisExpr = m_astBuilder->create<ThisExpr>();
        thisExpr->scope = ctor->ownedScope;
        thisExpr->type = ctor->returnType.type;

        // We treat the ctor with parameters and all parameters have default value as default ctor
        // as well, but the method to synthesize them are totally different, therefore, we need to
        // differentiate them here.
        bool isMemberInitCtor =
            ctor->containsFlavor(ConstructorDecl::ConstructorFlavor::SynthesizedMemberInit);

        // When we synthesize the member initialize constructor, we need to use the parameters in
        // the function body, so this inout parameter is used to keep track of the index of the
        // parameters.
        Index ioParamIndex = 0;

        // The first step is to synthesize the initialization of the base member.
        synthesizeCtorBodyForBases(
            ctor,
            inheritanceDefaultCtorList,
            thisExpr,
            seqStmtChild,
            isMemberInitCtor,
            ioParamIndex);

        // Then synthesize the initialization of the other members.
        for (auto directMemberVarDecl : structDecl->getDirectMemberDeclsOfType<VarDeclBase>())
        {
            synthesizeCtorBodyForMemberVar(
                ctor,
                directMemberVarDecl,
                thisExpr,
                cachedDeclToCheckedVar,
                seqStmtChild,
                isMemberInitCtor,
                ioParamIndex);
        }

        if (seqStmtChild->stmts.getCount() != 0)
        {
            seqStmt->stmts.insert(0, seqStmtChild);
        }
    }
}

void SemanticsDeclBodyVisitor::visitAggTypeDecl(AggTypeDecl* aggTypeDecl)
{
    if (aggTypeDecl->hasTag(TypeTag::Incomplete) && aggTypeDecl->hasModifier<HLSLExportModifier>())
    {
        getSink()->diagnose(Diagnostics::CannotExportIncompleteType{.decl = aggTypeDecl});
    }

    auto structDecl = as<StructDecl>(aggTypeDecl);
    if (!structDecl)
        return;

    List<DeclAndCtorInfo> inheritanceDefaultCtorList{};
    for (auto inheritanceMember : structDecl->getMembersOfType<InheritanceDecl>())
    {
        auto declRefType = as<DeclRefType>(inheritanceMember->base.type);
        if (!declRefType)
            continue;
        auto structOfInheritance = as<StructDecl>(declRefType->getDeclRef().getDecl());
        if (!structOfInheritance)
            continue;
        inheritanceDefaultCtorList.add(
            DeclAndCtorInfo(m_astBuilder, this, structOfInheritance, declRefType, true));
    }
    DeclAndCtorInfo structDeclInfo = DeclAndCtorInfo(
        m_astBuilder,
        this,
        structDecl,
        calcThisType(makeDeclRef(structDecl)),
        false);

    // ensure all varDecl members are processed up to SemanticsBodyVisitor so we can be sure that if
    // init expressions of members are to be synthisised, they are.
    bool isDefaultInitializableType = isSubtype(
        DeclRefType::create(m_astBuilder, structDecl),
        m_astBuilder->getDefaultInitializableType(),
        IsSubTypeOptions::None);
    for (auto varDeclBase : structDecl->getDirectMemberDeclsOfType<VarDeclBase>())
    {
        ensureDecl(varDeclBase->getDefaultDeclRef(), DeclCheckState::DefaultConstructorReadyForUse);
        if (!isDefaultInitializableType || varDeclBase->initExpr)
            continue;
        varDeclBase->initExpr = constructDefaultInitExprForType(this, varDeclBase);
    }

    synthesizeCtorBody(structDeclInfo, inheritanceDefaultCtorList, structDecl);

    if (structDeclInfo.defaultCtor)
    {
        auto seqStmt = as<SeqStmt>(as<BlockStmt>(structDeclInfo.defaultCtor->body)->body);
        if (seqStmt && seqStmt->stmts.getCount() == 0)
        {
            structDecl
                ->_removeDirectMemberConstructorDeclBecauseSynthesizedAnotherDefaultConstructorInstead(
                    structDeclInfo.defaultCtor);
        }
    }
}

Stmt* SemanticsVisitor::maybeParseStmt(Stmt* stmt, const SemanticsContext& context)
{
    if (auto unparsedStmt = as<UnparsedStmt>(stmt))
    {
        // Parse the statement now, and check it.
        SemanticsVisitor subVisitor(context);
        TokenList tokenList;
        tokenList.m_tokens = _Move(unparsedStmt->tokens);
        return parseUnparsedStmt(
            m_astBuilder,
            &subVisitor,
            getShared()->getTranslationUnitRequest(),
            unparsedStmt->sourceLanguage,
            tokenList,
            getShared()->getSink(),
            unparsedStmt->currentScope,
            unparsedStmt->outerScope);
    }
    return stmt;
}

void SemanticsDeclHeaderVisitor::cloneModifiers(Decl* dest, Decl* src)
{
    dest->modifiers = src->modifiers;
}
void SemanticsDeclHeaderVisitor::setFuncTypeIntoRequirementDecl(
    CallableDecl* decl,
    FuncType* funcType)
{
    if (!funcType)
        return;
    decl->returnType.type = funcType->getResultType();
    decl->errorType.type = funcType->getErrorType();
    for (Index i = 0; i < funcType->getParamCount(); i++)
    {
        auto paramInfo = funcType->getParamInfo(i);
        auto paramType = paramInfo.type;
        auto paramDir = paramInfo.mode;

        auto param = m_astBuilder->create<ParamDecl>();
        param->type.type = paramType;
        addModifiersForParamPassingMode(m_astBuilder, param, paramDir);
        decl->addMember(param);
    }
}

DeclaredSubtypeWitness* SemanticsVisitor::getThisTypeWitness(
    ASTBuilder* astBuilder,
    DeclRef<InterfaceDecl> inDeclRef)
{
    //
    // Find the this-type & this-type-witness for a given interface decl-ref.
    // This is a bit hacky, but works.
    //

    auto interfaceDeclRef =
        createDefaultSubstitutionsIfNeeded(astBuilder, this, inDeclRef.getDecl())
            .as<InterfaceDecl>();
    auto interfaceType = DeclRefType::create(astBuilder, interfaceDeclRef);
    auto thisType = this->calcThisType(interfaceDeclRef);
    auto thisTypeConstraint = as<DeclRefType>(thisType)
                                  ->getDeclRef()
                                  .as<ThisTypeDecl>()
                                  .getDecl()
                                  ->getMembersOfType<ThisTypeConstraintDecl>()
                                  .getFirst();
    auto thisTypeConstraintRef = createDefaultSubstitutionsIfNeeded(
        astBuilder,
        this,
        thisTypeConstraint->getDefaultDeclRef());

    auto declaredSubtypeWitness = astBuilder->getOrCreate<DeclaredSubtypeWitness>(
        thisType,
        interfaceType,
        thisTypeConstraintRef);

    return as<DeclaredSubtypeWitness>(
        declaredSubtypeWitness->substitute(astBuilder, SubstitutionSet(inDeclRef)));
}

DeclRef<Decl> SemanticsVisitor::getRequirementAsLookedUpDecl(ASTBuilder* astBuilder, Decl* decl)
{
    // Returns an interface requirement as a lookup decl-ref on the ThisType of the
    // parent interface.
    //
    auto declRef = createDefaultSubstitutionsIfNeeded(astBuilder, this, decl->getDefaultDeclRef());


    // Go find the this-type & this-type-witness manually for now. (TODO: This is a hack..)

    auto interfaceDeclRef = createDefaultSubstitutionsIfNeeded(
                                astBuilder,
                                this,
                                findParentInterfaceDecl(declRef.getDecl()))
                                .as<InterfaceDecl>();
    auto interfaceType = DeclRefType::create(astBuilder, interfaceDeclRef);
    auto thisType = this->calcThisType(interfaceDeclRef);
    auto thisTypeConstraint = as<DeclRefType>(thisType)
                                  ->getDeclRef()
                                  .as<ThisTypeDecl>()
                                  .getDecl()
                                  ->getMembersOfType<ThisTypeConstraintDecl>()
                                  .getFirst();
    auto thisTypeConstraintRef = createDefaultSubstitutionsIfNeeded(
        astBuilder,
        this,
        thisTypeConstraint->getDefaultDeclRef());

    auto declaredSubtypeWitness = astBuilder->getOrCreate<DeclaredSubtypeWitness>(
        thisType,
        interfaceType,
        thisTypeConstraintRef);


    // Add substitution args for each parent generic container up until we hit the interface
    // decl. This will form the full reference to the function as a lookup on itself.
    //

    List<GenericDecl*> genericParentDecls;
    for (auto dd = decl->parentDecl; dd != interfaceDeclRef.getDecl(); dd = dd->parentDecl)
    {
        if (auto genericParentDecl = as<GenericDecl>(dd))
        {
            genericParentDecls.add(genericParentDecl);
        }
    }

    DeclRef<Decl> lookupDeclRef;
    if (genericParentDecls.getCount() == 0)
    {
        lookupDeclRef = astBuilder->getLookupDeclRef(declaredSubtypeWitness, decl);
    }
    else
    {
        // Lookup outer-most generic.
        lookupDeclRef =
            astBuilder->getLookupDeclRef(declaredSubtypeWitness, genericParentDecls.getLast());

        // Specialize repeatedly until we reach the innermost decl.
        for (Index i = genericParentDecls.getCount() - 1; i >= 0; i--)
        {
            auto args = getDefaultSubstitutionArgs(astBuilder, this, genericParentDecls[i]);
            Decl* innerDecl = nullptr;
            if (i == 0 && decl->isChildOf(genericParentDecls[i]))
            {
                // Accessors belong to their storage declaration, not directly to the generic
                // environment. Consider this example:
                //
                //     interface ITensor<T, int D>
                //     {
                //         __subscript<each TIndex>(TIndex indices)
                //             where TIndex == int
                //             where countof(TIndex) == D
                //         {
                //             [Differentiable]
                //             get { return load(indices); }
                //         }
                //     }
                //
                // The getter requirement is therefore represented as a member lookup on the
                // specialized subscript:
                // `MemberDeclRef(GenericAppDeclRef(Lookup(This, operator[]), T), get)`.
                // `MemberDeclRef::resolve` can then remap the accessor after the subscript
                // lookup resolves through the witness table entry installed by
                // `doesSubscriptMatchRequirement`.
                if (as<AccessorDecl>(decl))
                    innerDecl = decl->parentDecl;
                else
                    innerDecl = decl;
            }
            lookupDeclRef = astBuilder->getGenericAppDeclRef(
                lookupDeclRef.as<GenericDecl>(),
                args.getArrayView(),
                innerDecl);
        }
    }

    if (lookupDeclRef.getDecl() != decl)
    {
        if (as<AccessorDecl>(decl))
        {
            // If it's an accessor, then the lookup would be referring to the parent
            // subscript-decl. We just need to access the member.
            //
            lookupDeclRef = astBuilder->getMemberDeclRef(lookupDeclRef, decl);
        }
        else
        {
            SLANG_UNEXPECTED("Unhandled case for constructing a lookup decl-ref for a requirement");
        }
    }

    return lookupDeclRef;
}

static DeclRef<SynthesizedFuncDecl> addSynthesizedFunc(
    SemanticsVisitor* visitor,
    ContainerDecl* parentDecl,
    Name* name,
    IROp opCode,
    List<DeclRefBase*> operands,
    FuncType* targetFuncType,
    bool isStatic,
    DeclVisibility visibility,
    SourceLoc sourceLoc = SourceLoc())
{
    auto astBuilder = getCurrentASTBuilder();
    auto synthesizedLoc = sourceLoc.isValid() ? sourceLoc : getDiagnosticPos(parentDecl);

    auto synFunc = astBuilder->create<SynthesizedFuncDecl>();
    synFunc->parentDecl = parentDecl;
    synFunc->loc = synthesizedLoc;
    synFunc->nameAndLoc.loc = synthesizedLoc;
    visitor->addVisibilityModifier(synFunc, visibility);

    for (auto operand : operands)
    {
        synFunc->operands.add(operand);
    }
    synFunc->irOp = opCode;
    synFunc->nameAndLoc.name = name;

    List<Expr*> synArgs;
    populateParams(getCurrentASTBuilder(), synFunc, targetFuncType, synArgs);
    synFunc->returnType.type = targetFuncType->getResultType();

    if (isStatic)
        addModifier(synFunc, astBuilder->create<HLSLStaticModifier>());

    parentDecl->addMember(synFunc);

    return synFunc;
}

static List<GenericDecl*> getOuterGenericDecls(Decl* decl)
{
    List<GenericDecl*> outerGenericDecls;
    for (auto ancestor = decl->parentDecl; ancestor; ancestor = ancestor->parentDecl)
    {
        if (auto genericParentDecl = as<GenericDecl>(ancestor))
        {
            outerGenericDecls.add(genericParentDecl);
        }
    }

    // Return the list in reverse order so that the outermost generic is first.
    outerGenericDecls.reverse();

    return outerGenericDecls;
}

static DeclRef<SynthesizedStructDecl> addOrExtendSynthesizedStruct(
    SemanticsVisitor* visitor,
    ContainerDecl* parentDecl,
    Name* name,
    IROp opCode,
    List<DeclRefBase*> operands,
    List<Type*> conformances,
    DeclVisibility structVisibility,
    DeclVisibility aliasVisibility,
    SourceLoc sourceLoc = SourceLoc(),
    String nameSuffix = String())
{
    auto astBuilder = getCurrentASTBuilder();
    auto synthesizedLoc = sourceLoc.isValid() ? sourceLoc : getDiagnosticPos(parentDecl);

    auto irInfo = getIROpInfo(opCode);
    auto mangledName = visitor->getName(
        "$__syn_" + String(irInfo.name) + "_" +
        getMangledName(getCurrentASTBuilder(), operands[0]) + nameSuffix);

    DeclRef<SynthesizedStructDecl> synStructDeclRef;

    // Do we already have a syn-struct that we created with this name?
    auto lookupResult =
        lookUp(astBuilder, visitor, mangledName, visitor->getOuterScope(), LookupMask::type);
    lookupResult = visitor->resolveOverloadedLookup(lookupResult);
    if (lookupResult.isValid() && !lookupResult.isOverloaded())
    {
        SynthesizedStructDecl* synStruct =
            as<SynthesizedStructDecl>(lookupResult.item.declRef.getDecl());
        SLANG_ASSERT(synStruct);

        // generic parents of the extension
        List<GenericDecl*> extGenericDecls = getOuterGenericDecls(parentDecl);

        // generic parents of the struct
        List<GenericDecl*> synStructGenericDecls = getOuterGenericDecls(synStruct);

        SLANG_ASSERT(extGenericDecls.getCount() == synStructGenericDecls.getCount());

        DeclRefBase* newDeclRef = nullptr;
        for (Index i = 0; i < (Index)synStructGenericDecls.getCount(); i++)
        {
            auto genericDecl = synStructGenericDecls[i];
            auto origGenericDecl = extGenericDecls[i];
            auto substArgs = getDefaultSubstitutionArgs(astBuilder, visitor, origGenericDecl);
            newDeclRef = getCurrentASTBuilder()->getGenericAppDeclRef(
                newDeclRef ? newDeclRef : genericDecl->getDefaultDeclRef(),
                substArgs.getArrayView(),
                genericDecl->inner);
        }

        synStructDeclRef = DeclRef<SynthesizedStructDecl>(
            newDeclRef ? newDeclRef : synStruct->getDefaultDeclRef());

        // Insert missing conformances
        // TODO: Maybe speed up? (but we really only expect 1 or 2 conformances at most)
        for (auto conformance : conformances)
        {
            // Check if the synthesized struct already has this conformance.
            bool hasConformance = false;
            for (auto existingInheritanceDecl :
                 getMembersOfType<InheritanceDecl>(astBuilder, synStructDeclRef))
            {
                auto supType = getSup(astBuilder, existingInheritanceDecl);
                if (supType == conformance)
                {
                    hasConformance = true;
                    break;
                }
            }

            if (!hasConformance)
            {
                for (Index i = 0; i < (Index)extGenericDecls.getCount(); i++)
                {
                    auto genericDecl = synStructGenericDecls[i];
                    auto origGenericDecl = extGenericDecls[i];
                    auto substArgs = getDefaultSubstitutionArgs(astBuilder, visitor, genericDecl);
                    auto genericSubst =
                        SubstitutionSet(getCurrentASTBuilder()->getGenericAppDeclRef(
                            origGenericDecl->getDefaultDeclRef(),
                            substArgs.getArrayView(),
                            origGenericDecl->inner));

                    conformance = as<Type>(conformance->substitute(astBuilder, genericSubst));
                }

                auto inheritanceDecl = astBuilder->create<InheritanceDecl>();
                inheritanceDecl->loc = synthesizedLoc;
                inheritanceDecl->base.type = conformance;
                synStruct->addMember(inheritanceDecl);
            }
        }
    }
    else if (lookupResult.isOverloaded())
    {
        SLANG_UNEXPECTED("Multiple conflicting structs for the same synthesized struct name.");
    }
    else
    {
        // Base case: we'll create a new struct & repeatedly clone any generic parent decls.

        auto synStruct = astBuilder->create<SynthesizedStructDecl>();
        synStruct->nameAndLoc.name = mangledName;
        synStruct->loc = synthesizedLoc;
        synStruct->nameAndLoc.loc = synthesizedLoc;
        visitor->addVisibilityModifier(synStruct, structVisibility);

        synStruct->parentDecl = parentDecl;
        SubstitutionSet substSet;
        synStructDeclRef =
            visitor->liftDeclFromGenericContainers(synStruct, substSet).as<SynthesizedStructDecl>();

        for (auto operand : operands)
            synStruct->operands.add(substituteDeclRef(substSet, astBuilder, operand));
        synStruct->irOp = opCode;

        for (auto conformance : conformances)
        {
            auto inheritanceDecl = astBuilder->create<InheritanceDecl>();
            inheritanceDecl->loc = synthesizedLoc;
            inheritanceDecl->base.type = substituteType(substSet, astBuilder, conformance);
            synStruct->addMember(inheritanceDecl);
        }

        Decl* outermostDecl = synStruct;
        while (outermostDecl->parentDecl && !as<ModuleDecl>(outermostDecl->parentDecl))
        {
            outermostDecl = outermostDecl->parentDecl;
        }

        getModuleDecl(parentDecl)->addMember(outermostDecl);
    }


    auto synContextTypeAliasDecl = astBuilder->create<TypeAliasDecl>();
    synContextTypeAliasDecl->nameAndLoc.name = name;
    synContextTypeAliasDecl->loc = synthesizedLoc;
    synContextTypeAliasDecl->nameAndLoc.loc = synthesizedLoc;
    visitor->addVisibilityModifier(synContextTypeAliasDecl, aliasVisibility);
    auto synStructType = DeclRefType::create(astBuilder, synStructDeclRef);
    synContextTypeAliasDecl->type.type = synStructType;

    // Add an alias decl to the parent declaration.
    parentDecl->addMember(synContextTypeAliasDecl);

    return synStructDeclRef;
}

// Takes two declarations with equivalent generic signatures and returns a decl-ref of
// "decl" with the parameters defined in fromDecl.
//
static DeclRef<Decl> buildQualifiedReference(SemanticsVisitor* visitor, Decl* decl, Decl* fromDecl)
{
    List<GenericDecl*> genericDecls = getOuterGenericDecls(decl);
    List<GenericDecl*> fromGenericDecls = getOuterGenericDecls(fromDecl);

    SLANG_ASSERT(genericDecls.getCount() == fromGenericDecls.getCount());

    auto astBuilder = getCurrentASTBuilder();

    DeclRef<Decl> declRef =
        createDefaultSubstitutionsIfNeeded(astBuilder, visitor, decl->getDefaultDeclRef());
    for (Index i = 0; i < (Index)genericDecls.getCount(); i++)
    {
        auto genericDecl = fromGenericDecls[i];
        auto origGenericDecl = genericDecls[i];
        auto substArgs = getDefaultSubstitutionArgs(astBuilder, visitor, genericDecl);
        auto genericSubst = SubstitutionSet(getCurrentASTBuilder()->getGenericAppDeclRef(
            origGenericDecl->getDefaultDeclRef(),
            substArgs.getArrayView(),
            origGenericDecl->inner));
        declRef = substituteDeclRef(genericSubst, astBuilder, declRef);
    }

    return declRef;
}

static Decl* _moveInterfaceDifferentiabilityRequirementToInterface(
    SemanticsVisitor* visitor,
    InterfaceDecl* interfaceDecl,
    CallableDecl* requirementDecl,
    GenericTypeConstraintDecl* constraintDecl,
    DeclRef<Decl>& ioCallableRequirementDeclRef)
{
    // Consider this example:
    //
    //     interface IFoo
    //     {
    //         [Differentiable]
    //         void f<T>(T value);
    //     }
    //
    // The annotation is a separate interface requirement about `This.f<T>`, but the synthesized
    // requirement type initially mentions `f`'s generic environment. Start the constraint under the
    // callable/accessor that owns that environment and let `liftDeclFromGenericContainers` hoist it
    // into a standalone generic requirement under the interface when needed. Non-generic callables
    // take the same path, but no generic wrappers are cloned. We only set `parentDecl` here instead
    // of appending to the callable's direct member list because the declaration is immediately
    // moved; leaving it in the callable member list would give the AST two owners for the same
    // requirement.
    constraintDecl->parentDecl = requirementDecl;
    SubstitutionSet declSubst;
    visitor->liftDeclFromGenericContainers(constraintDecl, declSubst, interfaceDecl);

    ioCallableRequirementDeclRef =
        substituteDeclRef(declSubst, visitor->getASTBuilder(), ioCallableRequirementDeclRef);

    Decl* outermostDecl = constraintDecl;
    while (outermostDecl->parentDecl && outermostDecl->parentDecl != interfaceDecl)
        outermostDecl = outermostDecl->parentDecl;

    return outermostDecl;
}

static bool _callableHasDifferentiabilityHeaderModifier(CallableDecl* decl)
{
    return decl->findModifier<DifferentiableAttribute>() ||
           decl->findModifier<MaybeDifferentiableAttribute>();
}

void SemanticsDeclHeaderVisitor::checkDifferentiableCallableSignature(CallableDecl* decl)
{
    // TODO: Need to make this not depend on the attribute, but rather on differentiability
    // in general..
    //
    if (decl->findModifier<DifferentiableAttribute>())
    {
        // Add `no_diff` modifiers to parameters.
        // This is necessary to preserve no-diff-ness for generic function before and after
        // specialization.
        for (auto paramDeclRef : getParametersForCallableSignature(m_astBuilder, makeDeclRef(decl)))
        {
            auto paramDecl = paramDeclRef.getDecl();
            if (!paramDecl->type.type)
                continue;
            if (!isTypeDifferentiable(paramDecl->type.type))
            {
                if (!paramDecl->hasModifier<NoDiffModifier>())
                {
                    auto noDiffModifier = m_astBuilder->create<NoDiffModifier>();
                    noDiffModifier->keywordName = getSession()->getNameObj("no_diff");
                    addModifier(paramDecl, noDiffModifier);
                }
            }
            if (!paramDecl->hasModifier<NoDiffModifier>())
            {
                // This is intentionally a restriction on an explicitly written `borrow`
                // modifier, not on the parameter's effective mode. A non-copyable declared type
                // can adjust an ordinary `in` parameter to `BorrowIn`; that declaration-derived
                // mode is valid here and must remain stable under specialization.
                if (auto modifier = paramDecl->findModifier<BorrowModifier>())
                {
                    getSink()->diagnose(Diagnostics::CannotUseBorrowInOnDifferentiableParameter{
                        .modifier = modifier});
                }
            }
        }

        // Handle return type non-differentiability
        if (decl->returnType.type && decl->returnType.type != m_astBuilder->getVoidType())
        {
            if (!isTypeDifferentiable(decl->returnType.type))
            {
                if (auto modifiedType = as<ModifiedType>(decl->returnType.type))
                {
                    if (!modifiedType->findModifier<NoDiffModifierVal>())
                    {
                        List<Val*> existingModifiers;
                        for (Index i = 0; i < (Index)modifiedType->getModifierCount(); i++)
                        {
                            existingModifiers.add(modifiedType->getModifier(i));
                        }
                        existingModifiers.add(m_astBuilder->getOrCreate<NoDiffModifierVal>());
                        decl->returnType.type = m_astBuilder->getModifiedType(
                            modifiedType->getBase(),
                            existingModifiers);
                    }
                }
                else
                {
                    decl->returnType.type = m_astBuilder->getModifiedType(
                        decl->returnType.type,
                        m_astBuilder->getOrCreate<NoDiffModifierVal>());
                }
            }
        }
    }
}

static Modifier* _findUnsupportedDifferentiableThisParamModeAttribute(Decl* decl)
{
    // This diagnostic is a restriction on the declaration's source spelling, not a query for its
    // effective mode. Preserve the established ConstRef-before-Ref choice even when another
    // attribute, such as `[mutating]`, takes precedence when the effective mode is computed.
    if (auto attribute = decl->findModifier<ConstRefAttribute>())
        return attribute;
    if (auto attribute = decl->findModifier<RefAttribute>())
        return attribute;
    return nullptr;
}

void SemanticsDeclHeaderVisitor::synthesizeDifferentiabilityRequirements(CallableDecl* decl)
{
    // Generate extensions for this function decl that implement
    // the auto-diff interfaces via synthesized declarations.
    //
    // extension __func_as_type(decl) : IForwardDifferentiable<__func_as_type(decl)>
    // { /* ..empty.. */ }
    // and
    // extension __func_as_type(decl) : IBackwardDifferentiable<__func_as_type(decl)>
    // { /* ..empty.. */ }
    //
    // For each mode, `__func_as_type(decl)` must have exactly one conformance to the derivative
    // interface: either the synthesized extension here, or the one that
    // `translateFwdDerivativeAttributeToAD2` / `translateBwdDerivativeAttributeToAD2` creates later
    // (at `ReadyForLookup`) from a `[ForwardDerivative]` / `[BackwardDerivative]` on the decl.
    // Two conformances of the same function type to the same interface get the same witness-table
    // linkage name in `visitInheritanceDecl`, and the linker keeps only one of them, so calls
    // through an interface requirement could silently use the synthesized derivative instead of the
    // user's. We therefore skip the synthesized extension for a mode whose attribute is present.
    // For the forward mode, that also skips the synthesized higher-order conformances of
    // `fwd_diff`; a differentiable user derivative provides them instead.
    //
    // The guard only sees attributes on the decl itself. A derivative attached from the other side
    // with `[ForwardDerivativeOf]` / `[BackwardDerivativeOf]`, or one a `[Differentiable]` decl
    // gets through `[PrimalSubstitute]`, is not visible here, so those spellings can still produce
    // both conformances.
    //

    if (decl->findModifier<DifferentiableAttribute>())
    {
        // Signature checking has already recorded the declaration's effective receiver ABI. Use
        // that checked result to decide whether this differentiability restriction applies. In
        // particular, a non-copyable receiver may have `BorrowIn` mode without a `[constref]`
        // attribute, and an extension on a callable may inherit the target callable's mode.
        if (auto thisParamInfo = findEffectiveThisParamInfo(getDefaultDeclRef(decl)))
        {
            if (auto attribute = _findUnsupportedDifferentiableThisParamModeAttribute(decl))
            {
                if (isTypeDifferentiable(unwrapModifiedType(thisParamInfo->type)))
                {
                    getSink()->diagnose(Diagnostics::CannotUseConstrefOnDifferentiableMemberMethod{
                        .attr = attribute});
                }
            }
        }
    }

    if (as<FunctionDeclBase>(decl))
    {
        auto getFuncAsTypeForDecl = [&](FunctionDeclBase* funcDecl) -> DeclRefType*
        {
            auto specializedFuncDeclRef = createDefaultSubstitutionsIfNeeded(
                m_astBuilder,
                this,
                funcDecl->getDefaultDeclRef());
            return as<DeclRefType>(DeclRefType::create(m_astBuilder, specializedFuncDeclRef));
        };
        if (!isInterfaceRequirement(decl))
        {
            if ((decl->findModifier<ForwardDifferentiableAttribute>() ||
                 decl->findModifier<BackwardDifferentiableAttribute>()) &&
                !decl->findModifier<ForwardDerivativeAttribute>())
            {
                auto declsToExtend = ShortList<FunctionDeclBase*, 4>{as<FunctionDeclBase>(decl)};
                for (auto _decl : getCurrentASTBuilder()->m_substituteMap[decl])
                    declsToExtend.add(as<FunctionDeclBase>(_decl));

                for (auto _decl : declsToExtend)
                {
                    auto funcAsTypeForDecl = getFuncAsTypeForDecl(_decl);
                    auto visibility = getDeclVisibility(_decl);
                    auto synthesizedVisibility = getSynthesizedExtensionVisibility(visibility);
                    SubstitutionSet substSet;
                    auto fwdDiffExtension = extendContainerDecl(
                        this,
                        _decl,
                        getForwardDiffFuncInterfaceType(funcAsTypeForDecl),
                        substSet,
                        synthesizedVisibility.extensionVisibility);


                    auto funcAsTypeFromExtension = as<DeclRefType>(
                        funcAsTypeForDecl->substitute(getCurrentASTBuilder(), substSet));
                    auto synFuncDeclRef = addSynthesizedFunc(
                        this,
                        fwdDiffExtension.getDecl(),
                        getName("fwd_diff"),
                        kIROp_ForwardDifferentiate,
                        {funcAsTypeFromExtension->getDeclRefBase()},
                        getCalculatedDiffFuncType("FwdDiffFuncType", funcAsTypeFromExtension),
                        true,
                        synthesizedVisibility.memberVisibility);

                    // Add in a conformance for "fwdDiffFunc : IForwardDifferentiable<fwdDiffFunc>"
                    // for higher-order differentiation.
                    //
                    {
                        auto synFuncType =
                            DeclRefType::create(getCurrentASTBuilder(), synFuncDeclRef);

                        auto fwdDiffFuncAsType = getForwardDiffFuncInterfaceType(synFuncType);
                        auto higherOrderFwdDiffExtension = extendContainerDecl(
                            this,
                            synFuncDeclRef.getDecl(),
                            fwdDiffFuncAsType,
                            substSet,
                            synthesizedVisibility.extensionVisibility,
                            SourceLoc(),
                            kIROp_SynthesizedForwardDerivativeWitnessTable);
                        this->ensureDecl(
                            higherOrderFwdDiffExtension,
                            DeclCheckState::ReadyForLookup);
                    }

                    // Add in a conformance for "fwdDiffFunc : IBackwardDifferentiable<fwdDiffFunc>"
                    // for higher-order differentiation.
                    //
                    {
                        auto fwdDiffFuncAsType = getBackwardDiffFuncInterfaceType(
                            DeclRefType::create(getCurrentASTBuilder(), synFuncDeclRef));
                        auto higherOrderBwdDiffExtension = extendContainerDecl(
                            this,
                            synFuncDeclRef.getDecl(),
                            fwdDiffFuncAsType,
                            substSet,
                            synthesizedVisibility.extensionVisibility,
                            SourceLoc(),
                            kIROp_SynthesizedBackwardDerivativeWitnessTable);
                        this->ensureDecl(
                            higherOrderBwdDiffExtension,
                            DeclCheckState::ReadyForLookup);
                    }

                    this->ensureDecl(fwdDiffExtension.getDecl(), DeclCheckState::ReadyForLookup);
                }
            }

            if (decl->findModifier<BackwardDifferentiableAttribute>() &&
                !decl->findModifier<BackwardDerivativeAttribute>())
            {
                auto declsToExtend = ShortList<FunctionDeclBase*, 4>{as<FunctionDeclBase>(decl)};
                for (auto _decl : getCurrentASTBuilder()->m_substituteMap[decl])
                    declsToExtend.add(as<FunctionDeclBase>(_decl));

                for (auto _decl : declsToExtend)
                {
                    SLANG_ASSERT(_decl);
                    auto funcAsTypeForDecl = getFuncAsTypeForDecl(_decl);

                    auto visibility = getDeclVisibility(_decl);
                    auto synthesizedVisibility = getSynthesizedExtensionVisibility(visibility);
                    SubstitutionSet substSet;
                    auto bwdDiffExtension = extendContainerDecl(
                        this,
                        _decl,
                        getBackwardDiffFuncInterfaceType(funcAsTypeForDecl),
                        substSet,
                        synthesizedVisibility.extensionVisibility);
                    auto funcAsTypeFromExtension = as<DeclRefType>(
                        funcAsTypeForDecl->substitute(getCurrentASTBuilder(), substSet));

                    auto synContextStruct = addOrExtendSynthesizedStruct(
                        this,
                        bwdDiffExtension.getDecl(),
                        getName("BwdCallable"),
                        kIROp_BackwardDiffIntermediateContextType,
                        {funcAsTypeFromExtension->getDeclRefBase()},
                        {getBwdCallableBaseType(funcAsTypeFromExtension)},
                        synthesizedVisibility.extensionVisibility,
                        synthesizedVisibility.memberVisibility);

                    auto synMinimalContextStruct = addOrExtendSynthesizedStruct(
                        this,
                        bwdDiffExtension.getDecl(),
                        getName("MinimalContext"),
                        kIROp_BackwardDiffMinimalContextType,
                        {funcAsTypeFromExtension->getDeclRefBase()},
                        {},
                        synthesizedVisibility.extensionVisibility,
                        synthesizedVisibility.memberVisibility);

                    auto minimalCtxType =
                        DeclRefType::create(getCurrentASTBuilder(), synMinimalContextStruct);
                    auto fullCtxType =
                        DeclRefType::create(getCurrentASTBuilder(), synContextStruct);

                    addSynthesizedFunc(
                        this,
                        bwdDiffExtension.getDecl(),
                        getName("apply_bwd"),
                        kIROp_BackwardDifferentiatePrimal,
                        {funcAsTypeFromExtension->getDeclRefBase()},
                        getCalculatedDiffFuncType(
                            "ApplyForBwdFuncType",
                            funcAsTypeFromExtension,
                            minimalCtxType),
                        false,
                        synthesizedVisibility.memberVisibility);

                    addSynthesizedFunc(
                        this,
                        bwdDiffExtension.getDecl(),
                        getName("remat"),
                        kIROp_BackwardRemat,
                        {funcAsTypeFromExtension->getDeclRefBase()},
                        getCalculatedDiffFuncType(
                            "RematFuncType",
                            funcAsTypeFromExtension,
                            minimalCtxType,
                            fullCtxType),
                        true,
                        synthesizedVisibility.memberVisibility);

                    this->ensureDecl(bwdDiffExtension.getDecl(), DeclCheckState::ReadyForLookup);
                }

                // Technically, we also need to create an 'operator()' function on the
                // BwdCallable, but this gets auto-synthesized during conformance checking,
                // and will always use the same operands as the BwdCallable synthesized
                // struct.
                //
            }

            if (decl->findModifier<TreatAsDifferentiableAttribute>())
            {
                auto declsToExtend = ShortList<FunctionDeclBase*, 4>{as<FunctionDeclBase>(decl)};
                for (auto _decl : getCurrentASTBuilder()->m_substituteMap[decl])
                    declsToExtend.add(as<FunctionDeclBase>(_decl));

                for (auto _decl : declsToExtend)
                {
                    SLANG_ASSERT(_decl);
                    auto funcAsTypeForDecl = getFuncAsTypeForDecl(_decl);

                    auto visibility = getDeclVisibility(_decl);
                    auto synthesizedVisibility = getSynthesizedExtensionVisibility(visibility);
                    SubstitutionSet substSet;
                    auto bwdDiffExtension = extendContainerDecl(
                        this,
                        _decl,
                        getBackwardDiffFuncInterfaceType(funcAsTypeForDecl),
                        substSet,
                        synthesizedVisibility.extensionVisibility);
                    auto funcAsTypeFromExtension = as<DeclRefType>(
                        funcAsTypeForDecl->substitute(getCurrentASTBuilder(), substSet));

                    auto synContextStruct = addOrExtendSynthesizedStruct(
                        this,
                        bwdDiffExtension.getDecl(),
                        getName("BwdCallable"),
                        kIROp_TrivialBackwardDiffIntermediateContextType,
                        {funcAsTypeFromExtension->getDeclRefBase()},
                        {getBwdCallableBaseType(funcAsTypeFromExtension)},
                        synthesizedVisibility.extensionVisibility,
                        synthesizedVisibility.memberVisibility);

                    auto synMinimalContextStruct = addOrExtendSynthesizedStruct(
                        this,
                        bwdDiffExtension.getDecl(),
                        getName("MinimalContext"),
                        kIROp_TrivialBackwardDiffMinimalContextType,
                        {funcAsTypeFromExtension->getDeclRefBase()},
                        {},
                        synthesizedVisibility.extensionVisibility,
                        synthesizedVisibility.memberVisibility);

                    auto minimalCtxType =
                        DeclRefType::create(getCurrentASTBuilder(), synMinimalContextStruct);
                    auto fullCtxType =
                        DeclRefType::create(getCurrentASTBuilder(), synContextStruct);

                    addSynthesizedFunc(
                        this,
                        bwdDiffExtension.getDecl(),
                        getName("apply_bwd"),
                        kIROp_TrivialBackwardDifferentiatePrimal,
                        {funcAsTypeFromExtension->getDeclRefBase()},
                        getCalculatedDiffFuncType(
                            "ApplyForBwdFuncType",
                            funcAsTypeFromExtension,
                            minimalCtxType),
                        false,
                        synthesizedVisibility.memberVisibility);

                    addSynthesizedFunc(
                        this,
                        bwdDiffExtension.getDecl(),
                        getName("remat"),
                        kIROp_TrivialBackwardRemat,
                        {funcAsTypeFromExtension->getDeclRefBase()},
                        getCalculatedDiffFuncType(
                            "RematFuncType",
                            funcAsTypeFromExtension,
                            minimalCtxType,
                            fullCtxType),
                        true,
                        synthesizedVisibility.memberVisibility);

                    this->ensureDecl(bwdDiffExtension.getDecl(), DeclCheckState::ReadyForLookup);
                }
            }

            if (decl->findModifier<TreatAsDifferentiableAttribute>() ||
                decl->findModifier<HasTrivialForwardDerivativeAttribute>())
            {
                auto declsToExtend = ShortList<FunctionDeclBase*, 4>{as<FunctionDeclBase>(decl)};
                for (auto _decl : getCurrentASTBuilder()->m_substituteMap[decl])
                    declsToExtend.add(as<FunctionDeclBase>(_decl));

                for (auto _decl : declsToExtend)
                {
                    auto funcAsTypeForDecl = getFuncAsTypeForDecl(_decl);
                    auto visibility = getDeclVisibility(_decl);
                    auto synthesizedVisibility = getSynthesizedExtensionVisibility(visibility);
                    SubstitutionSet substSet;
                    auto fwdDiffExtension = extendContainerDecl(
                        this,
                        _decl,
                        getForwardDiffFuncInterfaceType(funcAsTypeForDecl),
                        substSet,
                        synthesizedVisibility.extensionVisibility);

                    auto funcAsTypeFromExtension = as<DeclRefType>(
                        funcAsTypeForDecl->substitute(getCurrentASTBuilder(), substSet));
                    addSynthesizedFunc(
                        this,
                        fwdDiffExtension.getDecl(),
                        getName("fwd_diff"),
                        kIROp_TrivialForwardDifferentiate,
                        {funcAsTypeFromExtension->getDeclRefBase()},
                        getCalculatedDiffFuncType("FwdDiffFuncType", funcAsTypeFromExtension),
                        true,
                        synthesizedVisibility.memberVisibility);

                    this->ensureDecl(fwdDiffExtension.getDecl(), DeclCheckState::ReadyForLookup);
                }
            }
        }
        else
        {
            //
            // Is an interface requirement. Insert differentiability constraints as sibling
            // interface requirements.
            //

            auto funcAsLookupDeclRef = getRequirementAsLookedUpDecl(getCurrentASTBuilder(), decl);

            auto interfaceDecl = findParentInterfaceDecl(decl);
            SLANG_ASSERT(interfaceDecl);
            auto addDifferentiabilityRequirementConstraint =
                [&](bool isBackwardDifferentiabilityRequirement, bool isOptional)
            {
                auto requirementDeclRef = funcAsLookupDeclRef;
                auto constraintDecl = getCurrentASTBuilder()->create<FuncConstraintDecl>();
                constraintDecl->loc = decl->loc;

                auto interfaceMemberDecl = _moveInterfaceDifferentiabilityRequirementToInterface(
                    this,
                    interfaceDecl,
                    decl,
                    constraintDecl,
                    requirementDeclRef);

                // A differentiability annotation on an interface requirement is itself an
                // interface requirement: `This.f : IForward/BackwardDifferentiable<This.f>`.
                // Keep that fact as a sibling requirement, the same way constraints on
                // associated types are sibling requirements about `This.A`. For generic
                // callables, the hoist helper above moved the constraint under a standalone clone
                // of the callable's generic signature, so `This.f<T>` references parameters owned
                // by this requirement rather than by the callable declaration.
                auto funcAsLookupType =
                    DeclRefType::create(getCurrentASTBuilder(), requirementDeclRef);
                constraintDecl->callableRequirementDeclRef = requirementDeclRef.as<CallableDecl>();
                auto differentiabilityInterfaceType =
                    isBackwardDifferentiabilityRequirement
                        ? getBackwardDiffFuncInterfaceType(funcAsLookupType)
                        : getForwardDiffFuncInterfaceType(funcAsLookupType);

                auto typeExpr = getCurrentASTBuilder()->create<SharedTypeExpr>();
                typeExpr->loc = decl->loc;
                typeExpr->base.type = funcAsLookupType;
                typeExpr->type = QualType(getCurrentASTBuilder()->getTypeType(funcAsLookupType));

                constraintDecl->sub.type = funcAsLookupType;
                constraintDecl->sub.exp = typeExpr;
                constraintDecl->sup.type = differentiabilityInterfaceType;
                if (isOptional)
                    addModifier(
                        constraintDecl,
                        getCurrentASTBuilder()->create<OptionalConstraintModifier>());

                interfaceDecl->addMember(interfaceMemberDecl);
            };

            if (decl->findModifier<ForwardDifferentiableAttribute>() ||
                decl->findModifier<BackwardDifferentiableAttribute>() ||
                decl->findModifier<MaybeDifferentiableAttribute>())
            {
                auto isOptional = decl->findModifier<MaybeDifferentiableAttribute>() != nullptr;
                addDifferentiabilityRequirementConstraint(false, isOptional);
            }

            if (decl->findModifier<BackwardDifferentiableAttribute>() ||
                decl->findModifier<MaybeDifferentiableAttribute>())
            {
                auto isOptional = decl->findModifier<MaybeDifferentiableAttribute>() != nullptr;
                addDifferentiabilityRequirementConstraint(true, isOptional);
            }
        }
    }
}


void SemanticsDeclHeaderVisitor::checkCallableConstraints(CallableDecl* decl)
{
    for (auto genericTypeConstraint : decl->getMembersOfType<GenericTypeConstraintDecl>())
    {
        // Sub-type _must_ be a reference to this function itself.
        // So we'll just override the sub-type to be a full reference to the function.
        //
        if (isInterfaceRequirement(decl))
        {
            auto lookupFuncDeclRefType = DeclRefType::create(
                m_astBuilder,
                getRequirementAsLookedUpDecl(m_astBuilder, decl).as<CallableDecl>());
            SharedTypeExpr* typeExpr = m_astBuilder->create<SharedTypeExpr>();

            typeExpr->loc = decl->loc;
            typeExpr->base.type = lookupFuncDeclRefType;
            typeExpr->type = QualType(m_astBuilder->getTypeType(lookupFuncDeclRefType));

            genericTypeConstraint->sub.exp = typeExpr;
        }
        else
        {
            getSink()->diagnose(Diagnostics::Unexpected{
                .message = "GenericTypeConstraintDecl on a non-interface function",
                .location = decl->loc});
        }
    }
}

// Return true when a property requirement mixes accessor bodies with body-less accessors.
// Unlike subscripts, properties do not have an `InterfaceDefaultImplDecl` path here, so
// semantic checking owns the targeted diagnostic for this partial-default shape.
static bool isPartialPropertyAccessorDefaultImplementation(AccessorDecl* accessorDecl)
{
    auto propertyDecl = as<PropertyDecl>(accessorDecl->parentDecl);
    if (!propertyDecl)
        return false;

    bool hasAccessorBody = false;
    bool hasAccessorWithoutBody = false;
    for (auto siblingAccessorDecl : propertyDecl->getDirectMemberDeclsOfType<AccessorDecl>())
    {
        if (siblingAccessorDecl->body)
            hasAccessorBody = true;
        else
            hasAccessorWithoutBody = true;
    }

    return hasAccessorBody && hasAccessorWithoutBody;
}

void SemanticsDeclHeaderVisitor::checkInterfaceRequirement(Decl* decl)
{
    if (isInterfaceRequirement(decl))
    {
        if (auto accessorDecl = as<AccessorDecl>(decl))
        {
            // Subscript accessor defaults are handled by the parser's
            // `InterfaceDefaultImplDecl` path. Properties do not have that
            // representation, but a mixed `get; set {}` property is still a
            // partial accessor default and should get the targeted diagnostic
            // before the generic non-method-body check below.
            if (accessorDecl->body && isPartialPropertyAccessorDefaultImplementation(accessorDecl))
            {
                getSink()->diagnose(
                    Diagnostics::PartialInterfaceAccessorDefaultImplementation{.decl = decl});
                return;
            }
        }
        if (auto funcBase = as<FunctionDeclBase>(decl))
        {
            if (!as<FuncDecl>(decl) && funcBase->body != nullptr)
            {
                getSink()->diagnose(
                    Diagnostics::NonMethodInterfaceRequirementCannotHaveBody{.decl = decl});
                return;
            }
        }
        // Interface requirement cannot be `override`.
        if (decl->hasModifier<OverrideModifier>())
        {
            getSink()->diagnose(Diagnostics::InterfaceRequirementCannotBeOverride{.decl = decl});
        }
        // [TreatAsDifferentiable] cannot be applied to an interface requirement.
        if (auto treatAsDiffModifier = decl->findModifier<TreatAsDifferentiableAttribute>())
        {
            getSink()->diagnose(Diagnostics::TreatAsDifferentiableOnInterfaceRequirement{
                .attr = treatAsDiffModifier});
        }
    }
    else
    {
        // [MaybeDifferentiable] can only be applied to interface requirements.
        if (auto maybeDiffAttr = decl->findModifier<MaybeDifferentiableAttribute>())
        {
            getSink()->diagnose(
                Diagnostics::MaybeDifferentiableOnNonInterfaceRequirement{.attr = maybeDiffAttr});
        }
    }
}

// True if `name` is an *actual* operator: a name that can appear as the operator in a prefix,
// postfix, or infix operator expression (`-a`, `a++`, `a + b`). This is intentionally not every
// name that may be spelled with `operator <op>` syntax -- `operator()`, `operator[]`/`__subscript`,
// and `operator=` are written that way for historical reasons but are not operators in this sense
// (call and subscript are resolved by member lookup on the operand; assignment is checked as an
// `AssignExpr`), so this predicate returns false for them.
static bool isOperatorName(Name* name)
{
    if (!name)
        return false;
    auto text = name->text.getUnownedSlice();
    static const char* const kOperatorNames[] = {
        "+",  "-",  "*",  "/",   "%",   "!",  "~",  "<<", ">>", "==", "!=", ">",
        "<",  ">=", "<=", "&&",  "||",  "&",  "|",  "^",  "++", "--", "+=", "-=",
        "*=", "/=", "%=", "<<=", ">>=", "&=", "|=", "^=", ",",  "?:",
    };
    for (auto op : kOperatorNames)
    {
        if (text == op)
            return true;
    }
    return false;
}

// True if `name` is an operator that can appear in prefix (unary) position:
// `-`, `+`, `~`, or `!`. These are the unary operators the core module declares
// with `__prefix` and that a user may overload. `~`/`!` are unary-only, while
// `+`/`-` are also binary and so are only treated as prefix when the
// declaration's arity matches a unary operator (see
// `maybeInferPrefixModifierForOperator`).
static bool isPrefixOperatorName(Name* name)
{
    if (!name)
        return false;
    auto text = name->text.getUnownedSlice();
    return text == "-" || text == "+" || text == "~" || text == "!";
}

// Attaches a `PrefixModifier` to a user-defined unary operator declaration
// (e.g. `A operator-(A a)`) so it can be used in prefix position.
//
// Why this is needed: prefix-expression overload resolution only considers
// candidates carrying a `PrefixModifier` (see `TryCheckOverloadCandidateFixity`).
// The `__prefix` keyword that sets this modifier is an internal builtin used by
// the core module, not part of the documented surface language, yet the user
// guide documents `operator-`/`operator~`/`operator!` as overloadable unary
// operators; without this inference such a user operator would never be eligible
// in prefix position.
//
// Consider:
//
//     struct A { int x; }
//     A operator-(A a) { A na = { -a.x }; return na; }
//     A foo(A a) { return -a; }   // prefix `-a` must find `operator-(A)`
//
// A unary operator consumes exactly one operand. The operand is the single
// explicit parameter for a free-function operator, but for an instance-method
// operator (a member of an aggregate or an `extension`) the operand is the
// implicit `this`, so the explicit parameter list is empty. We must account for
// `this`: otherwise a binary instance-method operator such as
// `extension T { T operator-(T rhs) }` (one explicit parameter plus `this`)
// would be wrongly tagged prefix, and binary `a - b` would stop resolving to it.
// Inference also respects an explicit `__prefix`/`__postfix` if the user wrote
// one.
void SemanticsDeclHeaderVisitor::maybeInferPrefixModifierForOperator(CallableDecl* decl)
{
    if (!isPrefixOperatorName(decl->getName()))
        return;

    // Respect an explicit fixity modifier if the user wrote one.
    if (decl->findModifier<PrefixModifier>() || decl->findModifier<PostfixModifier>())
        return;

    // Use `getParentAggTypeDeclBase` (which walks past any enclosing
    // `GenericDecl`) rather than inspecting `decl->parentDecl` directly, so a
    // generic member/extension operator is still recognized as an instance
    // method; `isEffectivelyStatic` performs the same generic unwrapping.
    const bool isInstanceMethod =
        getParentAggTypeDeclBase(decl) != nullptr && !isEffectivelyStatic(decl);
    const Count unaryParamCount = isInstanceMethod ? 0 : 1;
    if (decl->getParameters().getCount() != unaryParamCount)
        return;

    auto prefixModifier = m_astBuilder->create<PrefixModifier>();
    prefixModifier->loc = decl->loc;
    addModifier(decl, prefixModifier);
}

// Diagnose an operator function declared as a member of a type or extension. A prefix/postfix/infix
// operator call site (`a + b`) resolves the operator name only through the enclosing lexical
// scopes, never by member lookup on the operand type, so an operator declared as a member can never
// be found from such a call and the user hits a confusing "no overload" at every use. We reject it
// at the declaration and steer the user to the free-function spelling instead (see #12761).
void SemanticsDeclHeaderVisitor::maybeDiagnoseOperatorDeclaredAsMember(FuncDecl* decl)
{
    // Only an actual operator name is relevant; `operator()`/`__subscript` (member-looked-up) and
    // ordinary function names are not.
    if (!isOperatorName(decl->getName()))
        return;

    // `getParentAggTypeDeclBase` (which walks past a wrapping `GenericDecl`) is null at
    // module/namespace scope -- where a free operator function is the supported form -- and
    // non-null for a type/interface/extension member.
    if (getParentAggTypeDeclBase(decl) == nullptr)
        return;

    getSink()->diagnose(Diagnostics::OperatorDeclaredAsMember{.decl = decl});
}

// We set a callable's error type when its header is checked. If one is present, either a
// `throws` clause (only `FuncDecl`s can spell one) or a type filled in by witness synthesis, it is
// checked, and `CheckProperType` leaves an already-resolved type as it is. Otherwise the callable
// gets `Bottom`, the type with no values, meaning it cannot throw. Checking of `throw` and `try`
// reads `errorType` on the function whose body is being checked and relies on it being set, so
// every `FunctionDeclBase` with a body passes through here.
void SemanticsDeclHeaderVisitor::checkCallableErrorType(CallableDecl* decl)
{
    auto errorType = decl->errorType;
    if (errorType.type || errorType.exp)
    {
        errorType = CheckProperType(errorType);
    }
    else
    {
        errorType = TypeExp(m_astBuilder->getBottomType());
    }
    decl->errorType = errorType;
}

void SemanticsDeclHeaderVisitor::checkCallableDeclCommon(CallableDecl* decl)
{
    for (auto paramDecl : decl->getParameters())
    {
        ensureDecl(paramDecl, DeclCheckState::ReadyForReference);
    }

    maybeInferPrefixModifierForOperator(decl);

    // Check that no parameter without a default value follows a parameter with one.
    bool seenDefaultParam = false;
    for (auto paramDecl : decl->getParameters())
    {
        if (paramDecl->initExpr)
        {
            seenDefaultParam = true;
        }
        else if (seenDefaultParam)
        {
            getSink()->diagnose(
                Diagnostics::ParameterWithoutDefaultAfterParameterWithDefault{.param = paramDecl});
        }
    }

    checkCallableErrorType(decl);

    // TODO: This is a workaround to make sure that the function's type constraints are represented
    // as a Constraint(sub=Lookup(This, funcDecl), sup=...), instead of referring to the function
    // directly.
    //
    checkCallableConstraints(decl);

    // TODO: Check the sub-type for GenericTypeConstraintDecl's to be `Lookup(This, funcDecl)`
    if (doesTypeHaveNoDiffModifier(decl->returnType.type))
    {
        auto noDiffMod = m_astBuilder->create<NoDiffModifier>();
        noDiffMod->loc = decl->loc;
        addModifier(decl, noDiffMod);
    }

    checkDifferentiableCallableSignature(decl);

    // If this method is intended to be a CUDA kernel, verify that the return type is void.
    if (decl->findModifier<CudaKernelAttribute>())
    {
        if (decl->returnType.type && !decl->returnType.type->equals(m_astBuilder->getVoidType()))
        {
            getSink()->diagnose(Diagnostics::CudaKernelMustReturnVoid{.decl = decl});
        }
    }

    // `[NoDiscard]` is meaningless on a function with no result to discard, so reject it
    // on a `void`-returning function.
    if (decl->findModifier<NoDiscardAttribute>())
    {
        if (decl->returnType.type && decl->returnType.type->equals(m_astBuilder->getVoidType()))
        {
            getSink()->diagnose(Diagnostics::NoDiscardOnVoidFunction{.decl = decl});
        }
    }

    checkInterfaceRequirement(decl);
    checkVisibility(decl);
}

void SemanticsDeclHeaderVisitor::checkPublicCallableOperandVisibility(CallableDecl* decl)
{
    validatePublicCallableOperandVisibility(this, decl);
}

void SemanticsDeclHeaderVisitor::visitCallableDecl(CallableDecl* decl)
{
    if (!as<FuncAliasDecl>(decl))
        return;

    checkPublicCallableOperandVisibility(decl);
    checkVisibility(decl);
}

void SemanticsDeclHeaderVisitor::visitFunctionDeclBase(FunctionDeclBase* decl)
{
    if (!as<SynthesizedFuncDecl>(decl))
        return;

    checkPublicCallableOperandVisibility(decl);
    checkVisibility(decl);
}

void SemanticsDeclHeaderVisitor::visitFuncDecl(FuncDecl* funcDecl)
{
    if (funcDecl->funcType.exp)
    {
        // Alternative way to provide a func declaration.
        funcDecl->funcType = CheckProperType(funcDecl->funcType);
    }
    else
    {
        auto resultType = funcDecl->returnType;
        if (resultType.exp)
        {
            resultType = CheckProperType(resultType);
        }
        else if (!funcDecl->returnType.type)
        {
            resultType = TypeExp(m_astBuilder->getVoidType());
        }
        funcDecl->returnType = resultType;
    }

    checkCallableDeclCommon(funcDecl);
    maybeDiagnoseOperatorDeclaredAsMember(funcDecl);
}

IntegerLiteralValue SemanticsVisitor::GetMinBound(IntVal* val)
{
    if (auto constantVal = as<ConstantIntVal>(val))
        return constantVal->getValue();

    // TODO(tfoley): Need to track intervals so that this isn't just a lie...
    return 1;
}

void SemanticsVisitor::maybeInferArraySizeForVariable(VarDeclBase* varDecl)
{
    // Not an array?
    auto arrayType = as<ArrayExpressionType>(varDecl->type);
    if (!arrayType)
        return;

    // Explicit element count given?
    if (!isUnsizedArrayType(arrayType))
        return;

    // No initializer?
    auto initExpr = varDecl->initExpr;
    if (!initExpr)
        return;

    IntVal* elementCount = nullptr;

    // Is the type of the initializer an array type?
    if (auto arrayInitType = as<ArrayExpressionType>(initExpr->type))
    {
        elementCount = arrayInitType->getElementCount();
    }
    else
    {
        // Nothing to do: we couldn't infer a size
        return;
    }

    // Create a new array type based on the size we found,
    // and install it into our type.
    varDecl->type.type = getArrayType(m_astBuilder, arrayType->getElementType(), elementCount);
}

void SemanticsVisitor::validateArraySizeForVariable(VarDeclBase* varDecl)
{
    auto arrayType = as<ArrayExpressionType>(varDecl->type);
    if (!arrayType)
        return;

    if (arrayType->isUnsized())
    {
        // Note(tfoley): For now we allow arrays of unspecified size
        // everywhere, because some source languages (e.g., GLSL)
        // allow them in specific cases.
#if 0
            getSink()->diagnose(varDecl, Diagnostics::invalidArraySize);
#endif
        return;
    }

    // TODO(tfoley): How to handle the case where bound isn't known?
    auto elementCount = arrayType->getElementCount();
    if (GetMinBound(elementCount) < 0)
    {
        getSink()->diagnose(Diagnostics::InvalidArraySize{.location = varDecl->loc});
        return;
    }

    if (elementCount->isLinkTimeVal())
    {
        getSink()->diagnose(Diagnostics::LinkTimeConstantArraySize{.decl = varDecl});
    }
}

void SemanticsVisitor::validateArrayElementTypeForVariable(VarDeclBase* varDecl)
{
    auto arrayType = as<ArrayExpressionType>(varDecl->type);
    if (!arrayType)
        return;

    const auto elementType = arrayType->getElementType();

    // Check if the element type has the NonAddressable tag
    TypeTag elementTags = getTypeTags(elementType);
    if ((int)elementTags & (int)TypeTag::NonAddressable)
    {
        getSink()->diagnose(Diagnostics::DisallowedArrayOfNonAddressableType{
            .elementType = elementType,
            .location = varDecl->loc});
        return;
    }
}

bool getExtensionTargetDeclList(
    ASTBuilder* astBuilder,
    DeclRefType* targetDeclRefType,
    ExtensionDecl* extDecl,
    ShortList<AggTypeDecl*>& targetDecls)
{
    if (auto aggTypeDeclRef = targetDeclRefType->getDeclRef().as<AggTypeDecl>())
    {
        auto aggTypeDecl = aggTypeDeclRef.getDecl();

        targetDecls.add(aggTypeDecl);
        return true;
    }

    auto genericParamDeclRef = targetDeclRefType->getDeclRef().as<GenericTypeParamDeclBase>();
    if (!genericParamDeclRef)
        return false;

    auto genericParent = as<GenericDecl>(genericParamDeclRef.getParent().getDecl());
    if (!genericParent)
        return false;

    if (genericParent != extDecl->parentDecl)
        return false;

    for (auto member : getMembersOfType<GenericTypeConstraintDecl>(astBuilder, genericParent))
    {
        if (getSub(astBuilder, member) == targetDeclRefType)
        {
            auto baseType = getSup(astBuilder, member);
            if (auto baseTypeDecl = isDeclRefTypeOf<AggTypeDecl>(baseType))
            {
                targetDecls.add(baseTypeDecl.getDecl());
            }
        }
    }
    return targetDecls.getCount() != 0;
}


void SemanticsDeclBasesVisitor::_validateExtensionDeclTargetType(ExtensionDecl* decl)
{
    // Validate generic parameters first
    _validateExtensionDeclGenericParams(decl);

    if (auto targetDeclRefType = as<DeclRefType>(decl->targetType))
    {
        // Attach our extension to that type as a candidate...
        if (targetDeclRefType->getDeclRef().as<InterfaceDecl>())
        {
            getSink()->diagnose(Diagnostics::InvalidExtensionOnInterface{
                .type = decl->targetType.type,
                .typeExp = decl->targetType.exp});
            return;
        }
        else if (auto aggTypeDeclRef = targetDeclRefType->getDeclRef().as<AggTypeDecl>())
        {
            auto aggTypeDecl = aggTypeDeclRef.getDecl();

            getShared()->registerCandidateExtension(aggTypeDecl, decl);

            return;
        }
        else if (auto funcDeclRef = targetDeclRefType->getDeclRef().as<FunctionDeclBase>())
        {
            auto funcDecl = funcDeclRef.getDecl();

            getShared()->registerCandidateExtension(funcDecl, decl);

            return;
        }
        else if (
            auto genericTypeParamDecl = targetDeclRefType->getDeclRef().as<GenericTypeParamDecl>())
        {
            // If we are extending a generic type parameter as in `extension<T:IFoo> T`,
            // we want to register the extension with the interface type `IFoo` instead.
            auto genericDecl = as<GenericDecl>(genericTypeParamDecl.getDecl()->parentDecl);
            if (!genericDecl)
                goto error;
            if (genericDecl != decl->parentDecl)
                goto error;
            bool isTypeConstrained = false;
            for (auto constraintDecl : genericDecl->getMembersOfType<GenericTypeConstraintDecl>())
            {
                ensureDecl(constraintDecl, DeclCheckState::ReadyForReference);
                if (targetDeclRefType == constraintDecl->sub.type)
                {
                    auto supTypeDeclRef = isDeclRefTypeOf<AggTypeDecl>(constraintDecl->sup.type);
                    getShared()->registerCandidateExtension(supTypeDeclRef.getDecl(), decl);
                    isTypeConstrained = true;
                }
            }
            if (isTypeConstrained)
                return;
        }
    }
error:;
    if (!as<ErrorType>(decl->targetType.type))
    {
        getSink()->diagnose(Diagnostics::InvalidExtensionOnType{
            .type = decl->targetType.type,
            .typeExp = decl->targetType.exp});
    }
}

void SemanticsDeclBasesVisitor::_validateExtensionDeclMembers(ExtensionDecl* decl)
{
    for (auto ctor : decl->getDirectMemberDeclsOfType<ConstructorDecl>())
    {
        // Note(tfoley): AFAICT, the logic here is enforcing that an
        // `extension` declaration cannot introduce a default constructor,
        // unless it introduces that default constructor without a body.
        //
        // If the constructor declaration is without a body, we allow it
        // here, and if it has a non-zero number of direct member declarations
        // (which this code is assuming will be equivalent to just the
        // parameter declarations), we also allow it.
        //
        // The underlying rationale

        if (!ctor->body || ctor->getDirectMemberDeclCount() != 0)
            continue;
        {
            StringBuilder sb;
            printDiagnosticArg(sb, ctor->astNodeType);
            getSink()->diagnose(Diagnostics::InvalidMemberTypeInExtension{
                .nodeType = sb.produceString(),
                .decl = ctor});
        }
    }
}

void SemanticsDeclBasesVisitor::_validateExtensionDeclGenericParams(ExtensionDecl* decl)
{
    // Check if any generic parameter on the extension is not referenced by the target type
    // or by constraints in the generic declaration
    if (auto genericDecl = as<GenericDecl>(decl->parentDecl))
    {
        ensureDecl(genericDecl, DeclCheckState::ReadyForReference);

        // Collect all declarations referenced by the target type
        HashSet<Decl*> genericParamsReferencedByTargetType;
        collectReferencedDecls(this, decl->targetType.type, genericParamsReferencedByTargetType);

        HashSet<Decl*> genericParamsReferencedByConstraints;

        // Also collect declarations referenced by generic constraints
        for (auto constraint :
             getMembersOfType<GenericTypeConstraintDecl>(getASTBuilder(), genericDecl))
        {
            collectReferencedDecls(
                this,
                constraint.getDecl()->sup.type,
                genericParamsReferencedByConstraints);
        }

        // Note: We intentionally do NOT check inheritance declarations in the extension.
        // Being referenced only in inheritance declarations is not sufficient for the
        // type system to solve for generic parameters when applying the extension.

        // Check each generic parameter directly
        for (auto member : genericDecl->getDirectMemberDecls())
        {
            if (isGenericParam(member))
            {
                bool referencedByTargetType = genericParamsReferencedByTargetType.contains(member);
                bool referencedByConstraint = genericParamsReferencedByConstraints.contains(member);
                if (!referencedByTargetType && !referencedByConstraint)
                {
                    getSink()->diagnose(Diagnostics::UnreferencedGenericParamInExtension{
                        .paramName = member->getName(),
                        .targetType = decl->targetType.type,
                        .decl = member});
                }
                else if (!referencedByTargetType && !isFromCoreModule(decl))
                {
                    getSink()->diagnose(
                        Diagnostics::GenericParamInExtensionNotReferencedByTargetType{
                            .paramName = member->getName(),
                            .targetType = decl->targetType.type,
                            .decl = member});
                }
            }
        }
    }
}

// Populate the extension for a forward derivative func_extension.
//
// Input:
//   __func_extension fwd_diff(foo)(DifferentialPair<float> x) -> DifferentialPair<float> { ... }
//
// Output:
//   extension foo : IForwardDifferentiable<foo>
//   {
//       static fwd_diff(DifferentialPair<float> x) -> DifferentialPair<float> { ... }  // user body
//   }
//
void SemanticsDeclBasesVisitor::_funcExtensionForwardDiff(
    ExtensionDecl* extensionDecl,
    FuncDecl* innerFunc,
    Type* baseFuncAsType,
    DeclVisibility visibility)
{
    SLANG_UNUSED(visibility);
    auto astBuilder = getASTBuilder();

    auto inheritanceDecl = astBuilder->create<InheritanceDecl>();
    inheritanceDecl->base.type = getForwardDiffFuncInterfaceType(baseFuncAsType);
    extensionDecl->addMember(inheritanceDecl);

    innerFunc->nameAndLoc.name = getName("fwd_diff");
    addModifier(innerFunc, astBuilder->create<HLSLStaticModifier>());
}

// Populate the extension for a backward derivative func_extension.
//
// Input:
//   __func_extension bwd_diff(foo)(inout DifferentialPair<float> x, float dOut) -> void { ... }
//
// Output:
//   extension foo : IBackwardDifferentiable<foo>
//   {
//       static userBwdFunc(inout DifferentialPair<float> x, float dOut) -> void { ... }  // user
//       body static bwd_diff  = FunctionCopy(userBwdFunc)              // typed as
//       BwdDiffFuncType<foo> struct BwdCallable  : IBwdCallable<foo> { ... }           //
//       synthesized from bwd_diff struct MinimalContext { ... }                              //
//       synthesized from bwd_diff apply_bwd = BackwardPrimalFromLegacyBwdDiffFunc(...)      //
//       synthesized static remat = BackwardRematFromLegacyBwdDiffFunc(...)    // synthesized
//   }
//
void SemanticsDeclBasesVisitor::_funcExtensionBackwardDiff(
    ExtensionDecl* extensionDecl,
    FuncDecl* innerFunc,
    Type* baseFuncAsType,
    DeclVisibility visibility)
{
    auto astBuilder = getASTBuilder();

    auto inheritanceDecl = astBuilder->create<InheritanceDecl>();
    inheritanceDecl->base.type = getBackwardDiffFuncInterfaceType(baseFuncAsType);
    extensionDecl->addMember(inheritanceDecl);

    // Mark the declaration static because the user's explicit self argument already represents
    // the value on which the derivative operates.
    addModifier(innerFunc, astBuilder->create<HLSLStaticModifier>());

    auto userFuncDeclRef =
        createDefaultSubstitutionsIfNeeded(astBuilder, this, innerFunc->getDefaultDeclRef());

    auto funcAsTypeForSynth = as<DeclRefType>(baseFuncAsType);

    auto synBwdDiffFunc = addSynthesizedFunc(
        this,
        extensionDecl,
        getName("bwd_diff"),
        kIROp_FunctionCopy,
        {userFuncDeclRef},
        getCalculatedDiffFuncType("BwdDiffFuncType", baseFuncAsType),
        true,
        visibility);
    synBwdDiffFunc = createDefaultSubstitutionsIfNeeded(astBuilder, this, synBwdDiffFunc)
                         .as<SynthesizedFuncDecl>();

    auto synContextStruct = addOrExtendSynthesizedStruct(
        this,
        extensionDecl,
        getName("BwdCallable"),
        kIROp_BackwardContextFromLegacyBwdDiffFunc,
        {funcAsTypeForSynth->getDeclRefBase(), synBwdDiffFunc},
        {getBwdCallableBaseType(baseFuncAsType)},
        visibility,
        visibility);

    auto synMinimalContextStruct = addOrExtendSynthesizedStruct(
        this,
        extensionDecl,
        getName("MinimalContext"),
        kIROp_BackwardMinimalContextFromLegacyBwdDiffFunc,
        {funcAsTypeForSynth->getDeclRefBase(), synBwdDiffFunc},
        {},
        visibility,
        visibility);

    auto minimalCtxType = DeclRefType::create(astBuilder, synMinimalContextStruct);
    auto fullCtxType = DeclRefType::create(astBuilder, synContextStruct);

    addSynthesizedFunc(
        this,
        extensionDecl,
        getName("apply_bwd"),
        kIROp_BackwardPrimalFromLegacyBwdDiffFunc,
        {funcAsTypeForSynth->getDeclRefBase(), synBwdDiffFunc},
        getCalculatedDiffFuncType("ApplyForBwdFuncType", baseFuncAsType, minimalCtxType),
        false,
        visibility);

    addSynthesizedFunc(
        this,
        extensionDecl,
        getName("remat"),
        kIROp_BackwardRematFromLegacyBwdDiffFunc,
        {funcAsTypeForSynth->getDeclRefBase(), synBwdDiffFunc},
        getCalculatedDiffFuncType("RematFuncType", baseFuncAsType, minimalCtxType, fullCtxType),
        true,
        visibility);
}

// Populate the extension for a custom __apply (forward pass) func_extension.
//
// Input:
//   struct MyCtx { void operator()(out float dx, float dOut) { ... } };
//   __func_extension __apply(foo)(float x) -> Tuple<float, MyCtx> { ... }
//
// Output:
//   extension foo : IBackwardDifferentiable<foo>
//   {
//       userApplyFunc(float x) -> Tuple<float, MyCtx> { ... }    // user body
//       apply_bwd  = FunctionCopy(userApplyFunc)                  // typed as ApplyForBwdFuncType
//       typealias BwdCallable = MyCtx;
//       typealias MinimalContext = MyCtx;
//       static remat = IdentityRemat(apply_bwd)                   // identity (MinCtx ==
//       BwdCallable)
//       // bwd_diff is synthesized later by LegacyBackwardDerivativeFunc requirement
//   }
//   extension MyCtx : IBwdCallable<foo> { }                       // conformance for the context
//   type
//
void SemanticsDeclBasesVisitor::_funcExtensionApply(
    ExtensionDecl* extensionDecl,
    FuncDecl* innerFunc,
    Type* baseFuncAsType,
    DeclVisibility visibility,
    SourceLoc loc)
{
    auto astBuilder = getASTBuilder();

    // Ensure innerFunc's return type is checked so we can extract CtxType.
    ensureDecl(innerFunc, DeclCheckState::SignatureChecked);

    // Extract the context type from the return type (Tuple<RetType, CtxType>).
    auto returnType = innerFunc->returnType.type;
    auto tupleType = as<TupleType>(returnType);
    if (!tupleType || tupleType->getMemberCount() != 2)
    {
        getSink()->diagnose(Diagnostics::FuncExtensionApplyReturnType{.location = loc});
        return;
    }
    auto ctxType = tupleType->getMember(1);

    // Do not advertise the differentiability conformance until the declaration has a usable
    // context type. If signature validation fails above, the generated extension remains the
    // function's canonical owner but contains no partial conformance for later phases to consume.
    auto inheritanceDecl = astBuilder->create<InheritanceDecl>();
    inheritanceDecl->base.type = getBackwardDiffFuncInterfaceType(baseFuncAsType);
    extensionDecl->addMember(inheritanceDecl);

    auto userFuncDeclRef =
        createDefaultSubstitutionsIfNeeded(astBuilder, this, innerFunc->getDefaultDeclRef());

    auto synApplyBwdFunc = addSynthesizedFunc(
        this,
        extensionDecl,
        getName("apply_bwd"),
        kIROp_FunctionCopy,
        {userFuncDeclRef},
        getCalculatedDiffFuncType("ApplyForBwdFuncType", baseFuncAsType, ctxType),
        false,
        visibility);
    synApplyBwdFunc = createDefaultSubstitutionsIfNeeded(astBuilder, this, synApplyBwdFunc)
                          .as<SynthesizedFuncDecl>();

    auto bwdCallableAlias = astBuilder->create<TypeAliasDecl>();
    bwdCallableAlias->nameAndLoc.name = getName("BwdCallable");
    addVisibilityModifier(bwdCallableAlias, visibility);
    bwdCallableAlias->type.type = ctxType;
    extensionDecl->addMember(bwdCallableAlias);

    auto minCtxAlias = astBuilder->create<TypeAliasDecl>();
    minCtxAlias->nameAndLoc.name = getName("MinimalContext");
    addVisibilityModifier(minCtxAlias, visibility);
    minCtxAlias->type.type = ctxType;
    extensionDecl->addMember(minCtxAlias);

    addSynthesizedFunc(
        this,
        extensionDecl,
        getName("remat"),
        kIROp_IdentityRemat,
        {synApplyBwdFunc},
        getCalculatedDiffFuncType("RematFuncType", baseFuncAsType, ctxType, ctxType),
        true,
        visibility);

    // Create IBwdCallable<F> conformance for the user's context type.
    // We create the conformance extension as a child of extensionDecl (which is
    // inside the func-extension's generic scope), then lift it out. This ensures
    // that baseFuncAsType (referencing the func-extension's generic T) is in the
    // correct scope when substituted during lifting.
    {
        auto bwdCallableConformanceExt = astBuilder->create<ExtensionDecl>();
        bwdCallableConformanceExt->loc = loc;
        addVisibilityModifier(bwdCallableConformanceExt, visibility);

        // Parent through the main extension so lifting can see any enclosing generic scope.
        bwdCallableConformanceExt->parentDecl = extensionDecl;

        // Lift from generic containers — this clones the func-extension's generic
        // params and creates wrappers at module scope.
        SubstitutionSet conformanceSubstSet;
        liftDeclFromGenericContainers(bwdCallableConformanceExt, conformanceSubstSet);

        // Apply substitutions to target type and interface type using the
        // func-extension's generic params (now substituted by the lift).
        auto substCtxType = as<Type>(ctxType->substitute(astBuilder, conformanceSubstSet));
        bwdCallableConformanceExt->targetType.type = substCtxType;
        bwdCallableConformanceExt->targetType.exp = astBuilder->create<SharedTypeExpr>();
        bwdCallableConformanceExt->targetType.exp->type =
            astBuilder->getOrCreate<TypeType>(substCtxType);

        auto substBwdCallableBase = as<Type>(
            getBwdCallableBaseType(baseFuncAsType)->substitute(astBuilder, conformanceSubstSet));
        auto bwdCallableInheritance = astBuilder->create<InheritanceDecl>();
        bwdCallableInheritance->base.type = substBwdCallableBase;
        bwdCallableConformanceExt->addMember(bwdCallableInheritance);

        // Walk up to outermost wrapper and add to module.
        Decl* outermostDecl = bwdCallableConformanceExt;
        while (outermostDecl->parentDecl && !as<ModuleDecl>(outermostDecl->parentDecl))
            outermostDecl = outermostDecl->parentDecl;
        getModuleDecl(extensionDecl)->addMember(outermostDecl);
    }
}

static void _moveModifiersToFunc(Decl* src, Decl* dst)
{
    Modifier** link = &src->modifiers.first;
    while (auto modifier = *link)
    {
        *link = modifier->next;
        modifier->next = nullptr;
        addModifier(dst, modifier);
    }
}

void SemanticsDeclBasesVisitor::visitFuncExtensionDecl(FuncExtensionDecl* decl)
{
    // Convert a __func_extension into a regular ExtensionDecl.
    //
    // E.g.:
    //   __func_extension<T:IFloat> fwd_diff(foo<T>)(...) -> ... { ... }
    // becomes:
    //   extension<T:IFloat> foo<T> : IForwardDifferentiable<foo<T>> { fwd_diff(...) -> ... { ... }
    //   }

    // Core-module meta code uses __func_extension to attach conditional derivative
    // witnesses, but user source still needs to opt in to the experimental syntax.
    if (!getOptionSet().getBoolOption(CompilerOptionName::ExperimentalFeature) &&
        !isFromCoreModule(decl))
    {
        getSink()->diagnose(
            Diagnostics::FuncExtensionRequiresExperimentalFeature{.location = decl->loc});
        return;
    }

    auto astBuilder = getASTBuilder();

    // 1. Resolve the base function from the target expression.
    //    The targetExpr is a higher-order expr like ForwardDifferentiateExpr
    //    wrapping the function reference (e.g. fwd_diff(foo<T>)).
    //    We resolve by constructing Invoke(diffExpr, fakeArgs) and letting
    //    the existing higher-order expression checking machinery handle
    //    overload resolution and type transformations.
    auto diffExpr = as<DifferentiateExpr>(decl->targetExpr);
    if (!diffExpr)
    {
        if (as<HigherOrderInvokeExpr>(decl->targetExpr))
            getSink()->diagnose(
                Diagnostics::FuncExtensionUnsupportedOperator{.location = decl->loc});
        else
            getSink()->diagnose(Diagnostics::FuncExtensionUnsupportedTarget{.location = decl->loc});
        return;
    }

    const bool isForwardDiff = as<ForwardDifferentiateExpr>(diffExpr) != nullptr;
    const bool isBackwardDiff = as<BackwardDifferentiateExpr>(diffExpr) != nullptr;
    const bool isApply = as<ApplyForBwdExpr>(diffExpr) != nullptr;
    if (!isForwardDiff && !isBackwardDiff && !isApply)
    {
        getSink()->diagnose(Diagnostics::FuncExtensionUnsupportedOperator{.location = decl->loc});
        return;
    }

    auto innerFunc = decl->innerFunc;

    // Attributes/modifiers on `__func_extension` conceptually decorate the
    // generated derivative/apply function.
    _moveModifiersToFunc(decl, innerFunc);

    // Ensure innerFunc's param types are checked so we can build fake args.
    for (auto param : innerFunc->getMembersOfType<ParamDecl>())
        ensureDecl(param, DeclCheckState::TypesFullyResolved);

    // Construct fake arguments from innerFunc's parameters.
    List<Expr*> fakeArgs;
    for (auto param : innerFunc->getParameters())
    {
        auto arg = astBuilder->create<VarExpr>();
        arg->declRef = makeDeclRef(param);
        auto paramMode = getParamPassingMode(param);
        arg->type.isLeftValue = paramMode == ParamPassingMode::Out ||
                                paramMode == ParamPassingMode::BorrowInOut ||
                                isByReferenceParamPassingMode(paramMode);
        arg->type.type = param->getType();
        arg->loc = decl->loc;
        fakeArgs.add(arg);
    }

    // Build Invoke(diffExpr, fakeArgs) and check it.
    // The higher-order expression checking (_checkHigherOrderInvokeExpr)
    // will resolve the inner function, handle overloads, and validate types.
    SemanticsContext::ExprLocalScope scope;
    auto ctx = withExprLocalScope(&scope);
    auto subVisitor = SemanticsVisitor(ctx.allowStaticReferenceToNonStaticMember());
    auto errorCountBeforeResolve = getSink()->getErrorCount();
    // First check the diffExpr (resolves base, handles overloads).
    auto checkedDiffExpr = subVisitor.CheckExpr(diffExpr);
    if (auto checkedApplyExpr = as<ApplyForBwdExpr>(checkedDiffExpr))
    {
        if (auto applyFuncType = as<FuncType>(checkedApplyExpr->type.type))
        {
            if (checkedApplyExpr->newParameterNames.getCount() &&
                checkedApplyExpr->newParameterNames[0] == getName("this") &&
                applyFuncType->getParamCount() == fakeArgs.getCount() + 1)
            {
                auto thisArg = astBuilder->create<VarExpr>();
                auto [thisArgType, thisArgDirection] = getParamInfoFromTypeWithModeWrapper(
                    applyFuncType->getParamTypeWithModeWrapper(0));
                thisArg->type.type = thisArgType;
                thisArg->type.isLeftValue = thisArgDirection == ParamPassingMode::Out ||
                                            thisArgDirection == ParamPassingMode::BorrowInOut ||
                                            isByReferenceParamPassingMode(thisArgDirection);
                thisArg->loc = decl->loc;
                fakeArgs.insert(0, thisArg);
            }
        }
    }

    // Then resolve the invoke with the checked diff expr and fake args.
    auto invokeExpr = subVisitor.constructUncheckedInvokeExpr(checkedDiffExpr, fakeArgs);
    auto resolved = subVisitor.ResolveInvoke(invokeExpr);

    // Extract the resolved base function from the higher-order expression.
    DeclRefExpr* baseFuncDeclRefExpr = nullptr;
    if (auto resolvedInvoke = as<InvokeExpr>(resolved))
    {
        if (auto innerDiffExpr = as<DifferentiateExpr>(resolvedInvoke->functionExpr))
            baseFuncDeclRefExpr = as<DeclRefExpr>(innerDiffExpr->baseFunction);
    }
    if (!baseFuncDeclRefExpr || !baseFuncDeclRefExpr->declRef)
    {
        if (getSink()->getErrorCount() == errorCountBeforeResolve)
        {
            getSink()->diagnose(
                Diagnostics::FuncExtensionUnresolvedFunction{.location = decl->loc});
        }
        return;
    }

    auto baseFuncDeclRef = baseFuncDeclRefExpr->declRef;
    auto baseFuncAsType = DeclRefType::create(astBuilder, baseFuncDeclRef);

    // 2. Create the ExtensionDecl.
    auto extensionDecl = astBuilder->create<ExtensionDecl>();
    extensionDecl->loc = decl->loc;
    extensionDecl->targetType.type = baseFuncAsType;
    extensionDecl->targetType.exp = astBuilder->create<SharedTypeExpr>();
    extensionDecl->targetType.exp->type = astBuilder->getOrCreate<TypeType>(baseFuncAsType);

    // Wire enough parent information for synthesis helpers
    // (addOrExtendSynthesizedStruct, createDefaultSubstitutionsIfNeeded, etc.)
    // to traverse the parent chain. Non-generic extensions are added to the
    // module after helper-specific population is complete, including when a
    // helper diagnoses an invalid signature and leaves only the ownership shell.
    auto genericParent = as<GenericDecl>(decl->parentDecl);
    if (genericParent)
    {
        genericParent->inner = extensionDecl;
        extensionDecl->parentDecl = genericParent;
    }
    else
    {
        extensionDecl->parentDecl = decl->parentDecl;
    }

    // 3. Determine the interface and populate the extension.
    auto visibility = getDeclVisibility(baseFuncDeclRef.getDecl());
    addVisibilityModifier(extensionDecl, visibility);

    // Moving the user-written function into the generated extension establishes its final
    // declaration context. This transfer is deliberately irreversible: signature checking records
    // context-dependent information, including the effective `this` parameter, and later phases
    // must be able to reach the checked declaration even if helper-specific validation diagnoses an
    // error. An invalid helper therefore leaves this ownership shell in place while omitting any
    // conformance or synthesized members that depend on the invalid signature.
    extensionDecl->addMember(innerFunc);

    // Dispatch to the appropriate helper based on the higher-order expression type.
    if (isForwardDiff)
        _funcExtensionForwardDiff(extensionDecl, innerFunc, baseFuncAsType, visibility);
    else if (isBackwardDiff)
        _funcExtensionBackwardDiff(extensionDecl, innerFunc, baseFuncAsType, visibility);
    else
        _funcExtensionApply(extensionDecl, innerFunc, baseFuncAsType, visibility, decl->loc);

    if (!genericParent)
        getModuleDecl(decl)->addMember(extensionDecl);

    // Now run the normal extension checking on the newly created ExtensionDecl.
    visitExtensionDecl(extensionDecl);
}

void SemanticsDeclBasesVisitor::visitExtensionDecl(ExtensionDecl* decl)
{
    // If the extension is a generic, we need to make sure to check
    // the outer generic constraints first.
    //
    ensureOuterGenericConstraints(decl, DeclCheckState::ReadyForReference);

    // We check the target type expression and members, and then validate
    // that the type it names is one that it makes sense
    // to extend.
    //
    decl->targetType = CheckProperType(decl->targetType);

    _validateExtensionDeclTargetType(decl);

    _validateExtensionDeclMembers(decl);

    for (auto inheritanceDecl : decl->getMembersOfType<InheritanceDecl>())
    {
        ensureDecl(inheritanceDecl, DeclCheckState::CanUseBaseOfInheritanceDecl);
        auto baseType = inheritanceDecl->base.type;

        // It is possible that there was an error in checking the base type
        // expression, and in such a case we shouldn't emit a cascading error.
        //
        if (const auto baseErrorType = as<ErrorType>(baseType); baseErrorType)
        {
            continue;
        }

        // An `extension` can only introduce inheritance from `interface` types.
        //
        // TODO: It might in theory make sense to allow an `extension` to
        // introduce a non-`interface` base if we decide that an `extension`
        // within the same module as the type it extends counts as just
        // a continuation of the type's body (like a `partial class` in C#).
        //
        auto baseDeclRefType = as<DeclRefType>(baseType);
        if (!baseDeclRefType)
        {
            getSink()->diagnose(Diagnostics::BaseOfExtensionMustBeInterface{
                .baseType = baseType,
                .inheritanceDecl = inheritanceDecl});
            continue;
        }

        auto baseDeclRef = baseDeclRefType->getDeclRef();
        auto baseInterfaceDeclRef = baseDeclRef.as<InterfaceDecl>();
        if (!baseInterfaceDeclRef)
        {
            getSink()->diagnose(Diagnostics::BaseOfExtensionMustBeInterface{
                .baseType = baseType,
                .inheritanceDecl = inheritanceDecl});
            continue;
        }

        // TODO: At this point we have the `baseInterfaceDeclRef`
        // and could use it to perform further validity checks,
        // and/or to build up a more refined representation of
        // the inheritance graph for this extension (e.g., a "class
        // precedence list").
        //
        // E.g., we can/should check that we aren't introducing
        // an inheritance relationship that already existed
        // on the type as originally declared.

        _validateCrossModuleInheritance(decl, inheritanceDecl);
    }
}

Type* SemanticsVisitor::calcThisType(DeclRef<Decl> declRef)
{
    if (auto interfaceDeclRef = declRef.as<InterfaceDecl>())
    {
        // In the body of an `interface`, a `This` type
        // refers to the concrete type that will eventually
        // conform to the interface and fill in its
        // requirements.
        //
        return DeclRefType::create(
            m_astBuilder,
            m_astBuilder->getDirectDeclRef(interfaceDeclRef.getDecl()->getThisTypeDecl()));
    }
    else if (auto aggTypeDeclRef = declRef.as<AggTypeDecl>())
    {
        // In the body of an ordinary aggregate type,
        // such as a `struct`, the `This` type just
        // refers to the type itself.
        //
        // TODO: If/when we support `class` types
        // with inheritance, then `This` inside a class
        // would need to refer to the eventual concrete
        // type, much like the `interface` case above.
        //
        return DeclRefType::create(m_astBuilder, aggTypeDeclRef);
    }
    else if (auto genTypeParam = declRef.as<GenericTypeParamDecl>())
    {
        // We will reach here when we are checking `extension<T> T {...}`,
        // where inside the extension, `This` type is the target type
        // of the extension, in this case this is a DeclRefType to
        // a GenericTypeParamDecl.
        //
        return DeclRefType::create(m_astBuilder, declRef);
    }
    else if (auto extDeclRef = declRef.as<ExtensionDecl>())
    {
        // In the body of an `extension`, the `This`
        // type refers to the type being extended.
        //
        // Note: we currently have this loop back
        // around through `calcThisType` for the
        // type being extended, rather than just
        // using it directly. This makes a difference
        // for polymorphic types like `interface`s,
        // and there are reasonable arguments for
        // the validity of either option.
        //
        // Does `extension IFoo` mean extending
        // exactly the type `IFoo` (an existential,
        // which could at runtime be a value of
        // any type conforming to `IFoo`), or does
        // it implicitly extend every type that
        // conforms to `IFoo`? The difference is
        // significant, and we need to make a choice
        // sooner or later.
        //
        ensureDecl(extDeclRef, DeclCheckState::CanUseExtensionTargetType);
        auto targetType = getTargetType(m_astBuilder, extDeclRef);
        return calcThisType(targetType);
    }
    else
    {
        return nullptr;
    }
}

Type* SemanticsVisitor::calcThisType(Type* type)
{
    if (auto declRefType = as<DeclRefType>(type))
    {
        return calcThisType(declRefType->getDeclRef());
    }
    else
    {
        return type;
    }
}

/// Does `modifier` specify the passing mode of a declaration's receiver parameter?
static bool _isReceiverParamModeSpecifier(Modifier* modifier)
{
    if (as<ReceiverParamModeSpecifierAttribute>(modifier))
        return true;
    return as<CppStyleTrailingReceiverParamConstModifier>(modifier) != nullptr;
}

/// Return the receiver parameter mode specifiers attached to `decl`, in the order written.
static ShortList<Modifier*, 1> _getReceiverParamModeSpecifiers(Decl* decl)
{
    ShortList<Modifier*, 1> specifiers;

    // `CompleteDecl` appends prefix attributes after the parser has attached trailing `const`.
    // We collect attributes first so a conflict is diagnosed at the later trailing `const`.
    for (auto modifier : decl->modifiers)
        if (as<ReceiverParamModeSpecifierAttribute>(modifier))
            specifiers.add(modifier);
    for (auto modifier : decl->modifiers)
        if (as<CppStyleTrailingReceiverParamConstModifier>(modifier))
            specifiers.add(modifier);
    return specifiers;
}

void SemanticsVisitor::checkReceiverParamModeSpecifiers(Decl* decl)
{
    // Each declaration can specify its receiver mode only once, so identical repeats are
    // diagnosed just like conflicting spellings.
    auto specifiers = _getReceiverParamModeSpecifiers(decl);
    if (specifiers.getCount() <= 1)
        return;

    auto firstSpecifier = specifiers[0];
    for (Index i = 1; i < specifiers.getCount(); ++i)
    {
        getSink()->diagnose(Diagnostics::DuplicateModifier{
            .existingModifier = firstSpecifier,
            .modifier = specifiers[i]});
    }
}

/// Calculate the receiver parameter mode specified directly on `decl`.
///
/// Returns no mode when no specifier is present. Modifier checking diagnoses multiple specifiers,
/// including identical repeats; error recovery uses the first specifier in the order written.
static std::optional<ParamPassingMode> _calcReceiverParamModeFromSpecifiers(Decl* decl)
{
    auto specifiers = _getReceiverParamModeSpecifiers(decl);
    if (specifiers.getCount() == 0)
        return std::nullopt;

    auto specifier = specifiers[0];
    if (as<MutatingAttribute>(specifier))
        return ParamPassingMode::BorrowInOut;
    if (as<ConstRefAttribute>(specifier))
        return ParamPassingMode::BorrowIn;
    if (as<RefAttribute>(specifier))
        return ParamPassingMode::RefReadWrite;
    if (as<NonmutatingAttribute>(specifier))
        return ParamPassingMode::In;
    if (as<CppStyleTrailingReceiverParamConstModifier>(specifier))
        return ParamPassingMode::In;
    SLANG_UNREACHABLE("all receiver parameter mode specifiers handled");
}

ParamPassingMode SemanticsVisitor::getDefaultReceiverParamMode(Decl* decl)
{
    if (as<SetterDecl>(decl))
        return ParamPassingMode::BorrowInOut;

    // Declarations other than `FuncDecl`s default to `in`.
    if (!as<FuncDecl>(decl))
        return ParamPassingMode::In;

    // We default synthesized functions to `in` rather than adopting the surrounding HLSL default.
    // For example, `visitLambdaExpr` synthesizes an `operator()` that must satisfy core `IFunc`'s
    // `in` receiver requirement.
    if (decl->hasModifier<SynthesizedModifier>())
        return ParamPassingMode::In;

    // Imported modules finish signature checking in their own semantic context before import.
    // Reflection and specialization read the attached mode, so this language query runs while
    // checking a written method in its owning translation unit.
    if (getSourceLanguage() == SourceLanguage::HLSL)
        return ParamPassingMode::BorrowInOut;
    return ParamPassingMode::In;
}

/// Return the mode specified by the outermost declaration in `policyDecls` that has a specifier.
///
/// Requires innermost-to-outermost declaration order. Returns no mode if none is specified.
static std::optional<ParamPassingMode> _foldReceiverParamModeSpecifiers(
    List<Decl*> const& policyDecls)
{
    std::optional<ParamPassingMode> mode;
    for (auto policyDecl : policyDecls)
    {
        if (auto specifiedMode = _calcReceiverParamModeFromSpecifiers(policyDecl))
            mode = specifiedMode;
    }
    return mode;
}

/// Diagnose receiver parameter mode specifiers on declarations that cannot use them.
///
/// Requires declarations for class members when `isClassMember` is true, or declarations
/// without a receiver parameter otherwise.
static void _diagnoseReceiverParamModeSpecifiers(
    SemanticsVisitor* semantics,
    List<Decl*> const& policyDecls,
    bool isClassMember)
{
    for (auto policyDecl : policyDecls)
    {
        for (auto modifier : policyDecl->modifiers)
        {
            if (!_isReceiverParamModeSpecifier(modifier))
                continue;

            if (isClassMember)
            {
                semantics->getSink()->diagnose(
                    Diagnostics::ReceiverParamModeSpecifierOnClassMember{.specifier = modifier});
            }
            else
            {
                semantics->getSink()->diagnose(
                    Diagnostics::ReceiverParamModeSpecifierWithoutReceiverParam{
                        .specifier = modifier});
            }
        }
    }
}

// Returns whether the effective parameter value type for `decl` must carry `no_diff`. Keeping this
// decision in the side-effect-free computation makes an in-progress signature preview identical
// to the value that will be published when signature checking finishes.
static bool _shouldEffectiveThisParamTypeBeNoDiff(
    SemanticsVisitor* semantics,
    Decl* decl,
    Type* receiverType)
{
    if (decl->hasModifier<NoDiffThisAttribute>() || doesTypeHaveNoDiffModifier(receiverType))
        return true;

    auto callableDecl = as<CallableDecl>(decl);
    return callableDecl && _callableHasDifferentiabilityHeaderModifier(callableDecl) &&
           !semantics->isTypeDifferentiable(receiverType);
}

std::optional<ParamInfo> SemanticsVisitor::checkEffectiveThisParamInfo(
    Decl* decl,
    bool shouldDiagnoseModeAttributes)
{
    // Build the effective `this` parameter from the declaration outward. Constructors do not have
    // such a parameter, and a static or unsupported nesting edge ends the search. Otherwise, walk
    // through property, subscript, and generic containers until reaching the declaration that
    // supplies the receiver value type, collecting the mode policy along the way.
    //
    // Next, resolve that receiver type. An extension on a callable delegates to the callable's
    // effective `this` parameter so that it preserves the callable ABI. Then select the effective
    // mode: a `SynthesizedParamPassingModeModifier` makes the mode declaration-owned; otherwise the
    // default receiver mode, collected policy, and declared receiver type determine it. Declaration
    // ownership is what lets a synthesized wrapper retain a non-`In` mode even for a class
    // receiver; an ordinary class member instead diagnoses mode specifiers and defaults to `In`.
    // Finally, encode `no_diff` in the parameter value type and return the `ParamInfo`.
    List<Decl*> policyDecls;
    policyDecls.add(decl);

    auto diagnoseModeAttributes = [&](bool isClassMember)
    {
        if (shouldDiagnoseModeAttributes)
            _diagnoseReceiverParamModeSpecifiers(this, policyDecls, isClassMember);
    };

    // A constructor operates on a local `this` value that is uninitialized on entry and returned
    // by default at the end of the body. That value is deliberately not modeled as a parameter.
    if (as<ConstructorDecl>(decl))
    {
        diagnoseModeAttributes(false);
        return std::nullopt;
    }

    Decl* innerDecl = decl;
    ContainerDecl* receiverProvider = nullptr;
    for (auto parentDecl = as<ContainerDecl>(innerDecl->parentDecl); parentDecl;
         parentDecl = as<ContainerDecl>(innerDecl->parentDecl))
    {
        // Staticness is a property of each nesting edge. Checking every edge is important for an
        // accessor nested under a static property/subscript and for declarations wrapped in a
        // `GenericDecl`.
        if (isEffectivelyStatic(innerDecl, parentDecl))
        {
            diagnoseModeAttributes(false);
            return std::nullopt;
        }

        if (as<InterfaceDefaultImplDecl>(parentDecl) || as<AggTypeDeclBase>(parentDecl))
        {
            receiverProvider = parentDecl;
            break;
        }

        // These declarations are transparent when finding the declaration that supplies the
        // receiver type, but their modifiers can still participate in the established mode
        // policy.
        if (as<PropertyDecl>(parentDecl) || as<SubscriptDecl>(parentDecl) ||
            as<GenericDecl>(parentDecl))
        {
            policyDecls.add(parentDecl);
            innerDecl = parentDecl;
            continue;
        }

        diagnoseModeAttributes(false);
        return std::nullopt;
    }

    if (!receiverProvider)
    {
        diagnoseModeAttributes(false);
        return std::nullopt;
    }

    Type* receiverType = nullptr;
    ParamPassingMode mode = ParamPassingMode::In;
    bool hasDeclarationOwnedMode = false;
    bool isClassMember = false;

    if (auto synthesizedMode = decl->findModifier<SynthesizedParamPassingModeModifier>())
    {
        mode = synthesizedMode->mode;
        hasDeclarationOwnedMode = true;
    }

    if (auto defaultImplDecl = as<InterfaceDefaultImplDecl>(receiverProvider))
    {
        receiverType =
            DeclRefType::create(m_astBuilder, DeclRef<Decl>(defaultImplDecl->thisTypeDecl));
    }
    else if (auto extensionDecl = as<ExtensionDecl>(receiverProvider))
    {
        ensureDecl(extensionDecl, DeclCheckState::CanUseExtensionTargetType);
        auto targetType = getTargetType(m_astBuilder, makeDeclRef(extensionDecl));
        if (auto targetDeclRefType = as<DeclRefType>(targetType);
            targetDeclRefType && targetDeclRefType->getDeclRef().as<CallableDecl>())
        {
            // A member of an extension on a callable has the same effective receiver as that
            // callable. In particular, the target's mode remains the source of truth, matching
            // the pre-existing ABI for function extensions.
            auto targetInfo = findEffectiveThisParamInfo(targetDeclRefType->getDeclRef());
            if (!targetInfo)
            {
                diagnoseModeAttributes(false);
                return std::nullopt;
            }
            receiverType = targetInfo->type;
            if (!hasDeclarationOwnedMode)
            {
                mode = targetInfo->mode;
                hasDeclarationOwnedMode = true;
            }
            isClassMember = isDeclRefTypeOf<ClassDecl>(unwrapModifiedType(receiverType));
        }
        else
        {
            receiverType = calcThisType(targetType);
            isClassMember = isDeclRefTypeOf<ClassDecl>(unwrapModifiedType(targetType));
        }
    }
    else
    {
        auto aggTypeDecl = as<AggTypeDecl>(receiverProvider);
        SLANG_ASSERT(aggTypeDecl);
        receiverType = calcThisType(getDefaultDeclRef(aggTypeDecl));
        isClassMember = as<ClassDecl>(aggTypeDecl) != nullptr;
    }

    if (!receiverType)
    {
        diagnoseModeAttributes(false);
        return std::nullopt;
    }

    if (isClassMember)
    {
        diagnoseModeAttributes(true);
        if (!hasDeclarationOwnedMode)
            mode = ParamPassingMode::In;
    }
    else if (!hasDeclarationOwnedMode)
    {
        if (auto specifiedMode = _foldReceiverParamModeSpecifiers(policyDecls))
            mode = *specifiedMode;
        else
            mode = getDefaultReceiverParamMode(decl);
        mode = adjustParamPassingModeBasedOnParamType(mode, receiverType);
    }

    if (_shouldEffectiveThisParamTypeBeNoDiff(this, decl, receiverType) &&
        !doesTypeHaveNoDiffModifier(receiverType))
    {
        receiverType =
            m_astBuilder->getModifiedType(receiverType, m_astBuilder->getNoDiffModifierVal());
    }

    ParamInfo result;
    result.type = receiverType;
    result.mode = mode;
    return result;
}

void SemanticsVisitor::checkAndAttachEffectiveThisParamInfo(Decl* decl)
{
    // Abstract storage and generic wrappers contribute context to an accessor/function, but they
    // do not own a callable receiver parameter themselves.
    if (!as<FunctionDeclBase>(decl) && !as<FuncAliasDecl>(decl))
        return;

    SLANG_ASSERT(!decl->findModifier<ThisParamInfoAttribute>());
    auto info = checkEffectiveThisParamInfo(decl, /* shouldDiagnoseModeAttributes */ true);
    if (!info)
        return;

    // The producer has already encoded the effective receiver's `no_diff` status in its value type.
    // When a callable with a differentiability header ends up with such a receiver, also publish
    // the declaration marker used by diagnostics and mangling. An explicit source marker or one
    // copied onto a synthesized wrapper already supplies that policy, so the existing-modifier
    // guard preserves a unique marker. In particular, accessors have a property or subscript
    // between themselves and the aggregate that supplies their receiver; deriving the status with
    // a separate parent walk can easily make interface and satisfying accessors produce different
    // witnesses.
    if (auto callableDecl = as<CallableDecl>(decl);
        callableDecl && _callableHasDifferentiabilityHeaderModifier(callableDecl) &&
        !decl->hasModifier<NoDiffThisAttribute>() && doesTypeHaveNoDiffModifier(info->type))
    {
        auto noDiffThisModifier = m_astBuilder->create<NoDiffThisAttribute>();
        noDiffThisModifier->isSynthesized = true;
        addModifier(decl, noDiffThisModifier);
    }

    auto attribute = m_astBuilder->create<ThisParamInfoAttribute>();
    attribute->loc = decl->loc;
    attribute->info = *info;
    addModifier(decl, attribute);
}

std::optional<ParamInfo> SemanticsVisitor::findEffectiveThisParamInfo(DeclRef<Decl> const& declRef)
{
    ensureDecl(declRef.getDecl(), DeclCheckState::SignatureChecked);

    // A lookup through a callable-as-type can delegate its effective receiver ABI to the callable
    // used as the lookup source. Ensure both declarations before entering the passive query, which
    // asserts that all semantic work has already been completed.
    if (auto lookupDeclRef = as<LookupDeclRef>(declRef.declRefBase))
    {
        if (auto callableDeclRef = isDeclRefTypeOf<CallableDecl>(lookupDeclRef->getLookupSource()))
        {
            ensureDecl(callableDeclRef.getDecl(), DeclCheckState::SignatureChecked);
        }
    }

    return Slang::findEffectiveThisParamInfo(m_astBuilder, declRef);
}

ParamInfo SemanticsVisitor::getEffectiveThisParamInfo(DeclRef<Decl> const& declRef)
{
    auto result = findEffectiveThisParamInfo(declRef);
    SLANG_RELEASE_ASSERT(result.has_value());
    return *result;
}

Type* SemanticsVisitor::findResultTypeForConstructorDecl(ConstructorDecl* decl)
{
    // We want to look at the parent of the declaration,
    // but if the declaration is generic, the parent will be
    // the `GenericDecl` and we need to skip past that to
    // the grandparent.
    //
    auto parent = decl->parentDecl;
    auto genericParent = as<GenericDecl>(parent);
    if (genericParent)
    {
        parent = genericParent->parentDecl;
    }

    // The result type for a constructor is whatever `This` would
    // refer to in the body of the outer declaration.
    //
    auto thisType = calcThisType(makeDeclRef(parent));
    if (!thisType)
    {
        // The nesting validation in validateDeclNesting already reports the error;
        // assert to catch regressions if that check is ever bypassed.
        SLANG_ASSERT(getSink()->getErrorCount() > 0);
        thisType = m_astBuilder->getErrorType();
    }
    return thisType;
}

void SemanticsDeclHeaderVisitor::visitConstructorDecl(ConstructorDecl* decl)
{
    // We need to compute the result type for this declaration,
    // since it wasn't filled in for us.
    decl->returnType.type = findResultTypeForConstructorDecl(decl);

    checkCallableDeclCommon(decl);
}

void SemanticsDeclHeaderVisitor::visitAbstractStorageDeclCommon(ContainerDecl* decl)
{
    // If we have a subscript or property declaration with no accessor declarations,
    // then we should create a single `GetterDecl` to represent
    // the implicit meaning of their declaration, so:
    //
    //      subscript(uint index) -> T;
    //      property x : Y;
    //
    // becomes:
    //
    //      subscript(uint index) -> T { get; }
    //      property x : Y { get; }
    //

    bool anyAccessors = decl->getMembersOfType<AccessorDecl>().isNonEmpty();
    for (auto accessor : decl->getMembersOfType<AccessorDecl>())
    {
        checkInterfaceRequirement(accessor);
    }
    if (!anyAccessors)
    {
        GetterDecl* getterDecl = m_astBuilder->create<GetterDecl>();
        getterDecl->loc = decl->loc;

        decl->addMember(getterDecl);
    }
}

void SemanticsDeclHeaderVisitor::visitSubscriptDecl(SubscriptDecl* decl)
{
    decl->returnType = CheckUsableType(decl->returnType, decl);

    visitAbstractStorageDeclCommon(decl);

    checkCallableDeclCommon(decl);

    for (auto param : decl->getParameters())
    {
        auto mode = getParamPassingMode(param);
        if (mode != ParamPassingMode::In && mode != ParamPassingMode::BorrowIn)
        {
            getSink()->diagnose(
                Diagnostics::SubscriptParamMustBeInputOnly{.mode = mode, .param = param});
        }
    }
}

void SemanticsDeclHeaderVisitor::visitPropertyDecl(PropertyDecl* decl)
{
    SemanticsVisitor subVisitor(withDeclToExcludeFromLookup(decl));
    decl->type = subVisitor.CheckUsableType(decl->type, decl);
    visitAbstractStorageDeclCommon(decl);
    checkVisibility(decl);
}

void SemanticsDeclHeaderVisitor::visitSemanticDecl(SemanticDecl* decl)
{
    for (auto member : decl->getMembers())
        dispatch(member);
}

void SemanticsDeclHeaderVisitor::visitSemanticGetterDecl(SemanticGetterDecl* decl)
{
    decl->type = CheckUsableType(decl->type, decl);
}

void SemanticsDeclHeaderVisitor::visitSemanticSetterDecl(SemanticSetterDecl* decl)
{
    decl->type = CheckUsableType(decl->type, decl);
}

Type* SemanticsDeclHeaderVisitor::_getAccessorStorageType(AccessorDecl* decl)
{
    auto parentDecl = decl->parentDecl;
    if (auto parentSubscript = as<SubscriptDecl>(parentDecl))
    {
        ensureDecl(parentSubscript, DeclCheckState::CanUseTypeOfValueDecl);
        return parentSubscript->returnType;
    }
    else if (auto parentProperty = as<PropertyDecl>(parentDecl))
    {
        ensureDecl(parentProperty, DeclCheckState::CanUseTypeOfValueDecl);
        return parentProperty->type.type;
    }
    else
    {
        // validateDeclNesting enforces that accessors only appear inside
        // subscript or property; assert to catch regressions.
        SLANG_ASSERT(getSink()->getErrorCount() > 0);
        return getASTBuilder()->getErrorType();
    }
}

// Check whether an AST type includes a dynamic-dispatch interface,
// i.e. a non-COM, non-builtin interface that requires AnyValue packing.
// This mirrors the IR-level `typeIncludesDynamicDispatch()` in
// slang-ir-typeflow-specialize.cpp but operates on AST types so it
// can be used during semantic checking.
//
// `visitor` is used to ensure struct field types are resolved via
// ensureDecl before inspection.  `seenDecls` guards against infinite
// recursion on self-recursive aggregates.
static bool _astTypeIncludesDynamicDispatch(
    SemanticsVisitor* visitor,
    Type* type,
    HashSet<Decl*>& seenDecls)
{
    // Peel ModifiedType wrappers (e.g. `const`, `volatile`).
    while (auto modifiedType = as<ModifiedType>(type))
        type = modifiedType->getBase();

    if (auto declRefType = as<DeclRefType>(type))
    {
        if (auto interfaceDecl = as<InterfaceDecl>(declRefType->getDeclRef().getDecl()))
        {
            bool isCom = interfaceDecl->findModifier<ComInterfaceAttribute>() != nullptr;
            bool isBuiltin = interfaceDecl->findModifier<BuiltinAttribute>() != nullptr;
            if (!isCom && !isBuiltin)
                return true;
        }
    }

    if (auto structType = as<DeclRefType>(type))
    {
        if (auto structDecl = as<StructDecl>(structType->getDeclRef().getDecl()))
        {
            if (!seenDecls.add(structDecl))
                return false;
            for (auto field : structDecl->getFields())
            {
                visitor->ensureDecl(field, DeclCheckState::CanUseTypeOfValueDecl);
                // Use getMemberDeclRef + getType to apply generic substitutions,
                // so that e.g. Box<IFoo> with field `T item` resolves T to IFoo.
                auto fieldDeclRef = visitor->getASTBuilder()
                                        ->getMemberDeclRef(structType->getDeclRef(), field)
                                        .as<VarDeclBase>();
                auto fieldType = fieldDeclRef ? getType(visitor->getASTBuilder(), fieldDeclRef)
                                              : field->type.type;
                if (fieldType && _astTypeIncludesDynamicDispatch(visitor, fieldType, seenDecls))
                    return true;
            }
            seenDecls.remove(structDecl);
        }
    }

    if (auto arrayType = as<ArrayExpressionType>(type))
    {
        if (auto elemType = arrayType->getElementType())
            return _astTypeIncludesDynamicDispatch(visitor, elemType, seenDecls);
    }

    if (auto optionalType = as<OptionalType>(type))
    {
        if (auto valType = optionalType->getValueType())
            return _astTypeIncludesDynamicDispatch(visitor, valType, seenDecls);
    }

    if (auto tupleType = as<TupleType>(type))
    {
        for (Index i = 0; i < tupleType->getMemberCount(); i++)
        {
            if (auto memberType = tupleType->getMember(i))
            {
                if (_astTypeIncludesDynamicDispatch(visitor, memberType, seenDecls))
                    return true;
            }
        }
    }

    return false;
}


void SemanticsDeclHeaderVisitor::visitAccessorDecl(AccessorDecl* decl)
{

    // Note: This subroutine is used by both `get`
    // and `ref` accessors, but is bypassed by
    // `set` accessors (which use `visitSetterDecl`
    // intead).

    // Accessors (other than setters) don't support
    // parameters.
    //
    if (decl->getParameters().getCount() != 0)
    {
        getSink()->diagnose(Diagnostics::NonSetAccessorMustNotHaveParams{.decl = decl});
    }

    // By default, the return type of an accessor is treated as
    // the type of the abstract storage location being accessed.
    //
    // A `ref`  accessor currently relies on this logic even though
    // it isn't quite correct, because we don't have support
    // for by-reference return values today. This is a non-issue
    // for now because we don't support user-defined `ref`
    // accessors yet.
    //
    // TODO: Once we can support the by-reference return value
    // correctly *or* we can move to something like a coroutine-based
    // `modify` accessor (a la Swift), we should split out
    // handling of `RefAccessorDecl` and only use this routine
    // for `GetterDecl`s.
    //
    decl->returnType.type = _getAccessorStorageType(decl);

    // A `ref` accessor returns a reference to the storage location.
    // If the storage type involves a dynamic-dispatch interface, the
    // reference would point directly into AnyValue-packed existential
    // storage, bypassing the pack/unpack marshalling that dynamic
    // dispatch requires.  This leads to runtime corruption/segfaults,
    // so we reject it at compile time.
    if (as<RefAccessorDecl>(decl))
    {
        auto storageType = decl->returnType.type;
        HashSet<Decl*> seenDecls;
        if (storageType && _astTypeIncludesDynamicDispatch(this, storageType, seenDecls))
        {
            getSink()->diagnose(Diagnostics::RefAccessorWithInterfaceTypeInDynamicDispatch{
                .valueType = storageType,
                .location = decl->loc});
            decl->returnType.type = getASTBuilder()->getErrorType();
        }
    }

    // Accessors skip `checkCallableDeclCommon` and cannot spell `throws`, so this gives the body
    // the `Bottom` error type that `throw`/`try` checking reads.
    checkCallableErrorType(decl);
    checkDifferentiableCallableSignature(decl);
}

void SemanticsDeclHeaderVisitor::visitSetterDecl(SetterDecl* decl)
{
    // A `set` accessor always returns `void`.
    //
    decl->returnType.type = getASTBuilder()->getVoidType();

    // A setter always receives a single value representing
    // the new value to set into the storage.
    //
    // The user may declare that parameter explicitly and
    // thereby control its name, or they can declare no
    // parameters and allow the compiler to synthesize one
    // named `newValue`.
    //
    ParamDecl* newValueParam = nullptr;
    auto params = decl->getParameters();
    if (params.getCount() >= 1)
    {
        // If the user declared an explicit parameter
        // then that is the one that will represent
        // the new value.
        //
        newValueParam = params.getFirst();

        if (params.getCount() > 1)
        {
            // If the user declared more than one explicit
            // parameter, then that is an error.
            //
            getSink()->diagnose(
                Diagnostics::SetAccessorMayNotHaveMoreThanOneParam{.param = params[1]});
        }
    }
    else
    {
        // If the user didn't declare any explicit parameters,
        // then we create an implicit one and add it into
        // the AST.
        //
        newValueParam = m_astBuilder->create<ParamDecl>();
        newValueParam->nameAndLoc.name = getName("newValue");
        newValueParam->nameAndLoc.loc = decl->loc;

        decl->addMember(newValueParam);
    }

    // The new-value parameter is expected to have the
    // same type as the abstract storage that the
    // accessor is setting.
    //
    auto newValueType = _getAccessorStorageType(decl);

    // It is allowed and encouraged for the programmer
    // to leave off the type on the new-value parameter,
    // in which case we will set it to the expected
    // type automatically.
    //
    if (!newValueParam->type.exp)
    {
        newValueParam->type.type = newValueType;
    }
    else
    {
        // If the user *did* give the new-value parameter
        // an explicit type, then we need to check it
        // and then enforce that it matches what we expect.
        //
        auto actualType = CheckProperType(newValueParam->type);
        newValueParam->type = actualType;
        auto actualValueType = getParamValueType(m_astBuilder, makeDeclRef(newValueParam));

        if (as<ErrorType>(actualType))
        {
        }
        else if (actualValueType->equals(newValueType))
        {
        }
        else
        {
            getSink()->diagnose(Diagnostics::SetAccessorParamWrongType{
                .actualType = actualValueType,
                .expectedType = newValueType,
                .param = newValueParam});
        }
    }

    if (newValueParam->initExpr)
    {
        getSink()->diagnose(Diagnostics::SetAccessorParamCannotHaveDefaultValue{
            .initExpr = newValueParam->initExpr});
    }

    auto newValueMode = getParamPassingMode(newValueParam);
    if (newValueMode != ParamPassingMode::In && newValueMode != ParamPassingMode::BorrowIn)
    {
        getSink()->diagnose(Diagnostics::SetAccessorParamMustBeInputOnly{
            .mode = newValueMode,
            .param = newValueParam});
    }
    // As for the other accessors in `visitAccessorDecl`.
    checkCallableErrorType(decl);
    checkDifferentiableCallableSignature(decl);
}

GenericDecl* SemanticsVisitor::GetOuterGeneric(Decl* decl)
{
    auto parentDecl = decl->parentDecl;
    if (!parentDecl)
        return nullptr;
    auto parentGeneric = as<GenericDecl>(parentDecl);
    return parentGeneric;
}

Decl* SemanticsVisitor::getOuterGenericOrSelf(Decl* decl)
{
    auto parentDecl = decl->parentDecl;
    if (!parentDecl)
        return decl;
    auto parentGeneric = as<GenericDecl>(parentDecl);
    if (!parentGeneric)
        return decl;
    return parentGeneric;
}

GenericDecl* SemanticsVisitor::findNextOuterGeneric(Decl* decl)
{
    for (auto p = decl->parentDecl; p; p = p->parentDecl)
    {
        if (auto genDecl = as<GenericDecl>(p))
            return genDecl;
    }
    return nullptr;
}

DeclRef<ExtensionDecl> SemanticsVisitor::applyExtensionToType(
    ExtensionDecl* extDecl,
    Type* type,
    Dictionary<Type*, SubtypeWitness*>* additionalSubtypeWitnessesForType)
{
    DeclRef<ExtensionDecl> extDeclRef = makeDeclRef(extDecl);

    // If the extension is a generic extension, then we
    // need to infer type arguments that will give
    // us a target type that matches `type`.
    //
    if (auto extGenericDecl = GetOuterGeneric(extDecl))
    {
        GenericInferenceContext inferenceContext;
        inferenceContext.genericDecl = extGenericDecl;
        if (additionalSubtypeWitnessesForType)
        {
            inferenceContext.subTypeForAdditionalWitnesses = type;
            inferenceContext.additionalSubtypeWitnesses = additionalSubtypeWitnessesForType;
        }

        // Inside the body of an extension declaration, we may end up trying to apply that
        // extension to its own target type.
        // If we see that we are in that case, we can apply the extension declaration as - is,
        // without any additional substitutions.
        if (extDecl->targetType->equals(type))
            return createDefaultSubstitutionsIfNeeded(m_astBuilder, this, extDeclRef)
                .as<ExtensionDecl>();

        if (!TryUnifyTypes(inferenceContext, UnificationOptions(), extDecl->targetType.Ptr(), type))
        {
            return DeclRef<ExtensionDecl>();
        }

        ConversionCost baseCost;
        auto solvedDeclRef = trySolveGenericArguments(
            _Move(inferenceContext),
            makeDeclRef(extGenericDecl),
            ArrayView<Val*>(),
            baseCost);
        if (!solvedDeclRef)
        {
            return DeclRef<ExtensionDecl>();
        }

        // Construct a reference to the extension with our inference variables
        // set as they were found by solving the generic arguments.
        extDeclRef = solvedDeclRef.as<ExtensionDecl>();
    }

    // Now extract the target type from our (possibly specialized) extension decl-ref.
    Type* targetType = getTargetType(m_astBuilder, extDeclRef);

    // As a bit of a kludge here, if the target type of the extension is
    // an interface, and the `type` we are trying to match up has a this-type
    // substitution for that interface, then we want to attach a matching
    // substitution to the extension decl-ref.
    if (auto targetDeclRefType = as<DeclRefType>(targetType))
    {
        if (auto targetInterfaceDeclRef = targetDeclRefType->getDeclRef().as<InterfaceDecl>())
        {
            // Okay, the target type is an interface.
            //
            // Is the type we want to apply to a ThisType?
            if (auto appDeclRefType = as<ThisType>(type))
            {
                if (auto thisTypeLookupDeclRef =
                        SubstitutionSet(appDeclRefType->getDeclRef()).findLookupDeclRef())
                {
                    if (thisTypeLookupDeclRef->getDecl() == targetInterfaceDeclRef.getDecl())
                    {
                        // Looks like we have a match in the types,
                        // now let's see if `type`'s declref starts with a Lookup.
                        targetType = type;
                        extDeclRef = m_astBuilder
                                         ->getLookupDeclRef(
                                             thisTypeLookupDeclRef->getWitness(),
                                             extDeclRef.getDecl())
                                         .as<ExtensionDecl>();
                    }
                }
            }
        }
    }

    // In order for this extension to apply to the given type, we
    // need to have a match on the target types.
    if (!type->equals(targetType))
        return DeclRef<ExtensionDecl>();

    return extDeclRef;
}

QualType SemanticsVisitor::GetTypeForDeclRef(DeclRef<Decl> declRef, SourceLoc loc)
{
    Type* typeResult = nullptr;
    return getTypeForDeclRef(m_astBuilder, this, getSink(), declRef, &typeResult, loc);
}

void SemanticsVisitor::importFileDeclIntoScope(Scope* scope, FileDecl* fileDecl)
{
    // Create a new sub-scope to wire the module
    // into our lookup chain.
    if (!fileDecl)
        return;
    addSiblingScopeForContainerDecl(getASTBuilder(), scope, fileDecl);
}

void SemanticsVisitor::importModuleIntoScope(Scope* scope, ModuleDecl* moduleDecl)
{
    if (!moduleDecl)
        return;

    // If we've imported this one already, then
    // skip the step where we modify the current scope.
    auto& importedModulesList = getShared()->importedModulesList;
    auto& importedModulesSet = getShared()->importedModulesSet;
    if (importedModulesSet.contains(moduleDecl))
    {
        return;
    }

    if (getText(moduleDecl->getName()) == "glsl")
    {
        // This is deliberately narrower than selecting GLSL as the source language. The parser
        // has already run, and all other language-dependent behavior continues to use the
        // translation unit's effective `sourceLanguage`. Retain only the historical effect that
        // importing this module enables GLSL's builtin operator rules.
        getShared()->m_hasImportedGLSLModule = true;
    }

    importedModulesList.add(moduleDecl);
    importedModulesSet.add(moduleDecl);

    // Create a new sub-scope to wire the module's scope and its nested FileDecl's scopes
    // into our lookup chain.
    for (auto moduleScope = moduleDecl->ownedScope; moduleScope;
         moduleScope = moduleScope->nextSibling)
    {
        // Re-export only this module's own scope and its own `__include`d files;
        // drop `using`-spliced namespace siblings (a primary-file `using namespace
        // Foo;` must not leak through `import`) and any foreign module's files that a
        // plain transitive `import` put on the chain. See
        // `isOwnModuleOrIncludedFileScope` / shader-slang/slang#11443.
        auto containerDecl = moduleScope->containerDecl;
        if (!isOwnModuleOrIncludedFileScope(containerDecl, moduleDecl))
            continue;

        addSiblingScopeForContainerDecl(getASTBuilder(), scope, containerDecl);
    }

    // Also import any modules from nested `import` declarations
    // with the `__exported` modifier
    for (auto importDecl : moduleDecl->getMembersOfType<ImportDecl>())
    {
        if (!importDecl->hasModifier<ExportedModifier>())
            continue;

        importModuleIntoScope(scope, importDecl->importedModuleDecl);
    }
}

void SemanticsDeclHeaderVisitor::visitImportDecl(ImportDecl* decl)
{
    // We need to look for a module with the specified name
    // (whether it has already been loaded, or needs to
    // be loaded), and then put its declarations into
    // the module's scope.

    auto name = decl->moduleNameAndLoc.name;
    if (!name)
        return;

    auto scope = getModuleDecl(decl)->ownedScope;

    // Try to load a module matching the name
    auto importedModule = findOrImportModule(
        getLinkage(),
        name,
        decl->moduleNameAndLoc.loc,
        getSink(),
        getShared()->m_environmentModules);

    // If we didn't find a matching module, then bail out
    if (!importedModule)
        return;

    // Record the module that was imported, so that we can use
    // it later during code generation.
    auto importedModuleDecl = importedModule->getModuleDecl();
    decl->importedModuleDecl = importedModuleDecl;

    // Add the declarations from the imported module into the scope
    // that the `import` declaration is set to extend.
    //
    importModuleIntoScope(scope, importedModuleDecl);

    // Record the `import`ed module (and everything it depends on)
    // as a dependency of the module we are compiling.
    if (auto module = getModule(decl))
    {
        module->addModuleDependency(importedModule);
    }
}

String getSimpleModuleName(Name* name)
{
    auto text = getText(name);
    auto dirPos = Math::Max(text.indexOf('/'), text.indexOf('\\'));
    if (dirPos < 0)
        return text;
    auto slice = text.getUnownedSlice().tail(dirPos + 1);
    auto dotPos = slice.indexOf('.');
    if (dotPos < 0)
        return slice;
    return String(slice.head(dotPos));
}

ModuleDeclarationDecl* findExistingModuleDeclarationDecl(ModuleDecl* moduleDecl)
{
    auto firstMemberOfModule = moduleDecl->getFirstDirectMemberDecl();
    if (!firstMemberOfModule)
        return nullptr;

    if (auto found = as<ModuleDeclarationDecl>(firstMemberOfModule))
        return found;

    for (auto fileDecl : moduleDecl->getMembersOfType<FileDecl>())
    {
        auto firstMemberOfFile = fileDecl->getFirstDirectMemberDecl();
        if (!firstMemberOfFile)
            continue;
        if (auto found = as<ModuleDeclarationDecl>(firstMemberOfFile))
            return found;
    }
    return nullptr;
}

void SemanticsDeclHeaderVisitor::visitIncludeDecl(IncludeDecl* decl)
{
    auto name = decl->moduleNameAndLoc.name;
    if (!name)
        return;

    if (!getShared()->getTranslationUnitRequest())
        getSink()->diagnose(
            Diagnostics::CannotProcessInclude{.location = decl->moduleNameAndLoc.loc});

    auto parentModule = getModule(decl);
    auto moduleDecl = parentModule->getModuleDecl();

    auto [fileDecl, isNew] = getLinkage()->findAndIncludeFile(
        getModule(decl),
        getShared()->getTranslationUnitRequest(),
        name,
        decl->moduleNameAndLoc.loc,
        getSink());

    if (!fileDecl)
        return;

    decl->fileDecl = fileDecl;

    if (!isNew)
        return;

    auto firstDeclInFile = fileDecl->getFirstDirectMemberDecl();
    if (!firstDeclInFile)
        return;

    if (auto moduleDeclaration = as<ModuleDeclarationDecl>(firstDeclInFile))
    {
        // We are trying to include a file that defines a module, the user could mean "import"
        // instead.
        getSink()->diagnose(Diagnostics::IncludedFileMissingImplementingDoYouMeanImport{
            .fileName = getText(name),
            .moduleName = getText(moduleDeclaration->getName()),
            .location = decl->moduleNameAndLoc.loc});
        return;
    }

    importFileDeclIntoScope(moduleDecl->ownedScope, fileDecl);

    if (auto implementing = as<ImplementingDecl>(firstDeclInFile))
    {
        // The file we are including must be implementing the current module.
        auto moduleName = getSimpleModuleName(implementing->moduleNameAndLoc.name);
        auto expectedModuleName = moduleDecl->getName();
        bool shouldSkipDiagnostic = false;

        if (auto firstDeclInModule = moduleDecl->getFirstDirectMemberDecl())
        {
            if (auto moduleDeclarationDecl = as<ModuleDeclarationDecl>(firstDeclInModule))
            {
                expectedModuleName = moduleDeclarationDecl->getName();
            }
            else if (getShared()->isInLanguageServer())
            {
                auto existingModuleDeclarationDecl = findExistingModuleDeclarationDecl(moduleDecl);
                if (existingModuleDeclarationDecl)
                {
                    expectedModuleName = existingModuleDeclarationDecl->getName();
                }
                else
                {
                    shouldSkipDiagnostic = true;
                }
            }
        }

        if (!shouldSkipDiagnostic)
        {
            // First check for the case when the user has put a file extension
            // in the include path
            String moduleNameStr = moduleName.getUnownedSlice();
            String expectedModuleNameStr = getText(expectedModuleName).getUnownedSlice();

            // Check if module name has a source file extension
            if (moduleNameStr.endsWith(".slang"))
            {
                String normalizedName = moduleNameStr.subString(0, moduleNameStr.getLength() - 6);

                // If the normalized name would match, emit warning but continue
                if (normalizedName.getUnownedSlice().caseInsensitiveEquals(
                        expectedModuleNameStr.getUnownedSlice()))
                {
                    getSink()->diagnose(Diagnostics::ModuleImplementationHasFileExtension{
                        .moduleName = moduleNameStr,
                        .normalizedName = normalizedName,
                        .location = implementing->moduleNameAndLoc.loc});
                    return;
                }
            }

            if (!moduleNameStr.getUnownedSlice().caseInsensitiveEquals(
                    expectedModuleNameStr.getUnownedSlice()))
            {
                getSink()->diagnose(Diagnostics::IncludedFileDoesNotImplementCurrentModule{
                    .expectedModule = expectedModuleName,
                    .actualModule = moduleName,
                    .location = decl->moduleNameAndLoc.loc});
                return;
            }
        }

        return;
    }

    getSink()->diagnose(Diagnostics::IncludedFileMissingImplementing{
        .fileName = getText(name),
        .location = decl->moduleNameAndLoc.loc});
}


void SemanticsDeclScopeWiringVisitor::visitImplementingDecl(ImplementingDecl* decl)
{
    // Don't need to do anything unless we are in a language server context.
    if (!getShared()->isInLanguageServer())
        return;

    // Treat an `implementing` declaration as an `include` declaration when
    // we are in a language server context.

    auto name = decl->moduleNameAndLoc.name;
    if (!name)
        return;

    if (!getShared()->getTranslationUnitRequest())
        getSink()->diagnose(
            Diagnostics::CannotProcessInclude{.location = decl->moduleNameAndLoc.loc});

    auto [fileDecl, isNew] = getLinkage()->findAndIncludeFile(
        getModule(decl),
        getShared()->getTranslationUnitRequest(),
        name,
        decl->moduleNameAndLoc.loc,
        getSink());

    decl->fileDecl = fileDecl;

    if (!isNew)
        return;

    if (!fileDecl)
        return;

    auto firstDeclInFile = fileDecl->getFirstDirectMemberDecl();
    if (!firstDeclInFile)
        return;

    if (as<ModuleDeclarationDecl>(firstDeclInFile))
    {
        // We are trying to implement a file that defines a module, this is expected.
    }
    else if (as<ImplementingDecl>(firstDeclInFile))
    {
        getSink()->diagnose(Diagnostics::ImplementingMustReferencePrimaryModuleFile{
            .location = decl->moduleNameAndLoc.loc});
        return;
    }

    if (auto moduleDecl = getModuleDecl(decl))
        importFileDeclIntoScope(moduleDecl->ownedScope, fileDecl);
}

void SemanticsDeclScopeWiringVisitor::visitUsingDecl(UsingDecl* decl)
{
    // First, we need to look up whatever the argument of the `using`
    // declaration names.
    //
    decl->arg = CheckTerm(decl->arg);

    // Next, we want to ensure that whatever is being named by `decl->arg`
    // is a namespace (or a module, since modules are namespace-like).
    //
    // If a user `import`s multiple modules that all have namespaces
    // of the same name, it would be possible for `decl->arg` to be overloaded.
    // To handle that case, we will iterate over all the entities that are
    // named and import any that are namespace-like.
    //
    bool scopesAdded = false;
    bool hasValidNamespace = false;

    // TODO: consider caching the scope set in NamespaceDecl.
    HashSet<ContainerDecl*> addedScopes;
    for (auto s = decl->scope; s; s = s->nextSibling)
        addedScopes.add(s->containerDecl);

    auto addAllSiblingScopesFromDecl = [&](Scope* scope, ContainerDecl* containerDecl)
    {
        for (auto s = containerDecl->ownedScope; s; s = s->nextSibling)
        {
            if (addedScopes.add(s->containerDecl))
            {
                scopesAdded = true;
                addSiblingScopeForContainerDecl(getASTBuilder(), scope, s->containerDecl);
            }
        }
    };

    if (auto declRefExpr = as<DeclRefExpr>(decl->arg))
    {
        if (auto namespaceDeclRef = declRefExpr->declRef.as<NamespaceDeclBase>())
        {
            auto namespaceDecl = namespaceDeclRef.getDecl();
            addAllSiblingScopesFromDecl(decl->scope, namespaceDecl);
            hasValidNamespace = true;
        }
    }
    else if (auto overloadedExpr = as<OverloadedExpr>(decl->arg))
    {
        for (auto item : overloadedExpr->lookupResult2)
        {
            if (auto namespaceDeclRef = item.declRef.as<NamespaceDeclBase>())
            {
                addAllSiblingScopesFromDecl(decl->scope, namespaceDeclRef.getDecl());
                hasValidNamespace = true;
            }
        }
    }

    if (!scopesAdded)
    {
        if (!hasValidNamespace)
            getSink()->diagnose(Diagnostics::ExpectedANamespace{.expr = decl->arg});
        return;
    }
}

void SemanticsDeclScopeWiringVisitor::visitNamespaceDecl(NamespaceDecl* decl)
{
    // Every scope that the parser creates for a namespace is in `lexicalScopes`, so wiring
    // all of them covers `ownedScope` too. A namespace with no body, such as one that a
    // `syntax` declaration creates, has no scopes and nothing to wire.
    SLANG_ASSERT(!decl->ownedScope || decl->lexicalScopes.contains(decl->ownedScope));

    // We need to wire up the scope of namespaces with other namespace decls of the same name
    // that is accessible from the current context.
    auto parent = as<ContainerDecl>(getParentDecl(decl));
    if (!parent)
        return;
    for (auto parentScope = parent->ownedScope; parentScope; parentScope = parentScope->parent)
    {
        for (auto scope = parentScope; scope; scope = scope->nextSibling)
        {
            auto container = scope->containerDecl;
            auto nsDecl = container->findLastDirectMemberDeclOfName(decl->getName());
            if (!nsDecl)
                continue;
            for (auto ns = nsDecl; ns; ns = container->getPrevDirectMemberDeclWithSameName(ns))
            {
                if (ns == decl)
                    continue;
                auto otherNamespace = as<NamespaceDeclBase>(ns);
                if (!otherNamespace)
                    continue;

                if (!ns->checkState.isBeingChecked())
                {
                    ensureDecl(ns, DeclCheckState::ScopesWired);
                }
                // We attach the other namespace to every scope of `decl`, not only to
                // `ownedScope`, because code in each body of a reopened namespace looks up
                // names through the scope of that body.
                for (auto lexicalScope : decl->lexicalScopes)
                    addSiblingScopeForContainerDecl(getASTBuilder(), lexicalScope, otherNamespace);
            }
        }
        // For file decls, we need to continue searching up in the parent module scope.
        if (!as<FileDecl>(parentScope->containerDecl))
            break;
    }
    for (auto usingDecl : decl->getMembersOfType<UsingDecl>())
    {
        ensureDecl(usingDecl, DeclCheckState::ScopesWired);
    }
}

/// Get a reference to the candidate extension list for `typeDecl` in the given dictionary
///
/// Note: this function creates an empty list of candidates for the given type if
/// a matching entry doesn't exist already.
///
static List<ExtensionDecl*>& _getCandidateExtensionList(
    Decl* decl,
    Dictionary<Decl*, RefPtr<CandidateExtensionList>>& mapDeclToCandidateExtensions)
{
    RefPtr<CandidateExtensionList> entry;
    if (!mapDeclToCandidateExtensions.tryGetValue(decl, entry))
    {
        entry = new CandidateExtensionList();
        mapDeclToCandidateExtensions.add(decl, entry);
    }
    return entry->candidateExtensions;
}

List<ExtensionDecl*> const& SharedSemanticsContext::getCandidateExtensionsForTypeDecl(Decl* decl)
{
    // We are caching the lists of candidate extensions on the shared
    // context, so we will only build the lists if they either have
    // not been built before, or if some code caused the lists to
    // be invalidated.
    //
    // For API/reflection contexts (when m_module is null), we use an
    // incremental update strategy similar to ContainerDecl's lookup
    // accelerators: we track how many modules we've processed and only
    // add extensions from newly-loaded modules.
    //
    // For module-scoped contexts (when m_module is set), we don't need this
    // check because all imports are processed upfront before the cache is built.
    //
    if (!m_candidateExtensionListsBuilt)
    {
        m_candidateExtensionListsBuilt = true;

        // We need to make sure that all extensions that were declared
        // as parts of our core module are always visible,
        // even if they are not explicit `import`ed into user code.
        //
        for (auto module : getSession()->coreModules)
        {
            _addCandidateExtensionsFromModule(module->getModuleDecl());
        }

        // There are two primary modes in which the `SharedSemanticsContext`
        // gets used.
        //
        // In the first mode, we are checking an entire `ModuleDecl`, and we
        // need to always check things from the "point of view" of that module
        // (so that the extensions that should be visible are based on what
        // that module can access via `import`s).
        //
        // In the second mode, we are checking code related to API interactions
        // by the user (e.g., parsing a type from a string, specializing an
        // entry point to type arguments, etc.). In these cases there is no
        // clear module that should determine the point of view for looking
        // up extensions, and we instead need/want to consider any extensions
        // from all modules loaded into the linkage.
        //
        // We differentiate these cases based on whether a "primary" module
        // was set at the time the `SharedSemanticsContext` was constructed.
        //
        if (m_module)
        {
            // We have a "primary" module that is being checked, and we should
            // look up extensions based on what would be visible to that
            // module.
            //
            // Extensions declared in the module itself should have already
            // been registered when we check them, but we still need to bring
            // along with everything the module imported.
            //
            // Note: there is an implicit assumption here that the `importedModules`
            // member on the `SharedSemanticsContext` is accurate in this case.
            //
            for (auto moduleDecl : this->importedModulesList)
            {
                _addCandidateExtensionsFromModule(moduleDecl);
            }
        }
        else
        {
            // We are in one of the many ad hoc checking modes where we really
            // want to resolve things based on the totality of what is
            // available/defined within the current linkage.
            //
            for (auto module : m_linkage->loadedModulesList)
            {
                _addCandidateExtensionsFromModule(module->getModuleDecl());
            }
            m_candidateExtensionListsBuiltForModuleCount = m_linkage->loadedModulesList.getCount();
        }
    }
    else if (!m_module)
    {
        // For ad hoc contexts without a primary module, incrementally add
        // extensions from any modules that have been loaded since we last
        // updated the cache. This follows the same pattern as ContainerDecl's
        // lookup accelerators.
        //
        Index currentModuleCount = m_linkage->loadedModulesList.getCount();
        Index processedModuleCount = m_candidateExtensionListsBuiltForModuleCount;

        SLANG_ASSERT(processedModuleCount >= 0 && processedModuleCount <= currentModuleCount);

        // Only process NEW modules (incremental update)
        for (Index i = processedModuleCount; i < currentModuleCount; ++i)
        {
            auto module = m_linkage->loadedModulesList[i];
            _addCandidateExtensionsFromModule(module->getModuleDecl());
        }

        m_candidateExtensionListsBuiltForModuleCount = currentModuleCount;
    }

    // Once we are sure that the dictionary-of-arrays of extensions
    // has been populated, we return to the user the entry they
    // asked for.
    //
    return _getCandidateExtensionList(decl, m_mapDeclToCandidateExtensions);
}

void SharedSemanticsContext::invalidateInheritanceInfo(Type* type)
{
    if (auto declRefType = as<DeclRefType>(type))
    {
        m_mapDeclRefToInheritanceInfo.remove(declRefType->getDeclRef());
    }
    else
    {
        m_mapTypeToInheritanceInfo.remove(type);
    }
}

void SharedSemanticsContext::registerCandidateExtension(Decl* typeDecl, ExtensionDecl* extDecl)
{
    // The primary cache of extension declarations is on the `ModuleDecl`.
    // We will add the `extDecl` to the cache for the module it belongs to.
    //
    // We can be sure that the resulting cache won't have lifetime issues,
    // because all the extensions it contains are owned by the module itself,
    // and the types used as keys had to be reachable/referenceable from the
    // code inside the module for the given `extDecl` to extend them.
    //
    auto moduleDecl = getModuleDecl(extDecl);
    _getCandidateExtensionList(typeDecl, moduleDecl->mapDeclToCandidateExtensions).add(extDecl);

    // Because we've loaded a new extension, we need to invalidate whatever
    // information the `SharedSemanticsContext` had cached about loaded
    // extensions, and force it to rebuild its cache to include the
    // new extension we just added.
    //
    _getCandidateExtensionList(typeDecl, m_mapDeclToCandidateExtensions).add(extDecl);

    bool hasImplicitCastMember = false;
    for (auto member : extDecl->getDirectMemberDecls())
    {
        if (auto ctorDecl = as<ConstructorDecl>(member))
        {
            if (ctorDecl->hasModifier<ImplicitConversionModifier>())
                hasImplicitCastMember = true;
        }
    }

    // A new extension can affect not only `typeDecl` itself, but also any cached
    // type whose linearized facets reference `typeDecl` transitively. Historically
    // we handled that by scanning the entire inheritance/subtype cache and removing
    // every potentially-affected entry. That is correct, but it turns extension
    // registration into a global cache invalidation point and makes synthesized
    // function extensions especially expensive.
    //
    // Instead we bump a per-declaration extension epoch here. Each cached
    // inheritance result snapshots the epochs of the declarations that contributed
    // facets to it, and subtype cache entries snapshot the inheritance-cache
    // generations of their endpoints. Old entries therefore get discarded lazily
    // when they are queried again, without forcing us to iterate the giant global
    // dictionaries up front.
    bumpDeclExtensionEpoch(typeDecl);

    if (hasImplicitCastMember)
    {
        ShortList<ImplicitCastMethodKey> entriesToRemove;
        for (auto& kv : m_mapTypePairToImplicitCastMethod)
        {
            // Since implicit casts are defined as constructors on the toType,
            // we only need to check if the toType is affected by the new extension.
            auto declRefType = as<DeclRefType>(kv.first.toType);

            if (!declRefType || declRefType->getDeclRef().getDecl() == typeDecl)
            {
                entriesToRemove.add(kv.first);
            }
        }
        for (auto& key : entriesToRemove)
        {
            m_mapTypePairToImplicitCastMethod.remove(key);
        }
    }
}

void SharedSemanticsContext::registerSynthesizedDeclRoot(Decl* decl)
{
    SLANG_RELEASE_ASSERT(decl);
    SLANG_RELEASE_ASSERT(m_module);
    SLANG_RELEASE_ASSERT(!as<GenericDecl>(decl->parentDecl));
    SLANG_RELEASE_ASSERT(getModuleDecl(decl) == m_module->getModuleDecl());

    if (m_synthesizedDeclRootSet.add(decl))
        m_synthesizedDeclRoots.add(decl);
}

void SharedSemanticsContext::_addCandidateExtensionsFromModule(ModuleDecl* moduleDecl)
{
    for (auto& [entryKey, entryValue] : moduleDecl->mapDeclToCandidateExtensions)
    {
        auto& list = _getCandidateExtensionList(entryKey, m_mapDeclToCandidateExtensions);
        list.addRange(entryValue->candidateExtensions);
    }
}

/// Get a reference to the associated decl list for `decl` in the given dictionary
///
/// Note: this function creates an empty list of candidates for the given type if
/// a matching entry doesn't exist already.
///
static List<RefPtr<DeclAssociation>>& _getDeclAssociationList(
    Decl* decl,
    OrderedDictionary<Decl*, RefPtr<DeclAssociationList>>& mapDeclToDeclarations)
{
    RefPtr<DeclAssociationList> entry;
    if (!mapDeclToDeclarations.tryGetValue(decl, entry))
    {
        entry = new DeclAssociationList();
        mapDeclToDeclarations.add(decl, entry);
    }
    return entry->associations;
}

void SharedSemanticsContext::_addDeclAssociationsFromModule(ModuleDecl* moduleDecl)
{
    for (auto& entry : moduleDecl->mapDeclToAssociatedDecls)
    {
        auto& list = _getDeclAssociationList(entry.key, m_mapDeclToAssociatedDecls);
        list.addRange(entry.value->associations);
    }
}

void SharedSemanticsContext::registerAssociatedDecl(
    Decl* original,
    DeclAssociationKind kind,
    Decl* associated)
{
    auto moduleDecl = getModuleDecl(associated);
    RefPtr<DeclAssociation> assoc = new DeclAssociation();
    assoc->kind = kind;
    assoc->decl = associated;
    _getDeclAssociationList(original, moduleDecl->mapDeclToAssociatedDecls).add(assoc);

    m_associatedDeclListsBuilt = false;
    m_mapDeclToAssociatedDecls.clear();
}

List<RefPtr<DeclAssociation>> const& SharedSemanticsContext::getAssociatedDeclsForDecl(Decl* decl)
{
    // This duplicates the exact same logic from `getCandidateExtensionsForTypeDecl`.
    // Consider refactoring them into the same framework.
    if (!m_associatedDeclListsBuilt)
    {
        m_associatedDeclListsBuilt = true;

        for (auto module : getSession()->coreModules)
        {
            _addDeclAssociationsFromModule(module->getModuleDecl());
        }

        if (m_module)
        {
            _addDeclAssociationsFromModule(m_module->getModuleDecl());
            for (auto moduleDecl : this->importedModulesList)
            {
                _addDeclAssociationsFromModule(moduleDecl);
            }
        }
        else
        {
            for (auto module : m_linkage->loadedModulesList)
            {
                _addDeclAssociationsFromModule(module->getModuleDecl());
            }
        }
    }
    return _getDeclAssociationList(decl, m_mapDeclToAssociatedDecls);
}

FunctionDifferentiableLevel SharedSemanticsContext::getFuncDifferentiableLevel(
    FunctionDeclBase* func)
{
    return _getFuncDifferentiableLevelImpl(func, 1);
}

FunctionDifferentiableLevel SharedSemanticsContext::_getFuncDifferentiableLevelImpl(
    FunctionDeclBase* func,
    int recurseLimit)
{
    if (!func)
        return FunctionDifferentiableLevel::None;

    if (recurseLimit > 0)
    {
        if (auto primalSubst = func->findModifier<PrimalSubstituteAttribute>())
        {
            if (auto declRefExpr = as<DeclRefExpr>(primalSubst->funcExpr))
            {
                if (auto primalSubstFunc = declRefExpr->declRef.as<FunctionDeclBase>())
                    return _getFuncDifferentiableLevelImpl(
                        primalSubstFunc.getDecl(),
                        recurseLimit - 1);
            }
        }
    }

    if (func->findModifier<BackwardDifferentiableAttribute>())
        return FunctionDifferentiableLevel::Backward;
    if (func->findModifier<BackwardDerivativeAttribute>())
        return FunctionDifferentiableLevel::Backward;

    if (func->findModifier<TreatAsDifferentiableAttribute>())
        return FunctionDifferentiableLevel::Backward;

    FunctionDifferentiableLevel diffLevel = FunctionDifferentiableLevel::None;
    if (func->findModifier<DifferentiableAttribute>() ||
        func->findModifier<HasTrivialForwardDerivativeAttribute>())
        diffLevel = FunctionDifferentiableLevel::Forward;

    for (auto assocDecl : getAssociatedDeclsForDecl(func))
    {
        switch (assocDecl->kind)
        {
        case DeclAssociationKind::BackwardDerivativeFunc:
            return FunctionDifferentiableLevel::Backward;
        case DeclAssociationKind::ForwardDerivativeFunc:
            diffLevel = FunctionDifferentiableLevel::Forward;
            break;
        case DeclAssociationKind::PrimalSubstituteFunc:
            if (auto assocFunc = as<FunctionDeclBase>(assocDecl->decl))
            {
                return _getFuncDifferentiableLevelImpl(assocFunc, recurseLimit - 1);
            }
            break;
        default:
            break;
        }
    }
    if (auto builtinReq = func->findModifier<BuiltinRequirementModifier>())
    {
        switch (builtinReq->kind)
        {
        case BuiltinRequirementKind::DAddFunc:
        case BuiltinRequirementKind::DZeroFunc:
            return FunctionDifferentiableLevel::Backward;
        default:
            break;
        }
    }
    return diffLevel;
}

List<ExtensionDecl*> const& getCandidateExtensions(
    DeclRef<Decl> const& declRef,
    SemanticsVisitor* semantics)
{
    auto decl = declRef.getDecl();
    auto shared = semantics->getShared();
    return shared->getCandidateExtensionsForTypeDecl(decl);
}

void _foreachDirectOrExtensionMemberOfType(
    SemanticsVisitor* semantics,
    DeclRef<ContainerDecl> const& containerDeclRef,
    SyntaxClassBase const& syntaxClass,
    void (*callback)(DeclRefBase*, void*),
    void const* userData)
{
    // We are being asked to invoke the given callback on
    // each direct member of `containerDeclRef`, along with
    // any members added via `extension` declarations, that
    // have the correct AST node class (`syntaxClass`).
    //
    // We start with the direct members.
    //
    for (auto memberDeclRef : getMembers(semantics->getASTBuilder(), containerDeclRef))
    {
        if (memberDeclRef.getDecl()->getClass().isSubClassOf(syntaxClass))
        {
            callback(memberDeclRef, (void*)userData);
        }
    }

    // Next, in the case wher ethe type can be subject to extensions,
    // we loop over the applicable extensions and their member.s
    //
    if (auto aggTypeDeclRef = containerDeclRef.as<AggTypeDecl>())
    {
        auto aggType = DeclRefType::create(semantics->getASTBuilder(), aggTypeDeclRef);
        auto candidateExtensions = getCandidateExtensions(aggTypeDeclRef, semantics);
        for (auto extDecl : candidateExtensions)
        {
            // Note that `extDecl` may have been declared for a type
            // base on the declaration that `aggTypeDeclRef` refers
            // to, but that does not guarantee that it applies to
            // the type itself. E.g., we might have an extension of
            // `vector<float, N>` for any `N`, but the current type is
            // `vector<int, 2>` so that the extension doesn't match.
            //
            // In order to make sure that we don't enumerate members
            // that don't make sense in context, we must apply
            // the extension to the type and see if we succeed in
            // making a match.
            //
            auto extDeclRef = applyExtensionToType(semantics, extDecl, aggType);
            if (!extDeclRef)
                continue;

            for (auto memberDeclRef : getMembers(semantics->getASTBuilder(), extDeclRef))
            {
                if (memberDeclRef.getDecl()->getClass().isSubClassOf(syntaxClass))
                {
                    callback(memberDeclRef, (void*)userData);
                }
            }
        }
    }
}

static void _dispatchDeclCheckingVisitor(Decl* decl, DeclCheckState state, SemanticsContext& shared)
{
    switch (state)
    {
    case DeclCheckState::ReadyForParserLookup:
        // We don't need to do anything to make a decl ready for parser lookup.
        break;
    case DeclCheckState::ModifiersChecked:
        SemanticsDeclModifiersVisitor(shared).dispatch(decl);
        break;
    case DeclCheckState::ScopesWired:
        SemanticsDeclScopeWiringVisitor(shared).dispatch(decl);
        break;

    case DeclCheckState::SignatureChecked:
        {
            SemanticsDeclHeaderVisitor visitor(shared);
            visitor.dispatch(decl);
            visitor.checkAndAttachEffectiveThisParamInfo(decl);
        }
        break;

    case DeclCheckState::ReadyForReference:
        {
            // Differentiability requirements inspect the declaration's effective `this` parameter
            // while constructing their type-info witness. Run that synthesis only after the
            // SignatureChecked transition has committed the checked parameter information, and
            // before redeclaration checking can consume the synthesized declarations.
            if (auto functionDecl = as<FunctionDeclBase>(decl);
                functionDecl && !as<SynthesizedFuncDecl>(functionDecl))
            {
                SemanticsDeclHeaderVisitor(shared).synthesizeDifferentiabilityRequirements(
                    functionDecl);
            }
            SemanticsDeclRedeclarationVisitor(shared, RedeclarationSeverity::Error).dispatch(decl);
        }
        break;

    case DeclCheckState::ReadyForLookup:
        SemanticsDeclDifferentialAttributesVisitor(shared).dispatch(decl);
        SemanticsDeclBasesVisitor(shared).dispatch(decl);
        break;

    case DeclCheckState::ReadyForConformances:
        SemanticsDeclConformancesVisitor(shared).dispatch(decl);
        break;

    case DeclCheckState::TypesFullyResolved:
        SemanticsDeclTypeResolutionVisitor(shared).dispatch(decl);
        SemanticsDeclFunctionConformancesVisitor(shared).dispatch(decl);
        break;

    case DeclCheckState::AttributesChecked:
        SemanticsDeclAttributesVisitor(shared).dispatch(decl);
        break;

    case DeclCheckState::DefinitionChecked:
        SemanticsDeclBodyVisitor(shared).dispatch(decl);
        // Lookup in a container also finds the members of its transparent variables, which
        // `checkForRedeclaration` does not compare. We compare them once per container, after
        // its own members are checked.
        if (auto containerDecl = as<ContainerDecl>(decl))
            SemanticsVisitor(shared).checkForRedeclarationOfTransparentMembers(containerDecl);
        break;

    case DeclCheckState::CapabilityChecked:
        if (!shared.getOptionSet().getBoolOption(CompilerOptionName::IgnoreCapabilities))
        {
            SemanticsDeclCapabilityVisitor(shared).dispatch(decl);
        }
        break;
    }
}


// Replace with <=> in C++20
template<typename T>
int compareThreeWays(T a, T b)
{
    if (a > b)
        return -1;
    else if (b > a)
        return 1;
    else
        return 0;
}

// lhs and rhs cannot be nullptr
int compareDecls(Decl& lhs, Decl& rhs);

// lhs and rhs cannot be nullptr
int compareVals(Val& lhs, Val& rhs);

template<typename T, class Compare>
int comparePtrs(T* lhs, T* rhs, Compare const& compare)
{
    int res = 0;
    if (lhs == rhs)
        res = 0;
    else if (!lhs)
        res = -1;
    else if (!rhs)
        res = 1;
    else
        res = compare(*lhs, *rhs);
    return res;
}

// lhs or rhs might be nullptr
int compareDecls(Decl* lhs, Decl* rhs)
{
    return comparePtrs(lhs, rhs, [&](Decl& lhs, Decl& rhs) { return compareDecls(lhs, rhs); });
}

// lhs or rhs might be nullptr
int compareVals(Val* lhs, Val* rhs)
{
    return comparePtrs(lhs, rhs, [&](Val& lhs, Val& rhs) { return compareVals(lhs, rhs); });
}

// Compare operands of lhs and rhs from offset,
// and at most count operands, if the capacity allows it.
int compareValOperands(Val& lhs, Val& rhs, Index offset, Index count)
{
    const Index lN = std::clamp<Index>(lhs.getOperandCount() - offset, 0, count);
    const Index rN = std::clamp<Index>(rhs.getOperandCount() - offset, 0, count);
    int res = compareThreeWays(lN, rN);
    if (res)
        return res;
    for (Index i = 0; i < lN; ++i)
    {
        auto lOp = lhs.m_operands[offset + i];
        auto rOp = rhs.m_operands[offset + i];
        res = compareThreeWays(lOp.kind, rOp.kind);
        if (res)
        {
            break;
        }
        switch (lOp.kind)
        {
        case ValNodeOperandKind::ConstantValue:
            res = compareThreeWays(lOp.getIntConstant(), rOp.getIntConstant());
            break;
        case ValNodeOperandKind::ValNode:
            res = compareVals(lOp.getVal(), rOp.getVal());
            break;
        case ValNodeOperandKind::ASTNode:
            res = compareDecls(lOp.getDecl(), rOp.getDecl());
            break;
        }
        if (res)
        {
            break;
        }
    }
    return res;
}

// Compare operands of lhs and rhs from offset to the end
int compareValOperands(Val& lhs, Val& rhs, Index offset)
{
    return compareValOperands(lhs, rhs, offset, std::numeric_limits<Index>::max());
}

// Find the lowest common ancestor (LCA) of nodes a and b
// Uppon return, a and b are modified to be direct children of the LCA
// Returns nullptr if a and b have no common ancestor
// (e.g. a and b are not in the same module)
// a and b are set to each respective module
ContainerDecl* findDeclsLowestCommonAncestor(Decl*& a, Decl*& b)
{
    auto ascendToRoot = [](Decl*& d)
    {
        UIndex depth = 0;
        while (d->parentDecl)
        {
            ++depth;
            d = d->parentDecl;
        }
        return depth;
    };

    Decl* aRoot = a;
    Decl* bRoot = b;
    auto aDepth = ascendToRoot(aRoot);
    auto bDepth = ascendToRoot(bRoot);
    if (aRoot != bRoot) // Not in the same tree / module
    {
        a = aRoot;
        b = bRoot;
        return nullptr;
    }
    // Level nodes
    Decl** toAscend = nullptr;
    Decl** reference = nullptr;
    UIndex n = 0;
    if (aDepth > bDepth)
    {
        toAscend = &a;
        reference = &b;
        n = aDepth - bDepth;
    }
    else if (bDepth > aDepth)
    {
        toAscend = &b;
        reference = &a;
        n = bDepth - aDepth;
    }
    if (n)
    {
        // Level until toAscend is one level under reference
        while (n > UIndex(1))
        {
            *toAscend = (*toAscend)->parentDecl;
            --n;
        }
        // If toAscend was a child of reference
        if ((*toAscend)->parentDecl == *reference)
        {
            return (*toAscend)->parentDecl;
        }
        else
        {
            *toAscend = (*toAscend)->parentDecl;
        }
    }
    while (a->parentDecl != b->parentDecl)
    {
        a = a->parentDecl;
        b = b->parentDecl;
    }
    return a->parentDecl;
}

static int _compareDeclsInCommonParentByOrderOfDeclaration(
    ContainerDecl* commonParent,
    Decl* lhs,
    Decl* rhs)
{
    if (lhs == rhs)
        return 0;

    SLANG_ASSERT(commonParent);
    SLANG_ASSERT(lhs);
    SLANG_ASSERT(rhs);
    SLANG_ASSERT(lhs->parentDecl == commonParent);
    SLANG_ASSERT(rhs->parentDecl == commonParent);

    // Without doing some kind of caching on `commonParent` (which
    // would bloat the storage of every `ContainerDecl` just to
    // support this one use case), the worst-cast complexity of
    // this operation is always going to be linear in the number
    // of declarations in `commonParent`.
    //
    // In an attempt to optimize for the common case, we will assume
    // that one or the other of the declarations is near the beginning
    // or end of the sequence of children.
    //
    Count childCount = commonParent->getDirectMemberDeclCount();
    Index loIndex = 0;
    Index hiIndex = childCount - 1;
    for (;;)
    {
        SLANG_ASSERT(loIndex < hiIndex);

        auto loDecl = commonParent->getDirectMemberDecl(loIndex);
        auto hiDecl = commonParent->getDirectMemberDecl(hiIndex);

        // TODO(tfoley): There is a frustratingly subtle issue lurking
        // in the Slang codebase, where operations (notably including
        // the reflection API's `getTypeParameterConstraintType()`)
        // assume that the a generic with N type parameters will have
        // N constraints, with one constraint per type parameter,
        // in a matching order.
        //
        // This assumption is fundamentally *not* guaranteed by the
        // Slang compiler, but it has worked often enough in practice
        // that code has ended up depending on this behavior.
        //
        // The long/short is that the ordering of the comparisons here
        // (which cases return `-1` vs. `1`) is important for not
        // breaking at least one Slang test, and may also have consequences
        // for other code.
        //
        // We need to audit all of the code that is looking up constraints
        // on generic declarations and trying to associate constraints
        // with specific parameters and... well, in the ideal case *stop*
        // them from doing so, because it isn't always a reasonable way
        // to do things (e.g., there are constraints that would be missed
        // if code only pays attention to constraints that have one of
        // the generic parameters on their left-hand-side). Given that
        // we probably can't fully deprecate things like the reflection
        // API operations that rely on this assumption, we should instead
        // author an as-correct-as-possible version of things that, given
        // the index of a generic (type) parameter, collects all of the
        // (conformance) constraints with that parameter on the left-hand-side
        // and forms a conjunction of the interfaces on the right-hand-side.
        //
        // (Alternatively we could separate the storage of the original
        // parameters/constraints as they were declared, vs. the canonicalized
        // constraints, and only have the reflection API access the former)

        if (loDecl == lhs)
            return 1;
        if (loDecl == rhs)
            return -1;

        if (hiDecl == lhs)
            return -1;
        if (hiDecl == rhs)
            return 1;

        loIndex++;
        hiIndex--;

        if (loIndex >= hiIndex)
        {
            SLANG_UNEXPECTED("failed to find lhs or rhs in common parent");
            UNREACHABLE_RETURN(0);
        }
    }
}

int compareDecls(Decl& lhs, Decl& rhs)
{
    int res = compareThreeWays(lhs.astNodeType, rhs.astNodeType);
    if (res)
        return res;
    Decl* lLCAChild = &lhs;
    Decl* rLCAChild = &rhs;

    // TODO(tfoley): This logic implements rules that provide very
    // little stability of generated mangled names, in cases where
    // declarations might ever get reordered.
    //
    // A more flexible solution would favor comparing declarations
    // by name whenever possible, along the lines of:
    //
    // * For each declaration identify it's deepest ancestor that
    //   has a meaningful stable name (anything like a module,
    //   namespace, type, function, etc. and not anything like
    //   a parameter, local declaration, etc.)
    //
    // * Compare those deepest ancestors by name lexicographically,
    //   from the root down. If the module names differ, that's
    //   enough to go by. If they are in the same moduel but in
    //   different types, then use that. If one path is a prefix
    //   of the other, then that establishes an ordering.
    //
    // * Only if the above wasn't enough to disambiguate things would
    //   we fall back to anthing based on order of declaration, and
    //   even *then* we would probably want to have some safety rails
    //   in place to identify what kinds of declarations are forcing
    //   us down that path, and ensuring that they are kinds of
    //   declarations we explicitly need/want to support here (e.g.,
    //   generic parameters).
    //
    if (ContainerDecl* lca = findDeclsLowestCommonAncestor(lLCAChild, rLCAChild))
    {
        res = _compareDeclsInCommonParentByOrderOfDeclaration(lca, lLCAChild, rLCAChild);
    }
    else
    {
        res = comparePtrs(
            lLCAChild->getName(),
            rLCAChild->getName(),
            [](Name const& lName, Name const& rName)
            { return strcmp(lName.text.begin(), rName.text.begin()); });
    }
    return res;
}

int compareVals(Val& lhs, Val& rhs)
{
    int res = compareThreeWays(lhs.astNodeType, rhs.astNodeType);
    if (res)
        return res;
    res = compareValOperands(lhs, rhs, 0);
    return res;
}

int compareTypes(Type* lhs, Type* rhs)
{
    return compareVals(lhs, rhs);
}

int compareTypes(Type& lhs, Type& rhs)
{
    return compareVals(lhs, rhs);
}

static void _getCanonicalConstraintTypes(List<Type*>& outTypeList, Type* type)
{
    if (auto andType = as<AndType>(type))
    {
        _getCanonicalConstraintTypes(outTypeList, andType->getLeft());
        _getCanonicalConstraintTypes(outTypeList, andType->getRight());
    }
    else
    {
        outTypeList.add(type);
    }
}
OrderedDictionary<GenericTypeParamDeclBase*, List<Type*>> getCanonicalGenericConstraints(
    ASTBuilder* astBuilder,
    DeclRef<ContainerDecl> genericDecl)
{
    OrderedDictionary<GenericTypeParamDeclBase*, List<Type*>> genericConstraints;
    for (auto mm : getMembersOfType<GenericTypeParamDeclBase>(astBuilder, genericDecl))
    {
        genericConstraints[mm.getDecl()] = List<Type*>();
    }
    for (auto genericTypeConstraintDecl :
         getMembersOfType<GenericTypeConstraintDecl>(astBuilder, genericDecl))
    {
        if (genericTypeConstraintDecl.getDecl()->sub.type->astNodeType == ASTNodeType::DeclRefType)
        {
            auto typeParamDecl = as<DeclRefType>(genericTypeConstraintDecl.getDecl()->sub.type)
                                     ->getDeclRef()
                                     .getDecl();
            List<Type*>* constraintTypes = genericConstraints.tryGetValue(typeParamDecl);
            if (!constraintTypes)
                continue;
            constraintTypes->add(genericTypeConstraintDecl.getDecl()->getSup().type);
        }
        else
        {
            SLANG_UNEXPECTED("Cannot extract Cannonical Generic Constraints on non DeclRefTypes. "
                             "Use getCanonicalGenericConstraints2(...) instead.");
        }
    }
    OrderedDictionary<GenericTypeParamDeclBase*, List<Type*>> result;
    for (auto& constraints : genericConstraints)
    {
        List<Type*> typeList;
        for (auto type : constraints.value)
        {
            _getCanonicalConstraintTypes(typeList, type);
        }
        const auto typeComparator = [&](Type* lhs, Type* rhs)
        { return compareTypes(*lhs, *rhs) < 0; };
        typeList.sort(typeComparator);
        result[constraints.key] = std::move(typeList);
    }
    return result;
}


OrderedDictionary<Type*, List<Type*>> getCanonicalGenericConstraints2(
    ASTBuilder* astBuilder,
    DeclRef<ContainerDecl> genericDecl)
{
    Dictionary<Type*, HashSet<Type*>> genericConstraints;
    for (auto genericTypeConstraintDecl :
         getMembersOfType<GenericTypeConstraintDecl>(astBuilder, genericDecl))
    {
        auto subExpr = genericTypeConstraintDecl.getDecl()->sub;
        auto supExpr = genericTypeConstraintDecl.getDecl()->sup;
        Type* typeToAdd = subExpr.type;
        if (typeToAdd)
        {
            if (!genericConstraints.containsKey(typeToAdd))
            {
                genericConstraints[typeToAdd] = HashSet<Type*>();
            }
            genericConstraints[typeToAdd].add(supExpr.type);
        }
    }
    const auto typeComparator = [&](Type* lhs, Type* rhs) { return compareTypes(lhs, rhs) < 0; };
    const List<Type*> sortedKeys = [&]()
    {
        List<Type*> res;
        res.reserve(genericConstraints.getCount());
        for (auto& t : genericConstraints)
        {
            res.add(t.first);
        }
        res.sort(typeComparator);
        return res;
    }();
    OrderedDictionary<Type*, List<Type*>> result;
    for (auto& key : sortedKeys)
    {
        List<Type*> typeList;
        for (auto type : genericConstraints[key])
        {
            _getCanonicalConstraintTypes(typeList, type);
        }
        typeList.sort(typeComparator);
        result[key] = std::move(typeList);
    }
    return result;
}

// Return true when generic inference can solve a specialization that makes the
// two `this` types compatible for derivative checking. This is intentionally a
// solver query rather than a pure predicate: it may collect unification
// constraints and run the generic argument solver to validate them.
bool canSolveGenericThisTypeCompatibility(SemanticsVisitor* visitor, Type* fst, Type* snd)
{
    if (fst->equals(snd))
        return true;

    if (auto declRefType = as<DeclRefType>(fst))
    {
        auto decl = declRefType->getDeclRef().getDecl();
        if (auto extGenericDecl = visitor->GetOuterGeneric(decl))
        {
            SemanticsVisitor::GenericInferenceContext inferenceContext;
            inferenceContext.genericDecl = extGenericDecl;

            if (!visitor->TryUnifyTypes(
                    inferenceContext,
                    SemanticsVisitor::UnificationOptions(),
                    fst,
                    snd))
                return false;

            ConversionCost baseCost;
            if (!visitor->trySolveGenericArguments(
                    _Move(inferenceContext),
                    makeDeclRef(extGenericDecl),
                    ArrayView<Val*>(),
                    baseCost))
                return false;

            // If we reach here, the solver found a valid substitution.
            return true;
        }
    }
    return false;
}


struct ArgsWithDirectionInfo
{
    List<Expr*> args;
    List<ParamPassingMode> directions;

    Expr* thisArg;
    ParamPassingMode thisArgDirection;
};

// Describes whether the primal and derivative's outer generic signatures have already been
// resolved against each other. A `[ForwardDerivativeOf]` attribute starts validation with
// `AlreadyResolved` because higher-order overload resolution selected a compatible primal
// specialization before calling `checkDerivativeAttributeImpl`.
enum class PrimalAndDerivativeGenericSignatureResolutionStatus
{
    NotYetResolved,
    AlreadyResolved,
};

// Returns the derivative expression applied to the primal's outer generic parameters when that
// application is still needed for signature resolution. Consider `[ForwardDerivative(derivative)]`
// on `primal<T, let N>()`: validation must resolve `derivative<T, N>()`, while an explicit generic
// application or a `[ForwardDerivativeOf]` expression resolved by the higher-order call already
// carries the required arguments. `getDefaultSubstitutionArgs` orders the ordinary type and value
// parameters before constraint witnesses, so this function consumes exactly that ordinary prefix
// in declaration order. `expressionVisitor` constructs value-parameter references in the temporary
// scope that will resolve the derivative call.
static Expr* getDerivativeExprWithPrimalGenericArgumentsIfNeeded(
    SemanticsVisitor* declarationVisitor,
    SemanticsVisitor& expressionVisitor,
    DeclRef<FunctionDeclBase> primalDeclRef,
    Expr* derivativeExpr,
    PrimalAndDerivativeGenericSignatureResolutionStatus genericSignatureResolutionStatus)
{
    if (genericSignatureResolutionStatus ==
        PrimalAndDerivativeGenericSignatureResolutionStatus::AlreadyResolved)
    {
        return derivativeExpr;
    }

    auto primalOuterGeneric = as<GenericDecl>(primalDeclRef.getDecl()->parentDecl);
    if (!primalOuterGeneric)
        return derivativeExpr;

    if (as<GenericAppExpr>(derivativeExpr))
        return derivativeExpr;

    auto astBuilder = declarationVisitor->getASTBuilder();
    auto substitutionArgs =
        getDefaultSubstitutionArgs(astBuilder, declarationVisitor, primalOuterGeneric);
    auto genericAppExpr = astBuilder->create<GenericAppExpr>();

    Index remainingGenericParameterCount = 0;
    for (auto member : primalOuterGeneric->getDirectMemberDecls())
    {
        if (isGenericParam(member))
            remainingGenericParameterCount++;
    }

    genericAppExpr->functionExpr = derivativeExpr;

    for (auto substitutionArg : substitutionArgs)
    {
        if (remainingGenericParameterCount == 0)
            break;

        if (auto declRefType = as<DeclRefType>(substitutionArg))
        {
            auto typeExpr = astBuilder->create<SharedTypeExpr>();
            typeExpr->base.type = declRefType;
            typeExpr->type.type = astBuilder->getOrCreate<TypeType>(declRefType);
            genericAppExpr->arguments.add(typeExpr);
        }
        else if (auto genericValueParam = as<DeclRefIntVal>(substitutionArg))
        {
            genericAppExpr->arguments.add(expressionVisitor.ConstructDeclRefExpr(
                genericValueParam->getDeclRef(),
                nullptr,
                nullptr,
                SourceLoc(),
                nullptr));
        }
        else
        {
            SLANG_UNEXPECTED("Unhandled substitution arg type");
        }

        remainingGenericParameterCount--;
    }

    return genericAppExpr;
}

// Checks a derivative against a primal declaration reference. `genericSignatureResolutionStatus`
// states whether this function must still infer a mapping between their outer generic signatures
// or preserve the specialized primal reference that higher-order overload resolution already chose.
template<typename TDerivativeAttr>
void checkDerivativeAttributeImpl(
    SemanticsVisitor* visitor,
    DeclRef<FunctionDeclBase> primalDeclRef,
    TDerivativeAttr* attr,
    const List<Expr*>& imaginaryArguments,
    const List<ParamPassingMode>& expectedParamDirections,
    Expr* expectedThisArg,
    ParamPassingMode expectedThisArgDirection,
    PrimalAndDerivativeGenericSignatureResolutionStatus genericSignatureResolutionStatus)
{
    auto primalFuncDecl = primalDeclRef.getDecl();
    if (isInterfaceRequirement(primalFuncDecl))
    {
        visitor->getSink()->diagnose(
            Diagnostics::CannotAssociateInterfaceRequirementWithDerivative{.attr = attr->loc});
        return;
    }

    SemanticsContext::ExprLocalScope scope;
    auto ctx = visitor->withExprLocalScope(&scope);
    auto subVisitor = SemanticsVisitor(ctx.allowStaticReferenceToNonStaticMember());

    auto derivativeExprToCheck = getDerivativeExprWithPrimalGenericArgumentsIfNeeded(
        visitor,
        subVisitor,
        primalDeclRef,
        attr->funcExpr,
        genericSignatureResolutionStatus);

    auto checkedDerivativeExpr = visitor->dispatchExpr(derivativeExprToCheck, ctx);
    attr->funcExpr = checkedDerivativeExpr;
    if (attr->args.getCount())
        attr->args[0] = attr->funcExpr;
    if (auto declRefExpr = as<DeclRefExpr>(checkedDerivativeExpr))
    {
        if (declRefExpr->declRef)
        {
            if (auto callableDeclRef = declRefExpr->declRef.template as<CallableDecl>())
            {
                for (auto paramDecl :
                     callableDeclRef.getDecl()->template getMembersOfType<ParamDecl>())
                    visitor->ensureDecl(paramDecl, DeclCheckState::TypesFullyResolved);
            }
            // visitor->ensureDecl(declRefExpr->declRef, DeclCheckState::TypesFullyResolved);
        }
        else
        {
            visitor->getSink()->diagnose(
                Diagnostics::CannotResolveDerivativeFunction{.attr = attr->loc});
            return;
        }
    }
    else if (auto overloadedExpr = as<OverloadedExpr>(checkedDerivativeExpr))
    {
        for (auto candidate : overloadedExpr->lookupResult2.items)
        {
            // visitor->ensureDecl(candidate.declRef, DeclCheckState::TypesFullyResolved);
            if (auto callableDeclRef = candidate.declRef.template as<CallableDecl>())
            {
                for (auto paramDecl :
                     callableDeclRef.getDecl()->template getMembersOfType<ParamDecl>())
                    visitor->ensureDecl(paramDecl, DeclCheckState::TypesFullyResolved);
            }
        }
    }
    else if (auto overloadedExpr2 = as<OverloadedExpr2>(checkedDerivativeExpr))
    {
        for (auto candidate : overloadedExpr2->candidateExprs)
        {
            if (auto candidateDeclRefExpr = as<DeclRefExpr>(candidate))
            {
                visitor->ensureDecl(
                    candidateDeclRefExpr->declRef,
                    DeclCheckState::TypesFullyResolved);
            }
        }
    }
    else
    {
        visitor->getSink()->diagnose(
            Diagnostics::CannotResolveDerivativeFunction{.attr = attr->loc});
        return;
    }

    /*if (!as<DeclRefExpr>(checkedDerivativeExpr))
    {
        visitor->getSink()->diagnose(attr, Diagnostics::cannotResolveDerivativeFunction);
        return;
    }

    if (!as<DeclRefExpr>(checkedDerivativeExpr)->declRef)
    {
        visitor->getSink()->diagnose(attr, Diagnostics::cannotResolveDerivativeFunction);
        return;
    }*/

    // If left value is true, then convert the
    // inner type to an BorrowInOutParamType.
    //
    auto qualTypeToString = [&](QualType qualType) -> String
    {
        Type* type = qualType.type;
        if (qualType.isLeftValue)
        {
            type = ctx.getASTBuilder()->getBorrowInOutParamType(type);
        }
        return type->toString();
    };

    List<Expr*> argList = imaginaryArguments;
    List<ParamPassingMode> paramDirections = expectedParamDirections;

    if (expectedThisArg)
    {
        argList.insert(0, expectedThisArg);
        paramDirections.insert(0, expectedThisArgDirection);
    }

    auto invokeExpr = subVisitor.constructUncheckedInvokeExpr(checkedDerivativeExpr, argList);
    auto resolved = subVisitor.ResolveInvoke(invokeExpr);

    if (auto resolvedInvoke = as<InvokeExpr>(resolved))
    {
        if (auto resolvedDerivativeDeclRefExpr = as<DeclRefExpr>(resolvedInvoke->functionExpr))
        {
            // There are two ways to make it to this point.. a proper resolution, and a
            // resolution that has failed due to type mismatch.
            // Further, a proper resolution can still be invalid due to incorrect parameter
            // directionality.
            // We'll detect both these incorrect cases here and issue an appropriate diagnostic.
            //
            auto funcType = as<FuncType>(resolvedDerivativeDeclRefExpr->type);
            if (!funcType)
            {
                // The best candidate does not have a function type.
                // If we reach here, it means the function is a generic and we can't deduce the
                // generic arguments from imaginary argument list.
                // In this case we issue a diagnostic to ask the user to explicitly provide the
                // arguments.
                visitor->getSink()->diagnose(
                    Diagnostics::CannotResolveGenericArgumentForDerivativeFunction{
                        .attr = attr->loc});
                return;
            }
            if (isInterfaceRequirement(resolvedDerivativeDeclRefExpr->declRef.getDecl()))
            {
                visitor->getSink()->diagnose(
                    Diagnostics::CannotUseInterfaceRequirementAsDerivative{.attr = attr->loc});
                return;
            }
            if (funcType->getParamCount() != argList.getCount())
            {
                goto error;
            }
            for (Index ii = 0; ii < argList.getCount(); ++ii)
            {
                // Check if the resolved invoke argument type is an error type.
                // If so, then we have a type mismatch.
                //
                if (resolvedInvoke->arguments[ii]->type.type->equals(
                        ctx.getASTBuilder()->getErrorType()) ||
                    funcType->getParamPassingMode(ii) != paramDirections[ii])
                {
                    visitor->getSink()->diagnose(
                        Diagnostics::CustomDerivativeSignatureMismatchAtPosition{
                            .position = (int64_t)ii,
                            .expectedType = qualTypeToString(argList[ii]->type),
                            .actualType = funcType->getParamTypeWithModeWrapper(ii)->toString(),
                            .attr = attr->loc});
                }
            }
            // A differentiated receiver is passed as the first explicit argument, so in that case
            // the custom derivative itself must not have an effective `this` parameter. Otherwise
            // its effective parameter must exactly preserve the primal's passing mode and have a
            // compatible checked type. This is an ABI check: inferring it again from expression
            // l-value state would lose distinctions such as `BorrowIn` versus `In`. Type modifiers
            // such as `no_diff` control whether the primal receiver becomes an explicit derivative
            // argument, but do not change the object type required by a member derivative.
            auto primalThisInfo = visitor->findEffectiveThisParamInfo(primalDeclRef);
            auto derivativeDeclRef =
                resolvedDerivativeDeclRefExpr->declRef.template as<FunctionDeclBase>();
            auto derivativeThisInfo = visitor->findEffectiveThisParamInfo(derivativeDeclRef);
            auto expectedDerivativeThisInfo =
                expectedThisArg ? std::optional<ParamInfo>() : primalThisInfo;

            if (expectedDerivativeThisInfo.has_value() != derivativeThisInfo.has_value())
            {
                if (!expectedDerivativeThisInfo && derivativeThisInfo)
                {
                    visitor->getSink()->diagnose(
                        Diagnostics::CustomDerivativeExpectedStatic{.attr = attr->loc});
                }
                else
                {
                    visitor->getSink()->diagnose(
                        Diagnostics::CustomDerivativeSignatureThisParamMismatch{.attr = attr->loc});
                }
                return;
            }

            if (expectedDerivativeThisInfo &&
                (expectedDerivativeThisInfo->mode != derivativeThisInfo->mode ||
                 !canSolveGenericThisTypeCompatibility(
                     visitor,
                     unwrapModifiedType(expectedDerivativeThisInfo->type),
                     unwrapModifiedType(derivativeThisInfo->type))))
            {
                visitor->getSink()->diagnose(
                    Diagnostics::CustomDerivativeSignatureThisParamMismatch{.attr = attr->loc});
                return;
            }

            // A `[ForwardDerivative]`, `[BackwardDerivative]`, or `[PrimalSubstitute]` attribute on
            // the primal reaches this point before the primal and derivative's outer generic
            // signatures have been matched. Diagnose a generic/non-generic mismatch, or infer the
            // substitution that expresses the derivative in the primal's generic context.
            // `[ForwardDerivativeOf]` already performed this work while selecting its primal
            // specialization, so repeating it would compare the wrong generic contexts.
            if (genericSignatureResolutionStatus ==
                PrimalAndDerivativeGenericSignatureResolutionStatus::NotYetResolved)
            {
                auto primalNextGeneric =
                    visitor->findNextOuterGeneric(visitor->getOuterGenericOrSelf(primalFuncDecl));
                auto derivativeNextGeneric =
                    visitor->findNextOuterGeneric(visitor->getOuterGenericOrSelf(
                        resolvedDerivativeDeclRefExpr->declRef.getDecl()));

                if ((!primalNextGeneric) != (!derivativeNextGeneric))
                {
                    visitor->getSink()->diagnose(
                        Diagnostics::CannotResolveGenericArgumentForDerivativeFunction{
                            .attr = attr->loc});
                    return;
                }

                if (primalNextGeneric != derivativeNextGeneric)
                {
                    DeclRef<Decl> specializedDecl;
                    if (!visitor->doGenericSignaturesMatch(
                            primalNextGeneric,
                            derivativeNextGeneric,
                            &specializedDecl))
                    {
                        visitor->getSink()->diagnose(Diagnostics::CustomDerivativeSignatureMismatch{
                            .expectedSignature = String{},
                            .attr = attr->loc});
                        return;
                    }

                    resolvedDerivativeDeclRefExpr->declRef = substituteDeclRef(
                        SubstitutionSet(specializedDecl),
                        visitor->getASTBuilder(),
                        resolvedDerivativeDeclRefExpr->declRef);
                    resolvedDerivativeDeclRefExpr->type = substituteType(
                        SubstitutionSet(specializedDecl),
                        visitor->getASTBuilder(),
                        resolvedDerivativeDeclRefExpr->type);
                }
            }

            attr->funcExpr = resolvedDerivativeDeclRefExpr;
            if (attr->args.getCount())
                attr->args[0] = attr->funcExpr;
            return;
        }
    }
error:;
    // Build the expected signature from imaginary args to diagnose
    // when no matching function is found (this excludes the case handled above)
    //
    StringBuilder builder;
    builder << "(";
    for (Index ii = 0; ii < argList.getCount(); ++ii)
    {
        if (ii != 0)
            builder << ", ";
        if (argList[ii]->type)
            builder << qualTypeToString(argList[ii]->type);
        else
            builder << "<error>";
    }
    builder << ")";

    visitor->getSink()->diagnose(Diagnostics::CustomDerivativeSignatureMismatch{
        .expectedSignature = builder.produceString(),
        .attr = attr->loc});
}

// Checks a derivative named by `[ForwardDerivative]`, `[BackwardDerivative]`, or
// `[PrimalSubstitute]` on the primal, using the primal's ordinary generic context.
template<typename TDerivativeAttr>
void checkDerivativeAttributeImpl(
    SemanticsVisitor* visitor,
    FunctionDeclBase* primalFuncDecl,
    TDerivativeAttr* attr,
    const List<Expr*>& imaginaryArguments,
    const List<ParamPassingMode>& expectedParamDirections,
    Expr* expectedThisArg,
    ParamPassingMode expectedThisArgDirection)
{
    auto primalDeclRef = createDefaultSubstitutionsIfNeeded(
                             visitor->getASTBuilder(),
                             visitor,
                             primalFuncDecl->getDefaultDeclRef())
                             .as<FunctionDeclBase>();
    checkDerivativeAttributeImpl(
        visitor,
        primalDeclRef,
        attr,
        imaginaryArguments,
        expectedParamDirections,
        expectedThisArg,
        expectedThisArgDirection,
        PrimalAndDerivativeGenericSignatureResolutionStatus::NotYetResolved);
}

template<typename TDerivativeAttr>
const char* getDerivativeAttrName()
{
    SLANG_UNREACHABLE("");
}

template<>
const char* getDerivativeAttrName<ForwardDerivativeAttribute>()
{
    return "ForwardDerivative";
}
template<>
const char* getDerivativeAttrName<BackwardDerivativeAttribute>()
{
    return "BackwardDerivative";
}
template<>
const char* getDerivativeAttrName<PrimalSubstituteAttribute>()
{
    return "PrimalSubstitute";
}

ArgsWithDirectionInfo getImaginaryArgsToFunc(
    ASTBuilder* astBuilder,
    FunctionDeclBase* func,
    SourceLoc loc)
{
    auto params =
        getParametersForCallableSignature(astBuilder, makeDeclRef(func).as<CallableDecl>());

    List<Expr*> imaginaryArguments;
    List<ParamPassingMode> directions;
    for (auto paramDeclRef : params)
    {
        auto param = paramDeclRef.getDecl();
        auto direction = getParamPassingMode(param);
        auto arg = astBuilder->create<VarExpr>();
        arg->declRef = makeDeclRef(param);
        arg->type.isLeftValue = doesParamPassingModeIndicateWritableStorage(direction);
        arg->type.type = param->getType();
        arg->loc = loc;
        imaginaryArguments.add(arg);
        directions.add(direction);
    }
    return {imaginaryArguments, directions, nullptr, ParamPassingMode::In};
}

ArgsWithDirectionInfo getImaginaryArgsToForwardDerivative(
    SemanticsVisitor* visitor,
    DeclRef<FunctionDeclBase> originalFuncDeclRef,
    SourceLoc loc)
{
    auto astBuilder = visitor->getASTBuilder();
    auto originalFuncDecl = originalFuncDeclRef.getDecl();
    SubstitutionSet substitutions(originalFuncDeclRef);

    Expr* thisArgExpr = nullptr;
    ParamPassingMode thisTypeDirection = ParamPassingMode::In;
    if (auto thisParamInfo = visitor->findEffectiveThisParamInfo(originalFuncDeclRef))
    {
        if (auto pairType = visitor->tryGetDifferentialPairType(thisParamInfo->type))
        {
            thisArgExpr = astBuilder->create<VarExpr>();
            thisTypeDirection = getDifferentiatedThisParamMode(thisParamInfo->mode);
            thisArgExpr->type.type = pairType;
            thisArgExpr->type.isLeftValue =
                doesParamPassingModeIndicateWritableStorage(thisTypeDirection);
            thisArgExpr->loc = loc;
        }
    }

    auto params = getParametersForCallableSignature(
        astBuilder,
        makeDeclRef(originalFuncDecl).as<CallableDecl>());

    List<Expr*> imaginaryArguments;
    for (auto paramDeclRef : params)
    {
        auto param = paramDeclRef.getDecl();
        auto paramType = substituteType(substitutions, astBuilder, param->getType());
        auto direction = getParamPassingMode(param);
        auto arg = astBuilder->create<VarExpr>();
        arg->declRef = makeDeclRef(param);
        arg->type.isLeftValue = doesParamPassingModeIndicateWritableStorage(direction);
        arg->type.type = paramType;
        arg->loc = loc;
        if (!param->findModifier<NoDiffModifier>())
        {
            if (auto pairType = visitor->tryGetDifferentialPairType(paramType))
            {
                arg->type.type = pairType;
            }
        }
        imaginaryArguments.add(arg);
    }

    // Copy parameter directions as is.
    List<ParamPassingMode> expectedParamDirections;
    for (auto paramDeclRef : params)
    {
        expectedParamDirections.add(getParamPassingMode(paramDeclRef.getDecl()));
    }

    return {imaginaryArguments, expectedParamDirections, thisArgExpr, thisTypeDirection};
}

ArgsWithDirectionInfo getImaginaryArgsToBackwardDerivative(
    SemanticsVisitor* visitor,
    DeclRef<FunctionDeclBase> originalFuncDeclRef,
    SourceLoc loc)
{
    auto astBuilder = visitor->getASTBuilder();
    auto originalFuncDecl = originalFuncDeclRef.getDecl();
    SubstitutionSet substitutions(originalFuncDeclRef);

    Expr* thisArgExpr = nullptr;
    ParamPassingMode thisTypeDirection = ParamPassingMode::In;
    if (auto thisParamInfo = visitor->findEffectiveThisParamInfo(originalFuncDeclRef))
    {
        if (auto pairType = visitor->tryGetDifferentialPairType(thisParamInfo->type))
        {
            thisArgExpr = astBuilder->create<VarExpr>();
            thisArgExpr->type.type = pairType;
            thisTypeDirection = getDifferentiatedThisParamMode(thisParamInfo->mode);

            // Back-propagating through a by-value differentiable receiver accumulates into its
            // differential, so an `In` value pair becomes writable storage. The remaining
            // reference mode stays part of the receiver ABI, and a pointer pair preserves the
            // differentiated mode because it already carries the required reference semantics.
            if (as<DifferentialPairType>(pairType) && thisTypeDirection == ParamPassingMode::In)
                thisTypeDirection = ParamPassingMode::BorrowInOut;

            thisArgExpr->type.isLeftValue =
                doesParamPassingModeIndicateWritableStorage(thisTypeDirection);
            thisArgExpr->loc = loc;
        }
    }

    List<Expr*> imaginaryArguments;
    List<ParamPassingMode> expectedParamDirections;

    auto params = getParametersForCallableSignature(
        astBuilder,
        makeDeclRef(originalFuncDecl).as<CallableDecl>());

    for (auto paramDeclRef : params)
    {
        auto param = paramDeclRef.getDecl();
        auto paramType = substituteType(substitutions, astBuilder, param->getType());
        ParamPassingMode direction = getParamPassingMode(param);
        bool isOutParam = direction == ParamPassingMode::Out;
        auto arg = astBuilder->create<VarExpr>();
        arg->declRef = makeDeclRef(param);
        arg->type.isLeftValue = doesParamPassingModeIndicateWritableStorage(direction);
        arg->type.type = paramType;
        arg->loc = loc;

        bool isDiffParam = (!param->findModifier<NoDiffModifier>());
        if (isDiffParam)
        {
            auto diffPair = visitor->tryGetDifferentialPairType(paramType);
            if (auto pairType = as<DifferentialPairType>(diffPair))
            {
                arg->type.type = pairType;
                arg->type.isLeftValue = true;

                if (isOutParam)
                {
                    // out T : IDifferentiable -> in T.Differential
                    arg->type.isLeftValue = false;
                    arg->type.type = visitor->tryGetDifferentialType(
                        visitor->getASTBuilder(),
                        pairType->getPrimalType());

                    direction = ParamPassingMode::In;
                }
                else
                {
                    // in T : IDifferentiable -> inout DifferentialPair<T>
                    // inout T : IDifferentiable -> inout DifferentialPair<T>
                    direction = ParamPassingMode::BorrowInOut;
                }
            }
            else if (auto refPairType = as<DifferentialPtrPairType>(diffPair))
            {
                // no need to change direction of ref-pairs.
                arg->type.type = refPairType;
            }
            else
            {
                isDiffParam = false;
            }
        }
        if (!isDiffParam)
        {
            if (isOutParam)
            {
                // Skip non-differentiable out params.
                continue;
            }

            // no_diff inout T -> in T
            // no_diff in T -> in T
            //
            direction = ParamPassingMode::In;
        }

        imaginaryArguments.add(arg);
        expectedParamDirections.add(direction);
    }
    auto returnType = substituteType(substitutions, astBuilder, originalFuncDecl->returnType.type);
    if (auto diffReturnType = visitor->tryGetDifferentialType(astBuilder, returnType))
    {
        auto arg = astBuilder->create<InitializerListExpr>();
        arg->type.isLeftValue = false;
        arg->type.type = diffReturnType;
        arg->loc = loc;
        imaginaryArguments.add(arg);
        expectedParamDirections.add(ParamPassingMode::In);
    }

    return {imaginaryArguments, expectedParamDirections, thisArgExpr, thisTypeDirection};
}

// This helper function is needed to workaround a gcc bug.
// Remove when we upgrade to a newer version of gcc.
template<typename T>
static T* _findModifier(Decl* decl)
{
    return decl->findModifier<T>();
}

static void checkDerivativeAttribute(
    SemanticsVisitor* visitor,
    FunctionDeclBase* funcDecl,
    ForwardDerivativeAttribute* attr);

// Checks a derivative whose `[ForwardDerivativeOf]` attribute names the primal. Higher-order
// resolution selects the matching primal specialization before this function emits a conditional
// extension for it. `attr` is freshly synthesized with an unresolved reference to
// `derivativeFuncDecl`.
static void checkDerivativeAttribute(
    SemanticsVisitor* visitor,
    DeclRef<FunctionDeclBase> primalDeclRef,
    FunctionDeclBase* derivativeFuncDecl,
    ForwardDerivativeAttribute* attr);

static void checkDerivativeAttribute(
    SemanticsVisitor* visitor,
    FunctionDeclBase* funcDecl,
    BackwardDerivativeAttribute* attr);

static void checkDerivativeAttribute(
    SemanticsVisitor* visitor,
    FunctionDeclBase* funcDecl,
    PrimalSubstituteAttribute* attr);

template<typename TDerivativeAttr, typename TDifferentiateExpr, typename TDerivativeOfAttr>
void checkDerivativeOfAttributeImpl(
    SemanticsVisitor* visitor,
    FunctionDeclBase* derivativeFuncDecl,
    TDerivativeOfAttr* derivativeOfAttr,
    DeclAssociationKind assocKind)
{
    auto astBuilder = visitor->getASTBuilder();
    DeclRef<Decl> selectedPrimalDeclRef;
    DeclRefExpr* selectedPrimalDeclRefExpr = nullptr;
    HigherOrderInvokeExpr* higherOrderFuncExpr = astBuilder->create<TDifferentiateExpr>();
    higherOrderFuncExpr->baseFunction = derivativeOfAttr->funcExpr;
    if (derivativeOfAttr->args.getCount() > 0)
        higherOrderFuncExpr->loc = derivativeOfAttr->args[0]->loc;

    Expr* checkedHigherOrderFuncExpr = visitor->dispatchExpr(
        higherOrderFuncExpr,
        visitor->allowStaticReferenceToNonStaticMember());

    if (!checkedHigherOrderFuncExpr)
    {
        visitor->getSink()->diagnose(
            Diagnostics::CannotResolveOriginalFunctionForDerivative{.attr = derivativeOfAttr->loc});
        return;
    }
    List<Expr*> imaginaryArgs =
        getImaginaryArgsToFunc(astBuilder, derivativeFuncDecl, derivativeOfAttr->loc).args;
    auto invokeExpr =
        visitor->constructUncheckedInvokeExpr(checkedHigherOrderFuncExpr, imaginaryArgs);
    SemanticsContext::ExprLocalScope scope;
    auto ctx = visitor->withExprLocalScope(&scope);
    auto subVisitor = SemanticsVisitor(ctx);
    auto resolved = subVisitor.ResolveInvoke(invokeExpr);
    if (auto resolvedInvoke = as<InvokeExpr>(resolved))
    {
        auto resolvedFuncExpr = as<HigherOrderInvokeExpr>(resolvedInvoke->functionExpr);
        if (resolvedFuncExpr)
        {
            selectedPrimalDeclRefExpr = as<DeclRefExpr>(resolvedFuncExpr->baseFunction);
            if (!selectedPrimalDeclRefExpr && as<OverloadedExpr>(resolvedFuncExpr->baseFunction))
            {
                visitor->getSink()->diagnose(
                    Diagnostics::OverloadedFuncUsedWithDerivativeOfAttributes{
                        .attr = derivativeOfAttr->loc});
            }
        }
    }

    if (!selectedPrimalDeclRefExpr)
    {
        visitor->getSink()->diagnose(
            Diagnostics::CannotResolveOriginalFunctionForDerivative{.attr = derivativeOfAttr->loc});
        return;
    }

    selectedPrimalDeclRefExpr->loc = higherOrderFuncExpr->loc;
    if (derivativeOfAttr->args.getCount() > 0)
        derivativeOfAttr->args[0] = selectedPrimalDeclRefExpr;

    selectedPrimalDeclRef = selectedPrimalDeclRefExpr->declRef;

    auto primalFuncDecl = as<FunctionDeclBase>(selectedPrimalDeclRef.getDecl());

    if (!primalFuncDecl)
    {
        // If we couldn't find a direct function, it might be a generic.
        if (auto genericDecl = as<GenericDecl>(selectedPrimalDeclRef.getDecl()))
        {
            primalFuncDecl = as<FunctionDeclBase>(genericDecl->inner);

            if (as<ErrorType>(resolved->type.type))
            {
                // If we can't resolve a type, something went wrong. If we're working with a
                // generic decl, the most likely cause is a failure of generic argument
                // inference. The error-recovery candidate still refers to the enclosing
                // `GenericDecl`, while `primalFuncDecl` refers to its inner function, so the
                // later null check would not stop function-only processing. This diagnostic is
                // the terminal boundary for that non-canonical reference.
                //
                visitor->getSink()->diagnose(
                    Diagnostics::CannotResolveGenericArgumentForDerivativeFunction{
                        .attr = derivativeOfAttr->loc});
                return;
            }
        }
    }

    if (!primalFuncDecl)
    {
        visitor->getSink()->diagnose(
            Diagnostics::CannotResolveOriginalFunctionForDerivative{.attr = derivativeOfAttr->loc});
        return;
    }

    // For now, if `primalFuncDecl` or `derivativeFuncDecl` is nested inside a generic aggregate,
    // they must be the same generic decl. For example, using B<T>.f() as the original function
    // for C<T>.derivative() is not allowed.
    // We may relax this restriction in the future by solving the "inverse" generic arguments
    // from `selectedPrimalDeclRef`, and use them to create a declaration reference to the
    // derivative from the primal.

    if (isInterfaceRequirement(primalFuncDecl))
    {
        visitor->getSink()->diagnose(Diagnostics::CannotAssociateInterfaceRequirementWithDerivative{
            .attr = derivativeOfAttr->loc});
        return;
    }
    if (isInterfaceRequirement(derivativeFuncDecl))
    {
        visitor->getSink()->diagnose(
            Diagnostics::CannotUseInterfaceRequirementAsDerivative{.attr = derivativeOfAttr->loc});
        return;
    }

    if (auto existingModifier = _findModifier<TDerivativeAttr>(primalFuncDecl))
    {
        // The primal function already has a `[*Derivative]` attribute, this is invalid.
        visitor->getSink()->diagnose(Diagnostics::DeclAlreadyHasAttribute{
            .decl = selectedPrimalDeclRef.getDecl(),
            .attrName = getDerivativeAttrName<TDerivativeAttr>(),
            .attr = derivativeOfAttr->loc});
        visitor->getSink()->diagnose(
            Diagnostics::SeeDeclarationOf{.decl = selectedPrimalDeclRef.getDecl()});
    }

    derivativeOfAttr->funcExpr = selectedPrimalDeclRefExpr;
    auto derivativeAttr = astBuilder->create<TDerivativeAttr>();
    derivativeAttr->loc = derivativeOfAttr->loc;
    DeclRef<Decl> declRef;
    if constexpr (std::is_same_v<TDerivativeAttr, ForwardDerivativeAttribute>)
    {
        // Higher-order overload resolution expressed the selected primal specialization in the
        // derivative's generic context. Form the corresponding specialized reference to the
        // derivative itself instead of rebuilding an application from the primal's raw generic
        // declaration.
        declRef = createDefaultSubstitutionsIfNeeded(
            astBuilder,
            visitor,
            derivativeFuncDecl->getDefaultDeclRef());
    }
    else
    {
        // The backward-derivative and primal-substitute consumers still validate and synthesize
        // from an unspecialized primal declaration. Keep their existing path explicit: unlike the
        // forward-derivative path above, an overloaded generic primal is not yet supported for
        // these two attribute kinds.
        auto outerGeneric = visitor->GetOuterGeneric(derivativeFuncDecl);
        declRef = makeDeclRef<Decl>((outerGeneric ? (Decl*)outerGeneric : derivativeFuncDecl));

        // If both the derivative and the original function are defined in the same outer generic
        // aggregate type, we want to form a full declref with default arguments.
        declRef = createDefaultSubstitutionsIfNeeded(astBuilder, visitor, declRef);
    }

    auto declRefExpr = visitor->ConstructDeclRefExpr(
        declRef,
        nullptr,
        declRef.getName(),
        derivativeOfAttr->loc,
        nullptr);
    declRefExpr->type.type = nullptr;
    derivativeAttr->args.add(declRefExpr);
    derivativeAttr->funcExpr = declRefExpr;
    if constexpr (std::is_same_v<TDerivativeAttr, ForwardDerivativeAttribute>)
    {
        // `AddHigherOrderOverloadCandidates` replaces a successfully inferred generic candidate's
        // base function with its specialized inner function reference. Error recovery can instead
        // retain the enclosing `GenericDecl`, but the `ErrorType` path above returns after
        // diagnosing failed generic argument inference. Enforce this producer-consumer boundary
        // in release builds before the unchecked typed rewrap below.
        SLANG_RELEASE_ASSERT(selectedPrimalDeclRef.is<FunctionDeclBase>());
        auto specializedPrimalDeclRef = selectedPrimalDeclRef.as<FunctionDeclBase>();
        checkDerivativeAttribute(
            visitor,
            specializedPrimalDeclRef,
            derivativeFuncDecl,
            derivativeAttr);
    }
    else
    {
        checkDerivativeAttribute(visitor, primalFuncDecl, derivativeAttr);
    }
    derivativeOfAttr->backDeclRef = derivativeAttr->funcExpr;
    derivativeAttr->funcExpr = nullptr;
    visitor->getShared()->registerAssociatedDecl(
        selectedPrimalDeclRef.getDecl(),
        assocKind,
        derivativeFuncDecl);
}


// Synthesizes an AD 2.0 forward-derivative extension. `primalDeclRef` supplies the specialized
// function type being extended, while `extensionContextFuncDecl` supplies the generic and module
// context in which the derivative reference is valid. They differ when `[ForwardDerivativeOf]` is
// written on the derivative because the selected primal specialization is expressed in the
// derivative declaration's generic context.
static void translateFwdDerivativeAttributeToAD2(
    SemanticsVisitor* visitor,
    FunctionDeclBase* extensionContextFuncDecl,
    DeclRef<FunctionDeclBase> primalDeclRef,
    ForwardDerivativeAttribute* attr)
{
    //
    // Translate a custom derivative function attribute to AD 2.0
    //

    // Create an extension for the target function &
    // and insert a decl that is a reference to that
    // target
    //
    auto astBuilder = visitor->getASTBuilder();
    auto fwdDiffExtension = astBuilder->create<ExtensionDecl>();
    auto funcAsType = DeclRefType::create(astBuilder, primalDeclRef);
    auto userDefinedFwdDiffFunc = as<DeclRefExpr>(attr->funcExpr)->declRef.as<CallableDecl>();
    auto visibility = getMoreRestrictiveVisibility(
        getDeclVisibility(primalDeclRef.getDecl()),
        getDeclVisibility(userDefinedFwdDiffFunc.getDecl()));
    auto synthesizedVisibility = getSynthesizedExtensionVisibility(visibility);

    fwdDiffExtension->parentDecl = extensionContextFuncDecl;
    fwdDiffExtension->loc = attr->loc;
    fwdDiffExtension->nameAndLoc.loc = attr->loc;
    visitor->addVisibilityModifier(fwdDiffExtension, synthesizedVisibility.extensionVisibility);

    SubstitutionSet substSet;
    visitor->liftDeclFromGenericContainers(fwdDiffExtension, substSet);

    funcAsType = as<Type>(funcAsType->substitute(getCurrentASTBuilder(), substSet));
    fwdDiffExtension->targetType.type = funcAsType;
    fwdDiffExtension->targetType.exp = astBuilder->create<SharedTypeExpr>();
    fwdDiffExtension->targetType.exp->type = astBuilder->getOrCreate<TypeType>(funcAsType);

    auto fwdDiffInheritanceDecl = astBuilder->create<InheritanceDecl>();
    fwdDiffInheritanceDecl->loc = attr->loc;
    fwdDiffInheritanceDecl->base.type = visitor->getForwardDiffFuncInterfaceType(funcAsType);
    fwdDiffExtension->addMember(fwdDiffInheritanceDecl);
    userDefinedFwdDiffFunc =
        substituteDeclRef(substSet, astBuilder, as<DeclRefExpr>(attr->funcExpr)->declRef)
            .as<CallableDecl>();


    auto funcAliasDecl = astBuilder->create<FuncAliasDecl>();
    funcAliasDecl->loc = attr->loc;
    funcAliasDecl->nameAndLoc.name = astBuilder->getNamePool()->getName("fwd_diff");
    funcAliasDecl->nameAndLoc.loc = attr->loc;
    visitor->addVisibilityModifier(funcAliasDecl, synthesizedVisibility.memberVisibility);
    funcAliasDecl->targetDeclRef = userDefinedFwdDiffFunc;

    if (!visitor->findEffectiveThisParamInfo(userDefinedFwdDiffFunc))
        addModifier(funcAliasDecl, astBuilder->create<HLSLStaticModifier>());

    fwdDiffExtension->addMember(funcAliasDecl);

    // Add the forward diff extension to the module.
    Decl* outermostFwdDiffDecl = fwdDiffExtension;
    while (outermostFwdDiffDecl->parentDecl && !as<ModuleDecl>(outermostFwdDiffDecl->parentDecl))
    {
        outermostFwdDiffDecl = outermostFwdDiffDecl->parentDecl;
    }

    getModuleDecl(extensionContextFuncDecl)->addMember(outermostFwdDiffDecl);
    // End AD 2.0 translation
}

static void translateFwdDerivativeAttributeToAD2(
    SemanticsVisitor* visitor,
    FunctionDeclBase* funcDecl,
    ForwardDerivativeAttribute* attr)
{
    auto funcDeclRef = createDefaultSubstitutionsIfNeeded(
                           getCurrentASTBuilder(),
                           visitor,
                           funcDecl->getDefaultDeclRef())
                           .as<FunctionDeclBase>();
    translateFwdDerivativeAttributeToAD2(visitor, funcDecl, funcDeclRef, attr);
}

static void translateBwdDerivativeAttributeToAD2(
    SemanticsVisitor* visitor,
    FunctionDeclBase* targetFuncDecl,
    DeclRef<FunctionDeclBase> primalDeclRef,
    BackwardDerivativeAttribute* attr)
{
    auto substFuncAsType = DeclRefType::create(getCurrentASTBuilder(), primalDeclRef);
    auto funcAsType =
        DeclRefType::create(getCurrentASTBuilder(), targetFuncDecl->getDefaultDeclRef());

    SubstitutionSet substSet;
    DeclRef<Decl> bwdDiffFunc = as<DeclRefExpr>(attr->funcExpr)->declRef;

    auto visibility = getMoreRestrictiveVisibility(
        getDeclVisibility(targetFuncDecl),
        getDeclVisibility(bwdDiffFunc.getDecl()));
    auto synthesizedVisibility = getSynthesizedExtensionVisibility(visibility);
    auto bwdDiffExtension = extendContainerDecl(
        visitor,
        targetFuncDecl,
        visitor->getBackwardDiffFuncInterfaceType(funcAsType),
        substSet,
        synthesizedVisibility.extensionVisibility,
        attr->loc);

    auto substFuncAsTypeFromExtension =
        as<DeclRefType>(substFuncAsType->substitute(getCurrentASTBuilder(), substSet));
    auto funcAsTypeFromExtension =
        as<DeclRefType>(funcAsType->substitute(getCurrentASTBuilder(), substSet));
    auto legacyBwdDiffFuncFromExtension =
        substituteDeclRef(substSet, getCurrentASTBuilder(), bwdDiffFunc);

    // bwd_diff is static in the interface (this-type becomes an explicit parameter).
    auto synBwdDiffFunc = addSynthesizedFunc(
        visitor,
        bwdDiffExtension.getDecl(),
        visitor->getName("bwd_diff"),
        kIROp_FunctionCopy,
        {legacyBwdDiffFuncFromExtension},
        visitor->getCalculatedDiffFuncType("BwdDiffFuncType", funcAsTypeFromExtension),
        true,
        synthesizedVisibility.memberVisibility,
        attr->loc);

    synBwdDiffFunc =
        createDefaultSubstitutionsIfNeeded(getCurrentASTBuilder(), visitor, synBwdDiffFunc)
            .as<SynthesizedFuncDecl>();
    auto synContextStruct = addOrExtendSynthesizedStruct(
        visitor,
        bwdDiffExtension.getDecl(),
        visitor->getName("BwdCallable"),
        kIROp_BackwardContextFromLegacyBwdDiffFunc,
        {substFuncAsTypeFromExtension->getDeclRefBase(), synBwdDiffFunc},
        {visitor->getBwdCallableBaseType(funcAsTypeFromExtension)},
        synthesizedVisibility.extensionVisibility,
        synthesizedVisibility.memberVisibility,
        attr->loc);

    auto synMinimalContextStruct = addOrExtendSynthesizedStruct(
        visitor,
        bwdDiffExtension.getDecl(),
        visitor->getName("MinimalContext"),
        kIROp_BackwardMinimalContextFromLegacyBwdDiffFunc,
        {substFuncAsTypeFromExtension->getDeclRefBase(), synBwdDiffFunc},
        {},
        synthesizedVisibility.extensionVisibility,
        synthesizedVisibility.memberVisibility,
        attr->loc);

    auto minimalCtxType = DeclRefType::create(getCurrentASTBuilder(), synMinimalContextStruct);
    auto fullCtxType = DeclRefType::create(getCurrentASTBuilder(), synContextStruct);

    FuncType* applyBwdFuncType = visitor->getCalculatedDiffFuncType(
        "ApplyForBwdFuncType",
        funcAsTypeFromExtension,
        minimalCtxType);
    addSynthesizedFunc(
        visitor,
        bwdDiffExtension.getDecl(),
        visitor->getName("apply_bwd"),
        kIROp_BackwardPrimalFromLegacyBwdDiffFunc,
        {substFuncAsTypeFromExtension->getDeclRefBase(), synBwdDiffFunc},
        applyBwdFuncType,
        false,
        synthesizedVisibility.memberVisibility,
        attr->loc);

    addSynthesizedFunc(
        visitor,
        bwdDiffExtension.getDecl(),
        visitor->getName("remat"),
        kIROp_BackwardRematFromLegacyBwdDiffFunc,
        {substFuncAsTypeFromExtension->getDeclRefBase(), synBwdDiffFunc},
        visitor->getCalculatedDiffFuncType(
            "RematFuncType",
            funcAsTypeFromExtension,
            minimalCtxType,
            fullCtxType),
        true,
        synthesizedVisibility.memberVisibility,
        attr->loc);
}

static void checkDerivativeAttribute(
    SemanticsVisitor* visitor,
    DeclRef<FunctionDeclBase> primalDeclRef,
    FunctionDeclBase* derivativeFuncDecl,
    ForwardDerivativeAttribute* attr)
{
    SLANG_RELEASE_ASSERT(attr->funcExpr && !attr->funcExpr->type.type);

    ArgsWithDirectionInfo imaginaryArguments =
        getImaginaryArgsToForwardDerivative(visitor, primalDeclRef, attr->loc);
    checkDerivativeAttributeImpl(
        visitor,
        primalDeclRef,
        attr,
        imaginaryArguments.args,
        imaginaryArguments.directions,
        imaginaryArguments.thisArg,
        imaginaryArguments.thisArgDirection,
        PrimalAndDerivativeGenericSignatureResolutionStatus::AlreadyResolved);

    if (!as<DeclRefExpr>(attr->funcExpr))
    {
        // `checkDerivativeAttributeImpl` diagnosed the failed derivative resolution. AD 2.0
        // translation requires its declaration reference, so no association can be synthesized.
        return;
    }

    translateFwdDerivativeAttributeToAD2(visitor, derivativeFuncDecl, primalDeclRef, attr);
}

static void checkDerivativeAttribute(
    SemanticsVisitor* visitor,
    FunctionDeclBase* funcDecl,
    ForwardDerivativeAttribute* attr)
{
    if (!attr->funcExpr)
        return;
    if (attr->funcExpr->type.type)
        return;

    auto primalDeclRef = createDefaultSubstitutionsIfNeeded(
                             getCurrentASTBuilder(),
                             visitor,
                             funcDecl->getDefaultDeclRef())
                             .as<FunctionDeclBase>();
    ArgsWithDirectionInfo imaginaryArguments =
        getImaginaryArgsToForwardDerivative(visitor, primalDeclRef, attr->loc);
    checkDerivativeAttributeImpl(
        visitor,
        primalDeclRef,
        attr,
        imaginaryArguments.args,
        imaginaryArguments.directions,
        imaginaryArguments.thisArg,
        imaginaryArguments.thisArgDirection,
        PrimalAndDerivativeGenericSignatureResolutionStatus::NotYetResolved);

    if (!as<DeclRefExpr>(attr->funcExpr))
    {
        // If the funcExpr did not resolve to a declRefExpr, we can't do anything.
        return;
    }

    translateFwdDerivativeAttributeToAD2(visitor, funcDecl, primalDeclRef, attr);

    if (getCurrentASTBuilder()->m_substituteMap.containsKey(funcDecl))
        for (auto targetDecl : getCurrentASTBuilder()->m_substituteMap[funcDecl])
            translateFwdDerivativeAttributeToAD2(visitor, as<FunctionDeclBase>(targetDecl), attr);
}

static void checkDerivativeAttribute(
    SemanticsVisitor* visitor,
    FunctionDeclBase* funcDecl,
    BackwardDerivativeAttribute* attr)
{
    if (!attr->funcExpr)
        return;
    if (attr->funcExpr->type.type)
        return;

    auto primalDeclRef = createDefaultSubstitutionsIfNeeded(
                             getCurrentASTBuilder(),
                             visitor,
                             funcDecl->getDefaultDeclRef())
                             .as<FunctionDeclBase>();
    ArgsWithDirectionInfo imaginaryArguments =
        getImaginaryArgsToBackwardDerivative(visitor, primalDeclRef, attr->loc);
    checkDerivativeAttributeImpl(
        visitor,
        primalDeclRef,
        attr,
        imaginaryArguments.args,
        imaginaryArguments.directions,
        imaginaryArguments.thisArg,
        imaginaryArguments.thisArgDirection,
        PrimalAndDerivativeGenericSignatureResolutionStatus::NotYetResolved);

    if (!as<DeclRefExpr>(attr->funcExpr))
    {
        // If the funcExpr did not resolve to a declRefExpr, we can't do anything.
        return;
    }

    translateBwdDerivativeAttributeToAD2(visitor, funcDecl, primalDeclRef, attr);

    if (getCurrentASTBuilder()->m_substituteMap.containsKey(funcDecl))
        for (auto targetDecl : getCurrentASTBuilder()->m_substituteMap[funcDecl])
        {
            auto qualifiedPrimalDeclRef = buildQualifiedReference(visitor, funcDecl, targetDecl);
            translateBwdDerivativeAttributeToAD2(
                visitor,
                as<FunctionDeclBase>(targetDecl),
                qualifiedPrimalDeclRef.as<FunctionDeclBase>(),
                attr);
        }
}


static void checkDerivativeAttribute(
    SemanticsVisitor* visitor,
    FunctionDeclBase* funcDecl,
    PrimalSubstituteAttribute* attr)
{
    if (!attr->funcExpr)
        return;
    if (attr->funcExpr->type.type)
        return;

    ArgsWithDirectionInfo imaginaryArguments =
        getImaginaryArgsToFunc(visitor->getASTBuilder(), funcDecl, attr->loc);
    checkDerivativeAttributeImpl(
        visitor,
        funcDecl,
        attr,
        imaginaryArguments.args,
        imaginaryArguments.directions,
        imaginaryArguments.thisArg,
        imaginaryArguments.thisArgDirection);

    // For primal-substitute we'd also want to make sure that the differentiability
    // level of the target is as high as the funcDecl itself
    //
    if (auto declRefExpr = as<DeclRefExpr>(attr->funcExpr))
    {
        if (auto declRef = declRefExpr->declRef)
        {
            auto targetDiffLevel = visitor->getShared()->getFuncDifferentiableLevel(
                declRef.as<FunctionDeclBase>().getDecl());
            auto currDiffLevel = visitor->getShared()->getFuncDifferentiableLevel(funcDecl);
            if (targetDiffLevel < currDiffLevel)
            {
                visitor->getSink()->diagnose(
                    Diagnostics::PrimalSubstituteTargetMustHaveHigherDifferentiabilityLevel{
                        .attr = attr});
                return;
            }

            auto substDecl = declRef.getDecl();
            getCurrentASTBuilder()->m_substituteMap.addIfNotExists(
                substDecl,
                ShortList<Decl*, 4>());
            ShortList<Decl*, 4>& list = getCurrentASTBuilder()->m_substituteMap[substDecl];
            list.add(funcDecl);

            if (auto fwdDerivAttribute = substDecl->findModifier<ForwardDerivativeAttribute>())
            {
                // If the substDecl has a forward derivative attribute, we want to
                // transfer it to the funcDecl.
                if (as<DeclRefExpr>(fwdDerivAttribute->funcExpr) &&
                    as<DeclRefExpr>(fwdDerivAttribute->funcExpr)->declRef)
                    translateFwdDerivativeAttributeToAD2(visitor, funcDecl, fwdDerivAttribute);
            }

            if (auto bwdDerivAttribute = substDecl->findModifier<BackwardDerivativeAttribute>())
            {
                // If the substDecl has a backward derivative attribute, we want to
                // transfer it to the funcDecl.
                if (as<DeclRefExpr>(bwdDerivAttribute->funcExpr) &&
                    as<DeclRefExpr>(bwdDerivAttribute->funcExpr)->declRef)
                {
                    auto primalDeclRef = buildQualifiedReference(visitor, substDecl, funcDecl);
                    translateBwdDerivativeAttributeToAD2(
                        visitor,
                        funcDecl,
                        primalDeclRef.as<FunctionDeclBase>(),
                        as<BackwardDerivativeAttribute>(
                            substDecl->findModifier<BackwardDerivativeAttribute>()));
                }
            }

            if (substDecl->findModifier<ForwardDifferentiableAttribute>() ||
                substDecl->findModifier<BackwardDifferentiableAttribute>())
            {
                auto substFuncAsType = DeclRefType::create(getCurrentASTBuilder(), declRef);
                auto funcAsType =
                    DeclRefType::create(getCurrentASTBuilder(), funcDecl->getDefaultDeclRef());

                auto visibility = getDeclVisibility(funcDecl);
                auto synthesizedVisibility = getSynthesizedExtensionVisibility(visibility);
                SubstitutionSet substSet;
                auto fwdDiffExtension = extendContainerDecl(
                    visitor,
                    funcDecl,
                    visitor->getForwardDiffFuncInterfaceType(funcAsType),
                    substSet,
                    synthesizedVisibility.extensionVisibility);

                auto substFuncAsTypeFromExtension =
                    as<DeclRefType>(substFuncAsType->substitute(getCurrentASTBuilder(), substSet));
                auto funcAsTypeFromExtension =
                    as<DeclRefType>(funcAsType->substitute(getCurrentASTBuilder(), substSet));
                addSynthesizedFunc(
                    visitor,
                    fwdDiffExtension.getDecl(),
                    visitor->getName("fwd_diff"),
                    kIROp_ForwardDifferentiate,
                    {substFuncAsTypeFromExtension->getDeclRefBase()},
                    visitor->getCalculatedDiffFuncType("FwdDiffFuncType", funcAsTypeFromExtension),
                    true,
                    synthesizedVisibility.memberVisibility);
            }

            if (substDecl->findModifier<BackwardDifferentiableAttribute>())
            {
                auto substFuncAsType = DeclRefType::create(getCurrentASTBuilder(), declRef);
                auto funcAsType =
                    DeclRefType::create(getCurrentASTBuilder(), funcDecl->getDefaultDeclRef());

                auto visibility = getDeclVisibility(funcDecl);
                auto synthesizedVisibility = getSynthesizedExtensionVisibility(visibility);
                SubstitutionSet substSet;
                auto bwdDiffExtension = extendContainerDecl(
                    visitor,
                    funcDecl,
                    visitor->getBackwardDiffFuncInterfaceType(funcAsType),
                    substSet,
                    synthesizedVisibility.extensionVisibility);

                auto substFuncAsTypeFromExtension =
                    as<DeclRefType>(substFuncAsType->substitute(getCurrentASTBuilder(), substSet));
                auto funcAsTypeFromExtension =
                    as<DeclRefType>(funcAsType->substitute(getCurrentASTBuilder(), substSet));

                auto synContextStruct = addOrExtendSynthesizedStruct(
                    visitor,
                    bwdDiffExtension.getDecl(),
                    visitor->getName("BwdCallable"),
                    kIROp_BackwardDiffIntermediateContextType,
                    {substFuncAsTypeFromExtension->getDeclRefBase()},
                    {visitor->getBwdCallableBaseType(funcAsTypeFromExtension)},
                    synthesizedVisibility.extensionVisibility,
                    synthesizedVisibility.memberVisibility);

                auto synMinimalContextStruct = addOrExtendSynthesizedStruct(
                    visitor,
                    bwdDiffExtension.getDecl(),
                    visitor->getName("MinimalContext"),
                    kIROp_BackwardDiffMinimalContextType,
                    {substFuncAsTypeFromExtension->getDeclRefBase()},
                    {},
                    synthesizedVisibility.extensionVisibility,
                    synthesizedVisibility.memberVisibility);

                auto minimalCtxType =
                    DeclRefType::create(getCurrentASTBuilder(), synMinimalContextStruct);
                auto fullCtxType = DeclRefType::create(getCurrentASTBuilder(), synContextStruct);

                addSynthesizedFunc(
                    visitor,
                    bwdDiffExtension.getDecl(),
                    visitor->getName("apply_bwd"),
                    kIROp_BackwardDifferentiatePrimal,
                    {substFuncAsTypeFromExtension->getDeclRefBase()},
                    visitor->getCalculatedDiffFuncType(
                        "ApplyForBwdFuncType",
                        funcAsTypeFromExtension,
                        minimalCtxType),
                    false,
                    synthesizedVisibility.memberVisibility);

                addSynthesizedFunc(
                    visitor,
                    bwdDiffExtension.getDecl(),
                    visitor->getName("remat"),
                    kIROp_BackwardRemat,
                    {substFuncAsTypeFromExtension->getDeclRefBase()},
                    visitor->getCalculatedDiffFuncType(
                        "RematFuncType",
                        funcAsTypeFromExtension,
                        minimalCtxType,
                        fullCtxType),
                    true,
                    synthesizedVisibility.memberVisibility);

                // Force conformance checking for BwdCallable.operator() on this context.
                visitor->ensureDecl(synContextStruct, DeclCheckState::ReadyForConformances);
            }
        }
    }
}

static void checkCudaKernelAttribute(
    SemanticsVisitor* visitor,
    FunctionDeclBase* funcDecl,
    CudaKernelAttribute*)
{
    // If the method is also marked differentiable, check that the data types are either
    // non-differentiable or marked with no_diff.
    //
    // Note: This is a temporary restriction until we have a more complete story for
    // differentiability.
    //
    if (funcDecl->findModifier<DifferentiableAttribute>())
    {
        for (auto paramDecl : funcDecl->getParameters())
        {
            auto paramType = paramDecl->type;

            if (visitor->isTypeDifferentiable(paramType))
            {
                if (!paramDecl->hasModifier<NoDiffModifier>())
                {
                    visitor->getSink()->diagnose(
                        Diagnostics::DifferentiableKernelEntryPointCannotHaveDifferentiableParams{
                            .param = paramDecl});
                }
            }
        }
    }
}

template<typename TDerivativeAttr, typename TDerivativeOfAttr>
bool tryCheckDerivativeOfAttributeImpl(
    SemanticsVisitor* visitor,
    FunctionDeclBase* funcDecl,
    TDerivativeOfAttr* derivativeOfAttr,
    DeclAssociationKind assocKind,
    const List<Expr*>& imaginaryArgsToOriginal)
{
    DiagnosticSink tempSink(visitor->getSourceManager(), nullptr);
    SemanticsVisitor subVisitor(visitor->withSink(&tempSink));
    checkDerivativeOfAttributeImpl<TDerivativeAttr>(
        &subVisitor,
        funcDecl,
        derivativeOfAttr,
        assocKind,
        imaginaryArgsToOriginal);
    return tempSink.getErrorCount() == 0;
}

void SemanticsDeclAttributesVisitor::checkVarDeclCommon(VarDeclBase* varDecl)
{
    // This producer check is selected by the semantic `GLSLAtomicUintType`, independently of the
    // source language. A supported GLSL global atomic counter has a `layout(binding = ...)`
    // modifier; parsing that modifier also creates an explicit or implicit offset that the checked
    // modifier and parameter-layout paths preserve for the backing-storage rewrite. By contrast,
    // `import glsl; atomic_uint counter;` in Slang source creates the same semantic type but does
    // not pass through that GLSL layout producer, so it is deliberately rejected here. Otherwise
    // the declaration would become a decoration-less `kIROp_GLSLAtomicUintType` global that no
    // target can emit.
    //
    // Existing atomic-counter legalization supports only directly-declared globals. Reject arrays
    // at this producer boundary even when they have a binding; otherwise their element type
    // remains an unhandled placeholder at emission. Supporting arrays requires a corresponding
    // aggregate representation and legalization design, not a recursive scan in the linker.
    if (isGlobalDecl(varDecl))
    {
        Type* declaredType = varDecl->getType();
        Type* arrayElementType = unwrapArrayType(declaredType);
        if (as<GLSLAtomicUintType>(arrayElementType))
        {
            const bool isAtomicCounterArray = as<ArrayExpressionType>(declaredType) != nullptr;
            if (isAtomicCounterArray)
            {
                getSink()->diagnose(Diagnostics::GlslAtomicCounterArraysNotSupported{
                    .location = varDecl->nameAndLoc.loc});
            }
            else
            {
                const bool hasBinding = varDecl->findModifier<GLSLBindingAttribute>() != nullptr;
                const bool hasOffset =
                    varDecl->findModifier<GLSLOffsetLayoutAttribute>() != nullptr;

                // The earlier ModifiersChecked phase emits MissingLayoutBindingModifier for
                // `hasOffset && !hasBinding`. Diagnose the remaining binding-less shape here:
                // `!hasOffset && !hasBinding`, such as an `atomic_uint` introduced into Slang
                // source by `import glsl`. A binding-producing GLSL declaration has both.
                if (!hasBinding && !hasOffset)
                {
                    getSink()->diagnose(Diagnostics::GlslAtomicCounterRequiresBinding{
                        .location = varDecl->nameAndLoc.loc});
                }
            }
        }
    }

    bool hasSpecConstAttr = false;
    bool hasPushConstAttr = false;
    for (auto modifier : varDecl->modifiers)
    {
        if (as<SpecializationConstantAttribute>(modifier) || as<VkConstantIdAttribute>(modifier))
        {
            if (!isValidSpecializationConstantType(varDecl->getType()) &&
                !as<ErrorType>(varDecl->getType()))
            {
                getSink()->diagnose(
                    Diagnostics::SpecializationConstantMustBeScalarOrEnum{.modifier = modifier});
            }
            hasSpecConstAttr = true;
        }
        else if (as<PushConstantAttribute>(modifier))
        {
            hasPushConstAttr = true;
        }
        else if (auto registerSemantic = as<HLSLRegisterSemantic>(modifier))
        {
            checkHLSLRegisterSemantic(varDecl, registerSemantic);
        }
    }
    if (hasSpecConstAttr && hasPushConstAttr)
    {
        getSink()->diagnose(
            Diagnostics::VariableCannotBePushAndSpecializationConstant{.decl = varDecl});
    }
    if (hasSpecConstAttr || hasPushConstAttr)
    {
        if (varDecl->findModifier<HLSLStaticModifier>())
        {
            getSink()->diagnose(
                Diagnostics::PushOrSpecializationConstantCannotBeStatic{.decl = varDecl});
        }
    }
}

void SemanticsDeclAttributesVisitor::checkHLSLRegisterSemantic(
    VarDeclBase* varDecl,
    HLSLRegisterSemantic* registerSemantic)
{
    auto registerName = registerSemantic->registerName.getContent();
    if (registerName.getLength() < 1)
    {
        getSink()->diagnose(Diagnostics::InvalidHlslRegisterName{
            .registerName = String(registerName),
            .location = registerSemantic->registerName.getLoc()});
        return;
    }

    // Check to make sure the HLSL semantic register name is consistent with the resource type.

    auto varType = getType(m_astBuilder, DeclRef<VarDeclBase>(varDecl));
    varType = unwrapModifiedType(unwrapArrayType(varType));
    bool isValid = true;
    if (auto resType = as<ResourceType>(varType))
    {
        switch (registerName[0])
        {
        case 't':
            if (resType->getAccess() != SLANG_RESOURCE_ACCESS_READ)
                isValid = false;
            break;
        case 'u':
            if (resType->getAccess() == SLANG_RESOURCE_ACCESS_READ)
                isValid = false;
            break;
        case 's':
            if (!resType->isCombined())
                isValid = false;
            break;
        default:
            isValid = false;
            break;
        }
    }
    else if (
        as<HLSLByteAddressBufferType>(varType) || as<HLSLStructuredBufferType>(varType) ||
        as<RaytracingAccelerationStructureType>(varType))
    {
        if (registerName[0] != 't')
        {
            isValid = false;
        }
    }
    else if (
        as<HLSLRWByteAddressBufferType>(varType) ||
        as<HLSLRasterizerOrderedByteAddressBufferType>(varType) ||
        as<HLSLRWStructuredBufferType>(varType) || as<HLSLConsumeStructuredBufferType>(varType) ||
        as<HLSLAppendStructuredBufferType>(varType) ||
        as<HLSLRasterizerOrderedStructuredBufferType>(varType))
    {
        if (registerName[0] != 'u')
        {
            isValid = false;
        }
    }
    else if (as<SamplerStateType>(varType))
    {
        if (registerName[0] != 's')
        {
            isValid = false;
        }
    }
    else if (as<ConstantBufferType>(varType))
    {
        if (registerName[0] != 'b')
        {
            isValid = false;
        }
    }
    if (!isValid)
    {
        getSink()->diagnose(Diagnostics::InvalidHlslRegisterNameForType{
            .registerName = String(registerName),
            .type = varType,
            .location = registerSemantic->registerName.getLoc()});
    }
}

void SemanticsDeclDifferentialAttributesVisitor::checkForwardDerivativeOfAttribute(
    FunctionDeclBase* funcDecl,
    ForwardDerivativeOfAttribute* attr)
{
    checkDerivativeOfAttributeImpl<ForwardDerivativeAttribute, ForwardDifferentiateExpr>(
        this,
        funcDecl,
        attr,
        DeclAssociationKind::ForwardDerivativeFunc);
}

void SemanticsDeclDifferentialAttributesVisitor::checkBackwardDerivativeOfAttribute(
    FunctionDeclBase* funcDecl,
    BackwardDerivativeOfAttribute* attr)
{
    checkDerivativeOfAttributeImpl<BackwardDerivativeAttribute, BackwardDifferentiateExpr>(
        this,
        funcDecl,
        attr,
        DeclAssociationKind::BackwardDerivativeFunc);
}

void SemanticsDeclDifferentialAttributesVisitor::checkPrimalSubstituteOfAttribute(
    FunctionDeclBase* funcDecl,
    PrimalSubstituteOfAttribute* attr)
{
    checkDerivativeOfAttributeImpl<PrimalSubstituteAttribute, PrimalSubstituteExpr>(
        this,
        funcDecl,
        attr,
        DeclAssociationKind::PrimalSubstituteFunc);
}

bool SemanticsDeclAttributesVisitor::collectInitializableMembers(
    StructDecl* structDecl,
    const DeclVisibility ctorVisibility,
    List<VarDeclBase*>& resultMembers)
{
    auto findMembers = [&](StructDecl* structDecl)
    {
        for (auto varDeclRef : getMembersOfType<VarDeclBase>(
                 getASTBuilder(),
                 structDecl,
                 MemberFilterStyle::Instance))
        {
            auto varDecl = varDeclRef.getDecl();
            if (getDeclVisibility(varDecl) < ctorVisibility)
                continue;

            auto type = GetTypeForDeclRef(varDeclRef, varDecl->loc);
            if (!type.isLeftValue)
                continue;

            resultMembers.add(varDecl);
            structDecl->m_membersVisibleInCtor.add(varDecl);
        }
    };

    // Find the base type's members first
    for (auto inheritanceMember : structDecl->getMembersOfType<InheritanceDecl>())
    {
        // For base types, we need to pick their parameters of the constructor to the derived
        // type's constructor
        if (auto baseTypeDeclRef = isDeclRefTypeOf<StructDecl>(inheritanceMember->base.type))
        {
            // We should only find the member initialization constructor because it is the
            // constructor has parameters
            ConstructorDecl* ctor = _getSynthesizedConstructor(
                baseTypeDeclRef.getDecl(),
                ConstructorDecl::ConstructorFlavor::SynthesizedMemberInit);

            // The constructor has to have higher or equal visibility level than the struct
            // itself, otherwise, it's not accessible so we will not pick up.
            if (ctor && getDeclVisibility(ctor) >= ctorVisibility)
            {
                for (ParamDecl* param : ctor->getParameters())
                {
                    // Because the parameters in the ctor must have the higher or equal
                    // visibility than the ctor itself, we don't need to check the visibility
                    // level of the parameter.
                    resultMembers.add(param);
                }
            }
        }
    }

    // Find the struct's members
    findMembers(structDecl);
    return (resultMembers.getCount() > 0);
}

// If a struct's member:
// 1. has an initialize expression: Struct S {int a = 1;}; or
// 2. is a default initializable type
//    Note, If a type is not default initializable, it doesn't have default value.
// it can be associated with default value expression in the constructor signature.
// This function helps to check whether either of those 2 conditions are met and create
// a default value for the parameter.
// It's totally fine that there is no default value for the parameter, in this case, user
// code has to provide the argument for this parameter.
static Expr* _getParamDefaultValue(SemanticsVisitor* visitor, VarDeclBase* varDecl)
{
    // 1st condition is easy, we can just use the init expression as the default value.
    if (varDecl->initExpr)
    {
        return varDecl->initExpr;
    }

    if (!varDecl->type || !varDecl->type.type)
        return nullptr;

    if (!isDefaultInitializable(varDecl))
        return nullptr;

    if (auto expr = constructDefaultConstructorForType(
            visitor,
            varDecl->type.type,
            getDiagnosticPos(varDecl->type)))
    {
        return expr;
    }

    return nullptr;
}

bool SemanticsDeclAttributesVisitor::_synthesizeCtorSignature(StructDecl* structDecl)
{
    // If a type or its base type already defines any explicit constructors, do not synthesize
    // any constructors. see:
    // https://github.com/shader-slang/slang/blob/master/docs/proposals/004-initialization.md#inheritance-initialization
    if (_hasExplicitConstructor(structDecl, true))
        return true;

    // synthesize the signature first.
    // The constructor's visibility level is the same as the struct itself.
    // See
    // https://github.com/shader-slang/spec/blob/main/proposals/004-initialization.md#synthesis-of-constructors-for-member-initialization
    DeclVisibility ctorVisibility = getDeclVisibility(structDecl);

    // Only the members whose visibility level is higher or equal than the
    // constructor's visibility level will appear in the constructor's parameter list.
    List<VarDeclBase*> resultMembers;
    if (!collectInitializableMembers(structDecl, ctorVisibility, resultMembers))
        return false;

    // synthesize the constructor signature:
    // 1. The constructor's name is always `$init`, we create one without parameters now.
    ConstructorDecl* ctor = createCtor(structDecl, ctorVisibility);
    ctor->addFlavor(ConstructorDecl::ConstructorFlavor::SynthesizedMemberInit);

    List<Decl*> ctorParamsBuiltInReverseOrder;
    ctorParamsBuiltInReverseOrder.reserve(resultMembers.getCount());

    // 2. Add the parameter list
    bool stopProcessingDefaultValues = false;
    for (SlangInt i = resultMembers.getCount() - 1; i >= 0; i--)
    {
        auto member = resultMembers[i];
        auto parentAggDecl = getParentAggTypeDecl(member);

        auto ctorParam = m_astBuilder->create<ParamDecl>();
        ctorParam->type = (TypeExp)member->type;
        if (auto atomicType = as<AtomicType>(ctorParam->type))
        {
            ctorParam->type.type = atomicType->getElementType();
        }

        if (!stopProcessingDefaultValues)
            ctorParam->initExpr = _getParamDefaultValue(this, member);

        if (!ctorParam->initExpr)
            stopProcessingDefaultValues = true;

        ctorParam->parentDecl = ctor;

        Name* paramName =
            (parentAggDecl == structDecl)
                ? member->getName()
                : getName(parentAggDecl->getName()->text + "_" + member->getName()->text);

        ctorParam->nameAndLoc = NameLoc(paramName, ctor->loc);

        ctorParam->loc = ctor->loc;
        ctorParamsBuiltInReverseOrder.add(ctorParam);

        // We need to ensure member is `no_diff` if it cannot be differentiated, `ctor`
        // modifiers do not matter in this case since member-wise ctor is always differentiable
        // or "treat as differentiable".
        if (!isTypeDifferentiable(member->getType()) || member->hasModifier<NoDiffModifier>())
        {
            auto noDiffMod = m_astBuilder->create<NoDiffModifier>();
            noDiffMod->loc = ctorParam->loc;
            addModifier(ctorParam, noDiffMod);
        }
    }
    ctorParamsBuiltInReverseOrder.reverse();
    for (auto ctorParam : ctorParamsBuiltInReverseOrder)
    {
        ctor->addDirectMemberDecl(ctorParam);
    }
    return true;
}

// Options that control bitfield-packing behavior.
//
// `getEffectiveBitfieldPackingRules` selects a rule from the compilation options, and
// `getBitfieldPackingOptions` maps that rule to these two choices.
struct BitfieldPackingOptions
{
    bool shouldPackBitfieldsMSBFirst = false;
    bool shouldStartNewBitfieldStorageOnTypeSizeChange = false;
};

// Resolve the packing rules indicated by the given compilation options.
//
// We consider these options from highest to lowest precedence:
// - An explicit `BitfieldPackingRules` option takes precedence, including when its value is
//   `Default`. Its command-line spelling is `-bitfield-packing-rules`.
// - A true `UseMSVCStyleBitfieldPacking` option selects `LegacyMSBFirstMSVC` when no explicit
//   rule is present. Its command-line spelling is `-msvc-style-bitfield-packing`.
// - The `Default` rules apply when neither option selects a rule.
static slang::BitfieldPackingRules getEffectiveBitfieldPackingRules(CompilerOptionSet& optionSet)
{
    if (optionSet.hasOption(CompilerOptionName::BitfieldPackingRules))
    {
        return optionSet.getEnumOption<slang::BitfieldPackingRules>(
            CompilerOptionName::BitfieldPackingRules);
    }
    if (optionSet.getBoolOption(CompilerOptionName::UseMSVCStyleBitfieldPacking))
        return slang::BitfieldPackingRules::LegacyMSBFirstMSVC;
    return slang::BitfieldPackingRules::Default;
}

// Map a bitfield-packing rules enumerant to the packing options it implies.
static BitfieldPackingOptions getBitfieldPackingOptions(slang::BitfieldPackingRules rules)
{
    switch (rules)
    {
    case slang::BitfieldPackingRules::Default:
        return {
            .shouldPackBitfieldsMSBFirst = false,
            .shouldStartNewBitfieldStorageOnTypeSizeChange = false,
        };
    case slang::BitfieldPackingRules::MSVC:
        return {
            .shouldPackBitfieldsMSBFirst = false,
            .shouldStartNewBitfieldStorageOnTypeSizeChange = true,
        };
    case slang::BitfieldPackingRules::LegacyMSBFirstMSVC:
        return {
            .shouldPackBitfieldsMSBFirst = true,
            .shouldStartNewBitfieldStorageOnTypeSizeChange = true,
        };
    }
    SLANG_UNREACHABLE("invalid bitfield packing rules");
}

void SemanticsDeclAttributesVisitor::visitStructDecl(StructDecl* structDecl)
{
    // add the member initialize constructor here to avoid circular checking logic
    if (!_synthesizeCtorSignature(structDecl))
    {
        // add a default CTor if missing; checking in attributes
        // to avoid circular checking logic
        auto defaultCtor = _getDefaultCtor(structDecl);
        if (!defaultCtor)
        {
            DeclVisibility ctorVisibility = getDeclVisibility(structDecl);
            createCtor(structDecl, ctorVisibility);
        }
    }

    // Check if this is a ray payload struct and validate field access qualifiers
    if (structDecl->findModifier<RayPayloadAttribute>())
    {
        checkRayPayloadStructFields(structDecl);
    }

    // We group adjacent bitfields into synthesized backing integers. The selected rules tell us
    // where to place each bitfield within its backing integer and when to start another one.
    const auto bitfieldPackingRules = getEffectiveBitfieldPackingRules(getOptionSet());
    const auto bitfieldPackingOptions = getBitfieldPackingOptions(bitfieldPackingRules);

    int backingWidth = 0;
    [[maybe_unused]] int totalWidth = 0;
    struct BitFieldInfo
    {
        int memberIndex;
        int bitWidth;
        Type* memberType;
        BitFieldModifier* bitFieldModifier;
    };
    List<BitFieldInfo> groupInfo;

    int memberIndex = 0;
    int backing_nonce = 0;

    // Some packing rules start a new backing integer when the declared bitfield type changes
    // size. Consider `uint8_t a : 7; uint32_t b : 1;`: the type width changes from 8 to 32 bits.
    // We track the type width of the preceding bitfield in the current group. Zero means there
    // is no preceding bitfield, since every built-in integer type has a nonzero bit width.
    int previousFieldTypeWidth = 0;

    // We insert a backing integer and assign bit offsets when the current group is nonempty.
    // The helper then clears the accumulated state so the next group starts fresh.
    const auto finishBitfieldGroup = [&]()
    {
        SLANG_ASSERT(totalWidth <= backingWidth);
        SLANG_ASSERT(backingWidth <= 64);

        // We're going to insert a backing member to be referenced in
        // all the bitfield properties
        if (groupInfo.getCount())
        {
            const auto backingMemberBasicType = backingWidth <= 8    ? BaseType::UInt8
                                                : backingWidth <= 16 ? BaseType::UInt16
                                                : backingWidth <= 32 ? BaseType::UInt
                                                                     : BaseType::UInt64;
            auto backingMember = m_astBuilder->create<VarDecl>();
            backingMember->type.type = m_astBuilder->getBuiltinType(backingMemberBasicType);
            backingMember->nameAndLoc.name =
                getName(String("$bit_field_backing_") + String(backing_nonce));
            backing_nonce++;
            // Give the synthesized backing storage an explicit zero initializer.
            // The backing field is synthesized after the constructor signature has been
            // collected, so it is never a constructor parameter (not in
            // `m_membersVisibleInCtor`); with a null `initExpr`,
            // `synthesizeCtorBodyForMemberVar` early-outs for non-parameter members and
            // never writes it, so `Foo f = {}` on a struct that mixes bitfields with a
            // normal field would leave the bitfield members reading uninitialized memory
            // (issue #11844).
            // The general per-member default-init loop in
            // `SemanticsDeclBodyVisitor::visitAggTypeDecl` does not cover this: it is gated
            // on the struct conforming to `IDefaultInitializable`, which these bitfield
            // structs do not, so it never fires here. Initializing the backing word at the
            // point of synthesis is therefore the single, uniform source of its zero
            // default across every synthesized-constructor path.
            // A raw `IntegerLiteralExpr(0)` (rather than `constructDefaultInitExprForType`)
            // is deliberate: the backing type is always a builtin unsigned integer
            // (selected just above), so a typed zero literal is the simplest provably
            // correct form, and it lowers to an explicit `store 0` on every target —
            // whereas a `DefaultConstructExpr` emits `= {}` only for CPP/CUDA and would not
            // zero the scalar on HLSL-class backends.
            auto zeroBackingInit = m_astBuilder->create<IntegerLiteralExpr>();
            zeroBackingInit->type = QualType(backingMember->type.type);
            zeroBackingInit->value = 0;
            zeroBackingInit->loc = structDecl->loc;
            backingMember->initExpr = zeroBackingInit;
            backingMember->parentDecl = structDecl;
            const auto backingMemberDeclRef = DeclRef<VarDecl>(backingMember->getDefaultDeclRef());

            if (bitfieldPackingOptions.shouldPackBitfieldsMSBFirst)
            {
                // With MSB-first packing, the first declared field occupies the high bits of the
                // backing integer. We count downward by each field's width to assign offsets.
                int currentBitPosition = backingWidth;
                for (const auto& m : groupInfo)
                {
                    currentBitPosition -= m.bitWidth;
                    SLANG_ASSERT(currentBitPosition >= 0);

                    m.bitFieldModifier->backingDeclRef = backingMemberDeclRef;
                    m.bitFieldModifier->offset = currentBitPosition;
                }
            }
            else
            {
                // With LSB-first packing, the first declared field occupies the low bits of the
                // backing integer. We count upward by each field's width to assign offsets.
                int bottomOfMember = 0;
                for (const auto& m : groupInfo)
                {
                    SLANG_ASSERT(bottomOfMember <= backingWidth);

                    m.bitFieldModifier->backingDeclRef = backingMemberDeclRef;
                    m.bitFieldModifier->offset = bottomOfMember;

                    bottomOfMember += m.bitWidth;
                }
            }

            const auto backingMemberIndex = groupInfo[0].memberIndex;

            structDecl->_insertDirectMemberDeclAtIndexForBitfieldPropertyBackingMember(
                backingMemberIndex,
                backingMember);

            ++memberIndex;
        }

        // Clear the group's widths and members. The next group has no preceding field type width.
        backingWidth = 0;
        totalWidth = 0;
        groupInfo.clear();
        previousFieldTypeWidth = 0;
    };

    for (; memberIndex < structDecl->getDirectMemberDeclCount(); ++memberIndex)
    {
        const auto& m = structDecl->getDirectMemberDecl(memberIndex);

        // A non-property declaration adds no bits to the group. A variable ends the group.
        const auto v = as<PropertyDecl>(m);
        if (!v)
        {
            if (as<VarDecl>(m))
                finishBitfieldGroup();
            continue;
        }

        const auto bfm = m->findModifier<BitFieldModifier>();
        // An ordinary property ends the current bitfield group.
        if (!bfm)
        {
            finishBitfieldGroup();
            continue;
        }

        // A bitfield property must have an integral declared type.
        const auto t = v->type.type->getCanonicalType();
        SLANG_ASSERT(t);
        const auto b = as<BasicExpressionType>(t);
        if (!b)
        {
            getSink()->diagnose(Diagnostics::BitFieldNonIntegral{.type = t, .location = v->loc});
            continue;
        }
        const auto baseType = b->getBaseType();
        const bool isIntegerType = isIntegerBaseType(baseType);
        if (!isIntegerType)
        {
            getSink()->diagnose(Diagnostics::BitFieldNonIntegral{.type = t, .location = v->loc});
            continue;
        }

        // The declared bit width cannot exceed the width of its underlying integer type.
        const auto thisFieldWidth = bfm->width;
        const auto thisFieldTypeWidth = getMaximumTypeBitSize(b);
        SLANG_ASSERT(thisFieldTypeWidth != 0);
        if (thisFieldWidth > thisFieldTypeWidth)
        {
            getSink()->diagnose(Diagnostics::BitFieldTooWide{
                .fieldWidth = (int64_t)thisFieldWidth,
                .type = t,
                .typeWidth = (int64_t)thisFieldTypeWidth,
                .location = v->loc});
            // An oversized field cannot join a backing group.
            continue;
        }

        // A zero-width bitfield ends the preceding group. This group break does not implement
        // MSVC's alignment rule for zero-width fields, so the MSVC mode diagnoses the field.
        if (thisFieldWidth == 0)
        {
            if (bitfieldPackingRules == slang::BitfieldPackingRules::MSVC)
            {
                getSink()->diagnose(
                    Diagnostics::ZeroWidthBitFieldUnsupportedInMsvcPacking{.location = bfm->loc});
            }
            finishBitfieldGroup();
        }

        // Some packing rules start a new backing field if the declared type size changes.
        if (bitfieldPackingOptions.shouldStartNewBitfieldStorageOnTypeSizeChange &&
            groupInfo.getCount() > 0 && thisFieldTypeWidth != previousFieldTypeWidth)
        {
            finishBitfieldGroup();
        }

        // If this member would not fit in the current backing integer, finish the group first.
        if (totalWidth + thisFieldWidth > std::max(thisFieldTypeWidth, backingWidth))
            finishBitfieldGroup();

        // The backing integer must fit the widest declared type in the group, while totalWidth
        // records how many of its bits the bitfields use.
        backingWidth = std::max(thisFieldTypeWidth, backingWidth);
        totalWidth += int(thisFieldWidth);
        groupInfo.add({memberIndex, int(thisFieldWidth), t, bfm});

        previousFieldTypeWidth = thisFieldTypeWidth;
    }
    // Finish any bitfield group still open after the last member.
    finishBitfieldGroup();
}

void SemanticsDeclDifferentialAttributesVisitor::visitFunctionDeclBase(FunctionDeclBase* decl)
{
    // Run checking on attributes that can't be fully checked in header checking stage.
    for (auto attr : decl->modifiers)
    {
        if (auto fwdDerivativeOfAttr = as<ForwardDerivativeOfAttribute>(attr))
            checkForwardDerivativeOfAttribute(decl, fwdDerivativeOfAttr);
        else if (auto bwdDerivativeOfAttr = as<BackwardDerivativeOfAttribute>(attr))
            checkBackwardDerivativeOfAttribute(decl, bwdDerivativeOfAttr);
        else if (auto primalOfAttr = as<PrimalSubstituteOfAttribute>(attr))
            checkPrimalSubstituteOfAttribute(decl, primalOfAttr);
        else if (auto fwdDerivativeAttr = as<ForwardDerivativeAttribute>(attr))
            checkDerivativeAttribute(this, decl, fwdDerivativeAttr);
        else if (auto bwdDerivativeAttr = as<BackwardDerivativeAttribute>(attr))
            checkDerivativeAttribute(this, decl, bwdDerivativeAttr);
        else if (auto primalAttr = as<PrimalSubstituteAttribute>(attr))
            checkDerivativeAttribute(this, decl, primalAttr);
        else if (auto cudaKernelAttr = as<CudaKernelAttribute>(attr))
            checkCudaKernelAttribute(this, decl, cudaKernelAttr);
    }
}

static void _propagateSeeDefinitionOf(
    SemanticsVisitor* visitor,
    Decl* funcDecl,
    DiagnosticCategory diagnosticCategory)
{
    maybeDiagnose(
        visitor->getSink(),
        visitor->getOptionSet(),
        diagnosticCategory,
        Diagnostics::SeeDefinitionOf{.decl = funcDecl});
}

static void _propagateRequirement(
    SemanticsVisitor* visitor,
    CapabilitySet& resultCaps,
    SyntaxNode* userNode,
    SyntaxNode* referencedNode,
    const CapabilitySetVal* nodeCaps,
    SourceLoc referenceLoc)
{
    auto referencedDecl = as<Decl>(referencedNode);

    // Ignore cyclic references.
    if (referencedDecl)
    {
        if (referencedDecl->checkState.isBeingChecked())
            return;

        ensureDecl(visitor, referencedDecl, DeclCheckState::CapabilityChecked);
    }

    // If we do not have the same target+stage, we need to `join` to remove excess target+stage.
    //
    // If we have the same target+stage but current capabilities do not imply incoming capabilities,
    // we need to `join`.
    if (!resultCaps.joinWithOtherWillChangeThis(CapabilitySet{nodeCaps}))
        return;

    auto oldCaps = resultCaps;
    bool isAnyInvalid = resultCaps.isInvalid() || (nodeCaps && nodeCaps->isInvalid());
    resultCaps.join(nodeCaps);

    auto decl = as<Decl>(userNode);

    if (!isAnyInvalid && resultCaps.isInvalid())
    {
        // If joining the referenced decl's requirements results an invalid capability set,
        // then the decl is using things that require conflicting set of capabilities, and we
        // should diagnose an error.
        if (referencedDecl && decl)
        {
            StringBuilder nodeCapsSb, oldCapsSb;
            printDiagnosticArg(nodeCapsSb, nodeCaps);
            printDiagnosticArg(oldCapsSb, oldCaps);
            maybeDiagnose(
                visitor->getSink(),
                visitor->getOptionSet(),
                DiagnosticCategory::Capability,
                Diagnostics::ConflictingCapabilityDueToUseOfDecl{
                    .referencedDecl = referencedDecl,
                    .requiredCaps = nodeCapsSb.produceString(),
                    .contextDecl = decl,
                    .existingCaps = oldCapsSb.produceString(),
                    .location = referenceLoc});
        }
        else if (decl)
        {
            StringBuilder nodeCapsSb, oldCapsSb;
            printDiagnosticArg(nodeCapsSb, nodeCaps);
            printDiagnosticArg(oldCapsSb, oldCaps);
            maybeDiagnose(
                visitor->getSink(),
                visitor->getOptionSet(),
                DiagnosticCategory::Capability,
                Diagnostics::ConflictingCapabilityDueToStatement{
                    .requiredCaps = nodeCapsSb.produceString(),
                    .context = ASTPrinter::getDeclSignatureString(decl, visitor->getASTBuilder()),
                    .existingCaps = oldCapsSb.produceString(),
                    .location = referenceLoc});
        }
        else
        {
            StringBuilder nodeCapsSb, oldCapsSb;
            printDiagnosticArg(nodeCapsSb, nodeCaps);
            printDiagnosticArg(oldCapsSb, oldCaps);
            maybeDiagnose(
                visitor->getSink(),
                visitor->getOptionSet(),
                DiagnosticCategory::Capability,
                Diagnostics::ConflictingCapabilityDueToStatementEnclosingFunc{
                    .requiredCaps = nodeCapsSb.produceString(),
                    .existingCaps = oldCapsSb.produceString(),
                    .location = referenceLoc});
        }
    }

    // if stmt inside parent, set the provenance tracker to the calling function
    if (!decl)
        decl = visitor->getParentFuncOfVisitor();
    if (referencedNode && decl)
    {
        // Here we store a childDecl that added/removed capabilities from a parentDecl
        decl->capabilityRequirementProvenance.add(
            ProvenenceNodeWithLoc{referencedNode, referenceLoc});
    }
};

CapabilitySet getStatementCapabilityUsage(SemanticsVisitor* visitor, Stmt* stmt);

// Return the function declaration that `expr` ultimately references, peeling off the
// syntactic wrappers that can sit between the surface reference and the underlying
// `DeclRefExpr`. Two families of wrapper matter here:
//   * generic application / higher-order invoke — e.g. `[BackwardDerivative(testCBwd<float>)]`
//     stores a `GenericAppExpr`, and a `fwd_diff(fn)` / `bwd_diff(fn)` operand is a
//     `HigherOrderInvokeExpr`;
//   * the base of a checked `primal.fwd_diff` / `primal.bwd_diff` member reference — after
//     checking, that base is a `SharedTypeExpr` (the function-as-type) that may wrap a
//     `CastToSuperTypeExpr` (cast to the `IForwardDifferentiable` / `IBackwardDifferentiable`
//     interface) around the original `primal` reference, possibly parenthesized.
// Returns null when the peeled expression is not a direct function reference.
static FunctionDeclBase* _getFuncDeclFromExpr(Expr* expr)
{
    for (;;)
    {
        if (auto genericApp = as<GenericAppExpr>(expr))
            expr = genericApp->functionExpr;
        else if (auto higherOrder = as<HigherOrderInvokeExpr>(expr))
            expr = higherOrder->baseFunction;
        else if (auto castToSuper = as<CastToSuperTypeExpr>(expr))
            expr = castToSuper->valueArg;
        else if (auto sharedType = as<SharedTypeExpr>(expr))
            expr = sharedType->base.exp;
        else if (auto paren = as<ParenExpr>(expr))
            expr = paren->base;
        else
            break;
    }
    if (auto declRefExpr = as<DeclRefExpr>(expr))
        return as<FunctionDeclBase>(declRefExpr->declRef.getDecl());
    return nullptr;
}

// A `[ForwardDerivative(fn)]` / `[BackwardDerivative(fn)]` attribute references a
// user-defined derivative function `fn` that is not part of the decorated function's
// body. Resolve the referenced function decl from the (already checked) attribute
// `funcExpr` so a caller can propagate its capability requirements.
static FunctionDeclBase* _getUserDefinedDerivativeFuncDecl(UserDefinedDerivativeAttribute* attr)
{
    return _getFuncDeclFromExpr(attr->funcExpr);
}

template<typename ProcessFunc, typename ParentDiagnosticFunc>
struct CapabilityDeclReferenceVisitor
    : public SemanticsDeclReferenceVisitor<
          CapabilityDeclReferenceVisitor<ProcessFunc, ParentDiagnosticFunc>>
{
    typedef SemanticsDeclReferenceVisitor<
        CapabilityDeclReferenceVisitor<ProcessFunc, ParentDiagnosticFunc>>
        Base;

    const ProcessFunc handleProcessFunc;
    const ParentDiagnosticFunc handleParentDiagnosticFunc;
    RequireCapabilityAttribute* maybeRequireCapability;
    SemanticsContext& outerContext;
    CapabilityDeclReferenceVisitor(
        const ProcessFunc& processFunc,
        const ParentDiagnosticFunc& parentDiagnosticFunc,
        RequireCapabilityAttribute* maybeRequireCapability,
        SemanticsContext& outer)
        : handleProcessFunc(processFunc)
        , handleParentDiagnosticFunc(parentDiagnosticFunc)
        , maybeRequireCapability(maybeRequireCapability)
        , outerContext(outer)
        , SemanticsDeclReferenceVisitor<
              CapabilityDeclReferenceVisitor<ProcessFunc, ParentDiagnosticFunc>>(outer)
    {
    }
    virtual void processReferencedDecl(Decl* decl) override
    {
        SourceLoc loc = SourceLoc();
        if (Base::sourceLocStack.getCount())
            loc = Base::sourceLocStack.getLast();
        handleProcessFunc(decl, decl->inferredCapabilityRequirements, loc);
    }
    virtual void processDeclModifiers(Decl* decl, SourceLoc refLoc) override
    {
        if (decl)
            handleProcessFunc(decl, decl->inferredCapabilityRequirements, refLoc);
    }
    // Join a user-defined derivative's capability requirements into the differentiating
    // function, gated on the derivative carrying an explicit `[require]`. The gate is
    // essential rather than cosmetic: the core module differentiates its own builtins
    // (e.g. `fwd_diff(__length_impl)` in diff.meta.slang), and those derivative families
    // carry no `[require]`, so joining their inferred requirements onto a builtin during
    // core-module compilation would over-constrain it. Restricting propagation to an
    // explicit `[require]` keeps deliberate user declarations only (see issue #11551).
    void propagateUserDefinedDerivativeRequirement(Decl* derivativeFuncDecl)
    {
        if (!derivativeFuncDecl->findModifier<RequireCapabilityAttribute>())
            return;
        this->ensureDecl(derivativeFuncDecl, DeclCheckState::CapabilityChecked);
        // Point the provenance note at the derivative function's name, which is where the
        // user declared both the `[require]` and the derivative linkage. The `see-using-of`
        // note pairs the decl name with this location, so use the identifier location
        // (`getNameLoc()`) for a stable caret rather than `Decl::loc`, which is not
        // guaranteed to sit on the identifier. Fall back to `loc` if the name has no
        // location.
        SourceLoc provenanceLoc = derivativeFuncDecl->getNameLoc();
        if (!provenanceLoc.isValid())
            provenanceLoc = derivativeFuncDecl->loc;
        handleProcessFunc(
            derivativeFuncDecl,
            derivativeFuncDecl->inferredCapabilityRequirements,
            provenanceLoc);
    }
    // Propagate the `[require]` capability requirements of `primalFuncDecl`'s user-defined
    // forward (`wantForward == true`) or backward (`wantForward == false`) derivative onto
    // the current differentiating function. Both derivative placements are handled and
    // matched by direction: the forward placement (`[ForwardDerivative]` /
    // `[BackwardDerivative]` modifier on the primal) and the inverse placement
    // (`[ForwardDerivativeOf]` / `[BackwardDerivativeOf]` on the derivative, recorded as a
    // derivative association on the primal). `fwd_diff` pulls only the forward derivative,
    // `bwd_diff` only the backward one.
    void propagateDerivativesOfPrimal(FunctionDeclBase* primalFuncDecl, bool wantForward)
    {
        if (!primalFuncDecl)
            return;
        DeclAssociationKind wantAssociationKind = wantForward
                                                      ? DeclAssociationKind::ForwardDerivativeFunc
                                                      : DeclAssociationKind::BackwardDerivativeFunc;

        // Forward placement: `[ForwardDerivative]` / `[BackwardDerivative]` on the primal.
        for (auto attr : primalFuncDecl->getModifiersOfType<UserDefinedDerivativeAttribute>())
        {
            bool isForwardAttr = as<ForwardDerivativeAttribute>(attr) != nullptr;
            if (isForwardAttr != wantForward)
                continue;
            if (auto derivativeFuncDecl = _getUserDefinedDerivativeFuncDecl(attr))
                propagateUserDefinedDerivativeRequirement(derivativeFuncDecl);
        }

        // Inverse placement: `[ForwardDerivativeOf]` / `[BackwardDerivativeOf]` on the
        // derivative, recorded as an association on the primal.
        for (auto assoc : this->getShared()->getAssociatedDeclsForDecl(primalFuncDecl))
        {
            if (assoc->kind != wantAssociationKind)
                continue;
            propagateUserDefinedDerivativeRequirement(assoc->decl);
        }
    }
    // Recognize a checked differentiation use-site of the form `primal.fwd_diff` /
    // `primal.bwd_diff` and propagate the primal's user-defined derivative requirement.
    //
    // A `fwd_diff(primal)` / `bwd_diff(primal)` operator materializes the primal's
    // user-defined derivative only when the primal is actually *differentiated*, so its
    // `[require]` capability requirements belong at the differentiation use-site rather than
    // on the primal (issue #11859: a plain `testC(2.0)` must compile even when `testC` has a
    // `[require(spirv)]` backward derivative, whereas `bwd_diff(testC)` on an incompatible
    // target must still error — issue #11551). Semantic checking rewrites an *invoked*
    // `bwd_diff(fn)(args)` into a member reference `fn.bwd_diff` (see
    // `convertHigherOrderExprToLookup` in slang-check-expr.cpp), so by capability-check time
    // the use-site is a member access whose member is the `fwd_diff` / `bwd_diff` associated
    // function of the built-in `IForwardDifferentiable` / `IBackwardDifferentiable` interface,
    // and whose base is the primal. `memberDecl` is that member; `baseExpr` is the primal.
    //
    // The `fwd_diff` / `bwd_diff` members are matched by name. The interface requirement decls
    // (core.meta.slang) carry a `BuiltinRequirementModifier`, but a checked use-site resolves
    // to the *satisfying* member on the concrete function type, which does not carry that
    // modifier; the member name is the stable signal. This cannot collide with a user
    // declaration, because these members live only on the built-in function-type interfaces
    // (users cannot add members to a function type), and `_getFuncDeclFromExpr` further
    // requires the base to resolve to a function — a non-differentiation member access named
    // `fwd_diff` / `bwd_diff` on some other type would yield a null primal and no-op here.
    void maybePropagateForDiffMember(Decl* memberDecl, Expr* baseExpr)
    {
        if (!memberDecl || !memberDecl->getName())
            return;
        auto name = memberDecl->getName()->text.getUnownedSlice();
        bool wantForward;
        if (name == UnownedStringSlice("fwd_diff"))
            wantForward = true;
        else if (name == UnownedStringSlice("bwd_diff"))
            wantForward = false;
        else
            return;
        propagateDerivativesOfPrimal(_getFuncDeclFromExpr(baseExpr), wantForward);
    }
    void visitStaticMemberExpr(StaticMemberExpr* expr)
    {
        Base::visitStaticMemberExpr(expr);
        maybePropagateForDiffMember(expr->declRef.getDecl(), expr->baseExpression);
    }
    void visitMemberExpr(MemberExpr* expr)
    {
        Base::visitMemberExpr(expr);
        maybePropagateForDiffMember(expr->declRef.getDecl(), expr->baseExpression);
    }
    // A `fwd_diff(primal)` / `bwd_diff(primal)` that survives semantic checking as a
    // `HigherOrderInvokeExpr` — a bare (non-invoked) operator, or an invoked form that was not
    // rewritten to a `primal.fwd_diff` member reference (see `maybePropagateForDiffMember` for
    // the rewritten form). Both hook paths are exercised in practice and funnel into
    // `propagateDerivativesOfPrimal`.
    void visitHigherOrderInvokeExpr(HigherOrderInvokeExpr* expr)
    {
        // Preserve the base behavior: the primal itself is referenced by the diff use.
        this->dispatchIfNotNull(expr->baseFunction);

        bool wantForward;
        if (as<ForwardDifferentiateExpr>(expr))
            wantForward = true;
        else if (as<BackwardDifferentiateExpr>(expr))
            wantForward = false;
        else
            return; // Other higher-order invokes do not materialize a user-defined derivative.

        propagateDerivativesOfPrimal(_getFuncDeclFromExpr(expr->baseFunction), wantForward);
    }
    void visitDiscardStmt(DiscardStmt* stmt)
    {
        // this-> here because the clang lsp chokes otherwise
        handleProcessFunc(
            stmt,
            this->getASTBuilder()->getCapabilitySetVal(CapabilityName::fragment),
            stmt->loc);
    }
    void visitAddressOfExpr(AddressOfExpr* expr)
    {
        // __getAddress only works with certain targets
        handleProcessFunc(
            expr,
            this->getASTBuilder()->getCapabilitySetVal(CapabilityName::cpp_cuda_metal_spirv_llvm),
            expr->loc);
        this->dispatchIfNotNull(expr->arg);
    }
    void visitTargetSwitchStmt(TargetSwitchStmt* stmt)
    {
        CapabilitySet set;
        auto targetCaseCount = stmt->targetCases.getCount();
        bool isStageSwitch = as<StageSwitchStmt>(stmt) != nullptr;

        for (Index targetCaseIndex = 0; targetCaseIndex < targetCaseCount; targetCaseIndex++)
        {
            // The logic here is to collect a list of `case` statment capabilities
            // so that down-the-line we can specialize according to the compile-capabilities.
            //
            // The additional goal we have is to merge all case-capabilities into 1 set
            // so that we can propegate them to the parent-function so that a user may break-down
            // a functon into `stage`/`target` specific code.
            //
            // A few important details
            // 1. Case statments (other than `default:`) may have overlapping capabilities. This is
            // to allow "more specialized" `case` statments to support specializing code on
            // higher-feature-levels to support writing 1 function to handle cases such as sm_5_0
            // and sm_6_0 support all in 1 function.
            //
            // 2. All `case:` statments are explicit with their own-capabilities, `default:`
            // statments are not. `default:` statments have the value `CapabilityName::Invalid`. If
            // we find a `default` statment we assign it all shader target/stage capabilities that
            // the other `case` statments did not specify which is legal for the current calling
            // function (based on the parent function `require` decl).
            CapabilitySet targetCap;
            if (CapabilityName(stmt->targetCases[targetCaseIndex]->capability) ==
                CapabilityName::Invalid)
            {
                // swap the `default` case to the end so that we process it last
                if (targetCaseCount - 1 != targetCaseIndex)
                {
                    for (Index i = targetCaseIndex; i < targetCaseCount - 1; i++)
                        std::swap(stmt->targetCases[i], stmt->targetCases[i + 1]);
                    continue;
                }
                if (as<StageSwitchStmt>(stmt))
                {
                    if (!maybeRequireCapability || !maybeRequireCapability->capabilitySet)
                        targetCap = (CapabilitySet(CapabilityName::any_target)
                                         .getStagesThisHasButOtherDoesNot(set));
                    else
                        targetCap =
                            (maybeRequireCapability->capabilitySet->getStagesThisHasButOtherDoesNot(
                                set));
                }
                else
                {
                    if (!maybeRequireCapability || !maybeRequireCapability->capabilitySet)
                        targetCap = (CapabilitySet(CapabilityName::any_target)
                                         .getTargetsThisHasButOtherDoesNot(set));
                    else
                        targetCap = (maybeRequireCapability->capabilitySet
                                         ->getTargetsThisHasButOtherDoesNot(set));
                }
            }
            else
            {
                targetCap =
                    CapabilitySet(CapabilityName(stmt->targetCases[targetCaseIndex]->capability));

                if (maybeRequireCapability)
                {
                    CapabilitySet testingForInvalid{maybeRequireCapability->capabilitySet};
                    // Ensure case statement is valid with parent `[require(...)]`
                    testingForInvalid.join(targetCap);
                    if (testingForInvalid.isInvalid())
                    {
                        StringBuilder targetCapSb, reqCapSb;
                        printDiagnosticArg(targetCapSb, targetCap);
                        printDiagnosticArg(
                            reqCapSb,
                            CapabilitySet{maybeRequireCapability->capabilitySet});
                        maybeDiagnose(
                            Base::getSink(),
                            outerContext.getOptionSet(),
                            DiagnosticCategory::Capability,
                            Diagnostics::ConflictingCapabilityDueToStatement{
                                .requiredCaps = targetCapSb.produceString(),
                                .context = String("[require] attribute"),
                                .existingCaps = reqCapSb.produceString(),
                                .location = stmt->targetCases[targetCaseIndex]->loc});
                        handleParentDiagnosticFunc(DiagnosticCategory::Capability);
                    }
                }
            }
            auto targetCase = stmt->targetCases[targetCaseIndex];
            auto oldCap = targetCap;
            auto bodyCap = getStatementCapabilityUsage(this, targetCase->body);
            targetCap.join(bodyCap);
            if (targetCap.isInvalid())
            {
                StringBuilder bodyCapSb, oldCapSb;
                printDiagnosticArg(bodyCapSb, bodyCap);
                printDiagnosticArg(oldCapSb, oldCap);
                maybeDiagnose(
                    Base::getSink(),
                    outerContext.getOptionSet(),
                    DiagnosticCategory::Capability,
                    Diagnostics::ConflictingCapabilityDueToStatement{
                        .requiredCaps = bodyCapSb.produceString(),
                        .context = "target_switch",
                        .existingCaps = oldCapSb.produceString(),
                        .location = targetCase->body->loc});
                handleParentDiagnosticFunc(DiagnosticCategory::Capability);
            }

            // Merge the capability set represent by this case into the overall set, depending on
            // this is a target-switch or stage-switch, we have different granuarity on how to merge
            // things. The CapabilitySet is a two level table:
            //
            //                  CapabilitySet
            //        +--------------+--------------+              (level 1)
            //      target1       target2       ... targetN
            //              +---------+---------+                  (level 2)
            //          stage1       stage2 ... stageN
            //
            // and each stage is a bit mask of capabilities. If this is a target-switch, then we
            // treat each target set as a large bit mask, and merge two target set entry. If this
            // is a stage-switch, then we treat each stage set as small bit mask, and merge two
            // stage set entry. Therefore `isStageSwitch` flag is used to indicate which merging
            // strategy to use.
            mergeNewCapability(
                set,
                targetCap,
                targetCase->loc,
                CapabilityName(targetCase->capability),
                isStageSwitch);
        }
        handleProcessFunc(stmt, set.freeze(this->getASTBuilder()), stmt->loc);
    }

    void visitRequireCapabilityDecl(RequireCapabilityDecl* decl)
    {
        handleProcessFunc(decl, decl->inferredCapabilityRequirements, decl->loc);
    }

private:
    void mergeNewCapability(
        CapabilitySet& currentSet,
        CapabilitySet& newSet,
        SourceLoc loc,
        CapabilityName caseName,
        bool isStageSwitch)
    {
        bool result = true;
        if (isStageSwitch)
        {
            // If this is stage-switch, we need to perform a more fine-grained merge
            for (auto target : newSet.getCapabilityTargetSets())
            {
                for (auto stage : target.second.getShaderStageSets())
                {
                    result &= currentSet.compatibleMerge(target.first, stage.second);
                    if (!result)
                        break;
                }
                if (!result)
                    break;
            }
        }
        else
        {
            // If this is target-switch, we can just merge the whole target set
            for (auto target : newSet.getCapabilityTargetSets())
            {
                result &= currentSet.compatibleMerge(target.second);
                if (!result)
                    break;
            }
        }

        if (!result)
        {
            StringBuilder newSetSb, currentSetSb;
            printDiagnosticArg(newSetSb, newSet);
            printDiagnosticArg(currentSetSb, currentSet);
            maybeDiagnose(
                Base::getSink(),
                outerContext.getOptionSet(),
                DiagnosticCategory::Capability,
                Diagnostics::TargetSwitchCapCasesConflict{
                    .caseName = capabilityNameToString(caseName),
                    .caseCaps = newSetSb.produceString(),
                    .prevCaps = currentSetSb.produceString(),
                    .location = loc});
        }
    }
};

template<typename ProcessFunc, typename ParentDiagnosticFunc>
void visitReferencedDecls(
    SemanticsContext& context,
    NodeBase* node,
    SourceLoc initialLoc,
    RequireCapabilityAttribute* maybeRequireCapability,
    const ProcessFunc& processFunc,
    const ParentDiagnosticFunc& parentDiagnosticFunc)
{
    CapabilityDeclReferenceVisitor<ProcessFunc, ParentDiagnosticFunc> visitor(
        processFunc,
        parentDiagnosticFunc,
        maybeRequireCapability,
        context);
    visitor.sourceLocStack.add(initialLoc);

    if (auto val = as<Val>(node))
        visitor.dispatchIfNotNull(val);
    if (auto stmt = as<Stmt>(node))
        visitor.dispatchIfNotNull(stmt);
    if (auto expr = as<Expr>(node))
        visitor.dispatchIfNotNull(expr);
    if (auto decl = as<Decl>(node))
        visitor.dispatchIfNotNull(decl);
}

CapabilitySet getDeclRefCapabilityRequirements(
    SemanticsVisitor* visitor,
    DeclRef<Decl> declRef,
    List<Decl*>& outReferencedDecls)
{
    // Consider this example:
    //     [require(metal)] struct MetalOnly {}
    //     void main<T>() {}
    // Selecting main<MetalOnly> retains MetalOnly in the checked reference even though the body
    // never uses T. Use the ordinary reference walk so selection has the same requirements as
    // calling main<MetalOnly>() in a function body. As in visitDeclRefExpr, include the selected
    // declaration itself as well as its operands.
    CapabilitySet requirements{declRef.getDecl()->inferredCapabilityRequirements};
    visitReferencedDecls(
        *visitor,
        declRef.declRefBase,
        declRef.getDecl()->loc,
        nullptr,
        [&](SyntaxNode* node, const CapabilitySetVal* nodeCaps, SourceLoc)
        {
            requirements.join(nodeCaps);
            if (auto decl = as<Decl>(node);
                decl && decl != declRef.getDecl() && nodeCaps && !nodeCaps->isEmpty())
                outReferencedDecls.add(decl);
        },
        [](DiagnosticCategory) {});
    return requirements;
}

CapabilitySet getStatementCapabilityUsage(SemanticsVisitor* visitor, Stmt* stmt)
{
    if (stmt == nullptr)
        return CapabilitySet{};

    CapabilitySet inferredRequirements;
    visitReferencedDecls(
        *visitor,
        stmt,
        stmt->loc,
        nullptr,
        [&](SyntaxNode* node, const CapabilitySetVal* nodeCaps, SourceLoc refLoc)
        { _propagateRequirement(visitor, inferredRequirements, stmt, node, nodeCaps, refLoc); },
        [](DiagnosticCategory category) { SLANG_UNUSED(category); });
    return inferredRequirements;
}

void SemanticsDeclCapabilityVisitor::checkVarDeclCommon(VarDeclBase* varDecl)
{
    CapabilitySet mutableCapSet{varDecl->inferredCapabilityRequirements};
    visitReferencedDecls(
        *this,
        varDecl->type.type,
        varDecl->loc,
        varDecl->findModifier<RequireCapabilityAttribute>(),
        [this,
         varDecl,
         &mutableCapSet](SyntaxNode* node, const CapabilitySetVal* nodeCaps, SourceLoc refLoc)
        { _propagateRequirement(this, mutableCapSet, varDecl, node, nodeCaps, refLoc); },
        [this, varDecl](DiagnosticCategory category)
        { _propagateSeeDefinitionOf(this, varDecl, category); });
    varDecl->inferredCapabilityRequirements = mutableCapSet.freeze(getASTBuilder());
}

CapabilitySet SemanticsDeclCapabilityVisitor::getDeclaredCapabilitySet(Decl* decl)
{
    // Merge a decls's declared capability set with all parent declarations.
    // For every existing target, we want to join their requirements together.
    // If the the parent defines additional targets, we want to add them to the disjunction set.
    // For example:
    //    [require(glsl)]
    //    struct Parent {
    //        [require(glsl, glsl_ext_1)]
    //        [require(spirv)]
    //        void foo();
    //    }
    // The requirement for `foo` should be glsl+glsl_ext_1 | spirv.
    //
    CapabilitySet declaredCaps;
    CapabilityAtom stageToJoin = CapabilityAtom::Invalid;
    for (Decl* parent = decl; parent; parent = getParentDecl(parent))
    {
        CapabilitySet localDeclaredCaps;
        bool shouldBreak = false;
        if (!as<AggTypeDeclBase>(parent) || !parent->inferredCapabilityRequirements ||
            parent->inferredCapabilityRequirements->isEmpty())
        {
            for (auto mod : parent->modifiers)
            {
                if (auto decoration = as<RequireCapabilityAttribute>(mod))
                    localDeclaredCaps.unionWith(decoration->capabilitySet);
                else if (as<Shader64BitIndexingAttribute>(mod))
                    localDeclaredCaps.unionWith(
                        CapabilitySet(CapabilityName::spvShader64BitIndexingEXT));
                else if (auto entrypoint = as<EntryPointAttribute>(mod))
                    stageToJoin = entrypoint->capabilitySet
                                      ? entrypoint->capabilitySet->getTargetStage()
                                      : CapabilityAtom::Invalid;
            }
        }
        else
        {
            shouldBreak = true;
        }
        // Merge decl's capability declaration with the parent.
        if (shouldBreak)
        {
            declaredCaps.nonDestructiveJoin(parent->inferredCapabilityRequirements);
            // If the parent already has inferred capability requirements, we should stop now
            // since that already covers transitive parents.
            break;
        }
        else
            declaredCaps.nonDestructiveJoin(localDeclaredCaps);
    }
    if (!declaredCaps.isEmpty() && stageToJoin != CapabilityAtom::Invalid)
        declaredCaps.join(CapabilitySet((CapabilityName)stageToJoin));
    return declaredCaps;
}

void SemanticsDeclCapabilityVisitor::visitContainerDecl(ContainerDecl* decl)
{
    // Any potential child must get it's capabilities from `getDeclaredCapabilitySet`.
    decl->inferredCapabilityRequirements = getDeclaredCapabilitySet(decl).freeze(getASTBuilder());
}

void SemanticsDeclCapabilityVisitor::visitExtensionDecl(ExtensionDecl* extensionDecl)
{
    // Set up the extension's own inferred capabilities from its [require(...)] attributes,
    // the same as any other container decl.
    visitContainerDecl(extensionDecl);

    // If the extension has no explicit capability requirements, there is nothing to validate
    // at the extension level. Member functions and constructors with their own [require(...)]
    // attributes are validated individually in visitFunctionDeclBase; subscripts and properties
    // are validated in visitSubscriptDecl and visitPropertyDecl via
    // _checkExtensionMemberCapConflict.
    if (!extensionDecl->inferredCapabilityRequirements ||
        extensionDecl->inferredCapabilityRequirements->isEmpty())
        return;

    // An extension can only be used where its target type is available. Therefore the
    // capabilities declared on the extension must be compatible with (i.e. have a non-empty
    // intersection with) the target type's capabilities. We use _propagateRequirement to
    // detect conflicts: it emits a diagnostic when the intersection of the extension's caps
    // and the target's caps is empty (i.e. no shared target/stage survives the join).
    //
    // Note: this is a non-empty-intersection check, not a strict subset check. An extension
    // may declare caps that are a superset of or overlap with the target's caps — the check
    // only fires when the two are disjoint. For example, [require(hlsl)][require(glsl)]
    // extension on a [require(hlsl)] type passes silently because the intersection {hlsl}
    // is non-empty. If strict subset semantics are ever desired, the check here and in
    // _checkExtensionMemberCapConflict would need to be replaced with an explicit subset test.
    //
    // We deliberately do NOT write back to extensionDecl->inferredCapabilityRequirements
    // here: doing so would alter how getDeclaredCapabilitySet walks the parent chain for
    // child declarations and would produce false positives in code where extension members
    // legitimately target a narrower subset of the target type's platforms (e.g. a member
    // [require(hlsl)] on a [require(glsl)][require(hlsl)] extension is valid).
    auto targetDeclRefType = as<DeclRefType>(extensionDecl->targetType.type);
    if (!targetDeclRefType)
        return;

    auto targetTypeDecl = targetDeclRefType->getDeclRef().getDecl();
    if (!targetTypeDecl)
        return;

    // We must call ensureDecl before the _propagateRequirement call below because
    // targetTypeDecl->inferredCapabilityRequirements is evaluated as a C++ argument
    // expression at the call site, before _propagateRequirement runs its own ensureDecl.
    // Without this pre-call the field can still be null/stale, and _propagateRequirement
    // tolerates null nodeCaps by no-opping — the conflict check would silently be skipped.
    // Genuine cycles are diagnosed inside ensureDecl itself (Diagnostics::CyclicReference),
    // so we do not need a separate guard here.
    ensureDecl(targetTypeDecl, DeclCheckState::CapabilityChecked);

    CapabilitySet checkCapSet{extensionDecl->inferredCapabilityRequirements};
    _propagateRequirement(
        this,
        checkCapSet,
        extensionDecl,
        targetTypeDecl,
        targetTypeDecl->inferredCapabilityRequirements,
        extensionDecl->loc);
}

void SemanticsDeclCapabilityVisitor::visitFunctionDeclBase(FunctionDeclBase* funcDecl)
{
    setParentFuncOfVisitor(funcDecl);

    CapabilitySet mutableFuncDeclCapSet{funcDecl->inferredCapabilityRequirements};
    // visit the members of our funcDecl
    for (auto member : funcDecl->getDirectMemberDecls())
    {
        ensureDecl(member, DeclCheckState::CapabilityChecked);
        _propagateRequirement(
            this,
            mutableFuncDeclCapSet,
            funcDecl,
            member,
            member->inferredCapabilityRequirements,
            member->loc);
    }

    // visit the body of our funcDecl, propagate capabilities.
    visitReferencedDecls(
        *this,
        funcDecl->body,
        funcDecl->loc,
        funcDecl->findModifier<RequireCapabilityAttribute>(),
        [this, funcDecl, &mutableFuncDeclCapSet](
            SyntaxNode* node,
            const CapabilitySetVal* nodeCaps,
            SourceLoc refLoc)
        { _propagateRequirement(this, mutableFuncDeclCapSet, funcDecl, node, nodeCaps, refLoc); },
        [this, funcDecl](DiagnosticCategory category)
        { _propagateSeeDefinitionOf(this, funcDecl, category); });

    // A user-defined forward/backward derivative is invoked only when the primal is
    // *differentiated* (`fwd_diff` / `bwd_diff`), not on every call to the primal.
    // Its `[require]` capability requirements are therefore propagated at the
    // differentiation use-site — see `CapabilityDeclReferenceVisitor::
    // visitHigherOrderInvokeExpr` above — rather than onto the primal here, so a plain
    // non-differentiated call to the primal is not over-constrained (issues #11551 and
    // #11859).

    // non-static function join's capabilities with parent
    // to become a superset of the parent.
    if (!isEffectivelyStatic(funcDecl))
    {
        auto parentAggTypeDecl = getParentAggTypeDecl(funcDecl);
        if (parentAggTypeDecl)
        {
            ensureDecl(parentAggTypeDecl, DeclCheckState::CapabilityChecked);

            _propagateRequirement(
                this,
                mutableFuncDeclCapSet,
                funcDecl,
                parentAggTypeDecl,
                parentAggTypeDecl->inferredCapabilityRequirements,
                funcDecl->loc);
        }
    }

    funcDecl->inferredCapabilityRequirements = mutableFuncDeclCapSet.freeze(getASTBuilder());

    // Get require of decl + add parents
    auto declaredCaps = getDeclaredCapabilitySet(funcDecl);

    // If 0 capabilities were annotated on this function,
    // keep the capabilities inferred from the children.
    if (declaredCaps.isEmpty())
    {
        funcDecl->inferredCapabilityRequirements = mutableFuncDeclCapSet.freeze(getASTBuilder());
    }
    else
    {
        auto vis = getDeclVisibility(funcDecl);
        const auto frozenDeclaredCaps = declaredCaps.freeze(getASTBuilder());
        auto declaredCapModifier = m_astBuilder->create<ExplicitlyDeclaredCapabilityModifier>();
        declaredCapModifier->declaredCapabilityRequirements = frozenDeclaredCaps;
        addModifier(funcDecl, declaredCapModifier);
        if (vis == DeclVisibility::Public)
        {
            // We need to enforce that the function-body
            // only uses capabilities that the function-decl declares.
            //
            // A small exception to this rule is that the body must
            // implement all shader stages/targets of the functionDecl
            // requirements. The body can support *more* stages/targets,
            // these will just be not accessible (which is fine since a user
            // may only need hlsl support for a function, using an STD-LIB function
            // implemented for all targets/stages).
            CapabilityAtomSet failedAvailableCapabilityConjunction;
            CheckCapabilityRequirementResult checkCapabilityResult;
            CapabilitySet::checkCapabilityRequirement(
                CheckCapabilityRequirementOptions::AvailableCanHaveSubsetOfAbstractAtoms,
                declaredCaps,
                CapabilitySet{funcDecl->inferredCapabilityRequirements},
                failedAvailableCapabilityConjunction,
                checkCapabilityResult);
            diagnoseUndeclaredCapability(
                funcDecl,
                UndeclaredCapabilityDiagnosticKind::UseOfUndeclaredCapability,
                failedAvailableCapabilityConjunction,
                true);

            // declared capabilities must be a superset.
            funcDecl->inferredCapabilityRequirements = frozenDeclaredCaps;
        }
        else
        {
            // For internal decls, their inferred capability should be joined
            // with the declared capabilities since we are assuming the stdlib
            // is not wrong.
            funcDecl->inferredCapabilityRequirements =
                CapabilitySet{funcDecl->inferredCapabilityRequirements}
                    .join(declaredCaps)
                    .freeze(getASTBuilder());
        }
    }

    // See _checkExtensionMemberCapConflict for the rationale behind checking
    // only own [require(...)] attributes here.
    //
    // Constructors are also checked despite isEffectivelyStatic returning true for
    // them: a [require(hlsl)] __init inside a [require(glsl)] extension target is
    // a genuine conflict even though there is no implicit `this` pointer.
    if (!isEffectivelyStatic(funcDecl) || as<ConstructorDecl>(funcDecl))
        _checkExtensionMemberCapConflict(funcDecl);
}

// Verify that a callable extension member's own [require(...)] attributes are
// compatible with the extension's target type capabilities.
//
// We check only the member's own [require(...)] attributes rather than the
// full declaredCaps (which includes caps inherited from the parent extension)
// for two reasons:
//  1. Avoids cascading errors: when the extension itself has an incompatible
//     [require(X)] (already caught by visitExtensionDecl), members that inherit
//     X should not also generate errors — fixing the extension fixes them too.
//  2. Catches a case that full declaredCaps misses: if an extension has a
//     compatible [require(glsl)] and a member adds its own [require(hlsl)],
//     declaredCaps would be {hlsl|glsl} and joining that with {glsl} gives the
//     valid {glsl}, hiding the conflict. Using just {hlsl} detects it.
void SemanticsDeclCapabilityVisitor::_checkExtensionMemberCapConflict(Decl* memberDecl)
{
    CapabilitySet ownDeclaredCaps;
    for (auto mod : memberDecl->modifiers)
    {
        if (auto req = as<RequireCapabilityAttribute>(mod))
            ownDeclaredCaps.unionWith(req->capabilitySet);
    }
    if (ownDeclaredCaps.isEmpty())
        return;

    // Walk up to find an enclosing ExtensionDecl, but stop at any AggTypeDeclBase:
    // a member that lives inside a nested struct/class inside the extension belongs to
    // that nested type, not to the extension target, and must not be checked here.
    // SubscriptDecl, PropertyDecl, and GenericDecl are transparent wrappers that we
    // skip past (e.g. an accessor's parent is the subscript, which lives in the extension).
    auto parentDecl = memberDecl->parentDecl;
    while (parentDecl && !as<ExtensionDecl>(parentDecl))
    {
        if (as<AggTypeDeclBase>(parentDecl))
            return;
        parentDecl = parentDecl->parentDecl;
    }
    auto extensionDecl = as<ExtensionDecl>(parentDecl);
    if (!extensionDecl)
        return;

    auto targetDeclRefType = as<DeclRefType>(extensionDecl->targetType.type);
    if (!targetDeclRefType)
        return;

    auto targetTypeDecl = targetDeclRefType->getDeclRef().getDecl();
    if (!targetTypeDecl)
        return;

    // We must call ensureDecl before the _propagateRequirement call below because
    // targetTypeDecl->inferredCapabilityRequirements is evaluated as a C++ argument
    // expression at the call site, before _propagateRequirement runs its own ensureDecl.
    // Without this pre-call the field can still be null/stale, and _propagateRequirement
    // tolerates null nodeCaps by no-opping — the conflict check would silently be skipped.
    // Genuine cycles are diagnosed inside ensureDecl itself (Diagnostics::CyclicReference),
    // so we do not need a separate guard here.
    ensureDecl(targetTypeDecl, DeclCheckState::CapabilityChecked);
    _propagateRequirement(
        this,
        ownDeclaredCaps,
        memberDecl,
        targetTypeDecl,
        targetTypeDecl->inferredCapabilityRequirements,
        memberDecl->loc);
    // Intentionally do not use ownDeclaredCaps after this: we only
    // called _propagateRequirement for its conflict-detection side-effect.
}

void SemanticsDeclCapabilityVisitor::visitSubscriptDecl(SubscriptDecl* subscriptDecl)
{
    visitContainerDecl(subscriptDecl);
    _checkExtensionMemberCapConflict(subscriptDecl);
}

void SemanticsDeclCapabilityVisitor::visitPropertyDecl(PropertyDecl* propertyDecl)
{
    visitContainerDecl(propertyDecl);
    _checkExtensionMemberCapConflict(propertyDecl);
}

void SemanticsDeclCapabilityVisitor::visitInheritanceDecl(InheritanceDecl* inheritanceDecl)
{
    auto inheritanceParentDecl = inheritanceDecl->parentDecl;
    ensureDecl(inheritanceParentDecl, DeclCheckState::CapabilityChecked);

    // Propegate capabilities of inheritance `base` to
    // `InheritanceDecl`
    CapabilitySet mutableInheritanceDeclCapSet{inheritanceDecl->inferredCapabilityRequirements};
    visitReferencedDecls(
        *this,
        inheritanceDecl->base,
        inheritanceDecl->loc,
        nullptr,
        [this, inheritanceDecl, &mutableInheritanceDeclCapSet](
            SyntaxNode* node,
            const CapabilitySetVal* nodeCaps,
            SourceLoc refLoc)
        {
            _propagateRequirement(
                this,
                mutableInheritanceDeclCapSet,
                inheritanceDecl,
                node,
                nodeCaps,
                refLoc);
        },
        [this, inheritanceDecl](DiagnosticCategory category)
        { _propagateSeeDefinitionOf(this, inheritanceDecl, category); });
    inheritanceDecl->inferredCapabilityRequirements =
        mutableInheritanceDeclCapSet.freeze(getASTBuilder());

    if (inheritanceDecl->witnessTable)
    {
        for (auto& kv : inheritanceDecl->witnessTable->m_requirementDictionary)
        {
            if (kv.value.getFlavor() != RequirementWitness::Flavor::declRef)
                continue;
            auto requirementDecl = kv.key;
            auto implDeclRef = kv.value.getDeclRef();
            if (!implDeclRef)
                continue;

            if (getModuleDecl(implDeclRef.getDecl())->languageVersion ==
                SLANG_LANGUAGE_VERSION_LEGACY)
                break;

            ensureDecl(requirementDecl, DeclCheckState::CapabilityChecked);
            ensureDecl(implDeclRef.declRefBase, DeclCheckState::CapabilityChecked);

            // Only if capabilities are opted-into, should we error.
            auto implDecl = implDeclRef.getDecl();
            if (!requirementDecl->hasModifier<ExplicitlyDeclaredCapabilityModifier>() &&
                !implDecl->hasModifier<ExplicitlyDeclaredCapabilityModifier>())
                continue;

            CapabilityAtomSet failedAvailableCapabilityConjunction;
            CheckCapabilityRequirementResult checkCapabilityResult;
            CapabilitySet::checkCapabilityRequirement(
                CheckCapabilityRequirementOptions::MustHaveEqualAbstractAtoms,
                CapabilitySet{requirementDecl->inferredCapabilityRequirements},
                CapabilitySet{implDecl->inferredCapabilityRequirements},
                failedAvailableCapabilityConjunction,
                checkCapabilityResult);

            if (checkCapabilityResult ==
                CheckCapabilityRequirementResult::AvailableIsNotASuperSetToRequired)
            {
                diagnoseUndeclaredCapability(
                    implDecl,
                    UndeclaredCapabilityDiagnosticKind::
                        UseOfUndeclaredCapabilityOfInterfaceRequirement,
                    failedAvailableCapabilityConjunction,
                    false);
                maybeDiagnose(
                    getSink(),
                    getOptionSet(),
                    DiagnosticCategory::Capability,
                    Diagnostics::SeeDeclarationOf{.decl = requirementDecl});
            }
            else if (
                checkCapabilityResult ==
                CheckCapabilityRequirementResult::RequiredIsMissingAbstractAtoms)
            {
                StringBuilder capsSb;
                printDiagnosticArg(capsSb, failedAvailableCapabilityConjunction);
                maybeDiagnose(
                    getSink(),
                    getOptionSet(),
                    DiagnosticCategory::Capability,
                    Diagnostics::RequirmentHasSubsetOfAbstractAtomsToImplementation{
                        .missingCaps = capsSb.produceString(),
                        .decl = implDecl});
                maybeDiagnose(
                    getSink(),
                    getOptionSet(),
                    DiagnosticCategory::Capability,
                    Diagnostics::SeeDeclarationOf{.decl = requirementDecl});
            }
        }
    }

    // validate that super-type is a super set of capabilities
    CapabilityAtomSet failedAvailableCapabilityConjunction;
    CheckCapabilityRequirementResult checkCapabilityResult;
    CapabilitySet::checkCapabilityRequirement(
        CheckCapabilityRequirementOptions::MustHaveEqualAbstractAtoms,
        CapabilitySet{inheritanceDecl->inferredCapabilityRequirements},
        CapabilitySet{inheritanceParentDecl->inferredCapabilityRequirements},
        failedAvailableCapabilityConjunction,
        checkCapabilityResult);

    // Get the base type decl from the inheritance clause for pointing to in diagnostics
    Decl* baseDecl = nullptr;
    if (auto baseDeclRefType = as<DeclRefType>(inheritanceDecl->base.type))
        baseDecl = baseDeclRefType->getDeclRef().getDecl();

    if (checkCapabilityResult ==
        CheckCapabilityRequirementResult::AvailableIsNotASuperSetToRequired)
    {
        diagnoseUndeclaredCapability(
            inheritanceParentDecl,
            UndeclaredCapabilityDiagnosticKind::UseOfUndeclaredCapabilityOfInheritanceDecl,
            failedAvailableCapabilityConjunction,
            false);
        // Point to the base type in the inheritance clause
        if (baseDecl)
        {
            maybeDiagnose(
                getSink(),
                getOptionSet(),
                DiagnosticCategory::Capability,
                Diagnostics::SeeDeclarationOf{.decl = baseDecl});
        }
    }
    else if (
        checkCapabilityResult == CheckCapabilityRequirementResult::RequiredIsMissingAbstractAtoms)
    {
        StringBuilder capsSb;
        printDiagnosticArg(capsSb, failedAvailableCapabilityConjunction);
        maybeDiagnose(
            getSink(),
            getOptionSet(),
            DiagnosticCategory::Capability,
            Diagnostics::SubTypeHasSubsetOfAbstractAtomsToSuperType{
                .missingCaps = capsSb.produceString(),
                .decl = inheritanceParentDecl});
        // Point to the base type in the inheritance clause
        if (baseDecl)
        {
            maybeDiagnose(
                getSink(),
                getOptionSet(),
                DiagnosticCategory::Capability,
                Diagnostics::SeeDeclarationOf{.decl = baseDecl});
        }
    }
}

DeclVisibility getDeclVisibility(Decl* decl)
{
    if (isGenericParam(decl) || as<GenericTypeConstraintDecl>(decl))
    {
        auto genericDecl = as<GenericDecl>(decl->parentDecl);
        if (!genericDecl)
            return DeclVisibility::Default;
        if (genericDecl->inner)
            return getDeclVisibility(genericDecl->inner);
        return DeclVisibility::Default;
    }
    if (auto genericDecl = as<GenericDecl>(decl))
        decl = genericDecl->inner;
    for (; decl; decl = getParentDecl(decl))
    {
        if (as<AccessorDecl>(decl))
            continue;
        if (as<EnumCaseDecl>(decl))
            continue;
        break;
    }
    if (!decl)
        return DeclVisibility::Public;

    for (auto modifier : decl->modifiers)
    {
        if (as<PublicModifier>(modifier))
            return DeclVisibility::Public;
        else if (as<InternalModifier>(modifier))
            return DeclVisibility::Internal;
        else if (as<PrivateModifier>(modifier))
            return DeclVisibility::Private;
    }
    // In Slang 2026+, an unmodified member of an aggregate inherits the aggregate's effective
    // visibility, mirroring the interface-member rule below. Keyed off effective visibility so it
    // composes transitively through nested aggregates.
    auto parentModule = getModuleDecl(decl);
    if (parentModule && parentModule->languageVersion >= SLANG_LANGUAGE_VERSION_2026)
    {
        if (auto parentAggTypeDecl = getParentAggTypeDecl(decl))
        {
            return getDeclVisibility(parentAggTypeDecl);
        }
    }
    // Interface members will always have the same visibility as the interface itself.
    if (auto interfaceDecl = findParentInterfaceDecl(decl))
    {
        return getDeclVisibility(interfaceDecl);
    }
    auto defaultVis = DeclVisibility::Default;
    if (parentModule)
    {
        defaultVis = parentModule->languageVersion == SLANG_LANGUAGE_VERSION_LEGACY
                         ? DeclVisibility::Public
                         : parentModule->defaultVisibility;
    }

    // Members of other agg type decls will have their default visibility capped to the
    // parents'.
    if (as<NamespaceDecl>(decl))
    {
        return DeclVisibility::Public;
    }
    return defaultVis;
}

VarDeclBase* getTrailingUnsizedArrayElement(
    Type* type,
    VarDeclBase* parentVar,
    ArrayExpressionType*& outArrayType)
{
    while (auto modifiedType = as<ModifiedType>(type))
        type = modifiedType->getBase();
    HashSet<Type*> seenTypes;
    for (;;)
    {
        if (auto arrayType = as<ArrayExpressionType>(type))
        {
            if (arrayType->isUnsized())
            {
                outArrayType = arrayType;
                return parentVar;
            }
            else
                return nullptr;
        }
        else if (auto declRefType = as<DeclRefType>(type))
        {
            if (auto aggTypeDecl = declRefType->getDeclRef().as<AggTypeDecl>())
            {
                auto varDecls = aggTypeDecl.getDecl()->getMembersOfType<VarDeclBase>();
                if (varDecls.getCount() == 0)
                    return nullptr;
                VarDeclBase* lastVarDecl = nullptr;
                for (auto varDecl : varDecls)
                {
                    if (isEffectivelyStatic(varDecl))
                        continue;
                    lastVarDecl = varDecl;
                }
                auto lastMember =
                    _getMemberDeclRef(getCurrentASTBuilder(), aggTypeDecl, lastVarDecl)
                        .as<VarDeclBase>();
                auto varType = getType(getCurrentASTBuilder(), lastMember);
                if (!varType)
                    return nullptr;
                if (!seenTypes.add(type))
                    return nullptr;
                type = varType;
                parentVar = lastMember.getDecl();
                continue;
            }
        }
    }
    return nullptr;
}

bool isImmutableBufferType(Type* type)
{
    if (as<UniformParameterGroupType>(type))
        return true;
    if (auto resourceType = as<ResourceType>(type))
        return resourceType->getAccess() == SLANG_RESOURCE_ACCESS_READ;
    return false;
}

bool isOpaqueHandleType(Type* type)
{
    while (auto modifiedType = as<ModifiedType>(type))
        type = modifiedType->getBase();
    if (as<ResourceType>(type))
        return true;
    if (as<SamplerStateType>(type))
        return true;
    if (as<UniformParameterGroupType>(type))
        return true;
    if (as<HLSLStructuredBufferTypeBase>(type))
        return true;
    if (as<UntypedBufferResourceType>(type))
        return true;
    if (as<GLSLShaderStorageBufferType>(type))
        return true;
    if (as<FeedbackType>(type))
        return true;
    if (as<HLSLPatchType>(type))
        return true;
    if (as<HLSLStreamOutputType>(type))
        return true;
    if (as<MeshOutputType>(type))
        return true;
    return false;
}

/// Returns true if `type` itself is an opaque handle type, or if it is a struct
/// (or array of structs) that transitively contains an opaque handle field.
/// Uses `seen` for cycle detection.
static bool _typeTransitivelyContainsOpaqueHandleImpl(
    SemanticsVisitor* visitor,
    Type* type,
    HashSet<Decl*>& seen)
{
    while (auto modifiedType = as<ModifiedType>(type))
        type = modifiedType->getBase();

    if (isOpaqueHandleType(type))
        return true;

    // Recurse into array element types.
    if (auto arrayType = as<ArrayExpressionType>(type))
        return _typeTransitivelyContainsOpaqueHandleImpl(
            visitor,
            arrayType->getElementType(),
            seen);

    // Recurse into struct fields (with substitution for generic structs).
    if (auto declRefType = as<DeclRefType>(type))
    {
        if (auto structDecl = as<StructDecl>(declRefType->getDeclRef().getDecl()))
        {
            if (!seen.add(structDecl))
                return false; // already visiting — no opaque handle found on this path
            for (auto field : structDecl->getFields())
            {
                visitor->ensureDecl(field, DeclCheckState::CanUseTypeOfValueDecl);
                auto fieldDeclRef = visitor->getASTBuilder()
                                        ->getMemberDeclRef(declRefType->getDeclRef(), field)
                                        .template as<VarDeclBase>();
                auto fieldType = fieldDeclRef ? getType(visitor->getASTBuilder(), fieldDeclRef)
                                              : field->type.type;
                if (fieldType &&
                    _typeTransitivelyContainsOpaqueHandleImpl(visitor, fieldType, seen))
                    return true;
            }
            seen.remove(structDecl);
        }
    }

    return false;
}

bool typeTransitivelyContainsOpaqueHandle(SemanticsVisitor* visitor, Type* type)
{
    HashSet<Decl*> seen;
    return _typeTransitivelyContainsOpaqueHandleImpl(visitor, type, seen);
}

bool containsRecursiveTypeImpl(SemanticsVisitor* visitor, Type* type, HashSet<Decl*>& currentPath)
{
    // Skip modified types (const, etc.)
    while (auto modifiedType = as<ModifiedType>(type))
        type = modifiedType->getBase();

    // Check if this is a StructuredBuffer type and look inside it
    if (auto structuredBufferType = as<HLSLStructuredBufferTypeBase>(type))
    {
        return containsRecursiveTypeImpl(
            visitor,
            structuredBufferType->getElementType(),
            currentPath);
    }

    // Check if this is an array type and look inside it
    if (auto arrayType = as<ArrayExpressionType>(type))
    {
        return containsRecursiveTypeImpl(visitor, arrayType->getElementType(), currentPath);
    }

    if (auto declRefType = as<DeclRefType>(type))
    {
        auto typeDecl = declRefType->getDeclRef().getDecl();

        // Check global cache first - if we've already fully analyzed this type, use that result
        auto shared = visitor->getShared();
        if (auto cachedResult = shared->m_typeContainsRecursionCache.tryGetValue(typeDecl))
        {
            return *cachedResult;
        }

        // If we're currently exploring this type, we found a cycle!
        if (currentPath.contains(typeDecl))
        {
            return true;
        }

        // Add to current exploration path
        currentPath.add(typeDecl);

        bool hasRecursion = false;

        // Check members if it's an aggregate type
        if (auto aggTypeDecl = declRefType->getDeclRef().as<AggTypeDecl>())
        {
            for (auto member : aggTypeDecl.getDecl()->getMembersOfType<VarDeclBase>())
            {
                if (isEffectivelyStatic(member))
                    continue;

                if (containsRecursiveTypeImpl(visitor, member->getType(), currentPath))
                {
                    hasRecursion = true;
                    break;
                }
            }
        }

        // Remove from current exploration path
        currentPath.remove(typeDecl);

        // Cache the result globally
        shared->m_typeContainsRecursionCache[typeDecl] = hasRecursion;

        return hasRecursion;
    }

    return false;
}

bool containsRecursiveType(SemanticsVisitor* visitor, Type* type)
{
    HashSet<Decl*> currentPath;
    return containsRecursiveTypeImpl(visitor, type, currentPath);
}

void validateStructuredBufferElementType(SemanticsVisitor* visitor, VarDeclBase* varDecl)
{
    auto type = unwrapArrayType(varDecl->getType());

    // Check if this is a StructuredBuffer type
    auto structuredBufferType = as<HLSLStructuredBufferTypeBase>(type);

    if (!structuredBufferType)
        return;

    // Get the element type
    auto elementType = structuredBufferType->getElementType();

    // Check if the element type contains recursive references
    if (containsRecursiveType(visitor, elementType))
    {
        visitor->getSink()->diagnose(Diagnostics::RecursiveTypesFoundInStructuredBuffer{
            .type = elementType,
            .location = varDecl->loc});
    }

    // Check if the element type is NonAddressable
    TypeTag elementTags = visitor->getTypeTags(elementType);
    if ((int)elementTags & (int)TypeTag::NonAddressable)
    {
        visitor->getSink()->diagnose(Diagnostics::NonAddressableTypeInStructuredBuffer{
            .type = elementType,
            .location = varDecl->loc});
    }
}

void diagnoseMissingCapabilityProvenance(
    CompilerOptionSet& optionSet,
    DiagnosticSink* sink,
    Decl* decl,
    CapabilitySet const& setToFind)
{
    HashSet<NodeBase*> checkedDecls;
    ProvenenceNodeWithLoc provNode;
    provNode.referencedNode = decl;
    provNode.referenceLoc = (decl) ? decl->loc : SourceLoc();
    bool bottomOfProvenanceStack = false;
    // Find the bottom of the atom provenance stack which fails to contain `setToFind`
    while (!bottomOfProvenanceStack && provNode.referencedNode)
    {
        bottomOfProvenanceStack = true;
        if (auto referencedDecl = as<Decl>(provNode.referencedNode))
        {
            for (auto& i : referencedDecl->capabilityRequirementProvenance)
            {
                if (checkedDecls.contains(i.referencedNode))
                    continue;
                checkedDecls.add(i.referencedNode);
                auto innerReferencedDecl = as<Decl>(i.referencedNode);
                if (!(innerReferencedDecl &&
                      CapabilitySet{innerReferencedDecl->inferredCapabilityRequirements}.implies(
                          setToFind)))
                {
                    // We found a source of the incompatible capability, follow this
                    // element inside the provenance stack until we are at the bottom
                    provNode = i;
                    bottomOfProvenanceStack = false;
                    break;
                }
            }
        }
        else
        {
            bottomOfProvenanceStack = true;
        }
    }

    if (!provNode.referencedNode)
        return;

    if (auto referencedDecl = as<Decl>(provNode.referencedNode))
    {
        // Diagnose the use-site
        maybeDiagnose(
            sink,
            optionSet,
            DiagnosticCategory::Capability,
            Diagnostics::SeeUsingOf{.decl = referencedDecl, .location = provNode.referenceLoc});
        // Diagnose the definition as the problem
        maybeDiagnose(
            sink,
            optionSet,
            DiagnosticCategory::Capability,
            Diagnostics::SeeDefinitionOf{.decl = referencedDecl});
        // If we find a 'require' modifier, this is contributing to the overall capability
        // incompatibility. We should hint to the user that this declaration is problematic.
        if (auto requireCapabilityAttribute =
                referencedDecl->findModifier<RequireCapabilityAttribute>())
            maybeDiagnose(
                sink,
                optionSet,
                DiagnosticCategory::Capability,
                Diagnostics::SeeDeclarationOfModifier{.modifier = requireCapabilityAttribute});
    }
    else
    {
        StringBuilder sb;
        printDiagnosticArg(sb, provNode.referencedNode->astNodeType);
        maybeDiagnose(
            sink,
            optionSet,
            DiagnosticCategory::Capability,
            Diagnostics::SeeUsingOfNodeType{
                .nodeType = sb.produceString(),
                .location = provNode.referenceLoc});
    }
}

void diagnoseCapabilityProvenance(
    CompilerOptionSet& optionSet,
    DiagnosticSink* sink,
    Decl* decl,
    CapabilityAtom atomToFind,
    HashSet<Decl*>& printedDecls)
{
    auto thisModule = getModuleDecl(decl);
    Decl* declToPrint = decl;
    while (declToPrint)
    {
        Decl* previousDecl = declToPrint;
        printedDecls.add(declToPrint);
        for (auto& provenance : declToPrint->capabilityRequirementProvenance)
        {
            auto referencedDecl = as<Decl>(provenance.referencedNode);
            if (!referencedDecl)
            {
                StringBuilder sb;
                printDiagnosticArg(sb, provenance.referencedNode->astNodeType);
                maybeDiagnose(
                    sink,
                    optionSet,
                    DiagnosticCategory::Capability,
                    Diagnostics::SeeUsingOfNodeType{
                        .nodeType = sb.produceString(),
                        .location = provenance.referenceLoc});
                break;
            }

            if (!CapabilitySet{referencedDecl->inferredCapabilityRequirements}.implies(atomToFind))
                continue;
            maybeDiagnose(
                sink,
                optionSet,
                DiagnosticCategory::Capability,
                Diagnostics::SeeUsingOf{
                    .decl = referencedDecl,
                    .location = provenance.referenceLoc});
            declToPrint = referencedDecl;
            if (printedDecls.contains(declToPrint))
                break;
            if (declToPrint->findModifier<RequireCapabilityAttribute>())
                break;
            auto moduleDecl = getModuleDecl(declToPrint);
            if (thisModule != moduleDecl)
                break;
        }
        if (previousDecl == declToPrint)
            break;
    }
    if (declToPrint)
    {
        maybeDiagnose(
            sink,
            optionSet,
            DiagnosticCategory::Capability,
            Diagnostics::SeeDefinitionOf{.decl = declToPrint});
    }
}

void SemanticsDeclCapabilityVisitor::diagnoseUndeclaredCapability(
    Decl* decl,
    UndeclaredCapabilityDiagnosticKind diagKind,
    const CapabilityAtomSet& failedAtomsInsideAvailableSet,
    bool printProvenance)
{
    if (!decl->inferredCapabilityRequirements || decl->inferredCapabilityRequirements->isEmpty())
        return;

    // There are two causes for why type checking failed on failedAvailableSet.
    // The first scenario is that failedAvailableSet defines a set of capabilities on a
    // compilation target (e.g. hlsl) that isn't defined by some callees, for example, if we
    // have a function:
    //    [require(hlsl)]  // <-- failedAvailableSet
    //    [require(cpp)]
    //    void caller()
    //    {
    //        printf(); // assume this is defined for (cpp | cuda).
    //    }
    // In this case we should diagnose error reporting printf isn't defined on a required
    // target.
    //
    // Now, we detect if we are case 1.

    {
        CapabilityAtom outFailedAtom{};
        if (hasTargetAtom(failedAtomsInsideAvailableSet, outFailedAtom))
        {
            StringBuilder targetSb;
            printDiagnosticArg(targetSb, outFailedAtom);
            maybeDiagnose(
                getSink(),
                this->getOptionSet(),
                DiagnosticCategory::Capability,
                Diagnostics::DeclHasDependenciesNotCompatibleOnTarget{
                    .target = targetSb.produceString(),
                    .decl = decl});

            // Anything defined on a non-failed target atom may be the culprit to why we fail
            // having a target capability. Print out all possible culprits.
            CapabilityAtomSet failedAtomSet;
            failedAtomSet.add((UInt)outFailedAtom);
            CapabilityAtomSet targetsNotUsedSet;
            CapabilityAtomSet::calcSubtract(
                targetsNotUsedSet,
                getAtomSetOfTargets(),
                failedAtomSet);

            if (printProvenance)
            {
                HashSet<Decl*> printedDecls;
                for (auto atom : targetsNotUsedSet)
                {
                    CapabilityAtom formattedAtom = asAtom(atom);
                    diagnoseCapabilityProvenance(
                        this->getOptionSet(),
                        getSink(),
                        decl,
                        formattedAtom,
                        printedDecls);
                }
            }
            return;
        }
    }

    // The second scenario is when the callee is using a capability that is not provided by the
    // requirement. For example:
    //     [require(hlsl,b,c)]
    //     void caller()
    //     {
    //         useD();    // requires capability (hlsl,d)
    //     }
    // In this case we should report that useD() is using a capability that is not declared by
    // caller. If we reach here, we are case 2. We will produce all failed atoms. This is important
    // since provenance of multiple atoms can come from multiple referenced items in a function
    // body.

    HashSet<Decl*> printedDecls;
    auto simplifiedFailedAtomsSet = failedAtomsInsideAvailableSet.newSetWithoutImpliedAtoms();
    for (auto i : simplifiedFailedAtomsSet)
    {
        CapabilityAtom formattedAtom = asAtom(i);
        CapabilityName canonicalName;
        StringBuilder capsSb;
        printDiagnosticArg(capsSb, formattedAtom);
        if (isStageAtom((CapabilityName)formattedAtom, canonicalName))
        {
            // Provide a more friendly message if atom is a stage.
            maybeDiagnose(
                getSink(),
                this->getOptionSet(),
                DiagnosticCategory::Capability,
                Diagnostics::DeclHasDependenciesNotCompatibleOnStage{
                    .stage = capsSb.produceString(),
                    .decl = decl});
        }
        else
        {
            switch (diagKind)
            {
            case UndeclaredCapabilityDiagnosticKind::UseOfUndeclaredCapability:
                maybeDiagnose(
                    getSink(),
                    this->getOptionSet(),
                    DiagnosticCategory::Capability,
                    Diagnostics::UseOfUndeclaredCapability{
                        .caps = capsSb.produceString(),
                        .decl = decl});
                break;
            case UndeclaredCapabilityDiagnosticKind::
                UseOfUndeclaredCapabilityOfInterfaceRequirement:
                maybeDiagnose(
                    getSink(),
                    this->getOptionSet(),
                    DiagnosticCategory::Capability,
                    Diagnostics::UseOfUndeclaredCapabilityOfInterfaceRequirement{
                        .caps = capsSb.produceString(),
                        .decl = decl});
                break;
            case UndeclaredCapabilityDiagnosticKind::UseOfUndeclaredCapabilityOfInheritanceDecl:
                maybeDiagnose(
                    getSink(),
                    this->getOptionSet(),
                    DiagnosticCategory::Capability,
                    Diagnostics::UseOfUndeclaredCapabilityOfInheritanceDecl{
                        .caps = capsSb.produceString(),
                        .decl = decl});
                break;
            }
        }
        if (printProvenance)
        {
            // Print provenances.
            diagnoseCapabilityProvenance(
                this->getOptionSet(),
                getSink(),
                decl,
                formattedAtom,
                printedDecls);
        }
    }
}

} // namespace Slang
