// slang-check-impl.h
#pragma once

// This file provides the private interfaces used by
// the various `slang-check-*` files that provide
// the semantic checking infrastructure.

#include "slang-check.h"
#include "slang-compiler.h"
#include "slang-visitor.h"

#include <cstring>
#include <type_traits>

namespace Slang
{
template<typename P, typename... Args>
bool diagnoseCapabilityErrors(
    DiagnosticSink* sink,
    CompilerOptionSet& optionSet,
    P const& pos,
    DiagnosticInfo const& info,
    Args const&... args)
{
    if (optionSet.getBoolOption(CompilerOptionName::IgnoreCapabilities))
        return false;
    return sink->diagnose(pos, info, args...);
}

template<typename D>
bool diagnoseCapabilityErrors(
    DiagnosticSink* sink,
    CompilerOptionSet& optionSet,
    D const& diagnostic)
{
    if (optionSet.getBoolOption(CompilerOptionName::IgnoreCapabilities))
        return false;
    return sink->diagnose(diagnostic);
}

enum class IsSubTypeOptions
{
    None = 0,

    /// A type may not be finished 'DeclCheckState::ReadyForLookup` while `isSubType` is called.
    /// We should not cache any negative results when this flag is set.
    NoCaching = 1 << 0,
};

/// Should the given `decl` be treated as a static rather than instance declaration?
bool isEffectivelyStatic(Decl* decl);

bool isGlobalDecl(Decl* decl);

bool isUnsafeForceInlineFunc(FunctionDeclBase* funcDecl);

bool isUniformParameterType(Type* type);

bool isSlang2026OrLater(SemanticsVisitor* visitor);
bool isSlang202cOrLater(SemanticsVisitor* visitor);

/// How `checkRedeclaration` reports two declarations of the same name that cannot coexist.
enum class RedeclarationSeverity
{
    /// An error in every language version.
    Error,
    /// A warning in every language version. Earlier compiler releases did not diagnose these
    /// conflicts, so we keep code that they accepted compiling; Slang 202c may make them errors
    /// (shader-slang/slang#13956).
    Warning,
};

/// Create a new component type based on `inComponentType`, but with all its requiremetns filled.
RefPtr<ComponentType> fillRequirements(ComponentType* inComponentType);

Type* checkProperType(Linkage* linkage, TypeExp typeExp, DiagnosticSink* sink);

/// Get the element type if `type` is Ptr or PtrLike type, otherwise returns null.
/// Note: this currently does not include PtrTypeBase.
Type* getPointedToTypeIfCanImplicitDeref(Type* type);

/// True if `containerDecl` is `moduleDecl` itself or one of its own `__include`d
/// `FileDecl` children — i.e. a scope that belongs on `moduleDecl`'s imported surface.
/// Used by both the `import` re-export filter (`importModuleIntoScope`) and the
/// legacy/API name-lookup scope (`_getOrCreateScopeForLegacyLookup`) to drop
/// `using`-spliced namespace siblings and other modules' transitively-imported files.
/// See shader-slang/slang#11443.
bool isOwnModuleOrIncludedFileScope(ContainerDecl* containerDecl, ModuleDecl* moduleDecl);

inline int getIntValueBitSize(IntegerLiteralValue val)
{
#if SLANG_VC
// Disable MSVC warning: "unary minus operator applied to unsigned type, result still unsigned"
#pragma warning(push)
#pragma warning(disable : 4146)
#endif
    uint64_t v = val > 0 ? (uint64_t)val : -(uint64_t)val;
#if SLANG_VC
#pragma warning(pop)
#endif
    int result = 1;
    while (v >>= 1)
    {
        result++;
    }
    return result;
}

// This returns the number of bits that the type could be. The only exceptional
// cases are IntPtr and UIntPtr, whose sizes are not known during checking, and
// the maximum supported value of 64 is returned instead.
int getMaximumTypeBitSize(Type* t);

// A flat representation of basic types (scalars, vectors and matrices)
// that can be used as lookup key in caches
struct BasicTypeKey
{
    uint32_t baseType : 5;
    uint32_t dim1 : 8;
    uint32_t dim2 : 8;
    uint32_t knownConstantBitCount : 6;
    uint32_t knownNegative : 1;
    uint32_t isLValue : 1;
    uint32_t reserved : 3;
    uint32_t getRaw() const
    {
        uint32_t val;
        memcpy(&val, this, sizeof(uint32_t));
        return val;
    }
    bool operator==(BasicTypeKey other) const { return getRaw() == other.getRaw(); }
    static BasicTypeKey invalid() { return BasicTypeKey{0x1f, 0, 0, 0, 0, 0, 0}; }
};

SLANG_FORCE_INLINE BasicTypeKey makeBasicTypeKey(
    BaseType baseType,
    IntegerLiteralValue dim1 = 0,
    IntegerLiteralValue dim2 = 0,
    bool inIsLValue = false)
{
    SLANG_ASSERT(dim1 >= 0 && dim2 >= 0);
    return BasicTypeKey{
        uint8_t(baseType),
        uint8_t(dim1),
        uint8_t(dim2),
        0,
        0,
        (inIsLValue ? 1u : 0u),
        0};
}

inline BasicTypeKey makeBasicTypeKey(QualType typeIn, Expr* exprIn = nullptr)
{
    if (auto basicType = as<BasicExpressionType>(typeIn))
    {
        auto rs = makeBasicTypeKey(basicType->getBaseType());
        if (auto constInt = as<IntegerLiteralExpr>(exprIn))
        {
            if (constInt->value < 0)
            {
                rs.knownNegative = 1;
            }
            rs.knownConstantBitCount = getIntValueBitSize(constInt->value);
        }
        rs.isLValue = typeIn.isLeftValue ? 1u : 0u;
        return rs;
    }
    else if (auto vectorType = as<VectorExpressionType>(typeIn))
    {
        if (auto elemCount = as<ConstantIntVal>(vectorType->getElementCount()))
        {
            if (auto elemBasicType = as<BasicExpressionType>(vectorType->getElementType()))
            {
                return makeBasicTypeKey(
                    elemBasicType->getBaseType(),
                    elemCount->getValue(),
                    0,
                    typeIn.isLeftValue);
            }
        }
    }
    else if (auto matrixType = as<MatrixExpressionType>(typeIn))
    {
        if (auto elemCount1 = as<ConstantIntVal>(matrixType->getRowCount()))
        {
            if (auto elemCount2 = as<ConstantIntVal>(matrixType->getColumnCount()))
            {
                if (auto elemBasicType = as<BasicExpressionType>(matrixType->getElementType()))
                {
                    return makeBasicTypeKey(
                        elemBasicType->getBaseType(),
                        elemCount1->getValue(),
                        elemCount2->getValue(),
                        typeIn.isLeftValue);
                }
            }
        }
    }
    return BasicTypeKey::invalid();
}

struct BasicTypeKeyPair
{
    BasicTypeKey type1, type2;
    bool operator==(const BasicTypeKeyPair& rhs) const
    {
        return type1 == rhs.type1 && type2 == rhs.type2;
    }
    bool operator!=(const BasicTypeKeyPair& rhs) const { return !(*this == rhs); }

    bool isValid() const
    {
        return type1.getRaw() != BasicTypeKey::invalid().getRaw() &&
               type2.getRaw() != BasicTypeKey::invalid().getRaw();
    }

    HashCode getHashCode() const { return combineHash(type1.getRaw(), type2.getRaw()); }
};

// Focused failure data produced while a generic candidate is still being
// inferred. The generic solver fills this optional record with the first
// concrete reason a candidate failed, and `CompleteOverloadCandidate` formats
// it into a focused diagnostic only if overload resolution selects that failed
// candidate. Each `Kind` captures just the offending fields (counts, a
// parameter name, or the substituted sub/super types) at the failure site;
// the more expensive diagnostic formatting is deferred to the selected-
// candidate path so speculative candidates never pay for it.
struct GenericArgumentInferenceFailure
{
    enum class Kind
    {
        None,
        VariadicPackCountMismatch,
        GenericArityMismatch,
        OrdinaryGenericParamNotInferred,
        InterfaceConformanceNotSatisfied,
        GenericConstraintNotSatisfied,
        GenericParamUnificationConflict,
    };

    struct VariadicPackCountMismatch
    {
        SourceLoc location = SourceLoc();
        int64_t expectedCount = 0;
        int64_t actualCount = 0;
    };

    // The call supplied a number of value arguments that the generic function's
    // parameter list could not match, so argument-to-parameter matching failed
    // before any inference could run.
    struct GenericArityMismatch
    {
        SourceLoc location = SourceLoc();
        Int expectedParamCount = 0;
        Int actualArgCount = 0;
    };

    // An ordinary generic parameter (such as a type `T` that appears only in
    // return position, or a value `N` not mentioned in any parameter) was never
    // determined from the call, so its solver constraint stayed unsatisfied.
    // The parameter declaration itself is stored (not just its name) so the
    // diagnostic can use the full declaration (name, type-vs-value kind, loc).
    struct OrdinaryGenericParamNotInferred
    {
        SourceLoc location = SourceLoc();
        Decl* member = nullptr;
    };

    // A source generic constraint `T : IFoo` could not be discharged: the
    // inferred argument for `T` (`subType`) does not conform to the required
    // interface (`supType`). The capture site records these only once both are
    // concrete (its `hasUnreadyDependenciesForVal` guard), so they are always
    // fully substituted under the current (failed) specialization when read.
    struct InterfaceConformanceNotSatisfied
    {
        SourceLoc location = SourceLoc();
        Type* subType = nullptr;
        Type* supType = nullptr;
    };

    // A source generic constraint that is not an interface conformance could not
    // be satisfied — the general fallback for every constraint kind handled by
    // the witness solver other than conformance (today: equality `where T == X`,
    // type coercion `where U(T)`, non-empty pack `where nonempty(P)`, ...).
    // `constraintDecl` is the source constraint declaration, rendered to a
    // readable form (e.g. `T == int`, `T : IFoo`, `int(T)`) by
    // `ASTPrinter::getGenericConstraintString`; `constraintLoc` anchors a
    // "see declaration" note. The declaration is captured (not a pre-rendered
    // string) so formatting stays deferred to `CompleteOverloadCandidate`.
    struct GenericConstraintNotSatisfied
    {
        SourceLoc location = SourceLoc();
        Decl* constraintDecl = nullptr;
        SourceLoc constraintLoc = SourceLoc();
    };

    // Two ordinary constraints inferred conflicting arguments for one generic
    // parameter (e.g. `foo<T>(T, T)` with unrelated `A`/`B`, or `foo<let N:int>`
    // required to be both `4` and `8`). Captures the parameter declaration and
    // both candidate values; `Val*` covers both type parameters (the candidates
    // are `Type`s) and value parameters (the candidates are `IntVal`s).
    struct GenericParamUnificationConflict
    {
        SourceLoc location = SourceLoc();
        Decl* paramDecl = nullptr;
        Val* firstVal = nullptr;
        Val* secondVal = nullptr;
    };

    Kind kind = Kind::None;
    union
    {
        VariadicPackCountMismatch variadicPackCountMismatch;
        GenericArityMismatch genericArityMismatch;
        OrdinaryGenericParamNotInferred ordinaryGenericParamNotInferred;
        InterfaceConformanceNotSatisfied interfaceConformanceNotSatisfied;
        GenericConstraintNotSatisfied genericConstraintNotSatisfied;
        GenericParamUnificationConflict genericParamUnificationConflict;
    };

    // Every payload must be trivially copyable: that is what lets this struct
    // use the implicitly-defaulted (trivial) copy/assignment, which copies the
    // whole object representation instead of switching on `kind` to copy only
    // the active member. A kind-switched copy performs conditional reads of
    // individual payload fields, which GCC's -Werror=maybe-uninitialized
    // rejects (it cannot prove the read member is the initialized one) once
    // `OverloadCandidate` values are copied inside standard-library
    // algorithms. Trivial copyability also implies trivial destructibility,
    // which is what makes the placement-new in the `set*()` members (which
    // never destroy the previously active member first) well-defined.
    static_assert(
        std::is_trivially_copyable_v<VariadicPackCountMismatch> &&
            std::is_trivially_copyable_v<GenericArityMismatch> &&
            std::is_trivially_copyable_v<OrdinaryGenericParamNotInferred> &&
            std::is_trivially_copyable_v<InterfaceConformanceNotSatisfied> &&
            std::is_trivially_copyable_v<GenericConstraintNotSatisfied> &&
            std::is_trivially_copyable_v<GenericParamUnificationConflict>,
        "GenericArgumentInferenceFailure payloads must be trivially copyable");

    // Zero the tag and the full union storage so every byte of the object is
    // initialized from birth and the trivial copy above never reads an
    // indeterminate byte. `Kind::None` is value zero, so the zeroed tag is the
    // correct "no failure recorded" state; assert that so a reordering of the
    // enum cannot silently break this constructor.
    static_assert(int(Kind::None) == 0, "zero-initialized tag must mean Kind::None");
    GenericArgumentInferenceFailure() { std::memset(static_cast<void*>(this), 0, sizeof(*this)); }

    // Select a union variant and return a reference for the caller to populate.
    // Each setter begins the chosen member's lifetime with placement-new and
    // updates `kind` in lockstep, so the invariant "`kind` names the live union
    // member" holds by construction at every capture site. The previously
    // active member is trivially destructible, so it needs no explicit
    // destruction before the new member is constructed in place.
    VariadicPackCountMismatch& setVariadicPackCountMismatch()
    {
        kind = Kind::VariadicPackCountMismatch;
        return *new (&variadicPackCountMismatch) VariadicPackCountMismatch();
    }
    GenericArityMismatch& setGenericArityMismatch()
    {
        kind = Kind::GenericArityMismatch;
        return *new (&genericArityMismatch) GenericArityMismatch();
    }
    OrdinaryGenericParamNotInferred& setOrdinaryGenericParamNotInferred()
    {
        kind = Kind::OrdinaryGenericParamNotInferred;
        return *new (&ordinaryGenericParamNotInferred) OrdinaryGenericParamNotInferred();
    }
    InterfaceConformanceNotSatisfied& setInterfaceConformanceNotSatisfied()
    {
        kind = Kind::InterfaceConformanceNotSatisfied;
        return *new (&interfaceConformanceNotSatisfied) InterfaceConformanceNotSatisfied();
    }
    GenericConstraintNotSatisfied& setGenericConstraintNotSatisfied()
    {
        kind = Kind::GenericConstraintNotSatisfied;
        return *new (&genericConstraintNotSatisfied) GenericConstraintNotSatisfied();
    }
    GenericParamUnificationConflict& setGenericParamUnificationConflict()
    {
        kind = Kind::GenericParamUnificationConflict;
        return *new (&genericParamUnificationConflict) GenericParamUnificationConflict();
    }
};

// The zero-filling constructor and the implicitly-defaulted copy operations
// above rely on the whole type — not just each payload — being trivially
// copyable; assert it so a user-provided copy operation or a non-trivial
// member cannot be reintroduced without failing the build.
static_assert(
    std::is_trivially_copyable_v<GenericArgumentInferenceFailure>,
    "GenericArgumentInferenceFailure must be trivially copyable");

DeclRefIntVal* getDeclRefIntValIgnoringCasts(IntVal* intVal);

struct OverloadCandidate
{
    enum class Flavor
    {
        Func,
        Generic,
        UnspecializedGeneric,
        Expr,
    };
    Flavor flavor;

    enum class Status
    {
        GenericArgumentInferenceFailed,
        Unchecked,
        ArityChecked,
        FixityChecked,
        TypeChecked,
        DirectionChecked,
        VisibilityChecked,
        Applicable,
    };
    Status status = Status::Unchecked;

    typedef unsigned int Flags;
    enum Flag : Flags
    {
        IsPartiallyAppliedGeneric = 1 << 0,
    };
    Flags flags = 0;

    // Reference to the declaration being applied
    LookupResultItem item;

    // The expression when flavor is Expr.
    Expr* exprVal = nullptr;

    // Type of function being applied (for cases where `item` is not used)
    FuncType* funcType = nullptr;

    // The type of the result expression if this candidate is selected
    Type* resultType = nullptr;

    // Generic overload candidates store the substitution used to type-check the
    // candidate. Before constraint validation this may contain only ordinary
    // generic arguments inferred from the call. After generic-constraint
    // validation succeeds, it is replaced with the full generic application
    // substitution, including compiler-solved witness arguments.

    // How much conversion cost should be considered for this overload,
    // when ranking candidates.
    ConversionCost conversionCostSum = kConversionCost_None;

    // When required, a candidate can store a pre-checked list of
    // arguments so that we don't have to repeat work across checking
    // phases. Currently this is only needed for generics.
    SubstitutionSet subst;

    // For a generic candidate, the number of leading ordinary generic arguments
    // that were supplied explicitly (as opposed to filled from a parameter's
    // default). `TryCheckOverloadCandidateConstraints` hands this prefix to the
    // generic constraint solver so defaults and witness arguments are resolved by
    // the solver's fixpoint -- the same path used for inferred generic arguments
    // -- rather than a separate linear pass. -1 until computed.
    Index explicitGenericArgCount = -1;

    // When a generic candidate fails before producing a specialized decl-ref,
    // the solver can record a focused failure reason here. The selected failed
    // candidate reports this reason instead of falling back to only the generic
    // "could not specialize" diagnostic.
    GenericArgumentInferenceFailure genericInferenceFailure;

    // Records the first argument that failed to type-check while trying this
    // candidate, so a "no applicable overload" diagnostic can point the user at
    // which argument is wrong (issue #7857). `argMismatchArgIndex` is the 0-based
    // argument index (-1 until a mismatch is recorded); `argMismatchExpectedType`
    // is the parameter type and `argMismatchActualType` is the argument type.
    Index argMismatchArgIndex = -1;
    Type* argMismatchExpectedType = nullptr;
    Type* argMismatchActualType = nullptr;
};

struct ResolvedOperatorOverload
{
    // The resolved decl.
    Decl* decl;

    // The cached overload candidate in the current TypeCheckingCache.
    // Note that a `OverloadCandidate` object is not migratable over different
    // Linkages (compile sessions), so we will need to use `cacheVersion` to track
    // if this `candidate` is valid for the current session. If not, we will
    // recreate it from `decl`.
    OverloadCandidate candidate;
    // The version of the TypeCheckingCache for which the cached candidate is valid.
    int cacheVersion;
};

struct TypeCheckingCache : public RefObject
{
    Dictionary<BasicTypeKeyPair, ConversionCost> conversionCostCache;
};

enum class CoercionSite
{
    General,
    Assignment,
    Argument,
    Return,
    Initializer,
    ExplicitCoercion
};

struct FacetImpl;

/// Information about one "facet" of a type or declaration
///
/// In the simplest terms, a facet represents a grouping of
/// member declarations that were all originally declared
/// as part of the same `{}`-enclosed body.
///
/// A given *entity* (a type, type declaration, or `extension`
/// declaration) may have multiple facets, depending on what it
/// declares, what it inherits from, or what `extension`s apply to it.
///
/// Broadly, an entity will have:
///
/// * A *self facet*, if it has a body, that contains the members
///   the entity directly declares.
///
/// * An *inherited facet* for each base type that it (transitively)
///   inherits from. Inherited facets are either *direct*, if the
///   original entity stated the inheritance relationship, or
///   *indirect* if they arise from the transitive closure of the
///   inheritance relationship. Each inherited facet contains the
///   members of the entity that was inherited from.
///
/// * An *extension facet* for each `extension` declaration that
///   is known to apply to the entity in the context where semantic
///   checking is being performed. Each extension facet contains the
///   members of the `extension` that applied.
///
struct Facet
{
public:
    /// Kinds of facets that can occur
    enum class Kind
    {
        Type,
        Extension,
    };

    /// How many indirections away from the self facet?
    typedef unsigned int DirectnessVal;
    enum class Directness : DirectnessVal
    {
        Self = 0,
        Direct = 1,
    };

    /// The *origin* of a facet is the type and/or declaration
    /// that the facet's members belong to.
    ///
    struct Origin
    {
        /// A `DeclRef` to the declaration this facet corresponds to, if any.
        ///
        /// This might be a type declaration, an `extension` declaration,
        /// or nothing.
        ///
        DeclRef<Decl> declRef;

        /// The type that this facet corresponds to, if any
        Type* type = nullptr;

        Origin() {}

        explicit Origin(DeclRef<Decl> declRef, Type* type = nullptr)
            : declRef(declRef), type(type)
        {
        }
    };

    Facet() {}

    typedef FacetImpl Impl;

    Facet(Impl* impl)
        : _impl(impl)
    {
    }

    Impl* getImpl() const { return _impl; }
    Impl* operator->() const { return _impl; }

private:
    Impl* _impl = nullptr;
};


/// Do the origins of `left` and `right` match,
/// such that they are both facets for the same
/// base type or `extension`?
///
bool originsMatch(Facet left, Facet right);

inline bool operator!(Facet facet)
{
    return !facet.getImpl();
}

bool operator==(Facet::Origin left, Facet::Origin right);

inline bool operator!=(Facet::Origin left, Facet::Origin right)
{
    return !(left == right);
}

/// Heap-allocated implementation of a single facet.
struct FacetImpl
{
    /// The kind of this facet
    Facet::Kind kind = Facet::Kind::Type;

    /// How many indirections away from the self facet?
    Facet::Directness directness = Facet::Directness::Self;

    /// The origin of this facet.
    ///
    /// This is the type or declaration that the facet
    /// corresponds to.
    ///
    Facet::Origin origin;

    // DeclRef to the container that represent this facet for member lookup.
    // If the facet is for an interface decl, this declref will be a specialized `LookupDeclRef`
    // containing the subtype witness that the type this facet belongs to is a subtype of interface
    // represented by this facet.
    DeclRef<ContainerDecl> declRefForMemberLookup;

    Type* getType() const { return origin.type; }
    DeclRef<Decl> getDeclRef() const { return origin.declRef; }

    /// A witness that the type this facet belongs to
    /// is a subtype of `origin.type` (if both of those
    /// types exist).
    ///
    SubtypeWitness* subtypeWitness = nullptr;

    /// The next facet in the linearized inheritance list of the entity.
    Facet next;

    void setSubtypeWitness(ASTBuilder* builder, SubtypeWitness* witness)
    {
        subtypeWitness = witness;
        init(builder);
    }

    void init(ASTBuilder* builder);

    FacetImpl() {}

    FacetImpl(
        ASTBuilder* astBuilder,
        Facet::Kind kind,
        Facet::Directness directness,
        DeclRef<Decl> declRef,
        Type* type,
        SubtypeWitness* subtypeWitness)
        : kind(kind), directness(directness), origin(declRef, type), subtypeWitness(subtypeWitness)
    {
        init(astBuilder);
    }
};

struct FacetListBuilder;

/// A singly linked list of facets.
struct FacetList
{
public:
    FacetList() {}

    explicit FacetList(Facet head)
        : _head(head)
    {
    }

    Facet getHead() const { return _head; }
    Facet& getHead() { return _head; }

    Facet advanceHead()
    {
        SLANG_ASSERT(_head.getImpl());
        auto facet = _head;
        _head = facet->next;
        return facet;
    }

    Facet popHead()
    {
        auto facet = advanceHead();
        facet->next = nullptr;
        return facet;
    }

    FacetList getTail() const
    {
        SLANG_ASSERT(_head.getImpl());
        return FacetList(_head->next);
    }

    bool containsMatchFor(Facet facet) const;

    bool isEmpty() const { return _head.getImpl() == nullptr; }

    struct Iterator
    {
    public:
        Iterator() {}

        Iterator(Facet::Impl* cursor)
            : _cursor(cursor)
        {
        }

        bool operator!=(Iterator const& that) const { return this->_cursor != that._cursor; }

        void operator++()
        {
            SLANG_ASSERT(_cursor);
            _cursor = _cursor->next.getImpl();
        }

        Facet operator*() const { return _cursor; }

    private:
        Facet::Impl* _cursor = nullptr;
    };

    Iterator begin() const { return Iterator(_head.getImpl()); }
    Iterator end() const { return Iterator(); }

    struct Appender
    {
    public:
        Appender(FacetList& list) { _link = &list._head; }

        void add(Facet facet)
        {
            *_link = facet;
            _link = &facet->next;
        }

    protected:
        Appender() {}

        Facet* _link = nullptr;
    };

    typedef FacetListBuilder Builder;

protected:
    Facet _head;
};

struct FacetListBuilder : FacetList, FacetList::Appender
{
public:
    FacetListBuilder() { _link = &_head; }
};

/// Information about the inheritance of an entity (type or declaration)
///
/// Currently this is only used to store a linearized list of the
/// `Facet`s that the type/declaration transitively inherits.
///
struct InheritanceInfo
{
    FacetList facets;
};

/// Records the extension epoch observed for one declaration dependency.
///
/// Inheritance and subtype cache entries can depend on many declarations via
/// transitive facets. We snapshot the epoch for each contributing declaration so
/// we can validate lazily instead of eagerly scanning and invalidating large
/// global cache dictionaries when a new extension is registered.
struct DeclExtensionEpochStamp
{
    Decl* decl = nullptr;
    UInt epoch = 0;
};

/// Cached inheritance info plus the declaration epochs it depends on.
///
/// The `generation` value changes whenever the entry is recomputed. Subtype
/// cache entries store the generations they were built against so they can
/// cheaply detect when either endpoint's inheritance info has changed.
struct InheritanceInfoCacheEntry
{
    InheritanceInfo info;
    List<DeclExtensionEpochStamp> dependencyEpochs;
    UInt generation = 0;
    bool isComputing = false;
};

/// Cached subtype query plus the inheritance cache generations it depended on.
struct SubtypeWitnessCacheEntry
{
    SubtypeWitness* witness = nullptr;
    UInt subTypeGeneration = 0;
    UInt superTypeGeneration = 0;
};

/// Key for the `_specializeInterfaceInheritanceWitness` result cache.
///
/// The three fields are exactly that function's parameters (see its declaration below), so this
/// key captures its complete input.
struct SpecializeInterfaceInheritanceWitnessKey
{
    InterfaceDecl* baseInterfaceDecl = nullptr;
    SubtypeWitness* selfIsSubtypeOfBase = nullptr;
    SubtypeWitness* baseIsSubtypeOfFacet = nullptr;

    HashCode getHashCode() const
    {
        return combineHash(
            Slang::getHashCode(baseInterfaceDecl),
            Slang::getHashCode(selfIsSubtypeOfBase),
            Slang::getHashCode(baseIsSubtypeOfFacet));
    }
    bool operator==(const SpecializeInterfaceInheritanceWitnessKey& other) const
    {
        return baseInterfaceDecl == other.baseInterfaceDecl &&
               selfIsSubtypeOfBase == other.selfIsSubtypeOfBase &&
               baseIsSubtypeOfFacet == other.baseIsSubtypeOfFacet;
    }
};

/// Cached information about how to convert between two types.
struct ImplicitCastMethod
{
    OverloadCandidate conversionFuncOverloadCandidate = OverloadCandidate();
    ConversionCost cost = kConversionCost_Impossible;
    bool isAmbiguous = false;
};

struct ImplicitCastMethodKey
{
    Type* fromType; // nullptr means default construct.
    bool isLValue;
    Type* toType;
    uint64_t constantVal;
    bool isConstant;
    HashCode getHashCode() const
    {
        return combineHash(
            Slang::getHashCode(fromType),
            Slang::getHashCode(toType),
            Slang::getHashCode(constantVal),
            (HashCode32)isConstant,
            (HashCode32)isLValue);
    }
    bool operator==(const ImplicitCastMethodKey& other) const
    {
        return fromType == other.fromType && toType == other.toType &&
               isConstant == other.isConstant && constantVal == other.constantVal &&
               isLValue == other.isLValue;
    }
    ImplicitCastMethodKey() = default;
    ImplicitCastMethodKey(QualType fromType, Type* toType, Expr* fromExpr)
        : fromType(fromType)
        , toType(toType)
        , constantVal(0)
        , isConstant(false)
        , isLValue(fromType.isLeftValue)
    {
        if (auto constInt = as<IntegerLiteralExpr>(fromExpr))
        {
            constantVal = constInt->value;
            isConstant = true;
        }
    }
};

/// Used to track offsets for atomic counter storage qualifiers.
struct GLSLBindingOffsetTracker
{
public:
    void setBindingOffset(int binding, int64_t byteOffset);
    int64_t getNextBindingOffset(int binding);

private:
    Dictionary<int, int64_t> bindingToByteOffset;
};

/// Describes whether semantic checking has traversed one concrete interface witness table.
enum class ConformanceInterfaceCheckStatus
{
    /// The table may contain lazily prepared entries, but whole-interface checking has not begun.
    Unchecked,

    /// An enclosing semantic operation is checking the table.
    Checking,

    /// Whole-interface traversal completed without a failed requirement.
    Succeeded,

    /// At least one requirement in the interface failed.
    Failed,
};

/// Stores the declaration-context inputs needed to check one concrete interface witness table.
///
/// A witness table is shared by every specialization of its declaring conformance, so all fields
/// are deliberately unspecialized. This state retains its `owner`, so an ephemeral child context
/// used during generic-witness synthesis cannot leave the table with a dangling semantic context.
/// A table has exactly one authoritative state even when synthesis creates such a child context.
struct ConformanceInterfaceCheckingState : public RefObject
{
    /// The conformance context that owns the table's declaration-context state.
    RefPtr<struct ConformanceCheckingContext> owner;

    /// The type whose conformance this table witnesses.
    Type* conformingType = nullptr;

    /// The interface type implemented by `conformingType`.
    Type* interfaceType = nullptr;

    /// The declared conformance or inherited-interface requirement that introduced this table.
    InheritanceDecl* inheritanceDecl = nullptr;

    /// The declaration-context reference to the interface implemented by this table.
    DeclRef<InterfaceDecl> interfaceDeclRef;

    /// The unspecialized table whose entries are checked by this state.
    RefPtr<WitnessTable> witnessTable;

    /// The witness used to project interface requirements into `conformingType`.
    SubtypeWitness* conformingWitness = nullptr;

    /// Distinguishes registration or lazy preparation from whole-interface validation.
    ConformanceInterfaceCheckStatus status = ConformanceInterfaceCheckStatus::Unchecked;
};

/// Stores semantic state shared by whole and on-demand checking of one declared conformance.
///
/// The context is keyed by its root `InheritanceDecl`. Its interface map contains the root table
/// and any canonical inherited-interface tables already encountered while checking that
/// conformance.
struct ConformanceCheckingContext : public RefObject
{
    /// The declaration-context type whose conformance is being checked.
    Type* conformingType = nullptr;

    /// The witness for `conformingType` and the root interface.
    SubtypeWitness* conformingWitness = nullptr;

    /// The type or extension declaration that owns the root conformance.
    ContainerDecl* parentDecl = nullptr;

    /// The inheritance clause that declared the root conformance.
    InheritanceDecl* rootInheritanceDecl = nullptr;

    /// Maps each encountered interface application to its declaration-context witness table.
    Dictionary<DeclRef<InterfaceDecl>, RefPtr<WitnessTable>> mapInterfaceToWitnessTable;
};

/// Shared state for a semantics-checking session.
struct SharedSemanticsContext : public RefObject
{
    Linkage* m_linkage = nullptr;

    /// The (optional) "primary" module that is the parent to everything that will be checked.
    Module* m_module = nullptr;

    /// The Slang language version whose rules apply to this checking session.
    ///
    /// Normal module checking derives this value from the primary module. Ad hoc checking that
    /// has no primary module must instead choose a version explicitly when it constructs the
    /// context.
    SlangLanguageVersion m_languageVersion = SLANG_LANGUAGE_VERSION_UNKNOWN;

    DiagnosticSink* m_sink = nullptr;

    /// (optional) modules that comes from previously processed translation units in the
    /// front-end request that are made visible to the module being checked. This allows
    /// `import` to use them instead of trying to find the files in file system.
    LoadedModuleDictionary* m_environmentModules = nullptr;

    /// (optional) The translation unit that is being checked.
    /// Needed for handling `__include`s.
    TranslationUnitRequest* m_translationUnitRequest = nullptr;

    DiagnosticSink* getSink() { return m_sink; }

    CompilerOptionSet& getOptionSet() { return m_linkage->m_optionSet; }

    // We need to track what has been `import`ed into
    // the scope of this semantic checking session,
    // and also to avoid importing the same thing more
    // than once.
    //
    List<ModuleDecl*> importedModulesList;
    HashSet<ModuleDecl*> importedModulesSet;

    /// Declaration roots synthesized and published during this semantic-checking session.
    ///
    /// Some synthesized declarations deliberately stay out of their parent's member list so that
    /// ordinary lookup cannot find them. Others can be added after the module walk has already
    /// visited their parent. The ordinary declaration-tree traversal cannot reliably discover
    /// either shape, so successful synthesis registers its outermost root here.
    ///
    /// This registry is append-only for the lifetime of the context. Every whole-module phase
    /// revisits the same list, which lets a declaration created in an early phase continue through
    /// all later phases. The set makes publication idempotent; the list preserves stable work-list
    /// order and permits index-based iteration while checking appends more roots.
    List<Decl*> m_synthesizedDeclRoots;
    HashSet<Decl*> m_synthesizedDeclRootSet;

    GLSLBindingOffsetTracker m_glslBindingOffsetTracker;

    Dictionary<Decl*, bool> m_typeContainsRecursionCache;

    Dictionary<TypePair, ConversionCost> m_typeConversionCostCache;

    Dictionary<Val*, VariadicPackCardinality> m_packCardinalityCache;

    // Cache from a semantic value to the ordinary-argument and witness-argument
    // declarations structurally mentioned by that value. Generic default solving
    // asks this Val* -> dependent Decl* question repeatedly across
    // specializations of the same generic, and the answer does not depend on a
    // particular solver instance; the solver later filters these declarations
    // through its current relevance/readiness rules.
    // Cached dependency declarations live in lists so the solver can return
    // array views instead of references into the dictionary's value storage.
    // Empty dependency lists are cached here too; an empty list has no element
    // buffer allocation.
    Dictionary<Val*, List<Decl*>> m_genericSolverValToDependentDeclsCache;

    // On-demand and whole-conformance checking must reuse the same declaration-context state. The
    // inheritance map owns root contexts, and the table map lets a forceful lookup recover the
    // exact semantic inputs needed to check one missing entry.
    Dictionary<InheritanceDecl*, RefPtr<ConformanceCheckingContext>>
        m_mapInheritanceDeclToConformanceCheckingContext;
    Dictionary<WitnessTable*, RefPtr<ConformanceInterfaceCheckingState>>
        m_mapWitnessTableToConformanceInterfaceCheckingState;

    // Track diagnostics that have already been reported to avoid duplicates.
    // Key format: "diagnosticId|sourceLocRaw" or "diagnosticId|sourceLocRaw|extraInfo"
    HashSet<String> m_reportedDiagnosticKeys;

    /// Whether semantic checking has imported the `glsl` module.
    bool m_hasImportedGLSLModule = false;

public:
    /// Whether the translation unit being checked uses the GLSL source language.
    ///
    /// A null translation-unit request denotes a module/reflection checking context that has no
    /// parser-language provenance, so it cannot establish GLSL source semantics and returns false.
    bool isGLSLSourceLanguage()
    {
        if (!m_translationUnitRequest)
        {
            // Reflection, specialization, and API expression-checking contexts can perform
            // semantic work without originating in a parsed translation unit. Such a context has
            // no source-language provenance, so it must not enable GLSL-specific semantic rules.
            return false;
        }

        return m_translationUnitRequest->sourceLanguage == SourceLanguage::GLSL;
    }

    /// Whether builtin operators should use the legacy GLSL operator rules.
    ///
    /// Actual GLSL source always uses those rules. For backward compatibility, explicitly
    /// importing the `glsl` module into non-GLSL source also opts operator checking into them
    /// without changing the source language or parser behavior.
    bool isGLSLOperatorScope() { return isGLSLSourceLanguage() || m_hasImportedGLSLModule; }

private:
    static SlangLanguageVersion _getModuleLanguageVersion(Module* module)
    {
        SLANG_RELEASE_ASSERT(module);
        return module->getModuleDecl()->languageVersion;
    }

public:
    SharedSemanticsContext(
        Linkage* linkage,
        Module* module,
        DiagnosticSink* sink,
        LoadedModuleDictionary* environmentModules = nullptr,
        TranslationUnitRequest* translationUnit = nullptr)
        : m_linkage(linkage)
        , m_module(module)
        , m_languageVersion(_getModuleLanguageVersion(module))
        , m_sink(sink)
        , m_environmentModules(environmentModules)
        , m_translationUnitRequest(translationUnit)
    {
    }

    SharedSemanticsContext(
        Linkage* linkage,
        SlangLanguageVersion languageVersion,
        DiagnosticSink* sink)
        : m_linkage(linkage), m_languageVersion(languageVersion), m_sink(sink)
    {
        SLANG_RELEASE_ASSERT(languageVersion != SLANG_LANGUAGE_VERSION_UNKNOWN);
    }

    /// Creates a context for an ad hoc checking operation whose primary module may be absent.
    ///
    /// A present module supplies the source-language policy and the moduleless version is ignored.
    /// Otherwise, the caller must provide the version for the ad hoc operation.
    static RefPtr<SharedSemanticsContext> createForOptionalModule(
        Linkage* linkage,
        Module* module,
        SlangLanguageVersion modulelessLanguageVersion,
        DiagnosticSink* sink)
    {
        if (module)
            return new SharedSemanticsContext(linkage, module, sink);
        return new SharedSemanticsContext(linkage, modulelessLanguageVersion, sink);
    }

    Session* getSession() { return m_linkage->getSessionImpl(); }

    Linkage* getLinkage() { return m_linkage; }

    Module* getModule() { return m_module; }

    SlangLanguageVersion getLanguageVersion() const { return m_languageVersion; }

    TranslationUnitRequest* getTranslationUnitRequest() { return m_translationUnitRequest; }

    /// Register an accepted synthesized declaration for eventual whole-module completion.
    ///
    /// `decl` must belong to this context's primary module and be the outermost root of the
    /// synthesized declaration graph, after its parent, scope, signature inputs, and body have
    /// reached their final published form. Registration does not satisfy immediate semantic
    /// dependencies; callers that are about to read checked data must still use the accessor that
    /// establishes the required declaration state.
    void registerSynthesizedDeclRoot(Decl* decl);

    /// Return the number of roots in the persistent synthesized-declaration work list.
    Index getSynthesizedDeclRootCount() const { return m_synthesizedDeclRoots.getCount(); }

    /// Return one root from the persistent synthesized-declaration work list.
    Decl* getSynthesizedDeclRoot(Index index) const { return m_synthesizedDeclRoots[index]; }

    bool isInLanguageServer()
    {
        if (m_linkage)
            return m_linkage->isInLanguageServer();
        return false;
    }
    /// Get the list of extension declarations that appear to apply to `decl` in this context
    List<ExtensionDecl*> const& getCandidateExtensionsForTypeDecl(Decl* decl);

    /// Register a candidate extension `extDecl` for `typeDecl` encountered during checking.
    void registerCandidateExtension(Decl* typeDecl, ExtensionDecl* extDecl);

    /// Invalidate inheritance info for `type`
    void invalidateInheritanceInfo(Type* type);

    /// Try to resolve the endpoint types of `constraintDeclRef` enough to match it
    /// during inheritance computation, for both constraint scans in
    /// `_calcInheritanceInfo` (the access-centric scan for associated-type accesses and
    /// the sub-centric scan for generic type parameters). A leaf endpoint is resolved
    /// eagerly; an unresolved multi-level (member-expression) endpoint is NOT resolved
    /// (doing so would re-enter the in-progress type).
    ///
    /// Returns true if the endpoints are resolved and the caller may proceed to match
    /// the constraint; false if a multi-level endpoint is still unresolved (the caller
    /// then defers the constraint and records it as an in-progress skip).
    bool tryResolveConstraintTypes(DeclRef<GenericTypeConstraintDecl> constraintDeclRef);

    void registerAssociatedDecl(Decl* original, DeclAssociationKind assoc, Decl* declaration);

    List<RefPtr<DeclAssociation>> const& getAssociatedDeclsForDecl(Decl* decl);

    FunctionDifferentiableLevel _getFuncDifferentiableLevelImpl(
        FunctionDeclBase* func,
        int recurseLimit);
    FunctionDifferentiableLevel getFuncDifferentiableLevel(FunctionDeclBase* func);

    struct InheritanceCircularityInfo
    {
        InheritanceCircularityInfo(Decl* decl, InheritanceCircularityInfo* next)
            : decl(decl), next(next)
        {
        }

        /// A declaration whose inheritance is being calculated
        Decl* decl = nullptr;

        /// The rest of the links in the chain of declarations being processed
        InheritanceCircularityInfo* next = nullptr;
    };

    GLSLBindingOffsetTracker* getGLSLBindingOffsetTracker() { return &m_glslBindingOffsetTracker; }

    /// Get the processed inheritance information for `type`, including all its facets.
    ///
    /// `ioSkippedIncompleteFacet` is an internal accumulator used to make
    /// inheritance computation tolerant of *benevolent* cycles introduced by
    /// equality constraints (e.g. an interface `__constraint A == B`, which
    /// makes `T.A` and `T.B` mutual bases). When a computation has to skip a
    /// constraint because its base type is still being computed (an ancestor on
    /// the call stack), the skipped ancestor's `DeclRef` is recorded here so the
    /// caller can tell its result is *contextual* (partial) and must not be
    /// cached. External callers leave it null. See `_getInheritanceInfo` for the
    /// "skipped-ancestors minus self" completeness rule.
    InheritanceInfo getInheritanceInfo(
        Type* type,
        InheritanceCircularityInfo* circularityInfo = nullptr,
        HashSet<DeclRef<Decl>>* ioSkippedIncompleteFacet = nullptr);

    /// Get the processed inheritance information for `extension`, including all its facets
    InheritanceInfo getInheritanceInfo(
        DeclRef<ExtensionDecl> const& extension,
        InheritanceCircularityInfo* circularityInfo = nullptr,
        HashSet<DeclRef<Decl>>* ioSkippedIncompleteFacet = nullptr);

    /// Prevent an unsupported case of
    /// ```
    ///     extension<T:IFoo> : IBar{};
    ///     extesnion<T:IBar> : IFoo{};
    /// ```
    /// from causing infinite recursion.
    bool _checkForCircularityInExtensionTargetType(
        Decl* decl,
        InheritanceCircularityInfo* circularityInfo);

    /// Try get subtype witness from cache, returns true if cache contains a result for the query.
    bool tryGetSubtypeWitnessFromCache(Type* sub, Type* sup, SubtypeWitness*& outWitness);
    void cacheSubtypeWitness(Type* sub, Type* sup, SubtypeWitness*& outWitness);
    ImplicitCastMethod* tryGetImplicitCastMethod(ImplicitCastMethodKey key)
    {
        return m_mapTypePairToImplicitCastMethod.tryGetValue(key);
    }
    void cacheImplicitCastMethod(ImplicitCastMethodKey key, ImplicitCastMethod candidate)
    {
        m_mapTypePairToImplicitCastMethod[key] = candidate;
    }

    bool* isCStyleType(Type* type) { return m_isCStyleTypeCache.tryGetValue(type); }

    void cacheCStyleType(Type* type, bool isCStyle)
    {
        m_isCStyleTypeCache.addIfNotExists(type, isCStyle);
    }
    // Get the inner most generic decl that a decl-ref is dependent on.
    // For example, `Foo<T>` depends on the generic decl that defines `T`.
    //
    DeclRef<GenericDecl> getDependentGenericParent(DeclRef<Decl> declRef);

private:
    /// Mapping from type declarations to the known extensions that apply to them
    Dictionary<Decl*, RefPtr<CandidateExtensionList>> m_mapDeclToCandidateExtensions;

    /// Is the `m_mapTypeDeclToCandidateExtensions` dictionary valid and up to date?
    bool m_candidateExtensionListsBuilt = false;

    /// The count of loadedModulesList when the candidate extension cache was last built.
    /// Used to detect when loadedModulesList has changed and the cache needs updating.
    Index m_candidateExtensionListsBuiltForModuleCount = 0;

    /// Add candidate extensions declared in `moduleDecl` to `m_mapTypeDeclToCandidateExtensions`.
    void _addCandidateExtensionsFromModule(ModuleDecl* moduleDecl);

    /// Mapping from a decl to additional declarations of the same decl.
    /// The additional declarations provide a location to hold extra decorations.
    OrderedDictionary<Decl*, RefPtr<DeclAssociationList>> m_mapDeclToAssociatedDecls;

    /// Is the `m_mapDeclToAssociatedDecls` dictionary valid and up to date?
    bool m_associatedDeclListsBuilt = false;

    /// Add associated decls declared in `moduleDecl` to `m_mapDeclToAssociatedDecls`
    void _addDeclAssociationsFromModule(ModuleDecl* moduleDecl);

    ASTBuilder* _getASTBuilder() { return m_linkage->getASTBuilder(); }

    InheritanceInfo _getInheritanceInfo(
        DeclRef<Decl> declRef,
        Type* selfType,
        InheritanceCircularityInfo* circularityInfo,
        HashSet<DeclRef<Decl>>* ioSkippedIncompleteFacet = nullptr);

    InheritanceInfo _calcInheritanceInfo(
        Type* type,
        InheritanceCircularityInfo* circularityInfo,
        HashSet<DeclRef<Decl>>* ioSkippedIncompleteFacet);

    InheritanceInfo _calcInheritanceInfo(
        DeclRef<Decl> declRef,
        Type* selfType,
        InheritanceCircularityInfo* circularityInfo,
        HashSet<DeclRef<Decl>>* ioSkippedIncompleteFacet);

    /// True if inheritance info for `type` is currently being computed (its
    /// cache entry is marked in-progress) -- i.e. `type` is an ancestor on the
    /// current inheritance-computation stack. Used to detect benevolent cycles.
    bool _isInheritanceInfoBeingComputed(Type* type);

    UInt getDeclExtensionEpoch(Decl* decl) const;
    void bumpDeclExtensionEpoch(Decl* decl);

    bool _isInheritanceInfoCacheEntryUpToDate(InheritanceInfoCacheEntry const& entry) const;

    void _collectInheritanceInfoDependencyEpochs(
        Decl* subjectDecl,
        InheritanceInfo const& info,
        List<DeclExtensionEpochStamp>& outDependencyEpochs) const;

    UInt _getInheritanceInfoCacheGeneration(
        Type* type,
        InheritanceCircularityInfo* circularityInfo = nullptr);

    void getDependentGenericParentImpl(DeclRef<GenericDecl>& genericParent, DeclRef<Decl> declRef);

    struct DirectBaseInfo
    {
        FacetList facets;

        Facet::Impl facetImpl;

        DirectBaseInfo* next = nullptr;
    };

    struct DirectBaseListBuilder;

    struct DirectBaseList
    {
    public:
        struct Iterator
        {
        public:
            Iterator() {}

            Iterator(DirectBaseInfo* cursor)
                : _cursor(cursor)
            {
            }

            bool operator!=(Iterator that) const { return _cursor != that._cursor; }

            void operator++()
            {
                SLANG_ASSERT(_cursor);
                _cursor = _cursor->next;
            }

            DirectBaseInfo* operator*() { return _cursor; }

        private:
            DirectBaseInfo* _cursor = nullptr;
        };

        Iterator begin() const { return Iterator(_head); }
        Iterator end() const { return Iterator(); }

        bool isEmpty() const { return _head == nullptr; }

        bool doesAnyTailContainMatchFor(Facet facet) const;

        void removeEmptyLists();

        typedef DirectBaseListBuilder Builder;

    public:
        DirectBaseInfo* _head = nullptr;
    };

    struct DirectBaseListBuilder : DirectBaseList
    {
    public:
        DirectBaseListBuilder() { _link = &_head; }

        void add(DirectBaseInfo* base)
        {
            *_link = base;
            _link = &base->next;
        }

    private:
        DirectBaseInfo** _link = nullptr;
    };

    void _mergeFacetLists(
        DirectBaseList bases,
        FacetList baseFacets,
        FacetList::Builder& ioMergedFacets);

    /// Rewrite an interface inheritance witness that is still expressed in terms of the
    /// base interface's abstract `This` lookup so it applies to a concrete/new subtype path.
    ///
    /// Inputs:
    /// - `baseInterfaceDecl`: the interface that contributed the original `This` type.
    /// - `selfIsSubtypeOfBase`: witness for `Self : Base`.
    /// - `baseIsSubtypeOfFacet`: witness for `Base : Facet`, expressed using `Base.This`.
    ///
    /// Returns:
    /// - A witness for `Self : Facet` produced by replacing the abstract `Base.This`
    ///   lookup inside `baseIsSubtypeOfFacet` with
    ///   `Lookup(selfIsSubtypeOfBase, baseInterfaceDecl.This)`.
    ///
    /// Examples:
    /// - If `baseIsSubtypeOfFacet` proves `IBase.This : IFacet`, and
    ///   `selfIsSubtypeOfBase` proves `Child : IBase`, the result proves `Child : IFacet`.
    /// - If `baseIsSubtypeOfFacet` proves `IBase.This : IFacet`, and
    ///   `selfIsSubtypeOfBase` proves `IDerived : IBase`, the result proves
    ///   `IDerived : IFacet`.
    ///
    /// This is a centralized workaround until we have a first-class utility for substituting
    /// an interface `This` type and its constraint with a concrete subtype witness.
    SubtypeWitness* _specializeInterfaceInheritanceWitness(
        InterfaceDecl* baseInterfaceDecl,
        SubtypeWitness* selfIsSubtypeOfBase,
        SubtypeWitness* baseIsSubtypeOfFacet);

    Dictionary<Type*, InheritanceInfoCacheEntry> m_mapTypeToInheritanceInfo;
    Dictionary<DeclRef<Decl>, InheritanceInfoCacheEntry> m_mapDeclRefToInheritanceInfo;
    Dictionary<TypePair, SubtypeWitnessCacheEntry> m_mapTypePairToSubtypeWitness;

    /// Cache for `_specializeInterfaceInheritanceWitness`, keyed on its full input.
    ///
    /// That function is a pure transformation of an already-resolved witness (a substitution,
    /// not a conformance query), so unlike the caches above it needs no generation/epoch
    /// tracking: the same three inputs always produce the same output regardless of what
    /// extensions are registered later. `_calcInheritanceInfo` calls it once per inheritance
    /// level while composing a type's transitive facets, so on a deep, non-diamond-shared
    /// inheritance chain (e.g. `interface I64 : I63 : ... : I0`) the same
    /// `(baseInterfaceDecl, selfIsSubtypeOfBase, baseIsSubtypeOfFacet)` triple recurs across many
    /// separate `_calcInheritanceInfo` calls -- each one otherwise re-running a full `Val`
    /// substitution from scratch. See #12139 (the `interface_depth` case left unresolved by that
    /// issue's ShortDictionary fix).
    ///
    /// Unsynchronized, like every other cache on this type: front-end work including
    /// specialization is documented as non-reentrant and requiring external synchronization when
    /// a `SharedSemanticsContext` is shared across threads (docs/user-guide/08-compiling.md,
    /// "Multithreading"), so this needs no lock any more than `m_mapDeclRefToInheritanceInfo`
    /// above does.
    Dictionary<SpecializeInterfaceInheritanceWitnessKey, SubtypeWitness*>
        m_specializeInterfaceInheritanceWitnessCache;
    Dictionary<ImplicitCastMethodKey, ImplicitCastMethod> m_mapTypePairToImplicitCastMethod;
    Dictionary<Type*, bool> m_isCStyleTypeCache;
    Dictionary<Decl*, UInt> m_mapDeclToExtensionEpoch;
    UInt m_nextInheritanceInfoCacheGeneration = 1;
};

/// Local/scoped state of the semantic-checking system
///
/// This type is kept distinct from `SharedSemanticsContext` so that we
/// can avoid unncessary mutable state being propagated through the
/// checking process.
///
/// Semantic-checking code should make a new local `SemanticsContext`
/// in cases where it want to check a sub-entity (expression, statement,
/// declaration, etc.) in a modified or extended context.
///
struct SemanticsContext
{
public:
    friend struct OuterScopeContextRAII;
    friend struct OperandTryCoverageRAII;

    explicit SemanticsContext(SharedSemanticsContext* shared)
        : m_shared(shared)
        , m_sink(shared->getSink())
        , m_astBuilder(shared->getLinkage()->getASTBuilder())
    {
        if (shared->getLinkage()->m_optionSet.hasOption(CompilerOptionName::DisableShortCircuit))
        {
            m_shouldShortCircuitLogicExpr = !shared->getLinkage()->m_optionSet.getBoolOption(
                CompilerOptionName::DisableShortCircuit);
        }
    }

    // This context stores a non-owning pointer. Reject a temporary owner so that its destruction
    // cannot leave `m_shared` dangling. An lvalue `RefPtr` intentionally reaches the raw-pointer
    // constructor through its implicit conversion while the caller keeps that owner in a local.
    SemanticsContext(RefPtr<SharedSemanticsContext>&&) = delete;

    SharedSemanticsContext* getShared() { return m_shared; }
    CompilerOptionSet& getOptionSet() { return getShared()->getOptionSet(); }
    ASTBuilder* getASTBuilder() { return m_astBuilder; }

    /// Return the language of the translation unit being checked.
    ///
    /// Returns `SourceLanguage::Unknown` for reflection and specialization contexts that have no
    /// translation unit.
    SourceLanguage getSourceLanguage()
    {
        auto translationUnit = getShared()->getTranslationUnitRequest();
        return translationUnit ? translationUnit->sourceLanguage : SourceLanguage::Unknown;
    }

    DiagnosticSink* getSink() { return m_sink; }

    Session* getSession() { return m_shared->getSession(); }

    Linkage* getLinkage() { return m_shared->m_linkage; }
    NamePool* getNamePool() { return getLinkage()->getNamePool(); }
    SourceManager* getSourceManager() { return getLinkage()->getSourceManager(); }

    SemanticsContext withSink(DiagnosticSink* sink)
    {
        SemanticsContext result(*this);
        result.m_sink = sink;
        return result;
    }

    FunctionDeclBase* getParentFuncOfVisitor() { return m_parentFunc; }
    void setParentFuncOfVisitor(FunctionDeclBase* funcDecl) { m_parentFunc = funcDecl; }

    SemanticsContext withParentFunc(FunctionDeclBase* parentFunc)
    {
        SemanticsContext result(*this);
        result.m_parentFunc = parentFunc;
        result.m_outerStmts = nullptr;
        result.m_parentDifferentiableAttr = parentFunc->findModifier<DifferentiableAttribute>();
        if (parentFunc->ownedScope)
            result.m_outerScope = parentFunc->ownedScope;
        return result;
    }

    SemanticsContext withParentExpandExpr(ExpandExpr* expr, OrderedHashSet<Val*>* capturedPacks)
    {
        SemanticsContext result(*this);
        result.m_parentExpandExpr = expr;
        result.m_capturedPacks = capturedPacks;
        return result;
    }

    SemanticsContext withParentLambdaExpr(
        LambdaExpr* expr,
        LambdaDecl* decl,
        Dictionary<Decl*, VarDeclBase*>* mapSrcDeclToCapturedLambdaDecl)
    {
        SemanticsContext result(*this);
        result.m_parentLambdaExpr = expr;
        result.m_mapSrcDeclToCapturedLambdaDecl = mapSrcDeclToCapturedLambdaDecl;
        result.m_parentLambdaDecl = decl;
        return result;
    }

    UInt getDefaultCtorRecursionDepth() const { return m_defaultCtorRecursionDepth; }
    void pushDefaultCtorRecursionDepth() { ++m_defaultCtorRecursionDepth; }
    void popDefaultCtorRecursionDepth() { --m_defaultCtorRecursionDepth; }

    /// Tracks a temporary local assumption that a specific pack is non-empty.
    ///
    /// This is needed when checking the non-empty branch operand of a
    /// `__packBranch(...)` type expression: inside that branch we want pack
    /// queries like `__first(...)` / `__trimFirst(...)` on the tested pack to
    /// type-check as if the pack had already been proven non-empty, without
    /// turning that fact into a global constraint or caching it in shared
    /// pack-cardinality state.
    struct AssumedNonEmptyPackInfo
    {
        Val* pack = nullptr;
        AssumedNonEmptyPackInfo* next = nullptr;
    };

    SemanticsContext withAssumedNonEmptyPack(AssumedNonEmptyPackInfo* assumedNonEmptyPack)
    {
        SemanticsContext result(*this);
        result.m_assumedNonEmptyPack = assumedNonEmptyPack;
        return result;
    }

    /// Information for tracking one or more outer statements.
    ///
    /// During checking of statements, we need to track what
    /// outer statements are in scope, so that we can resolve
    /// the target for a `break` or `continue` statement (and
    /// validate that such statements are only used in contexts
    /// where such a target exists).
    ///
    /// We use a linked list of `OuterStmtInfo` threaded up
    /// through the recursive call stack to track the statements
    /// that are lexically surrounding the one we are checking.
    ///
    struct OuterStmtInfo
    {
        Stmt* stmt = nullptr;
        OuterStmtInfo* next;
    };

    OuterStmtInfo* getOuterStmts() { return m_outerStmts; }

    SemanticsContext withOuterStmts(OuterStmtInfo* outerStmts)
    {
        SemanticsContext result(*this);
        result.m_outerStmts = outerStmts;
        return result;
    }

    template<typename T>
    T* FindOuterStmt(Stmt* searchUntil = nullptr)
    {
        for (auto outerStmtInfo = m_outerStmts; outerStmtInfo && outerStmtInfo->stmt != searchUntil;
             outerStmtInfo = outerStmtInfo->next)
        {
            auto outerStmt = outerStmtInfo->stmt;
            auto found = as<T>(outerStmt);
            if (found)
                return found;
        }
        return nullptr;
    }

    // Setup the flag to indicate disabling the short-circuiting evaluation
    // for the logical expressions associted with the subcontext
    SemanticsContext disableShortCircuitLogicalExpr()
    {
        SemanticsContext result(*this);
        result.m_shouldShortCircuitLogicExpr = false;
        return result;
    }

    // Setup the flag to indicate we're in a for-loop side effect context where comma operators are
    // allowed
    SemanticsContext withInForLoopSideEffect()
    {
        SemanticsContext result(*this);
        result.m_inForLoopSideEffect = true;
        return result;
    }

    bool getInForLoopSideEffect() { return m_inForLoopSideEffect; }


    TryClauseType getEnclosingTryClauseType() { return m_enclosingTryClauseType; }

    SemanticsContext withEnclosingTryClauseType(TryClauseType tryClauseType)
    {
        SemanticsContext result(*this);
        result.m_enclosingTryClauseType = tryClauseType;
        return result;
    }

    DifferentiableAttribute* getParentDifferentiableAttribute()
    {
        return m_parentDifferentiableAttr;
    }

    /// A scope that is local to a particular expression, and
    /// that can be used to allocate temporary bindings that
    /// might be needed by that expression or its sub-expressions.
    ///
    /// The scope is represented as a sequence of nested `LetExpr`s
    /// that introduce the bindings needed in the scope.
    ///
    struct ExprLocalScope
    {
    public:
        void addBinding(LetExpr* binding);

        LetExpr* getOuterMostBinding() const { return m_outerMostBinding; }

    private:
        LetExpr* m_outerMostBinding = nullptr;
        LetExpr* m_innerMostBinding = nullptr;
    };

    ExprLocalScope* getExprLocalScope() { return m_exprLocalScope; }
    Scope* getOuterScope() { return m_outerScope; }

    SemanticsContext withExprLocalScope(ExprLocalScope* exprLocalScope)
    {
        SemanticsContext result(*this);
        result.m_exprLocalScope = exprLocalScope;
        return result;
    }

    SemanticsContext withOuterScope(Scope* scope)
    {
        SemanticsContext result(*this);
        result.m_outerScope = scope;
        return result;
    }

    SemanticsContext withTreatAsDifferentiable(TreatAsDifferentiableExpr* expr)
    {
        SemanticsContext result(*this);
        result.m_treatAsDifferentiableExpr = expr;
        return result;
    }

    SemanticsContext allowDroppingDerivatives()
    {
        SemanticsContext result(*this);
        result.m_allowDroppingDerivatives = true;
        return result;
    }

    SemanticsContext allowStaticReferenceToNonStaticMember()
    {
        SemanticsContext result(*this);
        result.m_allowStaticReferenceToNonStaticMember = true;
        return result;
    }

    SemanticsContext withDeclToExcludeFromLookup(Decl* decl)
    {
        SemanticsContext result(*this);
        result.m_declToExcludeFromLookup = decl;
        return result;
    }

    TreatAsDifferentiableExpr* getTreatAsDifferentiableParentExpr()
    {
        return m_treatAsDifferentiableExpr;
    }

    Decl* getDeclToExcludeFromLookup() { return m_declToExcludeFromLookup; }

    SemanticsContext excludeTransparentMembersFromLookup()
    {
        SemanticsContext result(*this);
        result.m_excludeTransparentMembersFromLookup = true;
        return result;
    }

    bool getExcludeTransparentMembersFromLookup() { return m_excludeTransparentMembersFromLookup; }

    bool getAllowDroppingDerivatives() { return m_allowDroppingDerivatives; }

    OrderedHashSet<Val*>* getCapturedPacks() { return m_capturedPacks; }

    GLSLBindingOffsetTracker* getGLSLBindingOffsetTracker()
    {
        return m_shared->getGLSLBindingOffsetTracker();
    }

private:
    SharedSemanticsContext* m_shared = nullptr;

    DiagnosticSink* m_sink = nullptr;

    ExprLocalScope* m_exprLocalScope = nullptr;

    Decl* m_declToExcludeFromLookup = nullptr;

    bool m_excludeTransparentMembersFromLookup = false;

protected:
    // TODO: consider making more of this state `private`...

    /// The parent function (if any) that surrounds the statement being checked.
    FunctionDeclBase* m_parentFunc = nullptr;

    DifferentiableAttribute* m_parentDifferentiableAttr = nullptr;

    /// The linked list of lexically surrounding statements.
    OuterStmtInfo* m_outerStmts = nullptr;

    /// Whether an expr referencing to a non-static member in static style (e.g. `Type.member`)
    /// is considered valid in the current context.
    bool m_allowStaticReferenceToNonStaticMember = false;

    bool m_allowDroppingDerivatives = false;

    /// The type of the try clause (if any) that covers the call being checked. A `try` covers only
    /// the call it wraps, so `visitInvokeExpr`, `visitIndexExpr` and `visitTypeCastExpr` check
    /// their operands under an `OperandTryCoverageRAII`, where this is `None`.
    TryClauseType m_enclosingTryClauseType = TryClauseType::None;

    /// The throwing calls whose coverage waits for the single-argument call around them to
    /// resolve. Consider `try int(f())` where `f` returns `int`: `ResolveInvoke` reduces the
    /// identity conversion `int(...)` to `f()` itself, so the `try` covers `f()`, but that is only
    /// known after `f()` has been checked. Any other kind of operand is checked with this null.
    List<InvokeExpr*>* m_pendingTryCoverage = nullptr;

    /// Whether or not we are in a `no_diff` environment (and therefore should treat the call to
    /// a non-differentiable function as differentiable and not issue a diagnostic).
    TreatAsDifferentiableExpr* m_treatAsDifferentiableExpr = nullptr;

    ASTBuilder* m_astBuilder = nullptr;

    Scope* m_outerScope = nullptr;

    // By default, we will support short-circuit evaluation for the logic expression.
    // However, there are few exceptions where we will disable it:
    // 1. the logic expression is inside the generic parameter list.
    // 2. the logic expression is in the init expression of a static const variable.
    // 3. the logic expression is in an array size declaration.
    bool m_shouldShortCircuitLogicExpr = true;

    // Flag to track when we're in a for-loop side effect expression where comma operators are
    // allowed
    bool m_inForLoopSideEffect = false;

    // Recursion depth for synthesizing nested default-constructor/default-init expressions.
    UInt m_defaultCtorRecursionDepth = 0;


    ExpandExpr* m_parentExpandExpr = nullptr;

    OrderedHashSet<Val*>* m_capturedPacks = nullptr;

    // If we are checking inside a lambda expression, we need
    // to track the referenced variables that should be captured
    // by the lambda.
    LambdaExpr* m_parentLambdaExpr = nullptr;
    LambdaDecl* m_parentLambdaDecl = nullptr;
    Dictionary<Decl*, VarDeclBase*>* m_mapSrcDeclToCapturedLambdaDecl = nullptr;
    AssumedNonEmptyPackInfo* m_assumedNonEmptyPack = nullptr;
};

struct OuterScopeContextRAII
{
    SemanticsContext* m_context;
    Scope* m_oldOuterScope;

    OuterScopeContextRAII(SemanticsContext* context, Scope* outerScope)
        : m_context(context), m_oldOuterScope(context->getOuterScope())
    {
        context->m_outerScope = outerScope;
    }

    ~OuterScopeContextRAII() { m_context->m_outerScope = m_oldOuterScope; }
};

/// Checks the operands of a call, which a `try` on that call does not cover, on the current
/// context for the lifetime of this object. A throwing call found in an operand is diagnosed, or
/// collected in `pendingTryCoverage` when that is non-null (see `m_pendingTryCoverage`).
///
/// We change the context in place so that each recursive operand level does not hold a copy of it;
/// a long operator chain, as in `tests/glsl-intrinsic/intrinsic-texture.slang`, would otherwise
/// overflow the stack of a Debug build.
struct OperandTryCoverageRAII
{
    SemanticsContext* m_context;
    TryClauseType m_oldEnclosingTryClauseType;
    List<InvokeExpr*>* m_oldPendingTryCoverage;

    OperandTryCoverageRAII(SemanticsContext* context, List<InvokeExpr*>* pendingTryCoverage)
        : m_context(context)
        , m_oldEnclosingTryClauseType(context->m_enclosingTryClauseType)
        , m_oldPendingTryCoverage(context->m_pendingTryCoverage)
    {
        context->m_enclosingTryClauseType = TryClauseType::None;
        context->m_pendingTryCoverage = pendingTryCoverage;
    }

    ~OperandTryCoverageRAII()
    {
        m_context->m_enclosingTryClauseType = m_oldEnclosingTryClauseType;
        m_context->m_pendingTryCoverage = m_oldPendingTryCoverage;
    }
};

#define SLANG_OUTER_SCOPE_CONTEXT_RAII(context, scope) \
    OuterScopeContextRAII _outerScopeContextRAII(context, scope)
#define SLANG_OUTER_SCOPE_CONTEXT_DECL_RAII(context, decl) \
    OuterScopeContextRAII _outerScopeContextRAII(          \
        context,                                           \
        decl->ownedScope ? decl->ownedScope : context->getOuterScope())

struct RequirementSynthesisResult
{
    bool suceeded = false;
    operator bool() const { return suceeded; }
};

struct SemanticsVisitor : public SemanticsContext
{
    typedef SemanticsContext Super;

    explicit SemanticsVisitor(SharedSemanticsContext* shared)
        : Super(shared)
    {
    }

    // Keep direct visitor construction subject to the ownership rule on `SemanticsContext`; an
    // lvalue `RefPtr` still reaches the raw-pointer constructor through its implicit conversion.
    SemanticsVisitor(RefPtr<SharedSemanticsContext>&&) = delete;

    SemanticsVisitor(SemanticsContext const& context)
        : Super(context)
    {
    }

    CompilerOptionSet& getOptionSet() { return getShared()->getOptionSet(); }

    /// Diagnose a diagnostic only once per unique key (diagnostic ID + location + parameters).
    /// Useful for avoiding duplicate warnings in loops over aggregate elements.
    template<typename... Args>
    void diagnoseOnce(SourceLoc loc, DiagnosticInfo const& diagnostic, Args&&... args)
    {
        // Key = diagnostic ID + source location + all parameters
        StringBuilder keyBuilder;
        keyBuilder << diagnostic.id << "|" << loc.getRaw();
        if constexpr (sizeof...(args) > 0)
        {
            ((keyBuilder << "|" << args), ...); // Fold expression to append all args
        }
        String key = keyBuilder.produceString();
        if (!getShared()->m_reportedDiagnosticKeys.add(key))
            return; // Already reported
        getSink()->diagnose(loc, diagnostic, std::forward<Args>(args)...);
    }

    /// Diagnose a rich diagnostic only once per unique key (diagnostic ID + serialized content).
    template<typename D>
    void diagnoseOnce(D const& diagnostic)
    {
        auto genericDiag = diagnostic.toGenericDiagnostic();
        StringBuilder keyBuilder;
        keyBuilder << D::getInfo()->id;
        keyBuilder << "|" << genericDiag.primarySpan.range.begin.getRaw();
        keyBuilder << "|" << genericDiag.primarySpan.message;
        String key = keyBuilder.produceString();
        if (!getShared()->m_reportedDiagnosticKeys.add(key))
            return; // Already reported
        getSink()->diagnose(diagnostic);
    }

public:
    // Translate Types


    Expr* TranslateTypeNodeImpl(Expr* node);
    Type* ExtractTypeFromTypeRepr(Expr* typeRepr);
    Type* TranslateTypeNode(Expr* node);
    TypeExp TranslateTypeNodeForced(TypeExp const& typeExp);
    TypeExp TranslateTypeNode(TypeExp const& typeExp);
    Type* getRemovedModifierType(ModifiedType* type, ModifierVal* modifier);
    Type* getConstantBufferType(Type* elementType, Type* layoutType);
    DeclRefType* getExprDeclRefType(Expr* expr);
    LookupResult lookupConstructorsInType(Type* type, Scope* sourceScope);

    /// Is `decl` usable as a static member?
    bool isDeclUsableAsStaticMember(Decl* decl);

    /// Is `item` usable as a static member?
    bool isUsableAsStaticMember(LookupResultItem const& item);

    /// Move `expr` into a temporary variable and execute `func` on that variable.
    ///
    /// Returns an expression that wraps both the creation and initialization of
    /// the temporary, and the computation created by `func`.
    ///
    template<typename F>
    Expr* moveTemp(Expr* const& expr, F const& func);

    /// Execute `func` on a variable with the value of `expr`.
    ///
    /// If `expr` is just a reference to an immutable (e.g., `let`) variable
    /// then this might use the existing variable. Otherwise it will create
    /// a new variable to hold `expr`, using `moveTemp()`.
    ///
    template<typename F>
    Expr* maybeMoveTemp(Expr* const& expr, F const& func);

    /// Return an expression that represents "opening" the existential `expr`.
    ///
    /// The type of `expr` must be an interface type, matching `interfaceDeclRef`.
    ///
    /// If we scope down the PL theory to just the case that Slang cares about,
    /// a value of an existential type like `IMover` is a tuple of:
    ///
    ///  * a concrete type `X`
    ///  * a witness `w` of the fact that `X` implements `IMover`
    ///  * a value `v` of type `X`
    ///
    /// "Opening" an existential value is the process of decomposing a single
    /// value `e : IMover` into the pieces `X`, `w`, and `v`.
    ///
    /// Rather than return all those pieces individually, this operation
    /// returns an expression that logically corresponds to `v`: an expression
    /// of type `X`, where the type carries the knowledge that `X` implements `IMover`.
    ///
    Expr* openExistential(Expr* expr, DeclRef<InterfaceDecl> interfaceDeclRef);

    /// If `expr` has existential type, then open it.
    ///
    /// Returns an expression that opens `expr` if it had existential type.
    /// Otherwise returns `expr` itself.
    ///
    /// See `openExistential` for a discussion of what "opening" an
    /// existential-type value means.
    ///
    Expr* maybeOpenExistential(Expr* expr);

    /// If `expr` has Ref<T> Type, convert it into an l-value expr that has T type.
    Expr* maybeOpenRef(Expr* expr);

    Scope* getScope(SyntaxNode* node);

    /// Diagnose use of a deprecated or removed declaration at `loc`.
    ///
    /// Requires a resolved `declRef` and a diagnostic sink. Uses the current module's language
    /// version to decide whether removal applies; reports nothing when no module is available.
    /// Inspects `originalExpr`, when non-null, to suppress repeats and uses at the declaration's
    /// name location.
    void diagnoseDeprecatedAndRemovedDeclRefUsage(
        DeclRef<Decl> declRef,
        SourceLoc loc,
        Expr* originalExpr);

    DeclRef<Decl> getDefaultDeclRef(Decl* decl)
    {
        return createDefaultSubstitutionsIfNeeded(m_astBuilder, this, makeDeclRef(decl));
    }

    DeclRef<Decl> getSpecializedDeclRef(
        DeclRef<Decl> declToSpecialize,
        DeclRef<Decl> declRefWithSpecializationArgs)
    {
        return declRefWithSpecializationArgs.substitute(m_astBuilder, declToSpecialize);
    }

    DeclRef<Decl> getSpecializedDeclRef(
        Decl* declToSpecialize,
        DeclRef<Decl> declRefWithSpecializationArgs)
    {
        return declRefWithSpecializationArgs.substitute(
            m_astBuilder,
            getDefaultDeclRef(declToSpecialize));
    }

    /// Construct a checked variable or member expression for `declRef`.
    ///
    /// Requires a resolved declaration reference and a checked `baseExpr` when one is provided.
    /// Selects the expression kind from the base and whether the declaration is static. The result
    /// includes the declaration's type and the read/write restrictions of any instance-member
    /// access.
    DeclRefExpr* ConstructDeclRefExpr(
        DeclRef<Decl> declRef,
        Expr* baseExpr,
        Name* name,
        SourceLoc loc,
        Expr* originalExpr);

    Expr* ConstructDerefExpr(Expr* base, SourceLoc loc);
    Expr* constructDerefExpr(Expr* base, QualType elementType, SourceLoc loc);

    InvokeExpr* constructUncheckedInvokeExpr(Expr* callee, const List<Expr*>& arguments);

    Expr* maybeUseSynthesizedDeclForLookupResult(LookupResultItem const& item, Expr* orignalExpr);

    Expr* ConstructLookupResultExpr(
        LookupResultItem const& item,
        Expr* baseExpr,
        Name* name,
        SourceLoc loc,
        Expr* originalExpr);

    Expr* createLookupResultExpr(
        Name* name,
        LookupResult const& lookupResult,
        Expr* baseExpr,
        SourceLoc loc,
        Expr* originalExpr);

    DeclVisibility getTypeVisibility(Type* type);
    bool isDeclVisibleFromScope(DeclRef<Decl> declRef, Scope* scope);
    LookupResult filterLookupResultByVisibility(const LookupResult& lookupResult);
    LookupResult filterLookupResultByVisibilityAndDiagnose(
        const LookupResult& lookupResult,
        SourceLoc loc,
        bool& outDiagnosed);

    bool isWitnessUncheckedOptional(SubtypeWitness* witness);
    LookupResult filterLookupResultByCheckedOptional(const LookupResult& lookupResult);
    LookupResult filterLookupResultByCheckedOptionalAndDiagnose(
        const LookupResult& lookupResult,
        SourceLoc loc,
        bool& outDiagnosed);

    Val* resolveVal(Val* val)
    {
        if (!val)
            return nullptr;
        return val->resolve();
    }

    Type* resolveType(Type* type);

    DeclRef<Decl> resolveDeclRef(DeclRef<Decl> declRef);

    /// Attempt to "resolve" an overloaded `LookupResult` to only include the "best" results
    LookupResult resolveOverloadedLookup(LookupResult const& lookupResult, Type* targetType);
    inline LookupResult resolveOverloadedLookup(LookupResult const& lookupResult)
    {
        return resolveOverloadedLookup(lookupResult, nullptr);
    }

    /// Attempt to resolve `expr` into an expression that refers to a single declaration/value.
    /// If `expr` isn't overloaded, then it will be returned as-is.
    ///
    /// The provided `mask` is used to filter items down to those that are applicable in a given
    /// context (e.g., just types).
    ///
    /// If the expression cannot be resolved to a single value then *if* `diagSink` is non-null an
    /// appropriate "ambiguous reference" error will be reported, and an error expression will be
    /// returned. Otherwise, the original expression is returned if resolution fails.
    ///
    Expr* maybeResolveOverloadedExpr(
        Expr* expr,
        LookupMask mask,
        Type* targetType,
        DiagnosticSink* diagSink);

    inline Expr* maybeResolveOverloadedExpr(Expr* expr, LookupMask mask, DiagnosticSink* diagSink)
    {
        return maybeResolveOverloadedExpr(expr, mask, nullptr, diagSink);
    }

    /// Attempt to resolve `overloadedExpr` into an expression that refers to a single
    /// declaration/value.
    ///
    /// Equivalent to `maybeResolveOverloadedExpr` with `diagSink` bound to the sink for the
    /// `SemanticsVisitor`.
    Expr* resolveOverloadedExpr(OverloadedExpr* overloadedExpr, Type* targetType, LookupMask mask);
    inline Expr* resolveOverloadedExpr(OverloadedExpr* overloadedExpr, LookupMask mask)
    {
        return resolveOverloadedExpr(overloadedExpr, nullptr, mask);
    }

    bool hasNonEmptyPackConstraint(Decl* decl);
    VariadicPackCardinality getPackCardinality(Val* packVal);
    bool isKnownNonEmptyPack(Val* packVal);

    /// Worker reoutine for `maybeResolveOverloadedExpr` and `resolveOverloadedExpr`.
    Expr* _resolveOverloadedExprImpl(
        OverloadedExpr* overloadedExpr,
        LookupMask mask,
        Type* targetType,
        DiagnosticSink* diagSink);

    void diagnoseAmbiguousReference(
        OverloadedExpr* overloadedExpr,
        LookupResult const& lookupResult);
    void diagnoseAmbiguousReference(Expr* overloadedExpr);
    bool maybeDiagnoseAmbiguousReference(Expr* overloadedExpr);

    Expr* ExpectATypeRepr(Expr* expr);

    Type* ExpectAType(Expr* expr);

    Type* ExtractGenericArgType(Expr* exp);

    enum class ConstantFoldingKind
    {
        CompileTime,
        LinkTime,
        SpecializationConstant
    };

    struct ConstantFoldingCircularityInfo;

    IntVal* ExtractGenericArgInteger(
        Expr* exp,
        Type* genericParamType,
        ConstantFoldingKind kind,
        DiagnosticSink* sink,
        ConstantFoldingCircularityInfo* circularityInfo = nullptr);
    IntVal* ExtractGenericArgInteger(Expr* exp, Type* genericParamType);

    Val* ExtractGenericArgVal(Expr* exp, ConstantFoldingCircularityInfo* circularityInfo = nullptr);

    // Construct a type representing the instantiation of
    // the given generic declaration for the given arguments.
    // The arguments should already be checked against
    // the declaration.
    Type* InstantiateGenericType(DeclRef<GenericDecl> genericDeclRef, List<Expr*> const& args);

    // These routines are bottlenecks for semantic checking,
    // so that we can add some quality-of-life features for users
    // in cases where the compiler crashes
    //
    void dispatchStmt(Stmt* stmt, SemanticsContext const& context);
    Expr* dispatchExpr(Expr* expr, SemanticsContext const& context);

    /// Ensure that a declaration has been checked up to some state
    /// (aka, a phase of semantic checking) so that we can safely
    /// perform certain operations on it.
    ///
    /// Calling `ensureDecl` may cause the type-checker to recursively
    /// start checking `decl` on top of the stack that is already
    /// doing other semantic checking. Care should be taken when relying
    /// on this function to avoid blowing out the stack or (even worse
    /// creating a circular dependency).
    ///
    void ensureDecl(Decl* decl, DeclCheckState state, SemanticsContext* baseContext = nullptr);

    /// Helper routine allowing `ensureDecl` to be called on a `DeclRef`
    void ensureDecl(DeclRefBase* declRef, DeclCheckState state)
    {
        ensureDecl(declRef->getDecl(), state);
    }

    void ensureAllDeclsRec(Decl* decl, DeclCheckState state);

    /// Advance every published synthesized declaration root to `state`.
    ///
    /// The live list is iterated by index so checking one root can publish another root for the
    /// same phase. The registry remains intact after this operation for all later phases.
    void ensureRegisteredSynthesizedDecls(DeclCheckState state);

    /// Helper routine allowing `ensureDecl` to be used on a `DeclBase`
    ///
    /// `DeclBase` is the base clas of `Decl` and `DeclGroup`. When
    /// called on a `DeclGroup` this function just calls `ensureDecl()`
    /// on each declaration in the group.
    ///
    void ensureDeclBase(DeclBase* decl, DeclCheckState state, SemanticsContext* baseContext);

    void ensureOuterGenericConstraints(Decl* decl, DeclCheckState state);

    // Check if `lambdaStruct` can be coerced to `funcType`, if so returns the coerced
    // expression in `outExpr`. The coercion is only valid if the lambda struct
    // does not contain any captures.
    bool tryCoerceLambdaToFuncType(
        DeclRef<StructDecl> lambdaStruct,
        FuncType* funcType,
        Expr* fromExpr,
        Expr** outExpr);

    // A "proper" type is one that can be used as the type of an expression.
    // Put simply, it can be a concrete type like `int`, or a generic
    // type that is applied to arguments, like `Texture2D<float4>`.
    // The type `void` is also a proper type, since we can have expressions
    // that return a `void` result (e.g., many function calls).
    //
    // A "non-proper" type is any type that can't actually have values.
    // A simple example of this in C++ is `std::vector` - you can't have
    // a value of this type.
    //
    // Part of what this function does is give errors if somebody tries
    // to use a non-proper type as the type of a variable (or anything
    // else that needs a proper type).
    //
    // The other thing it handles is the fact that HLSL lets you use
    // the name of a non-proper type, and then have the compiler fill
    // in the default values for its type arguments (e.g., a variable
    // given type `Texture2D` will actually have type `Texture2D<float4>`).
    bool CoerceToProperTypeImpl(
        TypeExp const& typeExp,
        Type** outProperType,
        DiagnosticSink* diagSink);

    TypeExp CoerceToProperType(TypeExp const& typeExp);

    TypeExp tryCoerceToProperType(TypeExp const& typeExp);

    // Check a type, and coerce it to be proper
    TypeExp CheckProperType(TypeExp typeExp);

    // For our purposes, a "usable" type is one that can be
    // used to declare a function parameter, variable, etc.
    // These turn out to be all the proper types except
    // `void`.
    //
    // TODO(tfoley): consider just allowing `void` as a
    // simple example of a "unit" type, and get rid of
    // this check.
    TypeExp CoerceToUsableType(TypeExp const& typeExp, Decl* decl);

    // Check a type, and coerce it to be usable
    TypeExp CheckUsableType(TypeExp typeExp, Decl* decl);

    Expr* CheckTerm(Expr* term);

    Expr* _CheckTerm(Expr* term);

    /// Checks an object-oriented `this` expression without registering a lambda capture.
    ///
    /// `ConstructLookupResultExpr` uses this operation when it reconstructs an implicit `this`
    /// expression, because capture registration belongs to the surrounding expression-checking
    /// path. The ordinary `this` expression visitor registers its own capture after calling this
    /// operation.
    Expr* checkThisExprWithoutCapturing(ThisExpr* expr);

    /// If inside a lambda body, check whether `exprIn` (or its base sub-expression chain)
    /// references an outer-scope variable that needs to be captured into the lambda struct.
    /// This handles the case where an expression was already checked by the parser's
    /// two-phase generic disambiguation before the lambda capture context was established.
    Expr* maybeRegisterLambdaCapture(Expr* exprIn);

    Expr* CreateErrorExpr(Expr* expr);

    bool IsErrorExpr(Expr* expr);

    // Capture the "base" expression in case this is a member reference
    Expr* GetBaseExpr(Expr* expr);

    /// Validate a declaration to ensure that it doesn't introduce a circularly-defined constant
    ///
    /// Circular definition in a constant may lead to infinite looping or stack overflow in
    /// the compiler, so it needs to be protected against.
    ///
    /// Note that this function does *not* protect against circular definitions in general,
    /// and a program that indirectly initializes a global variable using its own value (e.g.,
    /// by calling a function that indirectly reads the variable) will be allowed and then
    /// exhibit undefined behavior at runtime.
    ///
    IntVal* _validateCircularVarDefinition(VarDeclBase* varDecl);

    bool shouldSkipChecking(Decl* decl, DeclCheckState state);

    // Auto-diff convenience functions for translating primal types to differential types.
    Type* _toDifferentialParamType(Type* primalType);

    Type* tryGetDifferentialPairType(Type* primalType);

    // Convert a function's original type to it's forward/backward diff'd type.
    Type* getForwardDiffFuncType(FuncType* originalType, std::optional<ParamInfo> thisParamInfo);
    Type* getBackwardDiffFuncType(
        FuncType* originalType,
        std::optional<ParamInfo> thisParamInfo = std::nullopt);

    /// Registers a type as conforming to IDifferentiable, along with a witness
    /// describing the relationship.
    ///
    void maybeRegisterDifferentiableTypeImplRecursive(ASTBuilder* builder, Type* type);

    // Construct the differential for 'type', if it exists.
    Type* getDifferentialType(ASTBuilder* builder, Type* type, SourceLoc loc);
    Type* tryGetDifferentialType(ASTBuilder* builder, Type* type);
    Type* tryGetDifferentialValueType(ASTBuilder* builder, Type* type);
    Type* tryGetDifferentialPtrType(ASTBuilder* builder, Type* type);


    // Helper function to check if a struct can be used as its own differential type.
    bool canStructBeUsedAsSelfDifferentialType(AggTypeDecl* aggTypeDecl);
    void markSelfDifferentialMembersOfType(AggTypeDecl* parent, Type* type);

    void checkDerivativeMemberAttributeReferences(
        VarDeclBase* varDecl,
        DerivativeMemberAttribute* derivativeMemberAttr);

public:
    bool ValuesAreEqual(IntVal* left, IntVal* right);

    // Compute the cost of using a particular declaration to
    // perform implicit type conversion.
    ConversionCost getImplicitConversionCost(Decl* decl);

    ConversionCost getImplicitConversionCostWithKnownArg(
        DeclRef<Decl> decl,
        Type* toType,
        Expr* arg);


    BuiltinConversionKind getImplicitConversionBuiltinKind(Decl* decl);

    bool isEffectivelyScalarForInitializerLists(Type* type);

    /// Should the provided expression (from an initializer list) be used directly to initialize
    /// `toType`?
    bool shouldUseInitializerDirectly(Type* toType, Expr* fromExpr);

    /// Read a value from an initializer list expression.
    ///
    /// This reads one or more argument from the initializer list
    /// given as `fromInitializerListExpr` to initialize a value
    /// of type `toType`. This may involve reading one or
    /// more arguments from the initializer list, depending
    /// on whether `toType` is an aggregate or not, and on
    /// whether the next argument in the initializer list is
    /// itself an initializer list.
    ///
    /// This routine returns `true` if it was able to read
    /// arguments that can form a value of type `toType`,
    /// and `false` otherwise.
    ///
    /// If the routine succeeds and `outToExpr` is non-null,
    /// then it will be filled in with an expression
    /// representing the value (or type `toType`) that was read,
    /// or it will be left null to indicate that a default
    /// value should be used.
    ///
    /// If the routine fails and `outToExpr` is non-null,
    /// then a suitable diagnostic will be emitted.
    ///
    bool _readValueFromInitializerList(
        Type* toType,
        Expr** outToExpr,
        InitializerListExpr* fromInitializerListExpr,
        UInt& ioInitArgIndex);

    /// Read an aggregate value from an initializer list expression.
    ///
    /// This reads one or more arguments from the initializer list
    /// given as `fromInitializerListExpr` to initialize the
    /// fields/elements of a value of type `toType`.
    ///
    /// This routine returns `true` if it was able to read
    /// arguments that can form a value of type `toType`,
    /// and `false` otherwise.
    ///
    /// If the routine succeeds and `outToExpr` is non-null,
    /// then it will be filled in with an expression
    /// representing the value (or type `toType`) that was read,
    /// or it will be left null to indicate that a default
    /// value should be used.
    ///
    /// If the routine fails and `outToExpr` is non-null,
    /// then a suitable diagnostic will be emitted.
    ///
    bool _readAggregateValueFromInitializerList(
        Type* inToType,
        Expr** outToExpr,
        InitializerListExpr* fromInitializerListExpr,
        UInt& ioArgIndex);

    /// Coerce an initializer-list expression to a specific type.
    ///
    /// This reads one or more arguments from the initializer list
    /// given as `fromInitializerListExpr` to initialize the
    /// fields/elements of a value of type `toType`.
    ///
    /// This routine returns `true` if it was able to read
    /// arguments that can form a value of type `toType`,
    /// with no arguments left over, and `false` otherwise.
    ///
    /// If the routine succeeds and `outToExpr` is non-null,
    /// then it will be filled in with an expression
    /// representing the value (or type `toType`) that was read,
    /// or it will be left null to indicate that a default
    /// value should be used.
    ///
    /// If the routine fails and `outToExpr` is non-null,
    /// then a suitable diagnostic will be emitted.
    ///
    bool _coerceInitializerList(
        Type* toType,
        Expr** outToExpr,
        InitializerListExpr* fromInitializerListExpr);

    /// Report that implicit type coercion is not possible.
    bool _failedCoercion(Type* toType, Expr** outToExpr, Expr* fromExpr, DiagnosticSink* sink);

    /// Central engine for implementing implicit coercion logic
    ///
    /// This function tries to find an implicit conversion path from
    /// `fromType` to `toType`. It returns `true` if a conversion
    /// is found, and `false` if not.
    ///
    /// If a conversion is found, then its cost will be written to `outCost`.
    ///
    /// If a `fromExpr` is provided, it must be of type `fromType`,
    /// and represent a value to be converted.
    ///
    /// If `outToExpr` is non-null, and if a conversion is found, then
    /// `*outToExpr` will be set to an expression that performs the
    /// implicit conversion of `fromExpr` (which must be non-null
    /// to `toType`).
    ///
    /// The case where `outToExpr` is non-null is used to identify
    /// when a conversion is being done "for real" so that diagnostics
    /// should be emitted on failure.
    ///
    /// If `outWitnessOfConversion` is non-null and zero valid conversions are found
    /// `outWitnessOfConversion` will be set to a `nullptr`.
    ///
    /// If `outWitnessOfConversion` is non-null and a conversion is found,
    /// `outWitnessOfConversion` will either be set to:
    /// (1) `BuiltinTypeCoercionWitness*` to signify that Slang casts without
    /// a user-definition.
    /// (2) `DeclRefTypeCoercionWitness*` to signify that Slang will cast
    /// via a user-definition.
    /// (3) `nullptr` to signify that the case is unhandled and should be handled
    ///
    bool _coerce(
        CoercionSite site,
        Type* toType,
        Expr** outToExpr,
        QualType fromType,
        Expr* fromExpr,
        DiagnosticSink* sink,
        ConversionCost* outCost,
        TypeCoercionWitness** outWitnessOfConversion);

    /// Determine whether an unscoped enum may implicitly convert to the builtin
    /// scalar type `toType`. This is an HLSL-compatibility widening: it holds
    /// only for an enum that `isUnscopedEnum`
    /// accepts (one carrying `UnscopedEnumAttribute`, from either `-unscoped-enum`
    /// or an explicit `[UnscopedEnum]` — see that predicate for the exact routes),
    /// in a translation unit using the HLSL-flavored dialect, and never for `bool`
    /// (which already has its own implicit conversion from any `__EnumType`).
    bool isEnumToBuiltinScalarConversionEnabled(EnumDecl* enumDecl, Type* toType);

    /// Check whether implicit type coercion from `fromType` to `toType` is possible.
    ///
    /// If conversion is possible, returns `true` and sets `outCost` to the cost
    /// of the conversion found (if `outCost` is non-null).
    ///
    /// If conversion is not possible, returns `false`.
    ///
    bool canCoerce(Type* toType, QualType fromType, Expr* fromExpr, ConversionCost* outCost = 0);

    TypeCastExpr* createImplicitCastExpr();

    Expr* CreateImplicitCastExpr(Type* toType, Expr* fromExpr);

    /// Create an "up-cast" from a value to an interface type
    ///
    /// This operation logically constructs an "existential" value,
    /// which packages up the value, its type, and the witness
    /// of its conformance to the interface.
    ///
    Expr* createCastToInterfaceExpr(Type* toType, Expr* fromExpr, Val* witness);

    /// Implicitly coerce `fromExpr` to `toType` and diagnose errors if it isn't possible
    Expr* coerce(CoercionSite site, Type* toType, Expr* fromExpr, DiagnosticSink* sink);

    // Fill in default substitutions for the 'subtype' part of a type constraint decl
    void CheckConstraintSubType(TypeExp& typeExp);

    void checkGenericDeclHeader(GenericDecl* genericDecl);

    IntVal* checkLinkTimeConstantIntVal(Expr* expr);

    ConstantIntVal* checkConstantIntVal(Expr* expr);

    ConstantIntVal* checkConstantEnumVal(Expr* expr);

    // Check an expression, coerce it to the `String` type, and then
    // ensure that it has a literal (not just compile-time constant) value.
    bool checkLiteralStringVal(Expr* expr, String* outVal);

    bool checkCapabilityName(Expr* expr, CapabilityName& outCapabilityName);

    void visitModifier(Modifier*);

    DeclRef<VarDeclBase> tryGetIntOrEnumSpecializationConstant(Expr* expr);

    AttributeDecl* lookUpAttributeDecl(Name* attributeName, Scope* scope);

    bool hasFloatArgs(Attribute* attr, int numArgs);
    bool hasIntArgs(Attribute* attr, int numArgs);
    bool hasStringArgs(Attribute* attr, int numArgs);

    bool getAttributeTargetSyntaxClasses(SyntaxClass<NodeBase>& cls, uint32_t typeFlags);

    // Check an attribute, and return a checked modifier that represents it.
    //
    Modifier* validateAttribute(
        Attribute* attr,
        AttributeDecl* attribClassDecl,
        ModifiableSyntaxNode* attrTarget);

    AttributeBase* checkAttribute(
        UncheckedAttribute* uncheckedAttr,
        ModifiableSyntaxNode* attrTarget);

    AttributeDecl* findOrSynthesizeAttributeDeclFromUserDefinedAttributeStruct(
        StructDecl* attributeTypeDecl);

    AttributeBase* checkGLSLLayoutAttribute(
        UncheckedGLSLLayoutAttribute* uncheckedAttr,
        ModifiableSyntaxNode* attrTarget);

    Modifier* checkModifier(
        Modifier* m,
        ModifiableSyntaxNode* syntaxNode,
        bool ignoreUnallowedModifier);

    void checkModifiers(ModifiableSyntaxNode* syntaxNode);

    /// Diagnoses repeated or conflicting receiver parameter mode specifiers attached to `decl`.
    ///
    /// Requires checked modifiers, so attributes have their concrete attribute classes.
    void checkReceiverParamModeSpecifiers(Decl* decl);

    void checkVisibility(Decl* decl);

    bool doesAccessorMatchRequirement(
        DeclRef<AccessorDecl> satisfyingMemberDeclRef,
        DeclRef<AccessorDecl> requiredMemberDeclRef);

    bool doesPropertyMatchRequirement(
        DeclRef<PropertyDecl> satisfyingMemberDeclRef,
        DeclRef<PropertyDecl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable);

    bool doesSubscriptMatchRequirement(
        DeclRef<SubscriptDecl> satisfyingMemberDeclRef,
        DeclRef<SubscriptDecl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable);

    bool doesVarMatchRequirement(
        DeclRef<VarDeclBase> satisfyingMemberDeclRef,
        DeclRef<VarDeclBase> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable);

    bool doesGenericSignatureMatchRequirement(
        DeclRef<GenericDecl> genDecl,
        DeclRef<GenericDecl> requirementGenDecl,
        RefPtr<WitnessTable> witnessTable);

    bool doesTypeSatisfyConstraintRequirements(
        DeclRef<ContainerDecl> requirementDeclRef,
        RefPtr<WitnessTable> witnessTable);

    bool doesTypeSatisfyAssociatedTypeRequirement(
        Type* satisfyingType,
        DeclRef<AssocTypeDecl> requiredAssociatedTypeDeclRef,
        RefPtr<WitnessTable> witnessTable);

    // Does the given `memberDecl` work as an implementation
    // to satisfy the requirement `requiredMemberDeclRef`
    // from an interface?
    //
    // If it does, then inserts a witness into `witnessTable`
    // and returns `true`, otherwise returns `false`

    // State used while checking if a declaration (either a type declaration
    // or an extension of that type) conforms to the interfaces it claims
    // via its inheritance clauses.
    //
    using ConformanceCheckingContext = Slang::ConformanceCheckingContext;
    using ConformanceInterfaceCheckingState = Slang::ConformanceInterfaceCheckingState;

    // Requirement resolution reports state at several adjacent layers:
    //
    // * `RequirementCheckState` persists the state of one entry in a `WitnessTable`, while
    //   `ConformanceInterfaceCheckStatus` persists whole-table traversal state.
    // * `RequirementWitnessLookupFrontierStatus` describes how far passive structural lookup got.
    // * `ConformanceRequirementCheckResult` reports one semantic attempt to populate an entry.
    // * `RequirementLookupStatus` reports forceful traversal of a complete witness path.
    // * `RequirementProjectionResolutionStatus` reports whether the resulting value is concrete,
    //   remains a valid symbolic projection, or belongs to a failed concrete conformance.
    //
    // The first three types live with their persistent or structural data; the semantic result
    // types are declared below beside the operations that convert between these layers.

    /// The result of requesting one interface-requirement witness.
    enum class ConformanceRequirementCheckResult
    {
        /// The table contains a final witness for this requirement.
        Satisfied,

        /// An enclosing semantic operation owns the check and has not published a final witness.
        InProgress,

        /// Checking proved that the concrete type does not satisfy this requirement.
        Failed,
    };

    /// Selects whether an inherited-interface requirement is only made traversable or is fully
    /// checked after its witness has been published.
    enum class InheritedInterfaceRequirementMode
    {
        PrepareForLookup,
        CheckConformance,
    };

    /// The result of looking up a requirement through a conformance witness.
    enum class RequirementLookupStatus
    {
        /// A structural witness is available; its conformance may still be under validation.
        Found,
        /// No existing witness was found and this witness path cannot be forced here.
        Unavailable,
        /// The same entry is recursively requested and has not published a structural witness.
        Recursive,

        /// Semantic checking proved that the concrete requirement cannot be satisfied.
        Failed,
    };

    struct RequirementLookupResult
    {
        RequirementLookupStatus status = RequirementLookupStatus::Unavailable;
        RequirementWitness witness;
    };

    /// Describes the result of forcefully resolving a possible requirement projection.
    enum class RequirementProjectionResolutionStatus
    {
        /// The returned value is structurally resolved, whether or not the input was a projection.
        Resolved,

        /// A valid abstract, external, or recursively owned projection remains symbolic.
        Unchanged,

        /// Checking a concrete conformance requirement failed.
        Failed,
    };

    /// The result of forcefully resolving a value that may project an interface requirement.
    struct RequirementProjectionResolutionResult
    {
        RequirementProjectionResolutionStatus status =
            RequirementProjectionResolutionStatus::Unchanged;
        Val* value = nullptr;
    };

    /// Reasons why witness synthesis can fail
    enum class WitnessSynthesisFailureReason
    {
        General,                  // Generic failure (default)
        MethodResultTypeMismatch, // Method return type doesn't match interface requirement
        ParameterDirMismatch,     // Parameter direction mismatch (e.g., `in` vs `out`)
        GenericSignatureMismatch, // Generic signature mismatch (e.g., number of generic parameters)
        DifferentiabilityMismatch, // Method differentiability doesn't match interface requirement
    };

    /// Details about method witness synthesis failure
    struct MethodWitnessSynthesisFailureDetails
    {
        WitnessSynthesisFailureReason reason = WitnessSynthesisFailureReason::General;
        DeclRef<Decl> candidateMethod; // The method that was considered but failed
        Type* actualType = nullptr;    // For type mismatches: the actual type found
        Type* expectedType = nullptr;  // For type mismatches: the expected type
        ParamPassingMode actualDir =
            ParamPassingMode::In; // For direction mismatches: the actual direction
        ParamPassingMode expectedDir =
            ParamPassingMode::In;       // For direction mismatches: the expected direction
        ParamDecl* paramDecl = nullptr; // For direction mismatches: the parameter declaration
    };

    bool doesSignatureMatchRequirement(
        DeclRef<CallableDecl> satisfyingMemberDeclRef,
        DeclRef<CallableDecl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable);

    bool doesMemberSatisfyRequirement(
        DeclRef<Decl> memberDeclRef,
        DeclRef<Decl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable);

    void addModifiersToSynthesizedDecl(
        ConformanceCheckingContext* context,
        DeclRef<Decl> requirement,
        CallableDecl* synthesized,
        ThisExpr*& synThis);

    void addRequiredParamsToSynthesizedDecl(
        DeclRef<CallableDecl> requirement,
        CallableDecl* synthesized,
        List<Expr*>& synArgs);

    CallableDecl* synthesizeMethodSignatureForRequirementWitnessInner(
        ConformanceCheckingContext* context,
        DeclRef<CallableDecl> requiredMemberDeclRef,
        List<Expr*>& synArgs,
        ThisExpr*& synThis);

    CallableDecl* synthesizeMethodSignatureForRequirementWitness(
        ConformanceCheckingContext* context,
        DeclRef<CallableDecl> requiredMemberDeclRef,
        List<Expr*>& synArgs,
        ThisExpr*& synThis);

    GenericDecl* synthesizeGenericSignatureForRequirementWitness(
        ConformanceCheckingContext* context,
        DeclRef<GenericDecl> requiredMemberDeclRef,
        List<Expr*>& synArgs,
        List<Expr*>& synGenericArgs,
        ThisExpr*& synThis);

    bool synthesizeAccessorRequirements(
        ConformanceCheckingContext* context,
        DeclRef<ContainerDecl> requiredMemberDeclRef,
        Type* resultType,
        LookupResult const& lookupResult,
        List<Expr*> const& synthesizedContainerArgs,
        ContainerDecl* synthesizedAccessorContainer,
        RefPtr<WitnessTable> witnessTable);

    void _addMethodWitness(
        WitnessTable* witnessTable,
        DeclRef<CallableDecl> requirement,
        DeclRef<CallableDecl> method);

    void markOverridingDecl(
        ConformanceCheckingContext* context,
        Decl* memberDecl,
        DeclRef<Decl> requiredMemberDeclRef);

    /// Attempt to synthesize a method that can satisfy `requiredMemberDeclRef` using
    /// `lookupResult`.
    ///
    /// On success, installs the syntethesized method in `witnessTable` and returns `true`.
    /// Otherwise, returns `false` and sets `outFailureDetails` with information about why
    /// synthesis failed.
    bool trySynthesizeMethodRequirementWitness(
        ConformanceCheckingContext* context,
        LookupResult const& lookupResult,
        DeclRef<FuncDecl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable,
        MethodWitnessSynthesisFailureDetails* outFailureDetails = nullptr);

    bool trySynthesizeConstructorRequirementWitness(
        ConformanceCheckingContext* context,
        LookupResult const& lookupResult,
        DeclRef<ConstructorDecl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable);

    /// Attempt to synthesize a property that can satisfy `requiredMemberDeclRef` using
    /// `lookupResult`.
    ///
    /// On success, installs the syntethesized method in `witnessTable` and returns `true`.
    /// Otherwise, returns `false`.
    ///
    bool trySynthesizePropertyRequirementWitness(
        ConformanceCheckingContext* context,
        LookupResult const& lookupResult,
        DeclRef<PropertyDecl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable);

    bool trySynthesizeSubscriptRequirementWitness(
        ConformanceCheckingContext* context,
        const LookupResult& lookupResult,
        DeclRef<SubscriptDecl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable);


    /// Attempt to synthesize a declartion that can satisfy `requiredMemberDeclRef` using
    /// `lookupResult`.
    ///
    /// On success, installs the syntethesized declaration in `witnessTable` and returns `true`.
    /// Otherwise, returns `false` and sets `outFailureDetails` with information about why
    /// synthesis failed.
    bool trySynthesizeRequirementWitness(
        ConformanceCheckingContext* context,
        LookupResult const& lookupResult,
        DeclRef<Decl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable,
        MethodWitnessSynthesisFailureDetails* outFailureDetails = nullptr);

    /// Clone the generic containers that make `decl` well-scoped after relocation.
    ///
    /// Generated interface requirements can be moved from a callable's local generic context to a
    /// sibling requirement on the interface. This clones the enclosing generic signatures, rewrites
    /// references from the source binders to the cloned binders, and returns a decl-ref that maps
    /// the source environment to the relocated declaration. `destinationParentDecl` lets callers
    /// place the cloned generic chain under the semantic owner that should contain the generated
    /// declaration.
    DeclRef<Decl> liftDeclFromGenericContainers(
        Decl* decl,
        SubstitutionSet& outSubst,
        ContainerDecl* destinationParentDecl = nullptr);

    enum SynthesisPattern
    {
        // Synthesized method inducts over all arguments.
        // T fn(T x, T y, T z, ...)
        // {
        //     typeof(T::member0)::fn(x.member0, y.member0, z.member0, ...);
        //     typeof(T::member1)::fn(x.member1, y.member1, z.member1, ...);
        //     ...
        // }
        //
        AllInductive,

        // Synthesized method inducts over all arguments except the first.
        // T fn(U x, T y, T z)
        // {
        //     typeof(T::member0)::fn(x, y.member0, z.member0, ...);
        //     typeof(T::member1)::fn(x, y.member1, z.member1, ...);
        //     ...
        // }
        FixedFirstArg
    };

    /// Attempt to synthesize `dzero` and `dadd` methods for a type that conforms to
    /// `IDifferentiable`.
    /// On success, installs the syntethesized functions and returns `true`.
    /// Otherwise, returns `false`.
    bool trySynthesizeDifferentialMethodRequirementWitness(
        ConformanceCheckingContext* context,
        DeclRef<Decl> requirementDeclRef,
        RefPtr<WitnessTable> witnessTable,
        SynthesisPattern pattern);

    /// Attempt to synthesize `fwd_diff`, `bwd_diff`, `apply`, `get_val` and
    /// other auto-diff related requirements.
    bool trySynthesizeDiffFuncRequirementWitness(
        ConformanceCheckingContext* context,
        DeclRef<Decl> requirementDeclRef,
        RefPtr<WitnessTable> witnessTable,
        BuiltinRequirementKind requirementKind);

    /// Attempt to synthesize an associated `Differential` type for a type that conforms to
    /// `IDifferentiable`.
    ///
    /// On success, installs the syntethesized type in `witnessTable`, injects `[DerivativeMember]`
    /// modifiers on differentiable fields to point to the corresponding field in the synthesized
    /// differential type, and returns `true`.
    /// Otherwise, returns `false`.
    bool trySynthesizeDifferentialAssociatedTypeRequirementWitness(
        ConformanceCheckingContext* context,
        DeclRef<AssocTypeDecl> requirementDeclRef,
        RefPtr<WitnessTable> witnessTable);

    bool trySynthesizeDiffContextTypeRequirementWitness(
        ConformanceCheckingContext* context,
        DeclRef<AssocTypeDecl> requirementDeclRef,
        RefPtr<WitnessTable> witnessTable,
        BuiltinRequirementKind requirementKind);

    /// Attempt to synthesize function requirements for enum types to make them conform to
    /// `ILogical`.
    bool trySynthesizeEnumTypeMethodRequirementWitness(
        ConformanceCheckingContext* context,
        DeclRef<FunctionDeclBase> requirementDeclRef,
        RefPtr<WitnessTable> witnessTable,
        BuiltinRequirementKind requirementKind);

    /// Check references from`[DerivativeMember(...)]` attributes on members of the agg-decl.
    /// this is typically deferred until after types are ready for reference.
    void checkDifferentiableMembersInType(AggTypeDecl* decl);

    struct DifferentiableMemberInfo
    {
        Decl* memberDecl;
        Type* diffType;
    };

    /// Gather differentiable members from decl.
    List<DifferentiableMemberInfo> collectDifferentiableMemberInfo(ContainerDecl* decl);

    // Check and register a type if it is differentiable.
    void maybeRegisterDifferentiableType(
        ASTBuilder* builder,
        Type* type,
        SourceLoc diagnosticLoc = SourceLoc());

    void maybeCheckMissingNoDiffThis(Expr* expr);

    // Find the default implementation of an interface requirement,
    // and insert it to the witness table, if it exists.
    //
    // `subTypeConformsToInterfaceWitness` is the witness that the conforming type satisfies the
    // interface whose requirement is being witnessed here. It is the witness for the *specific*
    // (possibly nested base-interface) table being populated, not necessarily the outer conformance
    // being checked; the default-impl generic is specialized against it so its interior
    // `lookupWitness` calls resolve against the correct table (see #12814).
    bool findDefaultInterfaceImpl(
        ConformanceCheckingContext* context,
        DeclRef<Decl> requiredMemberDeclRef,
        SubtypeWitness* subTypeConformsToInterfaceWitness,
        RefPtr<WitnessTable> witnessTable);

    // Find the appropriate member of a declared type to
    // satisfy a requirement of an interface the type
    // claims to conform to.
    //
    // The type declaration `typeDecl` has declared that it
    // conforms to the interface `interfaceDeclRef`, and
    // `requiredMemberDeclRef` is a required member of
    // the interface.
    //
    // If a satisfying value is found, registers it in
    // `witnessTable` and returns `true`, otherwise
    // returns `false`.
    //
    bool findWitnessForInterfaceRequirement(
        ConformanceCheckingContext* context,
        Type* subType,
        Type* superInterfaceType,
        InheritanceDecl* inheritanceDecl,
        DeclRef<InterfaceDecl> superInterfaceDeclRef,
        DeclRef<Decl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable,
        SubtypeWitness* subTypeConformsToSuperInterfaceWitness);

    /// Ensures that an inherited-interface requirement has a structural witness and optionally
    /// checks the nested conformance selected by `mode`.
    bool ensureInheritedInterfaceRequirement(
        ConformanceCheckingContext* context,
        Type* subType,
        DeclRef<InheritanceDecl> requiredInheritanceDeclRef,
        RefPtr<WitnessTable> witnessTable,
        InheritedInterfaceRequirementMode mode);

    /// Ensures that one requirement in a concrete interface conformance has been checked.
    ConformanceRequirementCheckResult ensureConformanceRequirement(
        ConformanceCheckingContext* context,
        Type* subType,
        Type* superInterfaceType,
        InheritanceDecl* inheritanceDecl,
        DeclRef<InterfaceDecl> superInterfaceDeclRef,
        DeclRef<Decl> requiredMemberDeclRef,
        RefPtr<WitnessTable> witnessTable,
        SubtypeWitness* subTypeConformsToSuperInterfaceWitness);

    /// Returns the persistent declaration-context state for a concrete conformance.
    ConformanceCheckingContext* getOrCreateConformanceCheckingContext(
        Type* conformingType,
        InheritanceDecl* inheritanceDecl,
        ContainerDecl* parentDecl);

    /// Registers the semantic information needed to force entries in one interface table.
    ConformanceInterfaceCheckingState* registerConformanceInterfaceCheckingState(
        ConformanceCheckingContext* context,
        Type* conformingType,
        Type* interfaceType,
        InheritanceDecl* inheritanceDecl,
        DeclRef<InterfaceDecl> interfaceDeclRef,
        RefPtr<WitnessTable> witnessTable,
        SubtypeWitness* conformingWitness);

    /// Ensures one entry using the persistent state registered for its witness table.
    ConformanceRequirementCheckResult ensureConformanceRequirement(
        WitnessTable* witnessTable,
        DeclRef<Decl> requiredMemberDeclRef);

    /// Ensures and returns one specialized witness when its lookup path reaches concrete tables.
    ///
    /// A missing entry on an abstract, existential, dynamic, serialized, or external path cannot be
    /// synthesized here and remains unavailable. The specialized requirement stays a `DeclRef` at
    /// this boundary; only the final lookup into a known witness table converts it to that table's
    /// identity key.
    RequirementLookupResult ensureAndLookupRequirementWitness(
        SubtypeWitness* conformanceWitness,
        DeclRef<Decl> requirementDeclRef);

    /// Resolves a projected conformance path and continues one requirement lookup through it.
    RequirementLookupResult ensureAndLookupRequirementWitnessThroughProjectedConformance(
        SubtypeWitness* projectedConformanceWitness,
        DeclRef<Decl> requirementDeclRef);

    /// Resolves one endpoint needed to reconstruct a concrete projected conformance.
    ///
    /// `Found` guarantees that `outType` is populated. `Unavailable` means the endpoint remains a
    /// valid symbolic projection, and `Failed` means its concrete conformance could not be
    /// satisfied. This operation never returns `Recursive`: recursive projection resolution is
    /// represented as an unchanged endpoint and therefore maps to `Unavailable` here.
    RequirementLookupStatus ensureConcreteConformanceEndpoint(Type* type, Type*& outType);

    /// Resolves ordinary aliases and then forcefully resolves one remaining concrete requirement
    /// projection. Valid projections that cannot be forced remain unchanged.
    RequirementProjectionResolutionResult ensureAndResolveRequirementProjection(Val* value);

    // Check that the type declaration `typeDecl`, which
    // declares conformance to the interface `interfaceDeclRef`,
    // (via the given `inheritanceDecl`) actually provides
    // members to satisfy all the requirements in the interface.
    bool checkInterfaceConformance(
        ConformanceCheckingContext* context,
        Type* subType,
        Type* superInterfaceType,
        InheritanceDecl* inheritanceDecl,
        DeclRef<InterfaceDecl> superInterfaceDeclRef,
        SubtypeWitness* subTypeConformsToSuperInterfaceWitness,
        WitnessTable* witnessTable);

    RefPtr<WitnessTable> checkInterfaceConformance(
        ConformanceCheckingContext* context,
        Type* subType,
        Type* superInterfaceType,
        InheritanceDecl* inheritanceDecl,
        DeclRef<InterfaceDecl> superInterfaceDeclRef,
        SubtypeWitness* subTypeConformsToSuperInterfaceWitness);

    void _checkDifferentialConformance(
        ConformanceCheckingContext* context,
        Type* subType,
        InheritanceDecl* inheritanceDecl,
        DeclRef<InterfaceDecl> superInterfaceDeclRef,
        WitnessTable* witnessTable);

    bool checkConformanceToType(
        ConformanceCheckingContext* context,
        Type* subType,
        InheritanceDecl* inheritanceDecl,
        Type* superType,
        SubtypeWitness* subIsSuperWitness,
        WitnessTable* witnessTable);

    /// Check that `type` which has declared that it inherits from (and/or implements)
    /// another type via `inheritanceDecl` actually does what it needs to for that
    /// inheritance to be valid.
    bool checkConformance(Type* type, InheritanceDecl* inheritanceDecl, ContainerDecl* parentDecl);

    void checkExtensionConformance(ExtensionDecl* decl);

    void calcOverridableCompletionCandidates(
        Type* aggType,
        ContainerDecl* aggTypeDecl,
        Decl* memberDecl);

    void checkAggTypeConformance(AggTypeDecl* decl);

    void checkGenericConstraintConformances(GenericDecl* genericDecl);

    void _fillInGenericConstraintPathResolutionTableForInheritance(
        Type* subType,
        Type* interfaceType,
        WitnessTable* pathResolutionTable);

    bool isIntegerBaseType(BaseType baseType);

    /// Is `type` a scalar integer type.
    bool isScalarIntegerType(Type* type);

    // This function is used to get the best integer type that matches the given type.
    // If `type` is already an integer type, return it as is.
    // If `type` is a enum type, return the tag type if it exists.
    // Otherwise, return the 32-bit signed integer type.
    Type* getMatchingIntType(Type* type);

    /// Is `type` a scalar half type.
    bool isHalfType(Type* type);

    /// Is `type` something we allow for specialization constants, i.e. scalar and enum types.
    bool isValidSpecializationConstantType(Type* type);

    /// Is `type` something we allow as compile time constants, i.e. scalar integer and enum types.
    bool isValidCompileTimeConstantType(Type* type);

    bool isIntValueInRangeOfType(IntegerLiteralValue value, Type* type);

    // Validate that `type` is a suitable type to use
    // as the tag type for an `enum`
    void validateEnumTagType(Type* type, SourceLoc const& loc);

    void checkStmt(Stmt* stmt, SemanticsContext const& context);

    Stmt* maybeParseStmt(Stmt* stmt, const SemanticsContext& context);

    void getGenericParams(GenericDecl* decl, List<Decl*>& outParams, List<Decl*>& outConstraints);

    /// Determine if `left` and `right` have matching generic signatures.
    /// If they do, then outputs a specialized declRef to `ioSubstRightToLeft` that
    /// represents a reference to `right` with the parameters of `left`.
    bool doGenericSignaturesMatch(
        GenericDecl* left,
        GenericDecl* right,
        DeclRef<Decl>* outSpecializedRightInner);

    // Check if two functions have the same signature for the purposes
    // of overload resolution.
    bool doFunctionSignaturesMatch(DeclRef<FuncDecl> fst, DeclRef<FuncDecl> snd);

    Result checkRedeclaration(Decl* newDecl, Decl* oldDecl, RedeclarationSeverity severity);
    Result checkFuncRedeclaration(FuncDecl* newDecl, FuncDecl* oldDecl);
    void checkForRedeclaration(Decl* decl, RedeclarationSeverity severity);
    void checkForRedeclarationOfTransparentMembers(ContainerDecl* containerDecl);

    Expr* checkPredicateExpr(Expr* expr);

    Expr* checkExpressionAndExpectIntegerConstant(
        Expr* expr,
        IntVal** outIntVal,
        ConstantFoldingKind kind);

    IntegerLiteralValue GetMinBound(IntVal* val);

    void maybeInferArraySizeForVariable(VarDeclBase* varDecl);

    void validateArraySizeForVariable(VarDeclBase* varDecl);
    void validateArrayElementTypeForVariable(VarDeclBase* varDecl);

    IntVal* getIntVal(IntegerLiteralExpr* expr);

    inline IntVal* getIntVal(SubstExpr<IntegerLiteralExpr> expr)
    {
        return getIntVal(expr.getExpr());
    }

    Name* getName(String const& text) { return getNamePool()->getName(text); }

    /// Helper type to detect and catch circular definitions when folding constants,
    /// to prevent the compiler from going into infinite loops or overflowing the stack.
    struct ConstantFoldingCircularityInfo
    {
        ConstantFoldingCircularityInfo(DeclRefBase* declRef, ConstantFoldingCircularityInfo* next)
            : declRef(declRef), next(next), depth(next ? next->depth + 1 : 1)
        {
        }

        /// A declaration reference whose value is contributing to the constant being folded.
        DeclRefBase* declRef = nullptr;

        /// The rest of the links in the chain of declarations being folded
        ConstantFoldingCircularityInfo* next = nullptr;

        /// Current recursion depth of constant folding/evaluation.
        UInt depth = 0;
    };
    /// Try to apply front-end constant folding to determine the value of `invokeExpr`.
    IntVal* tryConstantFoldExpr(
        SubstExpr<InvokeExpr> invokeExpr,
        ConstantFoldingKind kind,
        ConstantFoldingCircularityInfo* circularityInfo);

    /// Constant-fold a builtin-operator fast-path node (`a + b`, `N / 2`, etc.), producing a
    /// concrete `ConstantIntVal`, a `PolynomialIntVal` (for `+`/`-`/`*`), or a decl-free
    /// `BuiltinOperationIntVal` when operands are still symbolic.
    IntVal* tryConstantFoldBuiltinOperatorExpr(
        SubstExpr<BuiltinOperatorExpr> expr,
        ConstantFoldingKind kind,
        ConstantFoldingCircularityInfo* circularityInfo);

    /// Try to apply front-end constant folding to determine the value of `expr`.
    IntVal* tryConstantFoldExpr(
        SubstExpr<Expr> expr,
        ConstantFoldingKind kind,
        ConstantFoldingCircularityInfo* circularityInfo);

    bool _checkForCircularityInConstantFolding(
        DeclRefBase* declRef,
        ConstantFoldingCircularityInfo* circularityInfo);

    /// Try to resolve a compile-time constant `IntVal` from the given `declRef`.
    IntVal* tryConstantFoldDeclRef(
        DeclRef<VarDeclBase> const& declRef,
        ConstantFoldingKind kind,
        ConstantFoldingCircularityInfo* circularityInfo);

    /// Try to extract the value of an integer constant expression, either
    /// returning the `IntVal` value, or null if the expression isn't recognized
    /// as an integer constant.
    ///
    IntVal* tryFoldIntegerConstantExpression(
        SubstExpr<Expr> expr,
        ConstantFoldingKind kind,
        ConstantFoldingCircularityInfo* circularityInfo);

    IntVal* tryFoldIndexExpr(
        SubstExpr<IndexExpr> expr,
        ConstantFoldingKind kind,
        ConstantFoldingCircularityInfo* circularityInfo);

    // Enforce that an expression resolves to an integer constant, and get its value
    enum class IntegerConstantExpressionCoercionType
    {
        SpecificType,
        AnyInteger
    };
    IntVal* CheckIntegerConstantExpression(
        Expr* inExpr,
        IntegerConstantExpressionCoercionType coercionType,
        Type* expectedType,
        ConstantFoldingKind kind);
    IntVal* CheckIntegerConstantExpression(
        Expr* inExpr,
        IntegerConstantExpressionCoercionType coercionType,
        Type* expectedType,
        ConstantFoldingKind kind,
        DiagnosticSink* sink);
    IntVal* CheckIntegerConstantExpression(
        Expr* inExpr,
        IntegerConstantExpressionCoercionType coercionType,
        Type* expectedType,
        ConstantFoldingKind kind,
        DiagnosticSink* sink,
        ConstantFoldingCircularityInfo* circularityInfo);

    IntVal* CheckEnumConstantExpression(Expr* expr, ConstantFoldingKind kind);


    Expr* CheckSimpleSubscriptExpr(IndexExpr* subscriptExpr, Type* elementType);

    // The way that we have designed out type system, pretyt much *every*
    // type is a reference to some declaration in the core module.
    // That means that when we construct a new type on the fly, we need
    // to make sure that it is wired up to reference the appropriate
    // declaration, or else it won't compare as equal to other types
    // that *do* reference the declaration.
    //
    // This function is used to construct a `vector<T,N>` type
    // programmatically, so that it will work just like a type of
    // that form constructed by the user.
    VectorExpressionType* createVectorType(Type* elementType, IntVal* elementCount);

    //

    /// Given an immutable `expr` used as an l-value emit a special diagnostic if it was derived
    /// from `this`.
    void maybeDiagnoseConstVariableAssignment(Expr* expr);

    // Figure out what type an initializer/constructor declaration
    // is supposed to return. In most cases this is just the type
    // declaration that its declaration is nested inside.
    Type* findResultTypeForConstructorDecl(ConstructorDecl* decl);

    /// Determine what type `This` should refer to in the context of the given parent `decl`.
    Type* calcThisType(DeclRef<Decl> decl);

    /// Determine what type `This` should refer to in an extension of `type`.
    Type* calcThisType(Type* type);

    /// Compute the effective `this` parameter information for `decl`, if it has one.
    ///
    /// This operation is only used while advancing a declaration to
    /// `DeclCheckState::SignatureChecked`. Other semantic-checking code should use the queries
    /// below so that it reads the information attached to the declaration. A `this` expression in
    /// the declaration's own signature is the exception: it needs this computation before the
    /// transition can finish, but leaves diagnostics to the final call that publishes the result.
    std::optional<ParamInfo> checkEffectiveThisParamInfo(
        Decl* decl,
        bool shouldDiagnoseModeAttributes);

    /// Return the receiver parameter mode used for `decl` when no specifier is present.
    ///
    /// Setters and non-synthesized HLSL methods default to `ParamPassingMode::BorrowInOut`;
    /// other declarations use `ParamPassingMode::In`.
    /// For a non-synthesized `FuncDecl`, requires the context for its owning translation unit.
    ParamPassingMode getDefaultReceiverParamMode(Decl* decl);

    /// Compute and attach the effective `this` parameter information owned by `decl`.
    void checkAndAttachEffectiveThisParamInfo(Decl* decl);

    /// Return the effective `this` parameter information for `decl`, if it has one.
    ///
    /// These wrappers first ensure that the declaration has completed signature checking. The
    /// underlying passive queries assert that precondition themselves.
    std::optional<ParamInfo> findEffectiveThisParamInfo(DeclRef<Decl> const& declRef);
    ParamInfo getEffectiveThisParamInfo(DeclRef<Decl> const& declRef);

    DeclRef<Decl> getRequirementAsLookedUpDecl(ASTBuilder* astBuilder, Decl* decl);

    /// Calculate the builtin differentiable function interface type for a callable-as-type.
    ///
    /// The plain overloads derive the type-info witness from `baseFuncAsType`. The
    /// `WithWitness` overloads are used when conformance checking already selected a specific
    /// witness, so the computed interface type stays tied to that proof instead of re-synthesizing
    /// a different one.
    FuncType* getCalculatedDiffFuncType(const char* magicCalcName, Type* baseFuncAsType)
    {
        Val* args[] = {baseFuncAsType, getDiffTypeInfoWitness(baseFuncAsType)};
        return as<FuncType>(
            m_astBuilder->getSpecializedBuiltinType(makeArrayView(args), magicCalcName));
    }

    FuncType* getCalculatedDiffFuncTypeWithWitness(
        const char* magicCalcName,
        Type* baseFuncAsType,
        Witness* typeInfoWitness)
    {
        Val* args[] = {baseFuncAsType, typeInfoWitness};
        return as<FuncType>(
            m_astBuilder->getSpecializedBuiltinType(makeArrayView(args), magicCalcName));
    }

    FuncType* getCalculatedDiffFuncType(
        const char* magicCalcName,
        Type* baseFuncAsType,
        Type* operand1)
    {
        Val* args[] = {baseFuncAsType, operand1, getDiffTypeInfoWitness(baseFuncAsType)};
        return as<FuncType>(
            m_astBuilder->getSpecializedBuiltinType(makeArrayView(args), magicCalcName));
    }

    FuncType* getCalculatedDiffFuncTypeWithWitness(
        const char* magicCalcName,
        Type* baseFuncAsType,
        Type* operand1,
        Witness* typeInfoWitness)
    {
        Val* args[] = {baseFuncAsType, operand1, typeInfoWitness};
        return as<FuncType>(
            m_astBuilder->getSpecializedBuiltinType(makeArrayView(args), magicCalcName));
    }

    FuncType* getCalculatedDiffFuncType(
        const char* magicCalcName,
        Type* baseFuncAsType,
        Type* operand1,
        Type* operand2)
    {
        Val* args[] = {baseFuncAsType, operand1, operand2, getDiffTypeInfoWitness(baseFuncAsType)};
        return as<FuncType>(
            m_astBuilder->getSpecializedBuiltinType(makeArrayView(args), magicCalcName));
    }

    FuncType* getCalculatedDiffFuncTypeWithWitness(
        const char* magicCalcName,
        Type* baseFuncAsType,
        Type* operand1,
        Type* operand2,
        Witness* typeInfoWitness)
    {
        Val* args[] = {baseFuncAsType, operand1, operand2, typeInfoWitness};
        return as<FuncType>(
            m_astBuilder->getSpecializedBuiltinType(makeArrayView(args), magicCalcName));
    }

    Type* getForwardDiffFuncInterfaceType(Type* baseType);
    Type* getBackwardDiffFuncInterfaceType(Type* baseType);
    Type* getBwdCallableBaseType(Type* baseType);

    // Priority levels for constraint solving. Lower numeric values indicate
    // higher priority: a Required constraint overrides Optional, which
    // overrides Default.
    enum class ConstraintPriority
    {
        // Constraints from inferred argument types or where-clauses.
        Required = 0,
        // constraints from `where optional` clauses and hint values from
        // inferred-but-non-binding unification steps
        Optional,
        // default generic argument values (e.g., T = int)
        Default
    };

    // One collected constraint for generic argument solving.
    //
    // Unification writes ordinary type/value constraints into
    // `GenericInferenceContext::discoveredConstraints`, and the generic solver
    // adds default generic arguments and source generic constraints using the same shape.
    // Once copied into the solver's stable constraint table, `satisfied` and
    // `queued` track work-list state for the iterative solving loop.
    struct SolverConstraint
    {
        enum class Kind
        {
            // A constraint that solves an ordinary type/value argument. The
            // target argument is named by `decl`, the constraint value is
            // stored in `val`, and `ordinaryArgMergeMode` decides how that
            // value is merged with any previous answer.
            OrdinaryArgConstraint,

            // A default generic argument for an ordinary argument. In
            // `Foo<T : IFoo, U = T.A>`, the `U = T.A` default is represented by
            // this kind of constraint. The target argument is named by `decl`
            // and the declaration-time default is stored in `val`.
            DefaultArgConstraint,

            // A source generic constraint that must produce a witness argument,
            // such as `T : IFoo`, a type-coercion constraint, a non-empty-pack
            // constraint, or a differentiability constraint. The source
            // constraint declaration is named by `decl`.
            WitnessConstraint,
        };

        enum class OrdinaryArgMergeMode
        {
            // Merge type constraints with the existing type-join behavior. This is
            // used for normal type inference from call arguments, so a generic
            // parameter can still settle on a common type when several ordinary
            // argument constraints contribute types.
            TypeJoin,

            // Treat the constraint value as an exact answer. This is used for
            // value arguments such as `N = 4`, dependent values substituted as
            // ordinary constraints such as `U = T.A`, and source equality
            // requirements such as `T.A == U`.
            Exact,
        };

        // Selects the solver routine that handles this constraint. The fields
        // below document which `Kind` reads them.
        Kind kind = Kind::OrdinaryArgConstraint;

        // The generic declaration whose argument list contains the ordinary
        // argument or witness argument affected by this constraint. This field
        // is required for `DefaultArgConstraint` and `WitnessConstraint`; it is
        // usually not needed for `OrdinaryArgConstraint`, whose target
        // declaration already carries its parent generic.
        GenericDecl* genericDecl = nullptr;

        // For `OrdinaryArgConstraint`, the ordinary generic parameter being
        // solved. For `DefaultArgConstraint`, the ordinary generic parameter
        // whose default value is being substituted. For `WitnessConstraint`,
        // the source generic constraint declaration whose proof should be
        // written as a witness argument.
        Decl* decl = nullptr;

        // Only used by `OrdinaryArgConstraint` when `decl` names a type
        // parameter pack. It identifies which pack element the value in
        // `val` constrains.
        Index indexInPack = 0;

        // For `OrdinaryArgConstraint`, the type or value to merge into the
        // ordinary argument named by `decl`. For `DefaultArgConstraint`, the
        // unevaluated declaration-time default generic argument. Unused by
        // `WitnessConstraint`, which reads the source constraint declaration
        // from `decl`.
        Val* val = nullptr;

        // Only used by `OrdinaryArgConstraint` when `decl` names a type
        // parameter. It records whether the constraint came from an l-value
        // parameter use so the merged type keeps the correct value category.
        bool isUsedAsLValue = false;

        // True when the solver has no more work for this constraint. Ordinary
        // constraints stay satisfied once their value has been applied; default
        // generic arguments and witness constraints can be marked unsatisfied
        // again when a dependency changes and they need to substitute through
        // the current argument list again.
        bool satisfied = false;

        // Only used by `OrdinaryArgConstraint`. There are multiple levels of
        // ordinary-argument constraints: required constraints from call
        // inference or where clauses, optional constraints from
        // `where optional`, and defaults. Lower numeric priority wins when two
        // constraints compete.
        ConstraintPriority priority = ConstraintPriority::Required;

        // Only used by `OrdinaryArgConstraint`. It tells the type-parameter
        // merge path whether the constraint value should use ordinary type
        // joining or exact equality. Value-parameter constraints always use
        // `Exact`.
        OrdinaryArgMergeMode ordinaryArgMergeMode = OrdinaryArgMergeMode::TypeJoin;

        // True when `val` must be substituted through the current generic
        // argument list before it is used. This is used by
        // `OrdinaryArgConstraint` for dependent constraint values such as
        // `U = T.A`, and by `DefaultArgConstraint` for declaration-time
        // defaults. It is unused by `WitnessConstraint`, whose source
        // declaration is substituted by building a specialized decl-ref.
        bool potentiallyDependent = false;

        // True while this constraint's index is already present in the work-list
        // queue. This scheduling bit applies to every `Kind`.
        bool queued = false;

        // Build a constraint that merges one inferred ordinary type/value argument.
        static SolverConstraint makeOrdinaryArg(
            Decl* paramDecl,
            Val* arg,
            ConstraintPriority priority,
            OrdinaryArgMergeMode mergeMode,
            Index indexInPack = 0,
            bool isUsedAsLValue = false,
            bool potentiallyDependent = false)
        {
            SolverConstraint constraint;
            constraint.kind = Kind::OrdinaryArgConstraint;
            constraint.decl = paramDecl;
            constraint.indexInPack = indexInPack;
            constraint.val = arg;
            constraint.isUsedAsLValue = isUsedAsLValue;
            constraint.priority = priority;
            constraint.ordinaryArgMergeMode = mergeMode;
            constraint.potentiallyDependent = potentiallyDependent;
            return constraint;
        }

        // Build a constraint that substitutes a declaration-time default argument.
        static SolverConstraint makeDefaultArg(GenericDecl* genericDecl, Decl* paramDecl, Val* arg)
        {
            SolverConstraint constraint;
            constraint.kind = Kind::DefaultArgConstraint;
            constraint.genericDecl = genericDecl;
            constraint.decl = paramDecl;
            constraint.val = arg;
            constraint.potentiallyDependent = true;
            return constraint;
        }

        // Build a constraint that solves one compiler-formed witness argument.
        static SolverConstraint makeWitness(GenericDecl* genericDecl, Decl* constraintDecl)
        {
            SolverConstraint constraint;
            constraint.kind = Kind::WitnessConstraint;
            constraint.genericDecl = genericDecl;
            constraint.decl = constraintDecl;
            return constraint;
        }
    };

    // The shared context used while semantic checking, type joining, and
    // unification infer arguments for one generic application. It is not the
    // generic solver's work list; `discoveredConstraints` is only a temporary
    // inbox that shared helpers append to before the solver copies those
    // constraints into its own durable work table.
    struct GenericInferenceContext
    {
        // The generic declaration whose ordinary arguments and witness
        // arguments are being solved.
        GenericDecl* genericDecl = nullptr;

        // Ordinary argument constraints discovered by unification or type
        // joining. The generic solver drains and clears this list whenever it
        // needs to pull newly discovered constraints into the iterative loop.
        ShortList<SolverConstraint, 8> discoveredConstraints;

        // Hidden witness arguments discovered while unifying full generic-app
        // decl-refs. Consider this example:
        //
        //     interface ITensor<T, int D>
        //     {
        //         T load<each TIndex>(TIndex indices)
        //             where TIndex == int
        //             where countof(TIndex) == D;
        //     }
        //
        // A use site for this requirement already carries proof arguments for `load`'s source
        // generic constraints. When that lookup resolves to a satisfying method, the solver should
        // preserve those proof arguments instead of recomputing them from default declaration
        // context.
        Dictionary<Decl*, Val*> discoveredWitnessArgs;

        // Additional subtype witnesses available to the current constraint solving context.
        Type* subTypeForAdditionalWitnesses = nullptr;
        Dictionary<Type*, SubtypeWitness*>* additionalSubtypeWitnesses = nullptr;

        // Accumulated conversion cost from type promotions during constraint solving.
        // This tracks costs when a type parameter is promoted to satisfy an interface
        // constraint (e.g., int -> float to satisfy __BuiltinFloatingPointType).
        ConversionCost typePromotionCost = kConversionCost_None;

        // Optional channel for a generic-argument solve to explain a focused
        // failure to overload completion. Solving can run while collecting
        // speculative candidates, so diagnostics are delayed until overload
        // resolution selects the failed candidate.
        GenericArgumentInferenceFailure* failure = nullptr;
        SourceLoc applicationLoc = SourceLoc();
    };

    bool isRelevantGeneric(GenericInferenceContext& system, Decl* generic);

    Type* TryJoinVectorAndScalarType(
        GenericInferenceContext* constraints,
        VectorExpressionType* vectorType,
        BasicExpressionType* scalarType);

    /// Is the given interface one that a tagged-union type can conform to?
    ///
    /// If a tagged union type `__TaggedUnion(A,B)` is going to be
    /// plugged in for a type parameter `T : IFoo` then we need to
    /// be sure that the interface `IFoo` doesn't have anything
    /// that could lead to unsafe/unsound behavior. This function
    /// checks that all the requirements on the interfaceare safe ones.
    ///
    bool isInterfaceSafeForTaggedUnion(DeclRef<InterfaceDecl> interfaceDeclRef);

    /// Is the given interface requirement one that a tagged-union type can satisfy?
    ///
    /// Unsafe requirements include any `static` requirements,
    /// any associated types, and also any requirements that make
    /// use of the `This` type (once we support it).
    ///
    bool isInterfaceRequirementSafeForTaggedUnion(
        DeclRef<InterfaceDecl> interfaceDeclRef,
        DeclRef<Decl> requirementDeclRef);

    /// Check whether `subType` is a subtype of `superType`
    ///
    /// If `subType` is a subtype of `superType`, returns
    /// a witness value for the subtype relationship.
    ///
    /// If `subType` is *not* a subtype of `superType`, returns null.
    ///
    SubtypeWitness* isSubtype(Type* subType, Type* superType, IsSubTypeOptions isSubTypeOptions);

    SubtypeWitness* checkAndConstructSubtypeWitness(
        Type* subType,
        Type* superType,
        IsSubTypeOptions isSubTypeOptions);

    Witness* getDiffTypeInfoWitness(Type* type);
    Witness* getDiffTypeInfoWitness(DeclRef<FunctionDeclBase> callableDeclRef);

    bool isValidGenericConstraintType(Type* type);

    SubtypeWitness* isTypeDifferentiable(Type* type);

    /// Determine whether `type` has the storage property identified by `tag`.
    ///
    /// Returns whether `getTypeTags` establishes the property. A false result does not prove
    /// that a later specialization or linked replacement will lack it.
    bool doesTypeHaveTag(Type* type, TypeTag tag);

    /// Compute the storage properties of `type`, including its specialized instance fields.
    ///
    /// Checks aggregate and field declarations only far enough to use their types. Field
    /// initializers are checked only when needed to infer a type or array bound. For example,
    /// `struct Box<T> { T value; };` has an opaque field when instantiated as `Box<Texture2D>`,
    /// but not as `Box<float>`.
    /// Returns established flags, rather than proof that absent properties cannot occur.
    /// Unsubstituted generic parameters have no established flags. Includes `TypeTag::Incomplete`
    /// for externally replaceable definitions and link-time aliases, and when recursive
    /// inspection stops at a cycle or the nesting limit. Ordinary type validation diagnoses
    /// invalid recursion; linked-type validation checks restrictions after replacement.
    TypeTag getTypeTags(Type* type);

    Type* getConstantBufferElementType(Type* type);

    /// Check whether `subType` is a sub-type of `superTypeDeclRef`,
    /// and return a witness to the sub-type relationship if it holds
    /// (return null otherwise).
    ///
    SubtypeWitness* tryGetSubtypeWitness(Type* subType, Type* superType)
    {
        return isSubtype(subType, superType, IsSubTypeOptions::None);
    }

    /// Check whether `type` conforms to `interfaceDeclRef`,
    /// and return a witness to the conformance if it holds
    /// (return null otherwise).
    ///
    /// This function is equivalent to `tryGetSubtypeWitness()`.
    ///
    SubtypeWitness* tryGetInterfaceConformanceWitness(Type* type, Type* interfaceType);

    Expr* createCastToSuperTypeExpr(Type* toType, Expr* fromExpr, Val* witness);

    /// Expand a compressed interface-to-interface subtype witness into a
    /// transitive chain rooted at `subType`.
    ///
    /// The facet merger (see `_specializeInterfaceInheritanceWitness`) may
    /// produce a `DeclaredSubtypeWitness(sub, sup, declRef)` where
    /// `declRef.parent` is an interface *different* from `sub` — i.e. the
    /// witness is conceptually a composition of (sub : declRef.parent) and
    /// (declRef.parent : sup) but stored as a single node.  That shape is
    /// fine for facet-based lookup but malformed for IR lowering, because
    /// `declRef`'s inheritance key only resolves against the witness table
    /// of its declaring interface.
    ///
    /// This helper walks the witness tree and splits any such compressed
    /// step back into a `TransitiveSubtypeWitness`, so downstream lowering
    /// can mechanically chain `lookupWitnessMethod` calls without doing
    /// any inheritance-graph discovery itself.
    SubtypeWitness* normalizeSubtypeWitnessForInterfaceUpcast(
        Type* subType,
        SubtypeWitness* witness,
        int depth = 0);

    // Handles special modifier cases. In general case, calls createModifierCastExpr.
    Expr* createModifierCast(Type* toType, Type* fromType, Expr* fromExpr);
    Expr* createModifierCastExpr(Type* toType, Expr* fromExpr); // General modifier cast expr.

    /// Does there exist an implicit conversion from `fromType` to `toType`?
    bool canConvertImplicitly(Type* toType, QualType fromType);

    bool canConvertImplicitly(ConversionCost cost);

    ConversionCost getConversionCost(Type* toType, QualType fromType);

    Type* _tryJoinTypeWithInterface(
        GenericInferenceContext* constraints,
        Type* type,
        Type* interfaceType);

    // Try to compute the "join" between two types.
    //
    // `allowEnumScalarJoin` opts in to decaying an enum to its tag type so it can
    // join with a scalar; it is enabled only for common-type/convertibility
    // inference of ordinary call arguments (e.g. the arms of `?:`/`select`), and
    // left off for the witness/subtype/equality constraint solver, where a
    // fabricated enum->tag join would wrongly constrain a type parameter.
    Type* TryJoinTypes(
        GenericInferenceContext* constraints,
        QualType left,
        QualType right,
        bool allowEnumScalarJoin = false);

    // Try to solve the ordinary and witness arguments for one generic
    // application. The inference context must be moved into the solver because
    // solving drains discovered constraints, appends follow-up constraints, and
    // updates type-promotion cost while finding the final substitution.
    // Accepting an rvalue reference keeps this ownership transfer explicit and
    // avoids copying the discovered constraint list at the call boundary.
    //
    // Returns a new declref to the inner decl of `genericDeclRef`, representing
    // the specialized generic with the values and witnesses solved along the way.
    DeclRef<Decl> trySolveGenericArguments(
        GenericInferenceContext&& inferenceContext,
        DeclRef<GenericDecl> genericDeclRef,
        ArrayView<Val*> providedOrdinaryArgs,
        ConversionCost& outBaseCost);


    // State related to overload resolution for a call
    // to an overloaded symbol
    struct OverloadResolveContext
    {
        enum class Mode
        {
            // We are just checking if a candidate works or not
            JustTrying,

            // We want to actually update the AST for a chosen candidate
            ForReal,
        };

        // Location to use when reporting overload-resolution errors.
        SourceLoc loc;

        // The original expression (if any) that triggered things
        AppExprBase* originalExpr = nullptr;

        // Source location of the "function" part of the expression, if any
        SourceLoc funcLoc;

        // The source scope of the lookup for performing visibiliity tests.
        Scope* sourceScope = nullptr;

        // The original arguments to the call
        Index argCount = 0;
        List<Expr*>* args = nullptr;
        Type** argTypes = nullptr;

        Index getArgCount() { return argCount; }
        Expr*& getArg(Index index) { return (*args)[index]; }
        Type* getArgType(Index index)
        {
            if (argTypes)
                return argTypes[index];
            else
                return getArg(index)->type.type;
        }
        Type* getArgTypeForInference(Index index, SemanticsVisitor* semantics)
        {
            if (argTypes)
                return argTypes[index];
            else
                return semantics
                    ->maybeResolveOverloadedExpr(getArg(index), LookupMask::Default, nullptr)
                    ->type;
        }
        struct MatchedArg
        {
            Expr* argExpr = nullptr;
            Type* argType = nullptr;
        };
        bool matchArgumentsToParams(
            SemanticsVisitor* semantics,
            const List<QualType>& params,
            bool computeTypes,
            ShortList<MatchedArg>& outMatchedArgs);

        bool disallowNestedConversions = false;

        Expr* baseExpr = nullptr;

        // Are we still trying out candidates, or are we
        // checking the chosen one for real?
        Mode mode = Mode::JustTrying;

        // We store one candidate directly, so that we don't
        // need to do dynamic allocation on the list every time
        OverloadCandidate bestCandidateStorage;
        OverloadCandidate* bestCandidate = nullptr;

        // Full list of all candidates being considered, in the ambiguous case
        List<OverloadCandidate> bestCandidates;

        // Generic candidates whose recorded inference failure is a constraint failure (an
        // unsatisfied interface conformance or `where`-clause). Status-based pruning usually keeps
        // them out of `bestCandidates`, so they are retained here purely to render notes on the "no
        // overload applicable" error (issue #12965); this list never participates in selection.
        List<OverloadCandidate> constraintFailedGenericCandidates;
    };

    struct ParamCounts
    {
        Count required;
        Count allowed;
    };

    // count the number of parameters required/allowed for a callable
    ParamCounts CountParameters(List<DeclRef<ParamDecl>> const& params);

    // count the number of parameters required/allowed for a generic
    ParamCounts CountParameters(DeclRef<GenericDecl> genericRef);

    bool TryCheckOverloadCandidateClassNewMatchUp(
        OverloadResolveContext& context,
        OverloadCandidate const& candidate);

    bool TryCheckOverloadCandidateArity(
        OverloadResolveContext& context,
        OverloadCandidate const& candidate);

    bool TryCheckOverloadCandidateFixity(
        OverloadResolveContext& context,
        OverloadCandidate const& candidate);

    bool TryCheckOverloadCandidateVisibility(
        OverloadResolveContext& context,
        OverloadCandidate const& candidate);

    bool TryCheckGenericOverloadCandidateTypes(
        OverloadResolveContext& context,
        OverloadCandidate& candidate);

    bool TryCheckOverloadCandidateTypes(
        OverloadResolveContext& context,
        OverloadCandidate& candidate);

    bool TryCheckOverloadCandidateDirections(
        OverloadResolveContext& /*context*/,
        OverloadCandidate const& /*candidate*/
    );

    /// Check if the given `expr` refers to an `in` function
    /// parameter, or part of one (through field reference, etc.).
    ///
    /// If the expression refers into a parameter, returns
    /// the declaration of the parameter. Otherwise returns
    /// null.
    ///
    ParamDecl* isReferenceIntoFunctionInputParameter(Expr* expr);

    // Create a witness that attests to the fact that `type`
    // is equal to itself.
    TypeEqualityWitness* createTypeEqualityWitness(Type* type);

    // In the case where we are explicitly applying a generic
    // to arguments (e.g., `G<A,B>`) check that the constraints
    // on those parameters are satisfied.
    //
    // Note: the constraints actually work as additional parameters/arguments
    // of the generic, and so we need to reify them into the final
    // argument list.
    //
    bool TryCheckOverloadCandidateConstraints(
        OverloadResolveContext& context,
        OverloadCandidate& candidate);

    // Try to check an overload candidate, but bail out
    // if any step fails
    void TryCheckOverloadCandidate(OverloadResolveContext& context, OverloadCandidate& candidate);

    // Create the representation of a given generic applied to some arguments
    Expr* createGenericDeclRef(Expr* baseExpr, Expr* originalExpr, SubstitutionSet substSet);

    // Take an overload candidate that previously got through
    // `TryCheckOverloadCandidate` above, and try to finish
    // up the work and turn it into a real expression.
    //
    // If the candidate isn't actually applicable, this is
    // where we'd start reporting the issue(s).
    //
    // A call whose callee expression has an `ErrorType` is itself returned with an
    // `ErrorType`, as in `ResolveInvoke`, so consumers such as `visitTryExpr` can rely
    // on any call that is not an error having a `FuncType`-typed callee.
    Expr* CompleteOverloadCandidate(OverloadResolveContext& context, OverloadCandidate& candidate);

    // Implement a comparison operation between overload candidates,
    // so that the better candidate compares as less-than the other
    int CompareOverloadCandidates(OverloadCandidate* left, OverloadCandidate* right);

    /// Applies the pre-202c generic-parameter-count tie-breaker after all ordinary ranking rules.
    /// On success, copies the unique selected candidate into `context.bestCandidateStorage`, points
    /// `context.bestCandidate` at that storage, clears `context.bestCandidates`, and returns true.
    /// When `warningSink` is non-null, also emits the deprecation warning at `warningLocation`.
    /// On failure, leaves `context` unchanged and returns false.
    ///
    /// The final source-level call sites are `ResolveInvoke` and `_coerce`. `ResolveInvoke` always
    /// materializes an expression and passes its sink. `_coerce` passes its sink only when it also
    /// receives `outToExpr`; a speculative conversion-cost probe passes null so that the eventual
    /// materialization reports the warning.
    bool tryResolveOverloadUsingLegacyGenericParameterCountFallback(
        OverloadResolveContext& context,
        SourceLoc warningLocation,
        DiagnosticSink* warningSink);

    /// Returns the required parameter count of the generic whose inner declaration `declRef`
    /// names, or zero when `declRef` does not name a generic's inner declaration.
    Int getRequiredGenericParameterCount(DeclRef<Decl> const& declRef);

    /// Compare items `left` and `right` produced by lookup, to see if one should be favored for
    /// overloading.
    int CompareLookupResultItems(LookupResultItem const& left, LookupResultItem const& right);

    /// Compare items `left` and `right` being considered as overload candidates, and determine if
    /// one should be favored for structural reasons.
    int compareOverloadCandidateSpecificity(
        LookupResultItem const& left,
        LookupResultItem const& right);

    void AddOverloadCandidateInner(OverloadResolveContext& context, OverloadCandidate& candidate);

    void AddOverloadCandidate(
        OverloadResolveContext& context,
        OverloadCandidate& candidate,
        ConversionCost baseCost);

    void AddHigherOrderOverloadCandidates(
        Expr* funcExpr,
        OverloadResolveContext& context,
        ConversionCost baseCost);

    void AddFuncOverloadCandidate(
        LookupResultItem item,
        DeclRef<CallableDecl> funcDeclRef,
        OverloadResolveContext& context,
        ConversionCost baseCost);

    void AddFuncOverloadCandidate(
        FuncType* /*funcType*/,
        OverloadResolveContext& /*context*/,
        ConversionCost baseCost);

    void AddFuncExprOverloadCandidate(
        FuncType* funcType,
        OverloadResolveContext& context,
        Expr* expr,
        ConversionCost baseCost);

    // Add a candidate callee for overload resolution, based on
    // calling a particular `ConstructorDecl`.
    void AddCtorOverloadCandidate(
        LookupResultItem typeItem,
        Type* type,
        DeclRef<ConstructorDecl> ctorDeclRef,
        OverloadResolveContext& context,
        Type* resultType,
        ConversionCost baseCost);

    // If the given declaration has generic parameters, then
    // return the corresponding `GenericDecl` that holds the
    // parameters, etc. This returns the immediate generic parent
    // of `decl`, e.g. the generic for f<T>, and *not* any indirect
    // generic parents, such as P<T>.f().
    GenericDecl* GetOuterGeneric(Decl* decl);

    // If `decl` is inside a generic, return that outer generic,
    // otherwise returns `decl`.
    Decl* getOuterGenericOrSelf(Decl* decl);

    // Find the next outer generic parent of `decl`, including
    // indirect parents.
    GenericDecl* findNextOuterGeneric(Decl* decl);

    // Per-call options for recursive unification. These fields describe how a
    // discovered ordinary argument constraint should be interpreted, but they
    // do not own the discovered constraints themselves.
    struct UnificationOptions
    {
        // When a pack is expanded during unification, this records which pack
        // element is currently being constrained.
        Index indexInTypePack = 0;

        // True when the discovered constraint should be treated as optional
        // overload-ranking information rather than as a required answer.
        bool optionalConstraint = false;

        // True when a discovered type argument must be an exact answer instead
        // of being merged through the usual type-join behavior.
        bool equalityConstraint = false;
    };

    // Try to find a unification for two values
    bool TryUnifyVals(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        Val* fst,
        bool fstLVal,
        Val* snd,
        bool sndLVal);

    bool tryUnifyDeclRef(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        DeclRefBase* fst,
        bool fstLVal,
        DeclRefBase* snd,
        bool sndLVal);

    bool tryUnifyGenericAppDeclRef(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        GenericAppDeclRef* fst,
        bool fstLVal,
        GenericAppDeclRef* snd,
        bool sndLVal);

    bool TryUnifyTypeParam(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        GenericTypeParamDeclBase* typeParamDecl,
        QualType type);

    bool TryUnifyIntParam(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        GenericValueParamDecl* paramDecl,
        IntVal* val);

    bool TryUnifyIntParam(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        DeclRef<VarDeclBase> const& varRef,
        IntVal* val);

    bool TryUnifyFunctorByStructuralMatch(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        StructDecl* fst,
        FuncType* snd);

    bool TryUnifyFuncTypesByStructuralMatch(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        FuncType* fst,
        FuncType* snd);

    bool TryUnifyTypesByStructuralMatch(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        QualType fst,
        QualType snd);

    bool TryUnifyTypes(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        QualType fst,
        QualType snd);

    bool TryUnifyConjunctionType(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        QualType fst,
        QualType snd);

    bool tryAddOptionalIntParamConstraintIfUnconstrained(
        GenericInferenceContext& constraints,
        UnificationOptions unificationOptions,
        IntVal* param,
        IntVal* arg,
        bool paramIsLVal);

    // Is the candidate extension declaration actually applicable to the given type
    DeclRef<ExtensionDecl> applyExtensionToType(
        ExtensionDecl* extDecl,
        Type* type,
        Dictionary<Type*, SubtypeWitness*>* additionalSubtypeWitnessesForType = nullptr);

    // Take a generic declaration that is being applied
    // in a context and attempt to infer any missing generic
    // arguments to form a `DeclRef` to the inner declaration
    // that could be applicable in the context of the given
    // overloaded call.
    // Also computes a `baseCost` for the inferred arguments,
    // so that we can prefer a more specialized generic candidate
    // when there is ambiguity. For example, given
    // ```
    //     interface IBase;
    //     interface IDerived : IBase;
    //     struct Derived : IDerived {}
    //     void f1<T:IBase>(T b)
    //     void f2<T:IDerived>(T b);
    // ```
    // We will prefer f2 when seeing f(Derived()), because it takes
    // less steps to upcast `Derived` to  `IDerived` than it does
    // to `IBase`.
    //
    DeclRef<Decl> inferGenericArguments(
        DeclRef<GenericDecl> genericDeclRef,
        OverloadResolveContext& context,
        ArrayView<Val*> providedOrdinaryArgs,
        ConversionCost& outBaseCost,
        List<QualType>* innerParameterTypes = nullptr,
        GenericArgumentInferenceFailure* outFailure = nullptr);

    void AddTypeOverloadCandidates(Type* type, OverloadResolveContext& context);

    void AddDeclRefOverloadCandidates(
        LookupResultItem item,
        OverloadResolveContext& context,
        ConversionCost baseCost);

    void AddOverloadCandidates(LookupResult const& result, OverloadResolveContext& context);

    void AddOverloadCandidates(Expr* funcExpr, OverloadResolveContext& context);

    String getCallSignatureString(OverloadResolveContext& context);

    Expr* ResolveInvoke(InvokeExpr* expr);

    void AddGenericOverloadCandidate(LookupResultItem baseItem, OverloadResolveContext& context);

    void AddGenericOverloadCandidates(Expr* baseExpr, OverloadResolveContext& context);

    // Given an argument list, expand all `expand` expressions, if the type/value pack being
    // expanded is already specialized.
    void maybeExpandArgList(List<Expr*>& args);

    template<class T>
    void trySetGenericToRayTracingWithParamAttribute(
        LookupResultItem genericItem,
        DeclRef<GenericDecl> genericDeclRef,
        OverloadResolveContext& context);

    // Add overload candidates based on use of `genericDeclRef`
    // in an ordinary function-call context (that is, where it
    // has been applied to arguments using `()` and not `<>`).
    //
    // If some or all of the ordinary generic arguments to `genericDeclRef`
    // are already provided, they should be passed in via `providedOrdinaryArgs`.
    //
    void addOverloadCandidatesForCallToGeneric(
        LookupResultItem genericItem,
        OverloadResolveContext& context,
        ArrayView<Val*> providedOrdinaryArgs);

    /// Check a generic application where the operands have already been checked.
    Expr* checkGenericAppWithCheckedArgs(GenericAppExpr* genericAppExpr);

    Expr* CheckExpr(Expr* expr);


    void compareMemoryQualifierOfParamToArgument(ParamDecl* paramIn, Expr* argIn);
    void _checkAliasedOutArguments(
        InvokeExpr* invoke,
        FuncType* funcType,
        List<DeclRef<ParamDecl>> const& paramDeclRefs);
    Expr* CheckInvokeExprWithCheckedOperands(InvokeExpr* expr);

    /// Diagnose `invoke`, a call whose callee may throw, unless a `try` covers it. While its
    /// coverage is pending, `invoke` is added to `m_pendingTryCoverage` instead.
    void checkThrowingCallIsCovered(InvokeExpr* invoke);

    /// Return whether the coverage of the throwing calls in the argument of `expr` waits for
    /// `expr` to resolve: `expr` is a single-argument call that is not an operator, so it may
    /// resolve to an identity conversion of its argument, and a `try` covers or may cover it.
    bool shouldDeferArgumentTryCoverage(InvokeExpr* expr);

    /// Settle the coverage of `pendingCalls`, collected while the argument of a call was checked.
    /// A pending call that the call resolved to (`checkedExpr`) is covered when the call would be;
    /// no `try` covers any other pending call.
    void settlePendingTryCoverage(Expr* checkedExpr, List<InvokeExpr*> const& pendingCalls);

    // Get the type to use when referencing a declaration
    QualType GetTypeForDeclRef(DeclRef<Decl> declRef, SourceLoc loc);

    //
    //
    //

    Expr* CheckMatrixSwizzleExpr(
        MemberExpr* memberRefExpr,
        Type* baseElementType,
        IntegerLiteralValue baseElementRowCount,
        IntegerLiteralValue baseElementColCount);

    Expr* CheckMatrixSwizzleExpr(
        MemberExpr* memberRefExpr,
        Type* baseElementType,
        IntVal* baseElementRowCount,
        IntVal* baseElementColCount);

    Expr* checkTupleSwizzleExpr(MemberExpr* memberExpr, TupleType* baseTupleType);

    Expr* CheckSwizzleExpr(
        MemberExpr* memberRefExpr,
        Type* baseElementType,
        IntegerLiteralValue baseElementCount);

    Expr* CheckSwizzleExpr(
        MemberExpr* memberRefExpr,
        Type* baseElementType,
        IntVal* baseElementCount);

    // Check a member expr as a general member lookup.
    // This is the default/fallback behavior if the base type isn't swizzlable.
    Expr* checkGeneralMemberLookupExpr(MemberExpr* expr, Type* baseType);

    /// Perform semantic checking of an assignment where the operands have already been checked.
    Expr* checkAssignWithCheckedOperands(AssignExpr* expr);

    // Look up a static member
    // @param expr Can be StaticMemberExpr or MemberExpr
    // @param baseExpression Is the underlying type expression determined from resolving expr
    Expr* _lookupStaticMember(DeclRefExpr* expr, Expr* baseExpression);

    Expr* visitStaticMemberExpr(StaticMemberExpr* expr);

    /// Perform checking operations required for the "base" expression of a member-reference like
    /// `base.someField`
    enum class CheckBaseContext
    {
        Member,
        Subscript,
    };
    Expr* checkBaseForMemberExpr(
        Expr* baseExpr,
        CheckBaseContext checkBaseContext,
        bool& outNeedDeref);

    Expr* maybeDereference(Expr* inExpr, CheckBaseContext checkBaseContext);

    /// Prepare baseExpr for use as the base of a member expr.
    /// This include inserting implicit open-existential operations as needed.
    Expr* maybeInsertImplicitOpForMemberBase(
        Expr* baseExpr,
        CheckBaseContext checkBaseContext,
        bool& outNeedDeref);

    Expr* lookupMemberResultFailure(
        DeclRefExpr* expr,
        QualType const& baseType,
        bool supressDiagnostic = false);

    /// Called after member lookup on `expr` has failed with `baseType` as the base. If the base is
    /// a user-declared generic type parameter (directly, or as `T.m` / `v::m`), emit a note for
    /// each interface that: is visible from the failed access and not from the core module;
    /// directly declares a visible requirement of the failed name, static when the access is
    /// static; and, by its unqualified name, resolves to itself at the generic declaration that
    /// owns the parameter. A non-generic interface gets `where T : IFoo`; a generic one gets
    /// "consider constraining 'T' to interface 'IFoo'", since its type arguments cannot be
    /// inferred.
    void maybeSuggestMissingGenericConstraintForMemberLookup(
        DeclRefExpr* expr,
        QualType const& baseType);

    /// Return true if looking up `name` from `scope` (default lookup mask, keeping only results
    /// visible from `scope`) finds exactly one distinct declaration and it is `decl`. A diagnostic
    /// that prints an unqualified name for the user to write at `scope` uses this to check the name
    /// will mean `decl` there; for a generic declaration, `decl` is the `GenericDecl`, which is
    /// what lookup returns for its name. The default mask also finds non-type declarations, so a
    /// same-named function makes this conservatively return false.
    bool doesNameResolveToDecl(Name* name, Scope* scope, Decl* decl);

    SharedSemanticsContext& operator=(const SharedSemanticsContext&) = delete;


    //

    void importModuleIntoScope(Scope* scope, ModuleDecl* moduleDecl);
    void importFileDeclIntoScope(Scope* scope, FileDecl* fileDecl);


    void suggestCompletionItems(
        CompletionSuggestions::ScopeKind scopeKind,
        LookupResult const& lookupResult);

    bool createInvokeExprForExplicitCtor(
        Type* toType,
        InitializerListExpr* fromInitializerListExpr,
        Expr** outExpr);

    bool createCtorInvokeExprForAbstractType(
        Type* toType,
        InitializerListExpr* fromInitializerListExpr,
        Expr** outExpr);

    bool createInvokeExprForSynthesizedCtor(
        Type* toType,
        InitializerListExpr* fromInitializerListExpr,
        Expr** outExpr);

    Expr* _createCtorInvokeExpr(Type* toType, const SourceLoc& loc, const List<Expr*>& coercedArgs);
    bool _hasExplicitConstructor(StructDecl* structDecl, bool checkBaseType);
    ConstructorDecl* _getSynthesizedConstructor(
        StructDecl* structDecl,
        ConstructorDecl::ConstructorFlavor flavor);
    bool isCStyleType(Type* type, HashSet<Type*>& isVisit);

    void addVisibilityModifier(Decl* decl, DeclVisibility vis);

    void checkRayPayloadStructFields(StructDecl* structDecl);

    CatchStmt* findMatchingCatchStmt(Type* errorType);

    DeclaredSubtypeWitness* getThisTypeWitness(
        ASTBuilder* astBuilder,
        DeclRef<InterfaceDecl> interfaceDeclRef);

    // Differentiability of a function is represented by conformance of the function-as-type to
    // `IForwardDifferentiable`/`IBackwardDifferentiable`. Query that conformance directly instead
    // of probing for the `fwd_diff`/`bwd_diff` associated-function entries; those entries are
    // witnesses produced by the conformance, not the source of truth.
    SubtypeWitness* isFuncForwardDifferentiable(DeclRef<CallableDecl> declRef);
    SubtypeWitness* isFuncBackwardDifferentiable(DeclRef<CallableDecl> declRef);
};


inline void ensureDecl(SemanticsVisitor* visitor, Decl* decl, DeclCheckState state)
{
    visitor->ensureDecl(decl, state);
}

DeclRef<ExtensionDecl> applyExtensionToType(
    SemanticsVisitor* semantics,
    ExtensionDecl* extDecl,
    Type* type,
    Dictionary<Type*, SubtypeWitness*>* additionalSubtypeWitness = nullptr);


struct SemanticsExprVisitor : public SemanticsVisitor, ExprVisitor<SemanticsExprVisitor, Expr*>
{
public:
    SemanticsExprVisitor(SemanticsContext const& outer)
        : SemanticsVisitor(outer)
    {
    }

    Expr* visitSizeOfLikeExpr(SizeOfLikeExpr* expr);
    Expr* visitFloatBitCastExpr(FloatBitCastExpr* expr);
    Expr* visitAddressOfExpr(AddressOfExpr* expr);
    Expr* visitIncompleteExpr(IncompleteExpr* expr);
    Expr* visitBoolLiteralExpr(BoolLiteralExpr* expr);
    Expr* visitNullPtrLiteralExpr(NullPtrLiteralExpr* expr);
    Expr* visitNoneLiteralExpr(NoneLiteralExpr* expr);
    Expr* visitIntegerLiteralExpr(IntegerLiteralExpr* expr);
    Expr* visitFloatingPointLiteralExpr(FloatingPointLiteralExpr* expr);
    Expr* visitStringLiteralExpr(StringLiteralExpr* expr);

    Expr* visitIndexExpr(IndexExpr* subscriptExpr);

    Expr* visitParenExpr(ParenExpr* expr);

    Expr* visitTupleExpr(TupleExpr* expr);

    Expr* visitAssignExpr(AssignExpr* expr);

    Expr* visitGenericAppExpr(GenericAppExpr* genericAppExpr);

    Expr* visitSharedTypeExpr(SharedTypeExpr* expr);

    Expr* visitInvokeExpr(InvokeExpr* expr);

    // A `BuiltinOperatorExpr` is produced already-checked by `convertToBuiltinArithmeticOp`
    // (during `visitInvokeExpr`), so checking it is a no-op; this exists for visitor
    // completeness / idempotent re-checks.
    Expr* visitBuiltinOperatorExpr(BuiltinOperatorExpr* expr);

    Expr* visitSelectExpr(SelectExpr* expr);

    Expr* visitVarExpr(VarExpr* expr);

    Expr* visitTypeCastExpr(TypeCastExpr* expr);

    Expr* visitBuiltinCastExpr(BuiltinCastExpr* expr);

    Expr* visitTryExpr(TryExpr* expr);

    Expr* visitIsTypeExpr(IsTypeExpr* expr);

    Expr* visitAsTypeExpr(AsTypeExpr* expr);

    Expr* visitExpandExpr(ExpandExpr* expr);

    Expr* visitEachExpr(EachExpr* expr);

    Expr* visitLambdaExpr(LambdaExpr* expr);

    void maybeCheckKnownBuiltinInvocation(Expr* invokeExpr);

    //
    // Some syntax nodes should not occur in the concrete input syntax,
    // and will only appear *after* checking is complete. We need to
    // deal with this cases here, even if they are no-ops.
    //

#define CASE(NAME) \
    Expr* visit##NAME(NAME* expr) { return expr; }

    CASE(DerefExpr)
    CASE(MakeRefExpr)
    CASE(MatrixSwizzleExpr)
    CASE(SwizzleExpr)
    CASE(OverloadedExpr)
    CASE(OverloadedExpr2)
    CASE(AggTypeCtorExpr)
    CASE(ModifierCastExpr)
    CASE(LetExpr)
    CASE(ExtractExistentialValueExpr)
    CASE(OpenRefExpr)
    CASE(MakeOptionalExpr)
    CASE(CastOptionalExpr)
    CASE(PartiallyAppliedGenericExpr)
    CASE(PackExpr)
#undef CASE

    Expr* visitStaticMemberExpr(StaticMemberExpr* expr);

    Expr* visitMemberExpr(MemberExpr* expr);

    Expr* visitInitializerListExpr(InitializerListExpr* expr);
    Expr* visitMakeArrayFromElementExpr(MakeArrayFromElementExpr* expr);

    Expr* visitThisExpr(ThisExpr* expr);
    Expr* visitThisTypeExpr(ThisTypeExpr* expr);
    Expr* visitHLSLUnsignedTypeExpr(HLSLUnsignedTypeExpr* expr);
    Expr* visitThisInterfaceExpr(ThisInterfaceExpr* expr);
    Expr* visitCastToSuperTypeExpr(CastToSuperTypeExpr* expr);
    Expr* visitReturnValExpr(ReturnValExpr* expr);
    Expr* visitAndTypeExpr(AndTypeExpr* expr);
    Expr* visitPointerTypeExpr(PointerTypeExpr* expr);
    Expr* visitModifiedTypeExpr(ModifiedTypeExpr* expr);
    Expr* visitFuncTypeExpr(FuncTypeExpr* expr);
    Expr* visitTupleTypeExpr(TupleTypeExpr* expr);
    Expr* visitPackBranchTypeExpr(PackBranchTypeExpr* expr);

    Expr* visitFuncAsTypeExpr(FuncAsTypeExpr* expr);
    Expr* visitFuncTypeOfExpr(FuncTypeOfExpr* expr);

    Expr* visitForwardDifferentiateExpr(ForwardDifferentiateExpr* expr);
    Expr* visitBackwardDifferentiateExpr(BackwardDifferentiateExpr* expr);
    Expr* visitApplyForBwdExpr(ApplyForBwdExpr* expr);
    Expr* visitPrimalSubstituteExpr(PrimalSubstituteExpr* expr);
    Expr* visitDispatchKernelExpr(DispatchKernelExpr* expr);

    Expr* visitTreatAsDifferentiableExpr(TreatAsDifferentiableExpr* expr);

    Expr* visitGetArrayLengthExpr(GetArrayLengthExpr* expr);

    Expr* visitPackQueryExpr(PackQueryExpr* expr);
    Expr* visitShapePackTransformExpr(ShapePackTransformExpr* expr);

    Expr* visitDefaultConstructExpr(DefaultConstructExpr* expr);

    Expr* visitDetachExpr(DetachExpr* expr);

    Expr* visitSPIRVAsmExpr(SPIRVAsmExpr*);

    /// Perform semantic checking on a `modifier` that is being applied to the given `type`
    Val* checkTypeModifier(Modifier* modifier, Type* type);

private:
    // Convert the logic operator expression to not use 'InvokeExpr' type
    Expr* convertToLogicOperatorExpr(InvokeExpr* expr);

    // Recognize an ordinary builtin operator on builtin scalar/vector/matrix operands and
    // rewrite it directly to a `BuiltinOperatorExpr` carrying the resolved `BuiltinOperationKind`,
    // returning null when the operator should instead go through normal overload resolution.
    //
    // This exists for performance: the vast majority of operators in real shader code are builtin
    // arithmetic/comparison/bitwise/unary ops on numeric scalars/vectors/matrices, and routing
    // each one through full generic `operator OP` overload resolution (candidate collection,
    // inference, coercion) is a large front-end cost. Handling them here lets the common case skip
    // all of that and lower straight to the corresponding builtin IR op.
    //
    // Recognized: `+ - * / %`, `== != < > <= >=`, `& | ^ << >>`, and unary `- ! ~` on builtin
    // integer/floating-point/bool operands (same-type operands as-is; different builtin types
    // promoted via `getBuiltinArithmeticCommonType`). Returns null to fall back to normal
    // resolution for: the short-circuiting `&&`/`||`, mixed shapes that are not
    // broadcast-compatible, user-defined operand types, and -- in GLSL operator scope only --
    // matrix operands and vector equality (`==`/`!=`), whose semantics the `glsl` module owns.
    Expr* convertToBuiltinArithmeticOp(InvokeExpr* expr);

    // For a builtin binary operator `a OP b` whose operands have *different* builtin
    // scalar/vector/matrix types, compute the common operand type that overload resolution
    // would converge on (the "usual arithmetic conversions"): the result element type is the
    // higher-ranked of the two base types (float beats int; among ints the larger size wins,
    // and on a size tie the unsigned type wins) so neither operand needs a narrowing
    // conversion, and the result shape broadcasts a scalar against a vector/matrix (requiring
    // matching extents for vector-vector / matrix-matrix). Returns null when the operands are
    // not both builtin numeric scalar/vector/matrix types or the shapes are not
    // broadcast-compatible, in which case the caller falls back to overload resolution.
    Type* getBuiltinArithmeticCommonType(Type* left, Type* right);

    // Return `target` with its element/base type replaced by `newElementType`, preserving the
    // composite shape: a scalar becomes `newElementType`, a `vector<T,N>` becomes
    // `vector<newElementType,N>`, and a `matrix<T,R,C>` becomes `matrix<newElementType,R,C>`.
    Type* substituteElementOfCompositeType(Type* target, Type* newElementType);

    // Coerce the operands of a builtin binary operator to the common operand type that overload
    // resolution would have selected (via `getBuiltinArithmeticCommonType`), and return that
    // type. Each operand is converted to its *own* shape with the common element base (so e.g. a
    // `vector * scalar` stays a two-shape operation that backends can lower to a vector-times-
    // scalar instruction). `outLeftArg`/`outRightArg` receive the (possibly coerced) operand
    // expressions. Operands that are already the same type are returned unchanged. Returns null
    // when the operands are not broadcast-compatible builtin numeric types or a coercion fails,
    // signalling that the fast-path conversion should be abandoned.
    Type* coerceOperandsOfBuiltinBinaryExpr(
        Expr* leftArg,
        Expr* rightArg,
        Expr*& outLeftArg,
        Expr*& outRightArg);

    /// The scalar family (integer, floating-point, or boolean) that an operand element type is
    /// known to belong to for the purposes of the builtin-operator fast path. All three fields
    /// are false when the type is not known to belong to any of them.
    struct BuiltinArithmeticElementFamily
    {
        bool isInteger = false;
        bool isFloat = false;
        // True only for a genuinely `bool`-typed element: the concrete-type branch of
        // `classifyBuiltinArithmeticElementType` sets this from `baseType == BaseType::Bool`
        // directly. There is no sealed marker interface implemented by `bool` alone --
        // `__BuiltinLogicalType` (see `isLogical` below) is implemented by `bool` AND every
        // builtin integer type -- so a generic type parameter can never prove `isBool`; only a
        // concrete `bool` operand can. Required for unary logical-not (`!`), whose result must
        // be `bool`-shaped: taking the fast path for a `__BuiltinLogicalType`-constrained
        // generic instantiated with an integer would build a `Not` node typed as that integer.
        bool isBool = false;
        // True for a *generic* element type that conforms to `__BuiltinLogicalType` (`bool` and
        // every builtin integer type; see core.meta.slang) -- the concrete-type branch never sets
        // this, since a concrete `bool`/integer is already fully classified by `isBool`/
        // `isInteger`. Safe for an operator whose builtin semantics don't depend on which of
        // those the element actually is, e.g. equality (`==`/`!=`, which lower to the same
        // `kIROp_Eql`/`kIROp_Neq` regardless): a generic parameter constrained only to
        // `__BuiltinLogicalType` still needs equality fast-pathed, but must NOT take the
        // logical-not fast path -- that's exactly why this is a separate flag from `isBool`
        // rather than folded into it.
        bool isLogical = false;
        bool isKnown() const { return isInteger || isFloat || isBool || isLogical; }
    };

    /// Classifies `elementType`'s scalar family for the builtin-operator fast path in
    /// `convertToBuiltinArithmeticOp`. A concrete `BasicExpressionType` (`int`, `float`, `bool`,
    /// ...) is classified directly from `BaseTypeInfo`. A generic type parameter constrained to
    /// one of the `[sealed]` builtin marker interfaces (`__BuiltinIntegerType`,
    /// `__BuiltinFloatingPointType`, `__BuiltinLogicalType`; see core.meta.slang) is classified
    /// the same way: those interfaces are sealed, so only the compiler's own builtin scalar types
    /// can conform to them, which means every legal instantiation of such a parameter is itself a
    /// `BasicExpressionType` of that family, even though the parameter is not one yet. Any other
    /// type (aggregates, an unconstrained or differently-constrained generic parameter, etc.)
    /// classifies as unknown, which the caller treats as "not eligible for the fast path."
    BuiltinArithmeticElementFamily classifyBuiltinArithmeticElementType(Type* elementType);

    // True when builtin operators may have GLSL rather than Slang/HLSL semantics: either
    // `-allow-glsl` is set, or the `glsl` module is in scope (its `operator*` overloads
    // make `mat * mat` a matrix product). The builtin-operator fast path is disabled then.
    bool isGLSLOperatorScope();
};

struct SemanticsStmtVisitor : public SemanticsVisitor, StmtVisitor<SemanticsStmtVisitor>
{
    SemanticsStmtVisitor(SemanticsContext const& outer)
        : SemanticsVisitor(outer)
    {
    }

    FunctionDeclBase* getParentFunc() { return m_parentFunc; }

    void checkStmt(Stmt* stmt);

    Stmt* findOuterStmtWithLabel(Name* label);

    void visitDeclStmt(DeclStmt* stmt);

    /// Check `decl`, a local declaration whose statement has been reached, make it
    /// visible to the code that follows its declarator, and register the lambda
    /// captures in its initializer.
    void checkDeclAtDeclarationPoint(Decl* decl);

    void visitBlockStmt(BlockStmt* stmt);

    void visitSeqStmt(SeqStmt* stmt);

    void visitLabelStmt(LabelStmt* stmt);

    void visitBreakStmt(BreakStmt* stmt);

    void visitContinueStmt(ContinueStmt* stmt);

    void visitDoWhileStmt(DoWhileStmt* stmt);

    void visitForStmt(ForStmt* stmt);

    void visitCompileTimeForStmt(CompileTimeForStmt* stmt);

    void visitSwitchStmt(SwitchStmt* stmt);

    void visitCaseStmt(CaseStmt* stmt);

    void visitTargetSwitchStmt(TargetSwitchStmt* stmt);

    void visitTargetCaseStmt(TargetCaseStmt* stmt);

    void visitIntrinsicAsmStmt(IntrinsicAsmStmt*);

    void visitDefaultStmt(DefaultStmt* stmt);

    void visitIfStmt(IfStmt* stmt);

    void visitUnparsedStmt(UnparsedStmt*);

    void visitEmptyStmt(EmptyStmt*);

    void visitDiscardStmt(DiscardStmt*);

    void visitReturnStmt(ReturnStmt* stmt);

    void visitDeferStmt(DeferStmt* stmt);

    void visitThrowStmt(ThrowStmt* stmt);

    void visitCatchStmt(CatchStmt* stmt);

    void visitWhileStmt(WhileStmt* stmt);

    void visitGpuForeachStmt(GpuForeachStmt* stmt);

    void visitExpressionStmt(ExpressionStmt* stmt);

    void visitRequireCapabilityStmt(RequireCapabilityStmt* stmt);

    // If `expr` is the discarded result of a call to a `[NoDiscard]` function,
    // emit an error. Used for any context where an expression's result is
    // ignored (an expression statement, or a `for` loop's side-effect expression).
    void maybeDiagnoseDiscardedNoDiscardResult(Expr* expr);

    // Try to infer the max number of iterations the loop will run.
    void tryInferLoopMaxIterations(ForStmt* stmt);

    void checkLoopInDifferentiableFunc(Stmt* stmt);

private:
    void validateCaseStmts(SwitchStmt* stmt, DiagnosticSink* sink);

    void generateUniqueIDForStmt(BreakableStmt* stmt);
};

struct SemanticsDeclVisitorBase : public SemanticsVisitor
{
    SemanticsDeclVisitorBase(SemanticsContext const& outer)
        : SemanticsVisitor(outer)
    {
    }

    void checkBodyStmt(Stmt* stmt, FunctionDeclBase* parentDecl)
    {
        checkStmt(stmt, withParentFunc(parentDecl));
    }

    void checkModule(ModuleDecl* programNode);

    ConstructorDecl* createCtor(AggTypeDecl* decl, DeclVisibility ctorVisibility);
};

bool isUnsizedArrayType(Type* type);

bool isInterfaceType(Type* type);

bool isImmutableBufferType(Type* type);

// Check if `type` is nullable. An `Optional<T>` will occupy the same space as `T`, if `T`
// is nullable.
bool doesTypeHaveAnUnusedBitPatternThatCanBeUsedForOptionalRepresentation(Type* type);

EnumDecl* isEnumType(Type* type);

DeclVisibility getDeclVisibility(Decl* decl);

// If `type` is unsized, return the trailing unsized array field that makes it so.
VarDeclBase* getTrailingUnsizedArrayElement(
    Type* type,
    VarDeclBase* rootObject,
    ArrayExpressionType*& outArrayType);

// Test if `type` can be an opaque handle on certain targets, this includes
// texture, buffer, sampler, acceleration structure, etc.
bool isOpaqueHandleType(Type* type);

// Returns true if `type` itself is an opaque handle type, or if it is a struct
// (or array thereof) that transitively contains an opaque handle field.
bool typeTransitivelyContainsOpaqueHandle(SemanticsVisitor* visitor, Type* type);

void diagnoseMissingCapabilityProvenance(
    CompilerOptionSet& optionSet,
    DiagnosticSink* sink,
    Decl* decl,
    CapabilitySet const& setToFind);
void diagnoseCapabilityProvenance(
    CompilerOptionSet& optionSet,
    DiagnosticSink* sink,
    Decl* decl,
    CapabilityAtom atomToFind,
    HashSet<Decl*>& printedDecls);

void _ensureAllDeclsRec(SemanticsDeclVisitorBase* visitor, Decl* decl, DeclCheckState state);

RefPtr<EntryPoint> findAndValidateEntryPoint(FrontEndEntryPointRequest* entryPointReq);

bool resolveStageOfProfileWithEntryPoint(
    Profile& entryPointProfile,
    CompilerOptionSet& optionSet,
    const List<RefPtr<TargetRequest>>& targets,
    FuncDecl* entryPointFuncDecl,
    DiagnosticSink* sink);

// For an extensions decl, collect a list of decls on which the extension might be applying to.
// For example, if we see a `extension Foo`, return a `Decl*` that represents `struct Foo`.
// In the case of free-form generic extensions i.e. `extension<T:IFoo> T : IBar`, return `IFoo`.
// These are the decls that we need to register the extension with in
// `mapTypeToCandidateExtensions`.
// Returns true when any base decls are found.
bool getExtensionTargetDeclList(
    ASTBuilder* astBuilder,
    DeclRefType* targetDeclRefType,
    ExtensionDecl* extDeclRef,
    ShortList<AggTypeDecl*>& targetDecls);

void validateEntryPoint(EntryPoint* entryPoint, DiagnosticSink* sink);

// Collect the requirements of a checked declaration reference, including its generic arguments.
// Append contributing declarations to `outReferencedDecls` for use-site diagnostics without
// changing the shared declaration's requirements or provenance.
CapabilitySet getDeclRefCapabilityRequirements(
    SemanticsVisitor* visitor,
    DeclRef<Decl> declRef,
    List<Decl*>& outReferencedDecls);

RefPtr<ComponentType> createUnspecializedGlobalComponentType(
    FrontEndCompileRequest* compileRequest);

RefPtr<ComponentType> createUnspecializedGlobalAndEntryPointsComponentType(
    FrontEndCompileRequest* compileRequest,
    List<RefPtr<ComponentType>>& outUnspecializedEntryPoints);

RefPtr<ComponentType> createSpecializedGlobalComponentType(EndToEndCompileRequest* endToEndReq);

RefPtr<ComponentType> createSpecializedGlobalAndEntryPointsComponentType(
    EndToEndCompileRequest* endToEndReq,
    List<RefPtr<ComponentType>>& outSpecializedEntryPoints);

// Return the witness that proves a type-coercion constraint under `args`, or
// `nullptr` if the substituted source and destination types cannot be coerced.
// `maybeContext` is required when `shouldEmitError` is true so diagnostics can
// point at the operation that requested the constraint.
TypeCoercionWitness* findTypeCoercionWitnessForConstraint(
    ASTBuilder* astBuilder,
    SemanticsVisitor* visitor,
    TypeCoercionConstraintDecl* constraintDecl,
    DeclRef<GenericDecl> genericDeclRef,
    SemanticsVisitor::OverloadResolveContext* maybeContext,
    ArrayView<Val*> args,
    bool shouldEmitError);

// Return the witness that proves differentiability metadata is available for
// the substituted constraint type, or `nullptr` if the metadata cannot be
// proved. `maybeContext` is required when `shouldEmitError` is true so
// diagnostics can point at the operation that requested the constraint.
Witness* findDiffTypeInfoWitnessForConstraint(
    ASTBuilder* astBuilder,
    SemanticsVisitor* visitor,
    HasDiffTypeInfoConstraintDecl* constraintDecl,
    DeclRef<GenericDecl> genericDeclRef,
    SemanticsVisitor::OverloadResolveContext* maybeContext,
    ArrayView<Val*> args,
    bool shouldEmitError);

// Return the witness that proves `constrainedArg` is a non-empty pack, or
// `nullptr` if the pack is empty or not known to be non-empty. `maybeContext` is
// required when `shouldEmitError` is true so diagnostics can point at the
// operation that requested the constraint.
Witness* findNonEmptyPackWitnessForConstraint(
    ASTBuilder* astBuilder,
    SemanticsVisitor* visitor,
    Val* constrainedArg,
    SemanticsVisitor::OverloadResolveContext* maybeContext,
    bool shouldEmitError);

// Return the witness that proves `actualCount == expectedCount`, or `nullptr`
// if the concrete count or an in-scope declared constraint cannot prove that
// equality.
Witness* findVariadicPackCountWitnessForConstraint(
    ASTBuilder* astBuilder,
    SemanticsVisitor* visitor,
    IntVal* actualCount,
    IntVal* expectedCount,
    SemanticsVisitor::OverloadResolveContext* maybeContext,
    bool shouldEmitError);

SourceLoc _getTypeNestingDiagnosticPosForDecl(Decl* decl);

} // namespace Slang
