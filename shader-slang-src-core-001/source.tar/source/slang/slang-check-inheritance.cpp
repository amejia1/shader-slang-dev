// slang-check-inheritance.cpp
#include "slang-check-impl.h"
#include "slang-rich-diagnostics.h"

// This file implements the semantic checking logic
// related to computing linearized inheritance
// information for types and decalrations.

namespace Slang
{
UInt SharedSemanticsContext::getDeclExtensionEpoch(Decl* decl) const
{
    if (!decl)
        return 0;

    if (auto epoch = m_mapDeclToExtensionEpoch.tryGetValue(decl))
        return *epoch;

    return 0;
}

void SharedSemanticsContext::bumpDeclExtensionEpoch(Decl* decl)
{
    if (!decl)
        return;

    m_mapDeclToExtensionEpoch[decl] = getDeclExtensionEpoch(decl) + 1;
}

bool SharedSemanticsContext::_isInheritanceInfoCacheEntryUpToDate(
    InheritanceInfoCacheEntry const& entry) const
{
    for (auto const& stamp : entry.dependencyEpochs)
    {
        if (getDeclExtensionEpoch(stamp.decl) != stamp.epoch)
            return false;
    }

    return true;
}

void SharedSemanticsContext::_collectInheritanceInfoDependencyEpochs(
    Decl* subjectDecl,
    InheritanceInfo const& info,
    List<DeclExtensionEpochStamp>& outDependencyEpochs) const
{
    outDependencyEpochs.clear();

    auto addDependency = [&](Decl* decl)
    {
        if (!decl)
            return;

        for (auto const& stamp : outDependencyEpochs)
        {
            if (stamp.decl == decl)
                return;
        }

        DeclExtensionEpochStamp stamp;
        stamp.decl = decl;
        stamp.epoch = getDeclExtensionEpoch(decl);
        outDependencyEpochs.add(stamp);
    };

    // Always depend on the subject declaration itself. This ensures a cache entry
    // for `T` gets revalidated when a new extension that directly targets `T` is
    // registered, even if the previous inheritance info happened to be empty.
    addDependency(subjectDecl);

    for (auto facet : info.facets)
    {
        addDependency(facet->getDeclRef().getDecl());
    }
}

UInt SharedSemanticsContext::_getInheritanceInfoCacheGeneration(
    Type* type,
    InheritanceCircularityInfo* circularityInfo)
{
    if (auto declRefType = as<DeclRefType>(type))
    {
        _getInheritanceInfo(declRefType->getDeclRef(), declRefType, circularityInfo);
        if (auto entry = m_mapDeclRefToInheritanceInfo.tryGetValue(declRefType->getDeclRef()))
            return entry->generation;
        return 0;
    }

    getInheritanceInfo(type, circularityInfo);
    if (auto entry = m_mapTypeToInheritanceInfo.tryGetValue(type))
        return entry->generation;
    return 0;
}

bool SharedSemanticsContext::tryGetSubtypeWitnessFromCache(
    Type* sub,
    Type* sup,
    SubtypeWitness*& outWitness)
{
    auto pair = TypePair{sub, sup};
    auto cachedEntry = m_mapTypePairToSubtypeWitness.tryGetValue(pair);
    if (!cachedEntry)
        return false;

    auto entry = *cachedEntry;

    UInt currentSubTypeGeneration = _getInheritanceInfoCacheGeneration(sub);
    UInt currentSuperTypeGeneration = _getInheritanceInfoCacheGeneration(sup);
    if (entry.subTypeGeneration != currentSubTypeGeneration ||
        entry.superTypeGeneration != currentSuperTypeGeneration)
    {
        m_mapTypePairToSubtypeWitness.remove(pair);
        return false;
    }

    outWitness = entry.witness;
    return true;
}

void SharedSemanticsContext::cacheSubtypeWitness(Type* sub, Type* sup, SubtypeWitness*& outWitness)
{
    auto pair = TypePair{sub, sup};
    UInt subTypeGeneration = _getInheritanceInfoCacheGeneration(sub);
    UInt superTypeGeneration = _getInheritanceInfoCacheGeneration(sup);

    // A zero generation means one of the endpoint inheritance entries is still
    // being recomputed. In that state we don't want to pin a subtype answer to a
    // stale or incomplete inheritance snapshot.
    if (!subTypeGeneration || !superTypeGeneration)
        return;

    SubtypeWitnessCacheEntry entry;
    entry.witness = outWitness;
    entry.subTypeGeneration = subTypeGeneration;
    entry.superTypeGeneration = superTypeGeneration;
    m_mapTypePairToSubtypeWitness[pair] = entry;
}

InheritanceInfo SharedSemanticsContext::getInheritanceInfo(
    Type* type,
    InheritanceCircularityInfo* circularityInfo,
    HashSet<DeclRef<Decl>>* ioSkippedIncompleteFacet)
{
    // We cache the computed inheritance information for types,
    // and re-use that information whenever possible.

    // DeclRefTypes will have their inheritance info cached in m_mapDeclRefToInheritanceInfo.
    if (auto declRefType = as<DeclRefType>(type))
        return _getInheritanceInfo(
            declRefType->getDeclRef(),
            declRefType,
            circularityInfo,
            ioSkippedIncompleteFacet);

    // Non ordinary types are cached on m_mapTypeToInheritanceInfo.
    // Each entry also snapshots the extension epochs of the declarations that
    // contributed facets to it, so we can validate lazily after new extensions
    // are registered instead of eagerly purging the whole cache.
    if (auto found = m_mapTypeToInheritanceInfo.tryGetValue(type))
    {
        if (found->isComputing)
            return found->info;

        if (_isInheritanceInfoCacheEntryUpToDate(*found))
            return found->info;
    }

    // Mark the entry as in-progress before recursing so we can break cycles
    // during inheritance calculation without re-entering the same work.
    {
        auto& entry = m_mapTypeToInheritanceInfo[type];
        entry.info = InheritanceInfo();
        entry.dependencyEpochs.clear();
        entry.generation = 0;
        entry.isComputing = true;
    }

    // Collect any in-progress ancestors that had to be skipped to break a
    // benevolent cycle (see `_getInheritanceInfo`). A non-`DeclRefType` has no
    // `DeclRef` identity to subtract as "self"; but the equality cycles we
    // tolerate are between associated-type accesses, which are `DeclRefType`s
    // routed through `_getInheritanceInfo` (which subtracts their own self), so
    // a non-empty `frameSkipped` here means this result is still missing an
    // ancestor and must not be cached.
    HashSet<DeclRef<Decl>> frameSkipped;
    auto info = _calcInheritanceInfo(type, circularityInfo, &frameSkipped);

    if (frameSkipped.getCount() == 0)
    {
        auto& entry = m_mapTypeToInheritanceInfo[type];
        entry.info = info;
        _collectInheritanceInfoDependencyEpochs(nullptr, info, entry.dependencyEpochs);
        entry.generation = m_nextInheritanceInfoCacheGeneration++;
        entry.isComputing = false;
    }
    else
    {
        // Contextual/partial result: roll back the in-progress entry so a later
        // root-level query recomputes the complete list, and propagate the
        // unresolved ancestors to our caller.
        m_mapTypeToInheritanceInfo.remove(type);
        if (ioSkippedIncompleteFacet)
            for (auto& k : frameSkipped)
                ioSkippedIncompleteFacet->add(k);
    }

    return info;
}

InheritanceInfo SharedSemanticsContext::getInheritanceInfo(
    DeclRef<ExtensionDecl> const& extension,
    InheritanceCircularityInfo* circularityInfo,
    HashSet<DeclRef<Decl>>* ioSkippedIncompleteFacet)
{
    if (_checkForCircularityInExtensionTargetType(extension.getDecl(), circularityInfo))
    {
        // If we detect a circularity in the inheritance graph,
        // we will return an empty `InheritanceInfo` to avoid
        // infinite recursion.
        //
        return InheritanceInfo();
    }

    // We bottleneck the calculation of inheritance information
    // for type and `extension` `DeclRef`s through a single
    // routine with an optional `Type` parameter.
    //
    InheritanceCircularityInfo newCircularityInfo(extension.getDecl(), circularityInfo);
    return _getInheritanceInfo(extension, nullptr, &newCircularityInfo, ioSkippedIncompleteFacet);
}

bool SharedSemanticsContext::_isInheritanceInfoBeingComputed(Type* type)
{
    // A type is "in progress" when its inheritance-info cache entry exists and
    // is still marked `isComputing` -- i.e. it is an ancestor currently on the
    // inheritance-computation stack. We use this to detect a *benevolent* cycle:
    // an equality constraint such as `__constraint A == B` makes `T.A` and `T.B`
    // each a base of the other, so while computing `T.A` we will be asked to add
    // `T.B`, whose computation in turn wants to add `T.A` -- but `T.A` is still
    // in progress. Rather than feed that back into the linearization (which would
    // be reported as a cyclic-inheritance error), the caller skips the constraint.
    if (auto declRefType = as<DeclRefType>(type))
    {
        if (auto found = m_mapDeclRefToInheritanceInfo.tryGetValue(declRefType->getDeclRef()))
            return found->isComputing;
    }
    else if (auto found = m_mapTypeToInheritanceInfo.tryGetValue(type))
    {
        return found->isComputing;
    }
    return false;
}

bool SharedSemanticsContext::_checkForCircularityInExtensionTargetType(
    Decl* decl,
    InheritanceCircularityInfo* circularityInfo)
{
    for (auto info = circularityInfo; info; info = info->next)
    {
        if (decl == info->decl)
        {
            getSink()->diagnose(Diagnostics::CircularityInExtension{.decl = decl});
            return true;
        }
    }

    return false;
}

InheritanceInfo SharedSemanticsContext::_getInheritanceInfo(
    DeclRef<Decl> declRef,
    Type* selfType,
    InheritanceCircularityInfo* circularityInfo,
    HashSet<DeclRef<Decl>>* ioSkippedIncompleteFacet)
{
    // Just as with `Type`s, we cache and re-use the inheritance
    // information that has been computed for a `DeclRef` whenever
    // possible.

    if (auto found = m_mapDeclRefToInheritanceInfo.tryGetValue(declRef))
    {
        if (found->isComputing)
            return found->info;

        if (_isInheritanceInfoCacheEntryUpToDate(*found))
            return found->info;
    }

    // Mark the entry as in-progress before recursing so we can break cycles
    // during inheritance calculation without re-entering the same work.
    {
        auto& entry = m_mapDeclRefToInheritanceInfo[declRef];
        entry.info = InheritanceInfo();
        entry.dependencyEpochs.clear();
        entry.generation = 0;
        entry.isComputing = true;
    }

    // `_calcInheritanceInfo` accumulates into `frameSkipped` the set of
    // in-progress *ancestor* `DeclRef`s that had to be skipped to break a
    // benevolent equality cycle (its own skips plus any propagated up from the
    // bases it recursed into).
    HashSet<DeclRef<Decl>> frameSkipped;
    auto info = _calcInheritanceInfo(declRef, selfType, circularityInfo, &frameSkipped);

    // This frame *supplies* its own facet, so it resolves any skip that named
    // it. Remove ourselves from the unresolved set; what remains are ancestors
    // strictly above us that are still missing.
    //
    // Worked example -- `interface IDerived { __constraint A == B; }`:
    //   * computing `T.A` expands `A == B` and recurses into `T.B`;
    //   * `T.B` sees `T.A` is in progress, skips the constraint, and reports
    //     `frameSkipped = {T.A}` -> `T.B` is partial and is NOT cached;
    //   * back in `T.A`: `frameSkipped = {T.A}` minus self `{T.A}` = {} -> `T.A`
    //     is complete (the only thing `T.B` omitted was `T.A`, which `T.A`
    //     already contains) and IS cached;
    //   * a later root-level query for `T.B` (with `T.A` now cached) skips
    //     nothing -> complete -> cached.
    //
    // The set (rather than a bool) is required for longer cycles: in
    // `A -> B -> C -> A`, `C` skips `A`, and `B` stays partial (it inherits the
    // unresolved `{A}`) until the computation unwinds to `A` itself, which is
    // the only frame that may cache.
    frameSkipped.remove(declRef);
    bool isComplete = frameSkipped.getCount() == 0;

    if (isComplete)
    {
        auto& entry = m_mapDeclRefToInheritanceInfo[declRef];
        entry.info = info;
        _collectInheritanceInfoDependencyEpochs(declRef.getDecl(), info, entry.dependencyEpochs);
        entry.generation = m_nextInheritanceInfoCacheGeneration++;
        entry.isComputing = false;
    }
    else
    {
        // Partial/contextual result: it was computed while an ancestor was still
        // in progress, so it would wrongly omit that ancestor. Do not cache it;
        // roll the in-progress entry back to "not computed" so the next
        // (root-level) query recomputes the complete list, and propagate the
        // still-unresolved ancestors to our caller.
        m_mapDeclRefToInheritanceInfo.remove(declRef);
        if (ioSkippedIncompleteFacet)
            for (auto& k : frameSkipped)
                ioSkippedIncompleteFacet->add(k);
    }

    getSession()->m_typeDictionarySize = Math::Max(
        getSession()->m_typeDictionarySize,
        (int)m_mapDeclRefToInheritanceInfo.getCount());

    return info;
}

void SharedSemanticsContext::getDependentGenericParentImpl(
    DeclRef<GenericDecl>& genericParent,
    DeclRef<Decl> declRef)
{
    auto mergeParent = [](DeclRef<GenericDecl>& currentParent, DeclRef<GenericDecl> newParent)
    {
        if (!currentParent)
        {
            currentParent = newParent;
            return;
        }
        if (currentParent == newParent)
            return;
        if (newParent.getDecl()->isChildOf(currentParent.getDecl()))
            currentParent = newParent;
    };

    auto addDependentGenericParentsFromVal = [&](auto& self, Val* val) -> void
    {
        if (!val)
            return;

        if (auto declRefType = as<DeclRefType>(val))
        {
            getDependentGenericParentImpl(genericParent, declRefType->getDeclRef());
            return;
        }

        if (auto declRefIntVal = as<DeclRefIntVal>(val))
        {
            getDependentGenericParentImpl(genericParent, declRefIntVal->getDeclRef());
            return;
        }

        if (as<Witness>(val) || as<DeclRefBase>(val))
            return;

        // Generic value arguments can be compound expressions. Walk their operands so a generic
        // application is still recognized as dependent on the generic parameters referenced inside
        // those expressions.
        for (auto operand : val->m_operands)
        {
            if (operand.kind == ValNodeOperandKind::ValNode)
                self(self, operand.getVal());
        }
    };

    if (isGenericParam(declRef))
    {
        mergeParent(genericParent, declRef.getParent().as<GenericDecl>());
        return;
    }
    else if (auto lookupDeclRef = as<LookupDeclRef>(declRef.declRefBase))
    {
        if (auto lookupSourceDeclRef = isDeclRefTypeOf<Decl>(lookupDeclRef->getLookupSource()))
            getDependentGenericParentImpl(genericParent, lookupSourceDeclRef);
    }
    else if (auto memberDeclRef = as<MemberDeclRef>(declRef.declRefBase))
    {
        // A member/accessor can be the endpoint of a generic lookup path. The leaf accessor is not
        // owned by the generic, but the parent path still carries the generic arguments, so
        // dependency queries must continue through the parent decl-ref.
        getDependentGenericParentImpl(genericParent, DeclRef<Decl>(memberDeclRef->getParent()));
    }
    else if (auto genericAppDeclRef = as<GenericAppDeclRef>(declRef.declRefBase))
    {
        for (Index i = 0; i < genericAppDeclRef->getArgCount(); i++)
            addDependentGenericParentsFromVal(
                addDependentGenericParentsFromVal,
                genericAppDeclRef->getArg(i));
    }
}

DeclRef<GenericDecl> SharedSemanticsContext::getDependentGenericParent(DeclRef<Decl> declRef)
{
    DeclRef<GenericDecl> genericParent;
    getDependentGenericParentImpl(genericParent, declRef);
    return genericParent;
}

// `baseIsSubtypeOfFacet` is typically an interface-to-interface witness whose sub-type still
// refers to the base interface's abstract `This` path, not the concrete/self type we are
// currently reasoning about.
//
// For example, if we are merging:
// - `selfIsSubtypeOfBase`: `Child : IBase`
// - `baseIsSubtypeOfFacet`: `IBase.This : IFacet`
//
// then we want the returned witness to mean `Child : IFacet`.
//
// We do that by constructing the lookup `Lookup(selfIsSubtypeOfBase, IBase.This)` and using it
// as a substitution when cloning `baseIsSubtypeOfFacet`. That effectively rewrites uses of the
// base interface's abstract `This` and corresponding this-type witness to flow through the new
// `Child : IBase` path instead.
//
// This is intentionally a localized workaround: the type system does not yet have a first-class
// utility for "take an interface witness written in terms of Base.This and specialize it to Self".
SubtypeWitness* SharedSemanticsContext::_specializeInterfaceInheritanceWitness(
    InterfaceDecl* baseInterfaceDecl,
    SubtypeWitness* selfIsSubtypeOfBase,
    SubtypeWitness* baseIsSubtypeOfFacet)
{
    SLANG_ASSERT(baseInterfaceDecl);
    SLANG_ASSERT(selfIsSubtypeOfBase);
    SLANG_ASSERT(baseIsSubtypeOfFacet);

    SpecializeInterfaceInheritanceWitnessKey key = {
        baseInterfaceDecl,
        selfIsSubtypeOfBase,
        baseIsSubtypeOfFacet};
    if (auto found = m_specializeInterfaceInheritanceWitnessCache.tryGetValue(key))
        return *found;

    auto lookupSubstitution = SubstitutionSet(_getASTBuilder()->getLookupDeclRef(
        selfIsSubtypeOfBase,
        baseInterfaceDecl->getThisTypeDecl()));

    // `as<SubtypeWitness>` can be null if substitution ever produced a non-witness `Val` for a
    // witness input -- caching that is intentional and harmless: a cached null and a freshly
    // recomputed null behave identically to every caller, so there is nothing this cache changes
    // about how that case is handled.
    auto result =
        as<SubtypeWitness>(baseIsSubtypeOfFacet->substitute(_getASTBuilder(), lookupSubstitution));
    m_specializeInterfaceInheritanceWitnessCache.add(key, result);
    return result;
}

bool SharedSemanticsContext::tryResolveConstraintTypes(
    DeclRef<GenericTypeConstraintDecl> constraintDeclRef)
{
    // Try to resolve the `sub`/`sup` types of a constraint enough to match it during
    // inheritance computation. Shared by both constraint scans in
    // `_calcInheritanceInfo`. For a `sub`/`sup` type that is not yet resolved:
    //
    //   * a *leaf* reference (a bare type-parameter / associated-type name) is safe to
    //     resolve eagerly -- resolving it performs no member lookup on the type
    //     currently being computed -- and resolving it now lets a facet-introducing
    //     constraint take effect regardless of the order constraints are written in;
    //
    //   * a *multi-level* (member-expression) access such as `T.A.C` must NOT be
    //     resolved here: the lookup of `C` on `T.A` would re-enter `T.A`'s in-progress
    //     inheritance and fail with a spurious "member not found" (and poison the
    //     subtype).
    //
    // Returns true if the `sub`/`sup` types are resolved and the caller may match the
    // constraint. Returns false if a multi-level `sub`/`sup` type is still unresolved;
    // the caller then defers the constraint (the scans record it as an in-progress skip
    // so the frame is reported partial and recomputed later -- see the call sites).
    SemanticsVisitor visitor(this);
    auto constraintDecl = constraintDeclRef.getDecl();

    auto resolveLeafOrDefer = [&](TypeExp& operand) -> bool // true if must defer
    {
        if (operand.type)
            return false; // already resolved -> observe
        if (as<MemberExpr>(operand.exp))
            return true;                                    // unresolved multi-level -> defer
        operand = visitor.TranslateTypeNodeForced(operand); // leaf -> safe eager resolve
        return false;
    };

    ensureDecl(&visitor, constraintDecl, DeclCheckState::ScopesWired);
    visitor.CheckConstraintSubType(constraintDecl->sub);

    bool mustDefer = resolveLeafOrDefer(constraintDecl->sub);
    if (constraintDecl->isEqualityConstraint)
        mustDefer = resolveLeafOrDefer(constraintDecl->sup) || mustDefer;

    return !mustDefer;
}

static DeclRef<GenericTypeConstraintDecl> _tryGetDefaultDifferentiabilityConstraintDeclRef(
    ASTBuilder* astBuilder,
    SemanticsVisitor* visitor,
    GenericDecl* genericDifferentiabilityRequirementDecl,
    SubtypeWitness* conformingWitness,
    DeclRef<GenericDecl>& outLookedUpGenericRequirementDeclRef)
{
    // Consider this example:
    //
    //     interface IFoo
    //     {
    //         [Differentiable]
    //         void f<T>(T value);
    //     }
    //
    // The callable requirement remains `GenericDecl { inner = CallableDecl f }`, and the
    // differentiability annotation contributes a sibling
    // `GenericDecl { inner = FuncConstraintDecl(This.f<T> : IDiff<This.f<T>>) }`.
    //
    // When computing inheritance for a looked-up method type, the direct constraint scan sees the
    // outer generic requirement but cannot use the inner `FuncConstraintDecl` until it is expressed
    // through the source type's conformance witness. This helper forms that looked-up generic
    // requirement and applies default substitutions so the caller can copy the satisfying method's
    // generic arguments onto it.
    auto constraintDecl = as<FuncConstraintDecl>(genericDifferentiabilityRequirementDecl->inner);
    if (!constraintDecl || constraintDecl->checkState.isBeingChecked())
        return DeclRef<GenericTypeConstraintDecl>();

    DeclRef<GenericDecl> lookedUpGenericDeclRef =
        astBuilder->getLookupDeclRef(conformingWitness, genericDifferentiabilityRequirementDecl)
            .as<GenericDecl>();
    if (!lookedUpGenericDeclRef)
        return DeclRef<GenericTypeConstraintDecl>();
    outLookedUpGenericRequirementDeclRef = lookedUpGenericDeclRef;

    return createDefaultSubstitutionsIfNeeded(
               astBuilder,
               visitor,
               astBuilder->getMemberDeclRef(lookedUpGenericDeclRef, constraintDecl))
        .as<GenericTypeConstraintDecl>();
}

static DeclRef<GenericTypeConstraintDecl>
_getSpecializedDifferentiabilityConstraintDeclRefFromSatisfyingMethod(
    ASTBuilder* astBuilder,
    SemanticsVisitor* visitor,
    DeclRef<GenericDecl> lookedUpGenericRequirementDeclRef,
    DeclRef<GenericTypeConstraintDecl> defaultConstraintDeclRef,
    Type* satisfyingMethodType)
{
    if (!defaultConstraintDeclRef)
        return DeclRef<GenericTypeConstraintDecl>();

    auto constraintDecl = as<FuncConstraintDecl>(defaultConstraintDeclRef.getDecl());
    if (!constraintDecl)
        return DeclRef<GenericTypeConstraintDecl>();

    ensureDecl(visitor, constraintDecl, DeclCheckState::CanSpecializeGeneric);

    // The differentiability constraint generic is cloned from the satisfying method generic:
    // `__generic<T> f()` becomes sibling `__generic<T> __constraint f<T> : ...`. The
    // satisfying method type therefore already carries the declaration-order arguments (ordinary
    // arguments and hidden proof arguments) that the constraint generic needs.
    auto satisfyingMethodDeclRef = isDeclRefTypeOf<CallableDecl>(satisfyingMethodType);
    if (!satisfyingMethodDeclRef)
        return DeclRef<GenericTypeConstraintDecl>();

    auto callableRequirementGenericApp =
        SubstitutionSet(constraintDecl->callableRequirementDeclRef).findGenericAppDeclRef();
    if (!callableRequirementGenericApp)
        return DeclRef<GenericTypeConstraintDecl>();

    auto satisfyingMethodGenericApp =
        SubstitutionSet(satisfyingMethodDeclRef)
            .findGenericAppDeclRef(callableRequirementGenericApp->getGenericDecl());
    if (!satisfyingMethodGenericApp)
        return DeclRef<GenericTypeConstraintDecl>();

    auto defaultConstraintGenericApp =
        SubstitutionSet(defaultConstraintDeclRef)
            .findGenericAppDeclRef(lookedUpGenericRequirementDeclRef.getDecl());
    if (!defaultConstraintGenericApp ||
        defaultConstraintGenericApp->getArgCount() != satisfyingMethodGenericApp->getArgCount())
    {
        return DeclRef<GenericTypeConstraintDecl>();
    }

    return astBuilder
        ->getGenericAppDeclRef(
            lookedUpGenericRequirementDeclRef,
            satisfyingMethodGenericApp->getArgs(),
            constraintDecl)
        .as<GenericTypeConstraintDecl>();
}

InheritanceInfo SharedSemanticsContext::_calcInheritanceInfo(
    DeclRef<Decl> declRef,
    Type* selfType,
    InheritanceCircularityInfo* circularityInfo,
    HashSet<DeclRef<Decl>>* ioSkippedIncompleteFacet)
{
    // This method is the main engine for computing linearized inheritance
    // lists for types and `extension` declarations.
    //
    // The approach we use for linearization of an inheritance graph is based on
    // what is the most broadly-accepted solution to the problem, presented in
    // "A Monotonic Superclass Linearization for Dylan" by Barret et al.
    // The algorithm recommended in that paper is also called the "C3 linearization
    // algorithm." Many developers are most familiar with C3 linearization because
    // it is used to compute the method resolution order (MRO) for a class in Python.
    //
    // The basic idea is that given a type declaration like:
    //
    //      class A : B, C { ... }
    //
    // we can construct a linearization of the transitive bases of `A`
    // by merging the linearizations for `B` and `C`. Any transitive
    // base of `A` should appear in the linearization for `B` and/or `C`,
    // so the main tasks are to remove duplicates (when a base type appears
    // in both the linearization of `B` *and* `C`), and to ensure that
    // the ordering is reasonable.
    //
    // What makes an ordering "reasonable" is a little subtle, especially
    // in the context of Slang. In the original use case, the order of types
    // in the linearization would determine which methods would override
    // which other ones, so different orderings could have large semantic
    // impact. Slang currently has less support for overriding, but is
    // likely to add more over time.
    //
    // At the very least, we require that if `S <: T` for types `S` and `T`,
    // then `S` should appear *before* `T` in the linearization. This, e.g.,
    // guarantees that a concrete type that implements an `interface` will
    // be listed before that interface and thus during lookup the members
    // of the concrete type will be found before those of the `interface`.
    //
    // We will revisit the question of "reasonable" orderings later, as
    // we get more into the core of the algorithm.

    // Our linearization approach will construct a list of *facets* for
    // the `declRef` in question, where each facet corresponds to a
    // transitive base type, or an applicable `extension`.
    //
    FacetList::Builder allFacets;

    Facet::Kind selfFacetKind = Facet::Kind::Type;

    auto astBuilder = _getASTBuilder();
    auto& arena = astBuilder->getArena();
    SemanticsVisitor visitor(this);

    // An enum's `__EnumType` conformance is not written in source; it is synthesized in
    // `SemanticsDeclBasesVisitor::visitEnumDecl` when the enum reaches `ReadyForLookup`. Its base
    // list is therefore incomplete until then, so force that state before linearizing to avoid
    // caching a spurious non-conforming result.
    //
    // Restricted to enums, and skipped while the enum is itself being checked:
    //   * Enum-only because driving a general aggregate here could re-enter this same
    //     computation. `visitEnumDecl`'s one subtype query, `tryGetSubtypeWitness(tagType, ...)`,
    //     is on the enum's *tag* type, never on the enum, so it does not query the enum's own
    //     inheritance; a struct, by contrast, does (its `IDefaultInitializable` synthesis under
    //     `-zero-initialize` queries `isSubtype(self, ...)`).
    //   * The `isBeingChecked` guard avoids `ensureDecl` diagnosing a `CyclicReference` on the
    //     enum and returning without advancing. That happens when the enum's inheritance is
    //     linearized while the enum is itself mid-check -- e.g. a self-referential base
    //     `enum E : IFoo<E>` with `IFoo<T : __EnumType>`, a genuine cycle -- so we defer to the
    //     inheritance machinery's own cyclic-reference reporting (which points at the offending
    //     base) rather than emit a worse diagnostic on `E`.
    if (auto enumDeclRef = declRef.as<EnumDecl>())
    {
        auto* enumDecl = enumDeclRef.getDecl();
        if (!enumDecl->checkState.isBeingChecked())
            visitor.ensureDecl(enumDecl, DeclCheckState::ReadyForLookup);
    }

    if (auto extensionDeclRef = declRef.as<ExtensionDecl>())
    {
        auto extendedType = getTargetType(astBuilder, extensionDeclRef);
        selfType = extendedType;
        selfFacetKind = Facet::Kind::Extension;
    }

    // Because we are dealing with entities that have declarations, the
    // first item in our linearization will always be a facet for
    // the declaration itself.
    //
    SubtypeWitness* selfIsSelf = nullptr;
    if (selfType)
    {
        if (isDeclRefTypeOf<InterfaceDecl>(selfType))
        {
            // For an interface *type*, the self/base conformance witnesses are rooted at
            // the interface's `ThisType` (not at `selfType` as for every other type), so
            // a concrete conforming type `T : IInterface` can later specialize them via
            // `This -> T`. i.e. here `DeclRefType(InterfaceDecl)` is treated as a
            // *requirement template*, not as the *existential box* it also denotes.
            //
            // KNOWN LIMITATION (#11469): that dual meaning means using an interface type
            // as an existential (e.g. a generic argument `Foo<IInterface>`) gets this
            // `This`-rooted answer, so its conformance witness's `sub` is a standalone
            // `IInterface.This` -- ill-formed for the box, and a source of non-canonical
            // type identity. Properly disentangling box vs `ThisType` here is invasive,
            // so the symptom is normalized downstream instead (#11464 / #11465 / #11468).
            selfIsSelf = visitor.getThisTypeWitness(
                astBuilder,
                as<DeclRefType>(selfType)->getDeclRef().as<InterfaceDecl>());
        }
        else
        {
            // If we have a `selfType` that isn't already a decl-ref type, then
            // we need to create a witness that the type of the declaration
            // inherits from that `selfType`.
            selfIsSelf = visitor.createTypeEqualityWitness(selfType);
        }
    }
    Facet selfFacet = new (arena) Facet::Impl(
        astBuilder,
        selfFacetKind,
        Facet::Directness::Self,
        declRef,
        selfType,
        selfIsSelf);
    allFacets.add(selfFacet);

    // After the self facet will come a list of facets formed
    // by merging the facet lists of each of the direct/declared
    // bases of the type/declaration in question.
    //
    // We will first traverse the structure of `declRef` to
    // accumulate the list of bases, and then perform the merge
    // when we are done.
    //
    DirectBaseList::Builder directBases;
    FacetList::Builder directBaseFacets;

    // We start with a simple operation to add an entry
    // into the list of direct bases, for the case where
    // we already have all of the relevant information
    // about that base.
    //
    auto addDirectBaseFacet = [&](Facet::Kind kind,
                                  Type* baseType,
                                  SubtypeWitness* selfIsBaseWitness,
                                  DeclRef<Decl> const& baseDeclRef,
                                  InheritanceInfo const& baseInheritanceInfo)
    {
        auto baseInfo = new (arena) DirectBaseInfo();

        // The information we store for each direct
        // base comprises two main things.
        //
        // First, we have a `Facet` that will represent
        // the base in the linearized inheritance list
        // we are building.
        //
        baseInfo->facetImpl = FacetImpl(
            astBuilder,
            kind,
            Facet::Directness::Direct,
            baseDeclRef,
            baseType,
            selfIsBaseWitness);
        Facet baseFacet(&baseInfo->facetImpl);
        //
        // Second, we have a list of the facets in the
        // linearization of the base itself.
        //
        baseInfo->facets = baseInheritanceInfo.facets;

        directBaseFacets.add(baseFacet);
        directBases.add(baseInfo);
    };

    // In the case where we know that the base being added
    // represents a direct base *type* (and not an `extension`)
    // we can derive some of the information needed by
    // `addDirectBaseFacet`.
    //
    auto addDirectBaseType = [&](Type* baseType, SubtypeWitness* selfIsBaseWitness)
    {
        // If we are representing inheritance from a type,
        // then we should have a witness that the type
        // in question (either the type being declared by
        // `declRef`, or the type being *extended* by
        // `declRef`) inherits from that base.
        //
        SLANG_ASSERT(selfIsBaseWitness);

        auto baseInheritanceInfo =
            getInheritanceInfo(baseType, circularityInfo, ioSkippedIncompleteFacet);

        DeclRef<Decl> baseDeclRef;
        if (auto baseDeclRefType = as<DeclRefType>(baseType))
        {
            baseDeclRef = baseDeclRefType->getDeclRef();
        }

        addDirectBaseFacet(
            Facet::Kind::Type,
            baseType,
            selfIsBaseWitness,
            baseDeclRef,
            baseInheritanceInfo);
    };

    // If we know the type has a facet represented by `extensionTargetDeclRef`, we can consider
    // all extensions on this decl to see if they apply to the type.
    //
    auto considerExtension = [&](DeclRef<Decl> extensionTargetDeclRef,
                                 Dictionary<Type*, SubtypeWitness*>* additionalSubtypeWitness)
    {
        bool result = false;
        auto candidateExtensions = getCandidateExtensions(extensionTargetDeclRef, &visitor);
        for (auto extDecl : candidateExtensions)
        {
            // The list of *candidate* extensions is computed and
            // cached based on the identity of the declaration alone,
            // and does not take into account any generic arguments
            // of either the type or the `extension`.
            //
            // For example, we might have an `extension` that applies
            // to `vector<float,N>` for any `N`, but the `selfType`
            // that we are working with could be `<vector<int,2>` so
            // that the extension doesn't match.
            //
            // In order to make sure that we don't enumerate members
            // that don't make sense in context, we must apply
            // the extension to the type and see if we succeed in
            // making a match.
            //
            auto extDeclRef =
                applyExtensionToType(&visitor, extDecl, selfType, additionalSubtypeWitness);
            if (!extDeclRef)
                continue;

            // In the case where we *do* find an extension that
            // applies to the type, we add a declared base to
            // represent the `extension`, knowing that its
            // own linearized inheritance list will include
            // any transitive based declared on the `extension`.
            //
            auto extInheritanceInfo =
                getInheritanceInfo(extDeclRef, circularityInfo, ioSkippedIncompleteFacet);
            addDirectBaseFacet(
                Facet::Kind::Extension,
                selfType,
                selfIsSelf,
                extDeclRef,
                extInheritanceInfo);
            result = true;
        }
        return result;
    };

    // We now look at the structure of the declaration itself
    // to help us enumerate the direct bases.
    //
    auto currentDeclRef = declRef;
    for (; currentDeclRef;)
    {
        if (currentDeclRef.as<AggTypeDeclBase>() || currentDeclRef.as<CallableDecl>())
        {
            auto containerDeclRef = currentDeclRef.as<ContainerDecl>();

            // In the case where we have an aggregate type or `extension`
            // declaration, we can use the explicit list of direct bases.
            //
            for (auto typeConstraintDeclRef :
                 getMembersOfType<TypeConstraintDecl>(_getASTBuilder(), containerDeclRef))
            {
                // Note: In certain cases something takes the *syntactic* form of an inheritance
                // clause, but it is not actually something that should be treated as implying
                // a subtype relationship. For example, an `enum` declaration can use what looks
                // like an inheritance clause to indicate its underlying "tag type."
                //
                // We skip such pseudo-inheritance relationships for the purposes of determining
                // the linearized list of bases.
                //
                if (typeConstraintDeclRef.getDecl()->hasModifier<IgnoreForLookupModifier>())
                    continue;

                Type* subTypeForWitness = selfType;
                if (auto interfaceDeclRef = containerDeclRef.as<InterfaceDecl>())
                {
                    // If we're dealing with an interface decl, we'll need to
                    // represent the constraint as a lookup on the 'this' type of the
                    // interface.
                    //

                    typeConstraintDeclRef = substituteDeclRef(
                                                SubstitutionSet(declRef),
                                                astBuilder,
                                                visitor.getRequirementAsLookedUpDecl(
                                                    astBuilder,
                                                    typeConstraintDeclRef.getDecl()))
                                                .as<TypeConstraintDecl>();
                    subTypeForWitness = substituteType(
                        SubstitutionSet(declRef),
                        astBuilder,
                        visitor.calcThisType(interfaceDeclRef));
                }

                // A GenericTypeConstraintDecl reaches this point either as a member of an
                // `associatedtype` declaration or, for an interface, as a direct `__constraint`
                // member. For an `associatedtype` it contributes a base only when its subject
                // references the associated type itself (so a subject that is not even a `VarExpr`
                // cannot match and is skipped below). For an interface it never refines the
                // interface's own bases and is skipped entirely (see the interface guard further
                // down for why).
                //
                auto genericTypeConstraintDeclRef =
                    typeConstraintDeclRef.as<GenericTypeConstraintDecl>();
                if (genericTypeConstraintDeclRef)
                {
                    auto subExpr = genericTypeConstraintDeclRef.getDecl()->sub.exp;

                    // If the base expr on the constraint isn't even a `VarExpr`, then it can't be
                    // referencing the associated type itself and we can skip this constraint.
                    if (!genericTypeConstraintDeclRef.getDecl()->sub.type && !as<VarExpr>(subExpr))
                        continue;

                    // An interface-level `__constraint` (a direct `GenericTypeConstraintDecl`
                    // member of the interface) never refines the interface's *own* set of
                    // bases. Its subject is required to be one of the interface's associated
                    // types -- e.g. `__constraint This.DataType == This` -- whose effect is
                    // surfaced when computing the inheritance of the corresponding
                    // associated-type access (`T.DataType`), not here. (A bare-`This` subject
                    // such as `__constraint This : IBar` is rejected during checking; see
                    // `visitGenericTypeConstraintDecl`.) So we must not process such a
                    // constraint while enumerating the interface's bases: eagerly checking it
                    // would recurse into the inheritance of an associated type and form a cycle.
                    if (containerDeclRef.as<InterfaceDecl>())
                        continue;
                }

                visitor.ensureDecl(
                    typeConstraintDeclRef,
                    DeclCheckState::CanUseBaseOfInheritanceDecl);

                // For generic type constraint decls, always make sure it is about the type being
                // checked.
                //
                if (genericTypeConstraintDeclRef)
                {
                    auto subType = getSub(astBuilder, genericTypeConstraintDeclRef);
                    if (subType != selfType)
                        continue;
                }
                else if (currentDeclRef != declRef)
                {
                    continue;
                }
                // The base type and subtype witness can easily be determined
                // using the `InheritanceDecl`.
                //
                auto baseType = getSup(astBuilder, typeConstraintDeclRef);
                auto satisfyingWitness = astBuilder->getDeclaredSubtypeWitness(
                    subTypeForWitness,
                    baseType,
                    typeConstraintDeclRef);

                addDirectBaseType(baseType, satisfyingWitness);
            }
        }

        if (currentDeclRef.as<AssocTypeDecl>())
        {
            // If the current type is an associated type, continue inspecting the base/parent of the
            // associatedtype to discover additional constraints defined on the parent
            // associatedtype decls.
            //
            if (auto lookupDeclRef = as<LookupDeclRef>(currentDeclRef.declRefBase))
            {
                currentDeclRef =
                    isDeclRefTypeOf<Decl>(lookupDeclRef->getLookupSource()).as<AssocTypeDecl>();
                continue;
            }
        }
        break;
    }

    // Surface interface-level constraints (declared via `__constraint` in an
    // interface body, including those produced by an `associatedtype` with a
    // trailing constraint or synthesized for `[Differentiable]` interface
    // requirements) when computing the inheritance of a lookup-derived type such
    // as `T.DataType`, `T.TA.TB`, or `T.dadd`.
    //
    // A constraint like `__constraint This.DataType == This` is a direct
    // `GenericTypeConstraintDecl` member of an interface that some type in the
    // access chain conforms to. Its subject is written relative to the
    // interface's `This`, so it constrains a lookup access rooted at any type
    // that conforms to the interface. We therefore walk the lookup chain of
    // `selfType` and, at each conforming type, enumerate the interfaces it conforms
    // to and match constraints whose subject (relative to `This`) names exactly
    // the same lookup-derived type as `selfType`. The opposite (`sub`/`sup`) side
    // of a matching constraint is added as a base of `selfType`.
    //
    // Worked example:
    //
    //     interface IBase  { associatedtype D; }
    //     interface IDeriv : IBase { __constraint D == This; }
    //     // for some `T : IDeriv`, consider the access `T.D`
    //
    // Computing the inheritance of `T.D`: the conforming type `T` conforms to `IDeriv`,
    // whose member constraint `D == This` has subject `This.D` -- matching the
    // chain `[D]` leading from conforming type `T` down to `T.D`. The other endpoint,
    // `This`, re-expressed through the witness `T : IDeriv`, is `T`. So `T` is
    // added as a base of `T.D`, which is what lets a `T.D` value be used where a
    // `T` is expected. A subtype constraint such as `__constraint D : IFoo`
    // works the same way but only matches on its `sub` endpoint, adding `IFoo`
    // as the base.
    //
    // A `[Differentiable]` interface method uses the same mechanism:
    //
    //     interface IDiff
    //     {
    //         [Differentiable]
    //         static T dadd(T left, T right);
    //     }
    //
    // Header checking creates the sibling constraint
    // `__constraint This.dadd : IForwardDifferentiable<This.dadd>`. When a
    // generic function calls `T.dadd` for `T : IDiff`, the lookup type
    // `T.dadd` must inherit from `IForwardDifferentiable<T.dadd>` so
    // `registerAssociatedMethods` can record the derivative association before
    // IR differentiability checking.
    //
    // The constraints are discovered purely from the interfaces each conforming type
    // conforms to (via `getInheritanceInfo(conformingType).facets`); the relocation
    // pass guarantees an `associatedtype`'s trailing bound and `where` clauses
    // also appear as such interface-member `GenericTypeConstraintDecl`s.
    //
    if (SubstitutionSet(declRef).findLookupDeclRef())
    {
        // Walk the lookup chain of `type` from the outermost access inward,
        // invoking `callback` once per lookup with that lookup's source (the type
        // the access is rooted on at that step). For `T.A.B` it yields `T.A`,
        // then `T`; for `T.dadd` it yields `T`. The walk stops at the first
        // non-lookup-derived type.
        auto enumerateLookupSources = [](Type* type, auto&& callback)
        {
            Type* cur = type;
            for (;;)
            {
                auto declRefType = as<DeclRefType>(cur);
                if (!declRefType)
                    break;
                auto lookupDeclRef = SubstitutionSet(declRefType->getDeclRef()).findLookupDeclRef();
                if (!lookupDeclRef)
                    break;
                cur = lookupDeclRef->getLookupSource();
                callback(cur);
            }
        };

        // The depth of a lookup access is the number of lookup substitutions applied to its root
        // type.
        auto lookupChainDepth = [&](Type* type) -> Index
        {
            Index depth = 0;
            enumerateLookupSources(type, [&](Type*) { ++depth; });
            return depth;
        };

        // The depth of the access we are computing inheritance for. We never add a base that is a
        // *deeper* lookup access than `selfType`: a recursive associated-type equality would
        // otherwise make an access claim a deeper access as a base, which re-expands without bound.
        // Only the reduce-to-shallower direction of an equality is useful for member lookup, and it
        // terminates.
        Index selfChainDepth = lookupChainDepth(selfType);

        // Collect the conforming types along `selfType`'s lookup chain. For
        // `selfType == T.TA.TB` the conforming types are `T.TA` and `T`. Each is
        // a concrete source type (not an interface); we scan the interfaces it
        // conforms to for constraints below, then re-express each constraint through
        // the conforming witness and match its endpoints against `selfType`.
        List<Type*> conformingTypes;
        enumerateLookupSources(selfType, [&](Type* source) { conformingTypes.add(source); });

        for (auto conformingType : conformingTypes)
        {
            auto conformingTypeInheritanceInfo =
                getInheritanceInfo(conformingType, circularityInfo, ioSkippedIncompleteFacet);
            for (auto facet : conformingTypeInheritanceInfo.facets)
            {
                auto interfaceDeclRef = facet->origin.declRef.as<InterfaceDecl>();
                if (!interfaceDeclRef)
                    continue;
                auto conformingWitness = facet->subtypeWitness;
                if (!conformingWitness)
                    continue;

                auto tryAddConstraintBase =
                    [&](DeclRef<GenericTypeConstraintDecl> constraintDeclRef)
                {
                    auto constraintDecl = constraintDeclRef.getDecl();
                    bool isEqualityConstraint = constraintDecl->isEqualityConstraint;

                    // Skip a constraint that is currently being checked: resolving
                    // a multi-level subject (e.g. `This.TA.TB`) requires the
                    // inheritance of a shallower access (`This.TA`), which can
                    // re-enter this routine. Skipping the in-progress constraint
                    // breaks that cycle; the shallower access does not need the
                    // deeper constraint as one of its bases anyway.
                    if (constraintDecl->checkState.isBeingChecked())
                        return;

                    // Observe a constraint whose endpoint types resolve; defer one whose
                    // subject is an unresolved multi-level access (resolving it would
                    // re-enter the in-progress type). On deferral, record the constraint
                    // as an in-progress skip so this frame is reported partial (and not
                    // cached) and recomputed once the constraint has been checked on its
                    // own; the constraint's own `DeclRef` is never the self of an
                    // inheritance frame, so it is never removed from the skipped set. See
                    // `_getInheritanceInfo`. Shared with the generic-parameter scan below.
                    if (!tryResolveConstraintTypes(constraintDeclRef))
                    {
                        if (ioSkippedIncompleteFacet)
                            ioSkippedIncompleteFacet->add(constraintDeclRef);
                        return;
                    }

                    // Consider this example:
                    //
                    //     interface IContext {}
                    //     interface IConsumer<T> where T : IContext {}
                    //     interface ILayout
                    //     {
                    //         associatedtype Context : IContext;
                    //         associatedtype First : IConsumer<Context>;
                    //         associatedtype Second : IConsumer<Context>;
                    //     }
                    //
                    // This loop sees all three constraints while computing the bases of
                    // `T.Context`. If we call `ensureDecl` on the unrelated `Second` constraint,
                    // checking `IConsumer<T.Context>` asks for the bases of `T.Context` again.
                    // The first calculation is not finished yet, so this recursion causes a false
                    // conformance error.
                    //
                    // We must therefore find and skip unrelated constraints before `ensureDecl`.

                    // Step 1: Express the constraint in terms of the concrete lookup source.
                    // For example, change `This.Second` to `T.Second` so that it can be compared
                    // with `selfType`.
                    DeclRef<GenericTypeConstraintDecl> lookedUpConstraint = constraintDeclRef;
                    if (!SubstitutionSet(lookedUpConstraint).findLookupDeclRef())
                    {
                        lookedUpConstraint =
                            astBuilder->getLookupDeclRef(conformingWitness, constraintDecl)
                                .as<GenericTypeConstraintDecl>();
                        if (!lookedUpConstraint)
                            return;
                    }

                    // Step 2: Compare the constraint's endpoints with `selfType`. A directed
                    // constraint `A : B` applies only to `A`. An equality `A == B` applies to
                    // either endpoint.
                    //
                    // Use canonical equality because lookup through a witness can express an
                    // endpoint through its concrete typealias. Witnesses embedded in defaulted
                    // generic arguments are re-rooted by `TryCheckOverloadCandidateConstraints`
                    // before they reach this comparison.
                    Type* selfCanonical = selfType->getCanonicalType();
                    auto doesEndpointMatchSelfType = [&](Type* endpointType) -> bool
                    { return endpointType->getCanonicalType()->equals(selfCanonical); };

                    // `tryResolveConstraintTypes` has resolved the subject. That is enough to
                    // filter a directed constraint because only its subject can match `selfType`.
                    // Its super-type is intentionally left for `ensureDecl`: resolving an
                    // unrelated super-type here can re-enter the inheritance query described
                    // above. Re-expressing the constraint through a lookup only substitutes the
                    // resolved subject, so it cannot make the subject null.
                    Type* lookedUpSub = getSub(astBuilder, lookedUpConstraint);
                    SLANG_RELEASE_ASSERT(lookedUpSub);

                    bool constraintAppliesToSelf = doesEndpointMatchSelfType(lookedUpSub);
                    if (!constraintAppliesToSelf && isEqualityConstraint)
                    {
                        // If the left-hand side of an equality is not `selfType`, check the
                        // right-hand side as well. `tryResolveConstraintTypes` has resolved both
                        // sides.
                        Type* lookedUpSup = getSup(astBuilder, lookedUpConstraint);
                        SLANG_RELEASE_ASSERT(lookedUpSup);
                        constraintAppliesToSelf = doesEndpointMatchSelfType(lookedUpSup);
                    }

                    // Step 3: Skip the constraint unless it applies to `selfType`. Only relevant
                    // constraints are fully checked by `ensureDecl`.
                    if (!constraintAppliesToSelf)
                        return;

                    ensureDecl(&visitor, constraintDecl, DeclCheckState::CanSpecializeGeneric);

                    // The endpoint reads before `ensureDecl` were only for relevance filtering.
                    // Read the fully checked constraint below to select its base.
                    Type* baseType = nullptr;
                    if (isEqualityConstraint)
                    {
                        // `ensureDecl` has populated both endpoint types. It may also swap them
                        // into canonical order, so re-read them and use the endpoint opposite
                        // `selfType` as the base.
                        Type* checkedSub = getSub(astBuilder, lookedUpConstraint);
                        Type* checkedSup = getSup(astBuilder, lookedUpConstraint);
                        SLANG_RELEASE_ASSERT(checkedSub);
                        SLANG_RELEASE_ASSERT(checkedSup);

                        bool selfIsSub = doesEndpointMatchSelfType(checkedSub);
                        bool selfIsSup = doesEndpointMatchSelfType(checkedSup);

                        // Equality checking only reorders the endpoints; it does not replace
                        // them. The prefilter matched at least one endpoint, so at least one of
                        // the checked endpoints must still match.
                        SLANG_RELEASE_ASSERT(selfIsSub || selfIsSup);

                        baseType = selfIsSub ? checkedSup : checkedSub;
                    }
                    else
                    {
                        // A directed constraint cannot swap its endpoints. Its subject already
                        // matched `selfType`, so its checked super-type is the base.
                        baseType = getSup(astBuilder, lookedUpConstraint);
                        SLANG_RELEASE_ASSERT(baseType);
                    }

                    // Skip a trivial self-base. Differential idempotence makes
                    // `T.Differential.Differential` canonically equal to
                    // `T.Differential`, so the equality `Differential.Differential ==
                    // Differential` matches `selfType == T.Differential` on its deeper
                    // endpoint and would try to add `T.Differential` as its own base.
                    if (baseType->getCanonicalType()->equals(selfCanonical))
                        return;

                    // Never introduce a base that is a deeper lookup access than
                    // `selfType`; that is the non-terminating direction of a
                    // self-referential equality constraint.
                    if (lookupChainDepth(baseType) > selfChainDepth)
                        return;

                    // Break *benevolent* equality cycles. An equality such as
                    // `__constraint A == B` makes `T.A` and `T.B` each a base of
                    // the other. While computing one of them, the other is still
                    // in progress (an ancestor on the stack); adding it as a base
                    // here would put the in-progress type back into the
                    // linearization and surface as a "cyclic inheritance" error.
                    //
                    // Instead we skip the constraint and record the skipped
                    // in-progress ancestor. The frame that *is* that ancestor
                    // already contains itself, so it ends up complete (and
                    // cached); this contextual frame is reported partial (and not
                    // cached) so a later root-level query -- by which point the
                    // ancestor is cached -- recomputes the full list. See
                    // `_getInheritanceInfo`.
                    //
                    // This skip is deliberately scoped to constraint-derived
                    // bases (not the shared `addDirectBaseType` used for ordinary
                    // `interface` inheritance), so genuinely circular interface
                    // inheritance (`interface IFoo : IBar {} interface IBar :
                    // IFoo {}`) is still diagnosed rather than silently accepted.
                    if (_isInheritanceInfoBeingComputed(baseType))
                    {
                        if (ioSkippedIncompleteFacet)
                            if (auto baseDeclRefType = as<DeclRefType>(baseType))
                                ioSkippedIncompleteFacet->add(baseDeclRefType->getDeclRef());
                        return;
                    }

                    auto satisfyingWitness = astBuilder->getDeclaredSubtypeWitness(
                        selfType,
                        baseType,
                        lookedUpConstraint);
                    addDirectBaseType(baseType, satisfyingWitness);
                };

                for (auto constraintDeclRef :
                     getMembersOfType<GenericTypeConstraintDecl>(astBuilder, interfaceDeclRef))
                {
                    tryAddConstraintBase(constraintDeclRef);
                }

                for (auto memberDecl : interfaceDeclRef.getDecl()->getDirectMemberDecls())
                {
                    auto genericDecl = as<GenericDecl>(memberDecl);
                    if (!genericDecl)
                        continue;

                    DeclRef<GenericDecl> lookedUpGenericRequirementDeclRef;
                    auto defaultConstraintDeclRef =
                        _tryGetDefaultDifferentiabilityConstraintDeclRef(
                            astBuilder,
                            &visitor,
                            genericDecl,
                            conformingWitness,
                            lookedUpGenericRequirementDeclRef);
                    auto constraintDeclRef =
                        _getSpecializedDifferentiabilityConstraintDeclRefFromSatisfyingMethod(
                            astBuilder,
                            &visitor,
                            lookedUpGenericRequirementDeclRef,
                            defaultConstraintDeclRef,
                            selfType);
                    if (!constraintDeclRef)
                        continue;

                    tryAddConstraintBase(constraintDeclRef);
                }
            }
        }
    }

    if (auto genericDeclRef = getDependentGenericParent(declRef))
    {
        // The constraints placed on a generic type parameter are siblings of that
        // parameter in its parent `GenericDecl`, so we need to enumerate all of
        // the constraints of the parent declaration to find those that constrain
        // this parameter.
        //
        // TODO(tfoley): We might consider adding a cached representation of the
        // constraint information that is keyed on a per-parameter basis. Such a
        // representation would need to take into account canonicalization of
        // constraints.

        if (auto extensionDecl = as<ExtensionDecl>(genericDeclRef.getDecl()->inner))
        {
            if (isDeclRefTypeOf<GenericTypeParamDecl>(extensionDecl->targetType.type) == declRef)
            {
                // If `T` is a generic parameter where the same generic is an extension on `T`,
                // then we need to add the extension itself as a facet.
                //
                auto extDeclRef =
                    createDefaultSubstitutionsIfNeeded(astBuilder, &visitor, extensionDecl)
                        .as<ExtensionDecl>();
                auto extInheritanceInfo =
                    getInheritanceInfo(extDeclRef, circularityInfo, ioSkippedIncompleteFacet);
                addDirectBaseFacet(
                    Facet::Kind::Extension,
                    selfType,
                    selfIsSelf,
                    extDeclRef,
                    extInheritanceInfo);
            }
        }

        bool selfIsGenericParamType =
            isDeclRefTypeOf<GenericTypeParamDeclBase>(selfType) != nullptr;

        for (auto constraintDeclRef :
             getMembersOfType<GenericTypeConstraintDecl>(astBuilder, genericDeclRef))
        {
            auto constraintDecl = constraintDeclRef.getDecl();
            if (constraintDecl->checkState.isBeingChecked())
                continue;

            // A member-expression subject can't possibly constrain the *bare* generic
            // type parameter (it constrains a deeper access), so skip it outright when
            // computing the parameter's own inheritance -- this avoids circular checking
            // on the generic param type.
            if (selfIsGenericParamType && as<MemberExpr>(constraintDecl->sub.exp))
                continue;

            // Observe a constraint whose endpoint types resolve; defer one whose subject
            // is an unresolved multi-level access. On deferral, record it as an
            // in-progress skip so the frame is reported partial and recomputed later
            // (same as the associated-type scan above; see `_getInheritanceInfo`).
            if (!tryResolveConstraintTypes(constraintDeclRef))
            {
                if (ioSkippedIncompleteFacet)
                    ioSkippedIncompleteFacet->add(constraintDeclRef);
                continue;
            }

            auto sub = constraintDecl->sub;

            // Canonicalize the constraint declRef to make sure we have a full reference to it.
            constraintDeclRef =
                createDefaultSubstitutionsIfNeeded(astBuilder, &visitor, constraintDeclRef)
                    .as<GenericTypeConstraintDecl>();

            auto subType = constraintDeclRef.substitute(astBuilder, sub.type);

            // We only consider constraints where the type represented
            // by `declRef` is the subtype, since those
            // constraints are the ones that give us information about
            // the declared supertypes.
            //
            auto subDeclRefType = as<DeclRefType>(subType);
            if (!subDeclRefType)
            {
                if (auto subEachType = as<EachType>(subType))
                {
                    subDeclRefType = subEachType->getElementDeclRefType();
                }
                if (!subDeclRefType)
                    continue;
            }
            if (subDeclRefType->getDeclRef() != declRef)
                continue;

            // Further check the constraint, since we now need the sup-type.
            ensureDecl(&visitor, constraintDeclRef.getDecl(), DeclCheckState::CanSpecializeGeneric);

            auto superType = getSup(astBuilder, constraintDeclRef);

            // Because the constraint is a declared inheritance relationship,
            // adding the base to our list of direct bases is as straightforward
            // as in all the preceding cases.
            //
            auto satisfyingWitness =
                _getASTBuilder()->getDeclaredSubtypeWitness(selfType, superType, constraintDeclRef);
            addDirectBaseType(superType, satisfyingWitness);
        }
    }

    // At this point we have enumerated all of the bases that can be
    // gleaned by looking at the `declRef` itself. The next step is
    // to consider any `extension` declarations that might apply to
    // a type being delared.
    //
    // An `extension` may apply to our type, if it directly extends
    // the type, or extends a generic `T` type that are constrained
    // on one of the interfaces that our type conforms to.
    //
    if (auto directAggTypeDeclRef = declRef.as<AggTypeDecl>())
    {
        considerExtension(directAggTypeDeclRef, nullptr);
    }
    if (auto directFuncDeclRef = declRef.as<FunctionDeclBase>())
    {
        considerExtension(directFuncDeclRef, nullptr);
    }
    if (!declRef.as<ExtensionDecl>())
    {
        HashSet<Type*> supTypesConsideredForExtensionApplication;
        Dictionary<Type*, SubtypeWitness*> additionalSubtypeWitnesses;
        for (;;)
        {
            // After we flatten the list of bases, we may discover additional opportunities
            // to apply extensions.
            List<DeclRef<AggTypeDecl>> supTypeWorkList;
            auto base = directBases.begin();
            for (auto baseFacet = directBaseFacets.getHead(); baseFacet.getImpl();
                 baseFacet = baseFacet->next)
            {
                for (auto facet : (*base)->facets)
                {
                    if (auto interfaceDeclRef = facet->origin.declRef.as<InterfaceDecl>())
                    {
                        // TODO: De-duplicate the logic in the two branches.
                        if (auto baseInterfaceDeclRef =
                                baseFacet->origin.declRef.as<InterfaceDecl>())
                        {
                            auto transitiveWitness = _specializeInterfaceInheritanceWitness(
                                baseInterfaceDeclRef.getDecl(),
                                (*base)->facetImpl.subtypeWitness,
                                facet->subtypeWitness);
                            additionalSubtypeWitnesses.addIfNotExists(
                                facet->origin.type,
                                transitiveWitness);
                            if (supTypesConsideredForExtensionApplication.add(facet->origin.type))
                            {
                                supTypeWorkList.add(interfaceDeclRef);
                            }
                        }
                        else
                        {
                            SubtypeWitness* transitiveWitness = baseFacet->subtypeWitness;
                            transitiveWitness = astBuilder->getTransitiveSubtypeWitness(
                                baseFacet->subtypeWitness,
                                facet->subtypeWitness);

                            additionalSubtypeWitnesses.addIfNotExists(
                                facet->origin.type,
                                transitiveWitness);
                            if (supTypesConsideredForExtensionApplication.add(facet->origin.type))
                            {
                                supTypeWorkList.add(interfaceDeclRef);
                            }
                        }
                    }
                }
                ++base;
            }
            bool canExit = true;
            for (auto baseItem : supTypeWorkList)
            {
                if (considerExtension(baseItem, &additionalSubtypeWitnesses))
                    canExit = false;
            }
            if (canExit)
                break;
        }
    }

    // At this point, the list of direct bases (each with its own linearization)
    // is complete.
    //
    // At this point we could scan through the list of bases and perform
    // consistency checks on it. For example, when two types in the list of direct
    // bases have a subtype relationship between them, it is possible that the
    // programmer made some kind of mistake, and we could emit a diagnostic
    // about it.
    //
    // The published C3 algorithm actually considers the declared list of bases
    // as one of the inputs to its merge, and is very strict about ordering.
    // As such, it would be an error for strict C3 if direct bases were declared
    // in an order that is inconsitent with the partial order determined by
    // the subtype relationship. Our implementation of linearization is relaxed
    // compared to C3 so that it is robust to such ordering issues.
    //
    // Note: This step takes quadratic time in the number of direct bases, but
    // there's really no other way to easily detect these issues.
    //
    for (auto leftBase = directBaseFacets.getHead(); leftBase.getImpl(); leftBase = leftBase->next)
    {
        // Note: all of the direct base facets with a `Type` kind will
        // precede all of those with `Extension` kind, so we can bail
        // out of the outer loop as soon as we find a non-`Type`
        // facet.
        //
        if (leftBase->kind != Facet::Kind::Type)
            break;
        auto leftBaseType = leftBase->origin.type;

        // For the inner loop we scan only the facets that appear *after*
        // the `leftBase` in the list of direct bases.
        //
        for (auto rightBase = leftBase->next; rightBase.getImpl(); rightBase = rightBase->next)
        {
            if (rightBase->kind != Facet::Kind::Type)
                break;
            auto rightBaseType = rightBase->origin.type;

            if (visitor.isSubtype(leftBaseType, rightBaseType, IsSubTypeOptions::None))
            {
                // If a type earlier in the list of bases is a subtype of
                // one later in the list, then the ordering is consistent
                // with the linearization that will be produced, but it
                // might represent a mistake on the programmer's part,
                // since they listed a base type that is redundant.
                //
                // TODO: decide whether to diagnose this case.
            }
            else if (visitor.isSubtype(rightBaseType, leftBaseType, IsSubTypeOptions::None))
            {
                // If a type later in the list is a subtype of a type earlier
                // in the list, then the declared list of bases is inconsistent
                // with the ordering that will (indeed *must*) appear in the
                // linearization we generate.
                //
                // If we end up implementing a strict version of the C3 algorithm,
                // we would need to treat such situations as an error, or at least
                // emit a warning and then remove the subtype from the list of
                // bases.
                //
                // TODO: decide whether to diagnose this case.
            }
        }
    }

    // Now that we've built up the list of direct bases and their
    // respective linearizations, we can apply the core merge algorithm
    // to those lists to produce the rest of the linearization for
    // the declaration in question.
    //
    _mergeFacetLists(directBases, directBaseFacets, allFacets);

    InheritanceInfo info;
    info.facets = allFacets;
    return info;
}

void SharedSemanticsContext::_mergeFacetLists(
    DirectBaseList bases,
    FacetList baseFacets,
    FacetList::Builder& ioMergedFacets)
{
    // Our task here is to take the list of direct/declared `bases`,
    // each of which holds a linearized list of `Facet`s, and produce
    // a single linearized list of facets in `ioMergedFacets`.
    //
    // The `Facet`s in the lists referenced by `bases` are always
    // relative to the base type/extension itself, and not to
    // the type or declaration for which we are computing
    // a linearization.
    //
    // The `baseFacets` list provides one `Facet` for each direct
    // base that are relative to the type/declaration we are
    // computing a linearization for. These facets will be used
    // directly, instead of those from `bases`, where possible.
    //
    auto astBuilder = _getASTBuilder();
    auto& arena = astBuilder->getArena();
    for (;;)
    {
        // The basic logic here is that on each iteration we
        // will look at the first item on each list in `bases`
        // and pick one that we will append to the merged output
        // (after removing it from the relevant input(s)).

        // If we have run out of lists that need merging, then we are done.
        //
        if (bases.isEmpty())
            break;

        // Otherwise, we will look at the remaining non-empty lists,
        // and see if one of them starts with an facet that can
        // be appended to our merged output.
        //
        // If multiple such facets are viable, we will always take
        // the one from the earliest list in `bases`. Doing so favors
        // the types that appear earlier in a list of bases.
        //
        Facet foundFacet;
        DirectBaseInfo* foundBase = nullptr;
        for (auto base : bases)
        {
            Facet headFacet = base->facets.getHead();

            // If the head facet of the `base` list appears at a non-head
            // position in any of the other lists, we cannot append this
            // element without risking inverting the order of some facets
            // relative to those other lists.
            //
            if (bases.doesAnyTailContainMatchFor(headFacet))
                continue;

            // Otherwise, we are safe to add the `headFacet` to our
            // merged list, because it only ever appears as the head
            // of one or more of the lists in `bases`.
            //
            foundFacet = headFacet;
            foundBase = base;
            break;
        }

        if (!foundFacet)
        {
            // If we could not identify a facet that could be safely
            // removed from any of the base lists, then it means that
            // we must have a cycle in the ordering constraints implied
            // by the `bases` lists.
            //
            // The simplest example of such a cycle would be if we
            // had two lists, `A` and `B`, such that:
            //
            //      A = { X, Y }
            //      B = { Y, X }
            //
            // In this case, producing output in the order `X, Y` *or*
            // `Y, X` will always invalidate the ordering constraints
            // implied by either `A` or `B`.
            //
            // In the C3 algorithm as published, such a situation is an
            // error, and the algorithm fails to produce a linearization.
            // The reason for this decision is that allowing this case
            // means that a base type and a derived type could disagree
            // on the relative priority of method overrides, and thus
            // a subclass could possible break semantic assumptions of
            // a superclass.
            //
            // In a more static language like Slang, it seems better to
            // allow more flexible inheritance, *especially* when dealing
            // with things like `interface`s and `extension`s, where the
            // relative ordering of things will often be immaterial.
            //
            // In a case like this, we would like to arbitrarily pick
            // one or the other of `X` and `Y`, and given our default
            // policy to favor the earlier list in `bases` where possible,
            // we would select `X` from `A`.
            //
            // One thing worth noting is that when a case like the above
            // arises, it is not possible that `X <: Y` or `Y <: X`.
            // If a subtype relationship existed between the two, then
            // they would be consistently ordered in *both* lists.
            // We thus do not have to worry about violating the most
            // important requirement for a "reasonable" linearization.
            //
            foundBase = *bases.begin();
            foundFacet = foundBase->facets.getHead();

            // Note: because we are grabbing a facet that might appear
            // in a non-head position in one or more of our lists,
            // we need to have a plan for what to do when we see
            // that same facet come to the front of one of our lists
            // later.
        }

        // If we still cannot find a facet, then there is a true cycle in
        // the inheritance graph, which is an error in the user code.
        if (!foundFacet.getImpl())
        {
            if (!bases.isEmpty())
            {
                auto baseDecl = (*bases.begin())->facetImpl.origin.declRef.getDecl();
                getSink()->diagnose(Diagnostics::CyclicReferenceInInheritance{.decl = baseDecl});
            }
            return;
        }

        // At this point we definitely have a facet we'd like to
        // add to the output, whether it was found via the true
        // C3 approach, or our relaxed rule above.
        //
        SLANG_ASSERT(foundFacet.getImpl());

        // If the facet we want to append to the output is the same as the front-most
        // facet on the list of bases, then we want to use that facet as-is (since we
        // have already allocated storage for it).
        //
        // TODO: in cases where the strict C3 algorithm would fail, and we choose a
        // `foundFacet` that is at a non-head position in at least some lists, it
        // might be possible that we have a facet that matches ones of the `baseFacets`,
        // but not the head one. We should confirm what happens in that case.
        //
        if (originsMatch(foundFacet, baseFacets.getHead()))
        {
            auto directBaseFacet = baseFacets.popHead();
            ioMergedFacets.add(directBaseFacet);
        }
        else
        {
            // This facet is seemingly *not* a facet that represents one of the direct
            // bases for the type/declaration being processed.
            //
            // As such, we need to allocate a fresh facet to represent it in the
            // linearization we are creating, since the `foundFacet` already belongs
            // to the linearization of one of the bases, and shouldn't be repurposed.
            //
            auto indirectFacet = new (arena) Facet::Impl();

            // Look through the heads of all the lists to see if we can find a matching
            // facet with a lower level of indirection.
            //
            // We want to prioritize the most direct facet possible, to minimize the levels of
            // indirection in the final linearization.
            //
            Facet::DirectnessVal baseDirectness =
                Facet::DirectnessVal(foundFacet.getImpl()->directness);
            for (auto base : bases)
            {
                Facet headFacet = base->facets.getHead();
                if (originsMatch(foundFacet, headFacet))
                {
                    if (Facet::DirectnessVal(headFacet.getImpl()->directness) < baseDirectness)
                    {
                        foundFacet = headFacet;
                        foundBase = base;
                        baseDirectness = Facet::DirectnessVal(headFacet.getImpl()->directness);
                    }
                }
            }

            // We will initialize the fresh facet to a copy of the state of the
            // `foundFacet`, albeit with a higher level of indirection.
            //
            *indirectFacet = *(foundFacet.getImpl());
            indirectFacet->next = nullptr;
            indirectFacet->directness = Facet::Directness(baseDirectness + 1);

            // When using this facet for subtype tests, or when looking
            // up member through this facet, we will need a witness
            // to show that the self type of the declaration being
            // linearized (the type being declared or extended) is a
            // subtype of the type for this facet.
            //
            // We can construct the appropriate witness transitively,
            // by noting that:
            //
            // * The self type is known to be a subtype of the direct
            //   base represented by `foundBase`, and the facet for
            //   that base stores a witness to that fact.
            //
            SubtypeWitness* selfIsSubtypeOfBase = foundBase->facetImpl.subtypeWitness;
            //
            // * The direct base type must be a subtype of the type
            //   for any facet found in its own linearization, and
            //   the `foundFacet` that came from the relevant base
            //   stores a witness to that fact.
            //
            SubtypeWitness* baseIsSubtypeOfFacet = foundFacet->subtypeWitness;


            auto selfType = selfIsSubtypeOfBase->getSub();
            auto baseType = selfIsSubtypeOfBase->getSup();
            auto facetType = baseIsSubtypeOfFacet->getSup();

            if (as<TypeEqualityWitness>(baseIsSubtypeOfFacet))
            {
                indirectFacet->setSubtypeWitness(_getASTBuilder(), selfIsSubtypeOfBase);
                ioMergedFacets.add(indirectFacet);
            }
            else if (isTypeEqualityWitness(selfIsSubtypeOfBase))
            {
                indirectFacet->setSubtypeWitness(_getASTBuilder(), baseIsSubtypeOfFacet);
                ioMergedFacets.add(indirectFacet);
            }
            else if (
                isDeclRefTypeOf<StructDecl>(baseType) && isDeclRefTypeOf<InterfaceDecl>(facetType))
            {
                if (isDeclRefTypeOf<StructDecl>(selfType))
                {
                    // Do nothing. This facet will not be accepted since
                    // conformance and inheritance cannot be mixed.
                    // i.e. (struct Child : struct Parent) and (struct Parent : interface IFoo)
                    // does not imply (struct Child : interface IFoo)
                    //
                }
                else
                {
                    // `enum E : uint` gives us an explicit `E -> uint` structural witness, and
                    // `uint` may have interface facets. Do not infer `E : IFoo` through `uint`;
                    // that would be the same unsupported conformance/inheritance mix as the
                    // struct case above.
                }
            }
            else if (
                isDeclRefTypeOf<InterfaceDecl>(baseType) &&
                isDeclRefTypeOf<InterfaceDecl>(facetType))
            {
                // If we're dealing with an type parameter pack as the selfType,
                // we'll need to construct it as a Expand(chain-of-lookups(Each Witness))
                //
                if (isDeclRefTypeOf<GenericTypePackParamDecl>(selfType))
                {
                    selfIsSubtypeOfBase =
                        astBuilder->getEachSubtypeWitness(selfType, baseType, selfIsSubtypeOfBase);
                }

                auto transitiveWitness = _specializeInterfaceInheritanceWitness(
                    as<InterfaceDecl>(as<DeclRefType>(baseType)->getDeclRef().getDecl()),
                    selfIsSubtypeOfBase,
                    baseIsSubtypeOfFacet);

                // If we're dealing with a parameter pack, pack the witness back up.
                if (isDeclRefTypeOf<GenericTypePackParamDecl>(selfType))
                {
                    transitiveWitness =
                        astBuilder->getExpandSubtypeWitness(selfType, facetType, transitiveWitness);
                }

                indirectFacet->setSubtypeWitness(_getASTBuilder(), transitiveWitness);
                ioMergedFacets.add(indirectFacet);
            }
            else if (
                isDeclRefTypeOf<StructDecl>(baseType) && isDeclRefTypeOf<StructDecl>(facetType))
            {
                if (isDeclRefTypeOf<StructDecl>(selfType))
                {
                    // struct -> struct -> struct is fine, but we'll need to construct a transitive
                    // witness for it.
                    auto transitiveWitness = astBuilder->getTransitiveSubtypeWitness(
                        selfIsSubtypeOfBase,
                        baseIsSubtypeOfFacet);
                    indirectFacet->setSubtypeWitness(_getASTBuilder(), transitiveWitness);
                    ioMergedFacets.add(indirectFacet);
                }
                else
                {
                    // Enum tag types use inheritance syntax to name the underlying integer type,
                    // but they should not inherit all structural facets of that integer type. Keep
                    // enum-to-tag conversion on the explicit conversion path instead of adding
                    // indirect inheritance facets introduced by enum backing types.
                }
            }
        }

        // We picked one `foundFacet` above to be added to the merged
        // output list, and we now need to ensure that we won't ever
        // emit a matching facet again.
        //
        // In the case of the strict/standard C3 algorithm, any facets
        // matching `foundFacet` would need to appear at a head position
        // in one of the base lists. As such, it is sufficient to run
        // through the base lists, check for a match at the head of each,
        // and remove any matching facets we find.
        //
        for (auto base : bases)
        {
            if (originsMatch(foundFacet, base->facets.getHead()))
            {
                base->facets.advanceHead();
                continue;
            }
        }
        //
        // Because we are not implementing the C3 algorithm strictly,
        // we need a solution for the case where `foundFacet` is
        // in a non-head position in one or more of the base lists.
        //
        // Proactively filtering `foundFacet` out of all of the lists
        // is possible, but given that these are singly-linked lists
        // we cannot easily filter them without either allocation
        // or mutation.
        //
        // Instead, we will filter out facets that have already been
        // added to the merged list as needed, when such facets come
        // to the front of the relevant list.
        //
        for (auto base : bases)
        {
            for (;;)
            {
                // For each base list, we will check if its
                // head facet is one that has already been
                // emitted to the output.
                //
                // If the head facet has not been emitted
                // already, we don't need to perform any
                // filtering on the base list at this time.
                //
                auto head = base->facets.getHead();
                if (!ioMergedFacets.containsMatchFor(head))
                    break;

                // Otherwise, we remove the head facet from
                // the given base list and test again, unless
                // the list is now empty.
                //
                base->facets.advanceHead();
                if (base->facets.isEmpty())
                    break;
            }
        }

        // The filtering step might have led to one or more
        // of the `bases` lists becomming empty. Our merge
        // algorithm really only wants to consider non-empty
        // lists, so we go ahead and remove the empty lists
        // here.
        //
        bases.removeEmptyLists();

        // At this point all of the lists have been appropriately filtered,
        // and we are ready to circle back around again to the step
        // where select a facet to add to the merged list.
    }

    // At this point, all of the input lists in `bases` should be empty,
    // and all of the facets in those lists should have found their way
    // over to `ioMergedFacets`.
}

// The mering algorithm needs to be able to test if two potentially-distinct
// `Facet`s represent the same underlying type or declaration.
//
bool originsMatch(Facet left, Facet right)
{
    if (left.getImpl() == right.getImpl())
        return true;
    if (!left.getImpl() || !right.getImpl())
        return false;

    // If both of the facets are non-null, and not
    // identical, we check if their origins match,
    // meaning that they represent the same type
    // or declaration.
    //
    return left->origin == right->origin;
}

bool operator==(Facet::Origin left, Facet::Origin right)
{
    // If either facet represents a declaration, then
    // the origins only match if they both represent
    // the *same* declaration.
    //
    if (left.declRef.getDecl() || right.declRef.getDecl())
    {
        return left.declRef.getDecl() && right.declRef.getDecl() &&
               left.declRef.equals(right.declRef);
    }

    // Otherwise, if they both represent types, then the
    // origins match if they are the same type.
    //
    // Note: an `extension` facet will always have a non-null
    // `declRef`, so there is no risk here of an `extension`
    // and a type facet being matched by this step; they
    // would always land in the case above.
    //
    if (left.type || right.type)
    {
        return left.type && right.type && left.type->equals(right.type);
    }

    // TODO: The rules we are using for matching here
    // would need to be revisited and overhauled significantly
    // if we start supporting generic type declarations
    // with covariant/contravariant type parameters.
    //
    // In such cases we would need to treat two facets as
    // matching if their declarations or types are an exact
    // matching modulo type arguments, and the relationship
    // between pairwise type arguments is consistent with
    // the variance of the corresponding parameter.
    //
    // E.g., we would need to treat facets for `IEnumerable<Derived>`
    // and `IEnumerable<Base>` as matching, and ensure that a
    // merged output list for a type/declaration could only
    // include the more specific of the two (`IEnumerable<Derived>`).

    return false;
}

// The remaining list-related operations that relate to the merging
// process are relatively simple to follow once the definition of
// matching is clear.

bool SharedSemanticsContext::DirectBaseList::doesAnyTailContainMatchFor(Facet facet) const
{
    for (auto base : *this)
    {
        if (base->facets.isEmpty())
            continue;
        if (base->facets.getTail().containsMatchFor(facet))
            return true;
    }
    return false;
}

void SharedSemanticsContext::DirectBaseList::removeEmptyLists()
{
    DirectBaseInfo** link = &_head;
    while (auto base = *link)
    {
        if (base->facets.isEmpty())
        {
            *link = base->next;
        }
        else
        {
            link = &base->next;
        }
    }
}

bool FacetList::containsMatchFor(Facet facet) const
{
    for (auto f : *this)
    {
        if (originsMatch(f, facet))
            return true;
    }
    return false;
}

InheritanceInfo SharedSemanticsContext::_calcInheritanceInfo(
    Type* type,
    InheritanceCircularityInfo* circularityInfo,
    HashSet<DeclRef<Decl>>* ioSkippedIncompleteFacet)
{
    // The majority of the interesting for for computing linearized
    // inheritance information arises for `DeclRef`s, but we still
    // need a way to compute the relevant information for types
    // that might or might not be defined using `Decl`s.

    auto astBuilder = _getASTBuilder();
    auto& arena = astBuilder->getArena();
    if (auto declRefType = as<DeclRefType>(type))
    {
        // The `DeclRef` case is the easy one, since we can
        // bottleneck through the logic that gets shared between
        // type and `extension` declarations.
        //
        return _getInheritanceInfo(declRefType->getDeclRef(), declRefType, circularityInfo);
    }
    else if (auto extractExistentialType = as<ExtractExistentialType>(type))
    {
        // Forward the `This`-type's inheritance to obtain the correct facet *structure*
        // (ordering/directness/origins), then canonicalize each conformance witness so it
        // is rooted at the existential's own canonical witness (`getSubtypeWitness()` ->
        // ExtractExistentialSubtypeWitness) instead of the `DeclaredSubtypeWitness` the
        // forwarding produces. This makes the witnesses match those the direct
        // member-access path builds, so the same access (e.g. `foo.This.Params`) interns
        // to a single `Type*`. See issue #11464.
        auto forwarded = _getInheritanceInfo(
            extractExistentialType->getThisTypeDeclRef(),
            extractExistentialType,
            circularityInfo);

        SemanticsVisitor visitor(this);
        auto selfWitness = extractExistentialType->getSubtypeWitness(); // ee : IFoo
        auto interfaceType = extractExistentialType->getOriginalInterfaceType();
        auto ifaceInfo =
            getInheritanceInfo(interfaceType, circularityInfo, ioSkippedIncompleteFacet);

        auto directFacet = new (arena) Facet::Impl(
            astBuilder,
            Facet::Kind::Type,
            Facet::Directness::Self,
            DeclRef<Decl>(),
            extractExistentialType,
            visitor.createTypeEqualityWitness(extractExistentialType));
        Facet tail = directFacet;
        for (auto facet : forwarded.facets)
        {
            if (facet->directness == Facet::Directness::Self)
                continue;

            // Re-root the conformance witness `ee : sup` at the existential's canonical
            // witness: directly for the opened interface, transitively for its bases.
            SubtypeWitness* witness = facet->subtypeWitness;
            Type* sup = witness ? witness->getSup() : nullptr;
            if (sup == interfaceType)
            {
                witness = selfWitness;
            }
            else
            {
                for (auto ifaceFacet : ifaceInfo.facets)
                {
                    if (ifaceFacet->subtypeWitness && ifaceFacet->subtypeWitness->getSup() == sup)
                    {
                        witness = astBuilder->getTransitiveSubtypeWitness(
                            selfWitness,
                            ifaceFacet->subtypeWitness);
                        break;
                    }
                }
            }

            auto projectedFacet = new (arena) Facet::Impl(
                astBuilder,
                facet->kind,
                facet->directness,
                facet->origin.declRef,
                facet->origin.type,
                witness);
            tail->next = projectedFacet;
            tail = projectedFacet;
        }

        InheritanceInfo info;
        info.facets = FacetList(directFacet);
        return info;
    }
    else if (as<AndType>(type))
    {
        // AndType constraints should have been flattened into individual constraints
        // during visitGenericTypeConstraintDecl. If we get here, something is wrong.
        SLANG_UNEXPECTED("AndType should have been flattened before reaching getInheritanceInfo");
    }
    auto projectBaseFacets =
        [&](Type* projectedType, InheritanceInfo elementInheritanceInfo, auto makeProjectedWitness)
    {
        SemanticsVisitor visitor(this);
        auto directFacet = new (arena) Facet::Impl(
            astBuilder,
            Facet::Kind::Type,
            Facet::Directness::Self,
            DeclRef<Decl>(),
            projectedType,
            visitor.createTypeEqualityWitness(projectedType));
        Facet tail = directFacet;
        for (auto facet : elementInheritanceInfo.facets)
        {
            if (facet->directness != Facet::Directness::Self)
            {
                auto projectedFacet = new (arena) Facet::Impl(
                    astBuilder,
                    facet->kind,
                    facet->directness,
                    facet->origin.declRef,
                    facet->origin.type,
                    makeProjectedWitness(facet->subtypeWitness));
                tail->next = projectedFacet;
                tail = projectedFacet;
            }
        }
        InheritanceInfo info;
        info.facets = FacetList(directFacet);
        return info;
    };

    if (auto concreteTypePack = as<ConcreteTypePack>(type))
    {
        SemanticsVisitor visitor(this);
        auto directFacet = new (arena) Facet::Impl(
            astBuilder,
            Facet::Kind::Type,
            Facet::Directness::Self,
            DeclRef<Decl>(),
            type,
            visitor.createTypeEqualityWitness(type));
        Facet tail = directFacet;

        if (concreteTypePack->getTypeCount() > 0)
        {
            List<InheritanceInfo> elementInheritanceInfos;
            for (Index i = 0; i < concreteTypePack->getTypeCount(); i++)
            {
                elementInheritanceInfos.add(getInheritanceInfo(
                    concreteTypePack->getElementType(i),
                    circularityInfo,
                    ioSkippedIncompleteFacet));
            }

            for (auto facet : elementInheritanceInfos[0].facets)
            {
                if (facet->directness == Facet::Directness::Self)
                    continue;

                List<SubtypeWitness*> witnesses;
                witnesses.add(facet->subtypeWitness);

                bool foundMatchInAll = true;
                for (Index i = 1; i < elementInheritanceInfos.getCount(); i++)
                {
                    SubtypeWitness* matchingWitness = nullptr;
                    for (auto otherFacet : elementInheritanceInfos[i].facets)
                    {
                        if (originsMatch(facet, otherFacet))
                        {
                            matchingWitness = otherFacet->subtypeWitness;
                            break;
                        }
                    }

                    if (!matchingWitness)
                    {
                        foundMatchInAll = false;
                        break;
                    }

                    witnesses.add(matchingWitness);
                }

                if (!foundMatchInAll)
                    continue;

                auto projectedFacet = new (arena) Facet::Impl(
                    astBuilder,
                    facet->kind,
                    facet->directness,
                    facet->origin.declRef,
                    facet->origin.type,
                    astBuilder->getSubtypeWitnessPack(
                        type,
                        facet->subtypeWitness->getSup(),
                        witnesses.getArrayView()));
                tail->next = projectedFacet;
                tail = projectedFacet;
            }
        }

        InheritanceInfo info;
        info.facets = FacetList(directFacet);
        return info;
    }
    else if (auto eachType = as<EachType>(type))
    {
        auto elementInheritanceInfo = getInheritanceInfo(
            eachType->getElementType(),
            circularityInfo,
            ioSkippedIncompleteFacet);
        return projectBaseFacets(
            type,
            elementInheritanceInfo,
            [&](SubtypeWitness* patternWitness) {
                return astBuilder->getEachSubtypeWitness(
                    type,
                    patternWitness->getSup(),
                    patternWitness);
            });
    }
    else if (auto firstType = as<FirstPackElementType>(type))
    {
        auto packInheritanceInfo =
            getInheritanceInfo(firstType->getBasePack(), circularityInfo, ioSkippedIncompleteFacet);
        return projectBaseFacets(
            type,
            packInheritanceInfo,
            [&](SubtypeWitness* patternWitness) {
                return astBuilder->getFirstSubtypeWitness(
                    type,
                    patternWitness->getSup(),
                    patternWitness);
            });
    }
    else if (auto lastType = as<LastPackElementType>(type))
    {
        auto packInheritanceInfo =
            getInheritanceInfo(lastType->getBasePack(), circularityInfo, ioSkippedIncompleteFacet);
        return projectBaseFacets(
            type,
            packInheritanceInfo,
            [&](SubtypeWitness* patternWitness) {
                return astBuilder->getLastSubtypeWitness(
                    type,
                    patternWitness->getSup(),
                    patternWitness);
            });
    }
    else if (auto expandType = as<ExpandType>(type))
    {
        auto patternInheritanceInfo = getInheritanceInfo(
            expandType->getPatternType(),
            circularityInfo,
            ioSkippedIncompleteFacet);
        return projectBaseFacets(
            type,
            patternInheritanceInfo,
            [&](SubtypeWitness* patternWitness) {
                return astBuilder->getExpandSubtypeWitness(
                    type,
                    patternWitness->getSup(),
                    patternWitness);
            });
    }
    else if (auto trimFirstType = as<TrimFirstTypePack>(type))
    {
        auto packInheritanceInfo = getInheritanceInfo(
            trimFirstType->getBasePack(),
            circularityInfo,
            ioSkippedIncompleteFacet);
        return projectBaseFacets(
            type,
            packInheritanceInfo,
            [&](SubtypeWitness* patternWitness) {
                return astBuilder->getTrimFirstSubtypeWitness(
                    type,
                    patternWitness->getSup(),
                    patternWitness);
            });
    }
    else if (auto trimLastType = as<TrimLastTypePack>(type))
    {
        auto packInheritanceInfo = getInheritanceInfo(
            trimLastType->getBasePack(),
            circularityInfo,
            ioSkippedIncompleteFacet);
        return projectBaseFacets(
            type,
            packInheritanceInfo,
            [&](SubtypeWitness* patternWitness) {
                return astBuilder->getTrimLastSubtypeWitness(
                    type,
                    patternWitness->getSup(),
                    patternWitness);
            });
    }
    else if (auto packBranchType = as<PackBranchType>(type))
    {
        SemanticsVisitor visitor(this);
        auto directFacet = new (arena) Facet::Impl(
            astBuilder,
            Facet::Kind::Type,
            Facet::Directness::Self,
            DeclRef<Decl>(),
            type,
            visitor.createTypeEqualityWitness(type));
        Facet tail = directFacet;

        auto emptyInheritanceInfo = getInheritanceInfo(
            packBranchType->getEmptyType(),
            circularityInfo,
            ioSkippedIncompleteFacet);
        auto nonEmptyInheritanceInfo = getInheritanceInfo(
            packBranchType->getNonEmptyType(),
            circularityInfo,
            ioSkippedIncompleteFacet);

        for (auto emptyFacet : emptyInheritanceInfo.facets)
        {
            SubtypeWitness* matchingWitness = nullptr;
            for (auto nonEmptyFacet : nonEmptyInheritanceInfo.facets)
            {
                if (originsMatch(emptyFacet, nonEmptyFacet))
                {
                    matchingWitness = nonEmptyFacet->subtypeWitness;
                    break;
                }
            }

            if (!matchingWitness)
                continue;

            auto projectedFacet = new (arena) Facet::Impl(
                astBuilder,
                emptyFacet->kind,
                emptyFacet->directness,
                emptyFacet->origin.declRef,
                emptyFacet->origin.type,
                astBuilder->getPackBranchSubtypeWitness(
                    type,
                    emptyFacet->subtypeWitness->getSup(),
                    packBranchType->getPackOperand(),
                    emptyFacet->subtypeWitness,
                    matchingWitness));
            tail->next = projectedFacet;
            tail = projectedFacet;
        }

        InheritanceInfo info;
        info.facets = FacetList(directFacet);
        return info;
    }
    else if (auto modifiedType = as<ModifiedType>(type))
    {
        auto baseInheritanceInfo = _calcInheritanceInfo(
            modifiedType->getBase(),
            circularityInfo,
            ioSkippedIncompleteFacet);

        if (modifiedType->findModifier<NoDiffModifierVal>())
        {
            // Create a filtered facet list that excludes facets whose
            // origin matches the `IDifferentiable` or `IDifferentiablePtrType`
            // interface types.
            //
            SemanticsVisitor visitor(this);
            auto directFacet = new (arena) Facet::Impl(
                astBuilder,
                Facet::Kind::Type,
                Facet::Directness::Self,
                DeclRef<Decl>(),
                type,
                visitor.createTypeEqualityWitness(type));

            auto diffInterfaceDecl = astBuilder->getDifferentiableInterfaceDecl().getDecl();
            auto diffRefInterfaceDecl = astBuilder->getDifferentiableRefInterfaceDecl().getDecl();

            Facet tail = directFacet;
            for (auto facet : baseInheritanceInfo.facets)
            {
                // Skip self facet from base - we already have our own self facet
                if (facet->directness == Facet::Directness::Self)
                    continue;

                // Check if this facet corresponds to IDifferentiable or IDifferentiablePtrType
                bool shouldExclude = false;
                if (auto interfaceDeclRef = facet->origin.declRef.as<InterfaceDecl>())
                {
                    auto interfaceDecl = interfaceDeclRef.getDecl();
                    if (interfaceDecl == diffInterfaceDecl || interfaceDecl == diffRefInterfaceDecl)
                    {
                        shouldExclude = true;
                    }
                }

                if (shouldExclude)
                    continue;

                // Copy the facet with updated structure
                auto newFacet = new (arena) Facet::Impl(
                    astBuilder,
                    facet->kind,
                    facet->directness,
                    facet->origin.declRef,
                    facet->origin.type,
                    facet->subtypeWitness);
                tail->next = newFacet;
                tail = newFacet;
            }

            InheritanceInfo info;
            info.facets = FacetList(directFacet);
            return info;
        }

        return baseInheritanceInfo;
    }
    else
    {
        // As a fallback, any type not covered by the above cases will
        // get a trivial linearization that consists of a single facet
        // corresponding to that type itself.
        //
        SemanticsVisitor visitor(this);
        auto directFacet = new (arena) Facet::Impl(
            astBuilder,
            Facet::Kind::Type,
            Facet::Directness::Self,
            DeclRef<Decl>(),
            type,
            visitor.createTypeEqualityWitness(type));

        InheritanceInfo info;
        info.facets = FacetList(directFacet);
        return info;
    }
}
} // namespace Slang
