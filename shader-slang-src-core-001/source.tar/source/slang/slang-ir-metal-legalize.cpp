#include "slang-ir-metal-legalize.h"

#include "slang-ir-clone.h"
#include "slang-ir-insts.h"
#include "slang-ir-legalize-binary-operator.h"
#include "slang-ir-legalize-varying-params.h"
#include "slang-ir-specialize-address-space.h"
#include "slang-ir-util.h"
#include "slang-ir.h"
#include "slang-rich-diagnostics.h"

namespace Slang
{

// metal textures only support writing 4-component values, even if the texture is only 1, 2, or
// 3-component in this case the other channels get ignored, but the signature still doesnt match so
// now we have to replace the value being written with a 4-component vector where the new components
// get ignored, nice
void legalizeImageStoreValue(IRBuilder& builder, IRImageStore* imageStore)
{
    builder.setInsertBefore(imageStore);
    auto originalValue = imageStore->getValue();
    auto valueBaseType = originalValue->getDataType();
    IRType* elementType = nullptr;
    List<IRInst*> components;
    if (auto valueVectorType = as<IRVectorType>(valueBaseType))
    {
        if (auto originalElementCount = as<IRIntLit>(valueVectorType->getElementCount()))
        {
            if (originalElementCount->getValue() == 4)
            {
                return;
            }
        }
        elementType = valueVectorType->getElementType();

        // Extract components using IRElementExtract to handle any vector instruction type
        if (auto originalElementCount = as<IRIntLit>(valueVectorType->getElementCount()))
        {
            for (UInt i = 0; i < (UInt)originalElementCount->getValue(); i++)
            {
                auto elementExtract = builder.emitElementExtract(
                    elementType,
                    originalValue,
                    builder.getIntValue(builder.getIntType(), i));
                components.add(elementExtract);
            }
        }
    }
    else
    {
        elementType = valueBaseType;
        components.add(originalValue);
    }
    for (UInt i = components.getCount(); i < 4; i++)
    {
        components.add(builder.getIntValue(builder.getIntType(), 0));
    }
    auto fourComponentVectorType = builder.getVectorType(elementType, 4);
    imageStore->setOperand(2, builder.emitMakeVector(fourComponentVectorType, components));
}

void legalizeFuncBody(IRFunc* func)
{
    IRBuilder builder(func);
    for (auto block : func->getBlocks())
    {
        for (auto inst : block->getModifiableChildren())
        {
            if (auto call = as<IRCall>(inst))
            {
                ShortList<IRUse*> argsToFixup;
                // Metal doesn't support taking the address of a vector element.
                // If such an address is used as an argument to a call, we need to replace it with a
                // temporary. for example, if we see:
                // ```
                //     void foo(inout float x) { x = 1; }
                //     float4 v;
                //     foo(v.x);
                // ```
                // We need to transform it into:
                // ```
                //     float4 v;
                //     float temp = v.x;
                //     foo(temp);
                //     v.x = temp;
                // ```
                //
                for (UInt i = 0; i < call->getArgCount(); i++)
                {
                    if (auto addr = as<IRGetElementPtr>(call->getArg(i)))
                    {
                        auto ptrType = addr->getBase()->getDataType();
                        auto valueType = tryGetPointedToType(&builder, ptrType);
                        if (!valueType)
                            continue;
                        if (as<IRVectorType>(valueType))
                            argsToFixup.add(call->getArgs() + i);
                    }
                }
                if (argsToFixup.getCount() == 0)
                    continue;

                // Define temp vars for all args that need fixing up.
                for (auto arg : argsToFixup)
                {
                    auto addr = as<IRGetElementPtr>(arg->get());
                    auto ptrType = addr->getDataType();
                    auto valueType = tryGetPointedToType(&builder, ptrType);
                    builder.setInsertBefore(call);
                    auto temp = builder.emitVar(valueType);
                    auto initialValue = builder.emitLoad(valueType, addr);
                    builder.emitStore(temp, initialValue);
                    builder.setInsertAfter(call);
                    builder.emitStore(addr, builder.emitLoad(valueType, temp));
                    arg->set(temp);
                }
            }
            if (auto write = as<IRImageStore>(inst))
            {
                legalizeImageStoreValue(builder, write);
            }
        }
    }
}

struct MetalAddressSpaceAssigner : InitialAddressSpaceAssigner
{
    virtual bool tryAssignAddressSpace(IRInst* inst, AddressSpace& outAddressSpace) override
    {
        switch (inst->getOp())
        {
        case kIROp_Var:
            outAddressSpace = AddressSpace::ThreadLocal;
            return true;
        case kIROp_RWStructuredBufferGetElementPtr:
            outAddressSpace = AddressSpace::Global;
            return true;
        case kIROp_Load:
            {
                auto addrSpace = getAddressSpaceFromVarType(inst->getDataType());
                if (addrSpace != AddressSpace::Generic)
                {
                    outAddressSpace = addrSpace;
                    return true;
                }
            }
            return false;
        default:
            return false;
        }
    }

    virtual AddressSpace getAddressSpaceFromVarType(IRInst* type) override
    {
        if (as<IRUniformParameterGroupType>(type))
        {
            return AddressSpace::Uniform;
        }
        if (as<IRByteAddressBufferTypeBase>(type))
        {
            return AddressSpace::Global;
        }
        if (as<IRHLSLStructuredBufferTypeBase>(type))
        {
            return AddressSpace::Global;
        }
        if (as<IRGLSLShaderStorageBufferType>(type))
        {
            return AddressSpace::Global;
        }
        if (auto ptrType = as<IRPtrTypeBase>(type))
        {
            if (ptrType->hasAddressSpace())
            {
                auto addrSpace = ptrType->getAddressSpace();
                // Pointers into buffer elements (e.g. produced by
                // lowerBufferElementTypeToStorageType) carry the abstract
                // `StorageBuffer` address space. Metal has no distinct
                // storage-buffer address space — such pointers live in
                // `device` memory — so map them to `Global`, which the
                // Metal emitter renders as `device*`.
                if (addrSpace == AddressSpace::StorageBuffer)
                    return AddressSpace::Global;
                return addrSpace;
            }
            return AddressSpace::Generic;
        }
        return AddressSpace::Generic;
    }

    virtual AddressSpace getLeafInstAddressSpace(IRInst* inst) override
    {
        if (as<IRGroupSharedRate>(inst->getRate()))
            return AddressSpace::GroupShared;
        switch (inst->getOp())
        {
        case kIROp_RWStructuredBufferGetElementPtr:
            return AddressSpace::Global;
        case kIROp_Var:
            if (as<IRBlock>(inst->getParent()))
                return AddressSpace::ThreadLocal;
            break;
        default:
            break;
        }
        auto type = unwrapAttributedType(inst->getDataType());
        if (!type)
            return AddressSpace::Generic;
        return getAddressSpaceFromVarType(type);
    }
};

// MSL rejects a direct cast between a vector and a pointer, but allows vector<->scalar
// `as_type` and scalar<->pointer C-style casts — so split the bit-cast through a scalar
// `uint64_t`. Such casts arise when a 64-bit value carried as `uint2` (a dynamic-dispatch
// handle, or a pointer packed into an any-value payload) is reinterpreted as a pointer,
// or when a pointer is packed into such a `uint2`.
static void legalizeVectorPointerBitCast(IRInst* inst)
{
    auto toType = inst->getDataType();
    auto fromType = inst->getOperand(0)->getDataType();
    bool toIsPointer = as<IRPtrTypeBase>(toType) || as<IRRawPointerTypeBase>(toType);
    bool fromIsPointer = as<IRPtrTypeBase>(fromType) || as<IRRawPointerTypeBase>(fromType);
    bool toIsVector = as<IRVectorType>(toType) != nullptr;
    bool fromIsVector = as<IRVectorType>(fromType) != nullptr;
    if (!((toIsPointer && fromIsVector) || (toIsVector && fromIsPointer)))
        return;

    IRBuilder builder(inst);
    builder.setInsertBefore(inst);
    auto scalarHop = builder.emitBitCast(builder.getUInt64Type(), inst->getOperand(0));
    inst->setOperand(0, scalarHop);
}

static void processInst(IRInst* inst, TargetProgram* targetProgram, DiagnosticSink* sink)
{
    switch (inst->getOp())
    {
    case kIROp_Add:
    case kIROp_Sub:
    case kIROp_Mul:
    case kIROp_Div:
    case kIROp_FRem:
    case kIROp_IRem:
    case kIROp_And:
    case kIROp_Or:
    case kIROp_BitAnd:
    case kIROp_BitOr:
    case kIROp_BitXor:
    case kIROp_Lsh:
    case kIROp_Rsh:
    case kIROp_Eql:
    case kIROp_Neq:
    case kIROp_Greater:
    case kIROp_Less:
    case kIROp_Geq:
    case kIROp_Leq:
        legalizeBinaryOp(inst, sink, targetProgram);
        break;
    case kIROp_MeshOutputRef:
        sink->diagnose(Diagnostics::AssignToRefNotSupported{.location = getDiagnosticPos(inst)});
        break;
    case kIROp_BitCast:
        legalizeVectorPointerBitCast(inst);
        break;
    case kIROp_MetalCastToDepthTexture:
        {
            // If the operand is already a depth texture, don't do anything.
            auto textureType = as<IRTextureTypeBase>(inst->getOperand(0)->getDataType());
            if (textureType && getIntVal(textureType->getIsShadowInst()) == 1)
            {
                inst->replaceUsesWith(inst->getOperand(0));
                inst->removeAndDeallocate();
            }
            break;
        }
    default:
        for (auto child : inst->getModifiableChildren())
        {
            processInst(child, targetProgram, sink);
        }
    }
}

static void legalizeSubpassInputsForMetal(
    IRModule* module,
    DiagnosticSink* sink,
    List<EntryPointInfo>& entryPoints)
{
    List<IRGlobalParam*> subpassGlobals;
    for (auto inst : module->getGlobalInsts())
    {
        if (auto globalParam = as<IRGlobalParam>(inst))
        {
            if (as<IRSubpassInputType>(globalParam->getDataType()))
                subpassGlobals.add(globalParam);
        }
    }

    ShortList<IRFunc*> entryPointsToFix;
    for (auto globalParam : subpassGlobals)
    {
        auto subpassType = as<IRSubpassInputType>(globalParam->getDataType());
        auto elementType = subpassType->getElementType();

        HashSet<IRFunc*> fragmentUsers;
        for (auto use = globalParam->firstUse; use; use = use->nextUse)
        {
            auto pf = getParentFunc(use->getUser());
            if (!pf)
                continue;
            for (auto& ep : entryPoints)
                if (ep.entryPointFunc == pf &&
                    ep.entryPointDecor->getProfile().getStage() == Stage::Fragment)
                    fragmentUsers.add(pf);
        }
        if (auto entryPointParamDecor = globalParam->findDecoration<IREntryPointParamDecoration>())
        {
            if (auto func = as<IRFunc>(entryPointParamDecor->getEntryPoint()))
                fragmentUsers.add(func);
        }
        if (fragmentUsers.getCount() == 0)
        {
            sink->diagnose(Diagnostics::SubpassInputUsedOutsideEntryPoint{
                .location = getDiagnosticPos(globalParam)});
            continue;
        }

        IRIntegerValue attachmentIndex = 0;
        if (auto layoutDecor = globalParam->findDecoration<IRLayoutDecoration>())
        {
            if (auto varLayout = as<IRVarLayout>(layoutDecor->getLayout()))
            {
                if (auto offsetAttr =
                        varLayout->findOffsetAttr(LayoutResourceKind::InputAttachmentIndex))
                {
                    attachmentIndex = offsetAttr->getOffset();
                }
            }
        }

        Dictionary<IRFunc*, IRInst*> paramPerEntryPoint;
        IRBuilder builder(module);
        for (auto entryPointFunc : fragmentUsers)
        {
            auto firstBlock = entryPointFunc->getFirstBlock();
            if (!firstBlock)
                continue;

            auto newParam = builder.createParam(elementType);
            auto firstOrdinary = firstBlock->getFirstOrdinaryInst();
            if (firstOrdinary)
                newParam->insertBefore(firstOrdinary);
            else
                newParam->insertAtEnd(firstBlock);

            StringBuilder colorStr;
            colorStr << "color(" << Int(attachmentIndex) << ")";
            String colorString = colorStr.produceString();
            builder.addTargetSystemValueDecoration(newParam, colorString.getUnownedSlice());

            if (auto nameHint = globalParam->findDecoration<IRNameHintDecoration>())
                builder.addNameHintDecoration(newParam, nameHint->getName());

            paramPerEntryPoint[entryPointFunc] = newParam;
            if (entryPointsToFix.indexOf(entryPointFunc) == -1)
                entryPointsToFix.add(entryPointFunc);
        }

        IRUse* nextUse = nullptr;
        for (IRUse* use = globalParam->firstUse; use; use = nextUse)
        {
            nextUse = use->nextUse;
            auto user = use->getUser();

            // Decorations referencing the global (e.g., debug-value, layout
            // metadata) are not value uses; leave them alone so they aren't
            // destroyed alongside the global's data uses.
            if (as<IRDecoration>(user))
                continue;

            auto parentFunc = getParentFunc(user);

            IRInst* newParam = nullptr;
            if (parentFunc)
                paramPerEntryPoint.tryGetValue(parentFunc, newParam);

            if (!newParam)
            {
                sink->diagnose(Diagnostics::SubpassInputUsedOutsideEntryPoint{
                    .location = getDiagnosticPos(user)});
                if (auto resultType = user->getDataType())
                {
                    IRBuilder localBuilder(user);
                    localBuilder.setInsertBefore(user);
                    user->replaceUsesWith(localBuilder.getPoison(resultType));
                }
                user->removeAndDeallocate();
                continue;
            }

            if (user->getOp() == kIROp_SubpassLoad)
            {
                auto subpassLoad = as<IRSubpassLoad>(user);
                if (subpassLoad->getSample())
                {
                    sink->diagnose(Diagnostics::MultisampledSubpassInputNotSupportedOnMetal{
                        .location = getDiagnosticPos(user)});
                }
                user->replaceUsesWith(newParam);
                user->removeAndDeallocate();
                continue;
            }
            sink->diagnose(
                Diagnostics::SubpassInputUsedOutsideEntryPoint{.location = getDiagnosticPos(user)});
            if (auto resultType = user->getDataType())
            {
                IRBuilder localBuilder(user);
                localBuilder.setInsertBefore(user);
                user->replaceUsesWith(localBuilder.getPoison(resultType));
            }
            user->removeAndDeallocate();
        }

        globalParam->removeAndDeallocate();
    }

    for (auto func : entryPointsToFix)
        fixUpFuncType(func);
}

void legalizeIRForMetal(IRModule* module, TargetProgram* targetProgram, DiagnosticSink* sink)
{
    List<EntryPointInfo> entryPoints;
    for (auto inst : module->getGlobalInsts())
    {
        if (auto func = as<IRFunc>(inst))
        {
            if (auto entryPointDecor = func->findDecoration<IREntryPointDecoration>())
            {
                EntryPointInfo info;
                info.entryPointDecor = entryPointDecor;
                info.entryPointFunc = func;
                entryPoints.add(info);
            }
            legalizeFuncBody(func);
        }
    }

    legalizeSubpassInputsForMetal(module, sink, entryPoints);

    legalizeEntryPointVaryingParamsForMetal(module, sink, entryPoints);

    processInst(module->getModuleInst(), targetProgram, sink);
}

void specializeAddressSpaceForMetal(IRModule* module)
{
    MetalAddressSpaceAssigner metalAddressSpaceAssigner;
    specializeAddressSpace(module, &metalAddressSpaceAssigner);
}

} // namespace Slang
