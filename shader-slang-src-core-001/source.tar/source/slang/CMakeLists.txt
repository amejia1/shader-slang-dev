#
# Invoke the "fiddle" tool to generate source
#

set(SLANG_FIDDLE_INPUT_DIR "${CMAKE_CURRENT_SOURCE_DIR}")
set(SLANG_FIDDLE_OUTPUT_DIR "${CMAKE_CURRENT_BINARY_DIR}/fiddle")

file(
    GLOB SLANG_FIDDLE_INPUT_FILE_NAMES
    CONFIGURE_DEPENDS
    RELATIVE "${SLANG_FIDDLE_INPUT_DIR}"
    "*.h"
    "*.cpp"
)

list(
    TRANSFORM SLANG_FIDDLE_INPUT_FILE_NAMES
    PREPEND "${SLANG_FIDDLE_INPUT_DIR}/"
    OUTPUT_VARIABLE SLANG_FIDDLE_INPUTS
)
glob_append(SLANG_FIDDLE_LUA_INPUTS "*.lua")

list(
    TRANSFORM SLANG_FIDDLE_INPUT_FILE_NAMES
    APPEND ".fiddle"
    OUTPUT_VARIABLE SLANG_FIDDLE_OUTPUTS
)
list(TRANSFORM SLANG_FIDDLE_OUTPUTS PREPEND "${SLANG_FIDDLE_OUTPUT_DIR}/")

#
# slang-fiddle is a many-input / many-output generator that uses
# `writeAllTextIfChanged()` to avoid touching outputs whose content has
# not changed. CMake's add_custom_command(OUTPUT …) treats every listed
# output as an up-to-date marker: if any single output is older than the
# command's dependencies, it re-runs the command. Because fiddle leaves
# unchanged outputs alone, those output mtimes stay older than the
# generator binary itself, so CMake re-runs fiddle on every build, and
# downstream link steps re-link.
#
# Drive the rule from a stamp file we touch unconditionally; list the
# generated source files via BYPRODUCTS so dependants still see them
# but their (stale) mtimes are not used as up-to-date markers.
set(SLANG_FIDDLE_STAMP "${SLANG_FIDDLE_OUTPUT_DIR}/.fiddle.stamp")
add_custom_command(
    OUTPUT ${SLANG_FIDDLE_STAMP}
    BYPRODUCTS ${SLANG_FIDDLE_OUTPUTS}
    COMMAND ${CMAKE_COMMAND} -E make_directory ${SLANG_FIDDLE_OUTPUT_DIR}
    COMMAND
        slang-fiddle -i "${SLANG_FIDDLE_INPUT_DIR}/" -o
        "${SLANG_FIDDLE_OUTPUT_DIR}/" ${SLANG_FIDDLE_INPUT_FILE_NAMES}
    COMMAND ${CMAKE_COMMAND} -E touch ${SLANG_FIDDLE_STAMP}
    DEPENDS ${SLANG_FIDDLE_INPUTS} ${SLANG_FIDDLE_LUA_INPUTS} slang-fiddle
    WORKING_DIRECTORY ${slang_SOURCE_DIR}
    VERBATIM
)
add_library(
    slang-fiddle-output
    INTERFACE
    EXCLUDE_FROM_ALL
    ${SLANG_FIDDLE_STAMP}
)
set_target_properties(slang-fiddle-output PROPERTIES FOLDER generated)
target_include_directories(
    slang-fiddle-output
    INTERFACE ${SLANG_FIDDLE_OUTPUT_DIR}
)

# Optimize slang-rich-diagnostics.cpp for size regardless of build type.
# This file includes generated fiddle code that can be large.
# Use /O1;/Os for MSVC, -Oz for Clang, -Os for GCC.
# For MSVC, we must disable PCH for this file since changing optimization
# level is incompatible with precompiled headers (warning C4653).
# Skip optimization in MSVC Debug builds to avoid /RTC1 conflicts.
# GCC/Clang don't have this issue, so they get size optimization in all configs.
string(
    CONCAT
    RICH_DIAG_SIZE_OPT_FLAGS
    "$<$<NOT:"
    "$<AND:$<CONFIG:Debug>,$<CXX_COMPILER_ID:MSVC>>"
    ">:"
    "$<IF:$<CXX_COMPILER_ID:MSVC>,/O1;/Os,"
    "$<IF:$<CXX_COMPILER_ID:GNU>,-Os,-Oz>>"
    ">"
)
set_source_files_properties(
    slang-rich-diagnostics.cpp
    PROPERTIES
        SKIP_PRECOMPILE_HEADERS ON
        COMPILE_OPTIONS "${RICH_DIAG_SIZE_OPT_FLAGS}"
)

# MSVC can exceed the COFF section limit for this translation unit in optimized
# ARM64 builds. Use the extended object format to accommodate its generated code.
set_property(
    SOURCE slang-check-decl.cpp
    APPEND
    PROPERTY COMPILE_OPTIONS "$<$<CXX_COMPILER_ID:MSVC>:/bigobj>"
)

# mimalloc-new-delete.h defines the aligned operator new/delete overloads only when __cplusplus
# reports C++17 or later, which MSVC does only with /Zc:__cplusplus. We set the option on this file
# alone because it changes the __cplusplus checks in every header a file includes, such as
# slang-common.h. The file also skips the precompiled header, which is built without the option,
# because MSVC expects a file that uses a precompiled header to be compiled with consistent options.
set_source_files_properties(
    slang-mimalloc.cpp
    PROPERTIES
        SKIP_PRECOMPILE_HEADERS ON
        COMPILE_OPTIONS "$<$<CXX_COMPILER_ID:MSVC>:/Zc:__cplusplus>"
)

#
# generate capability files
#
glob_append(SLANG_CAPABILITY_SOURCE "*.capdef")

set(SLANG_CAPABILITY_OUTPUT_DIR "${CMAKE_CURRENT_BINARY_DIR}/capability")

# Generate the output file list
set(SLANG_CAPABILITY_GENERATED_HEADERS
    "${SLANG_CAPABILITY_OUTPUT_DIR}/slang-generated-capability-defs.h"
    "${SLANG_CAPABILITY_OUTPUT_DIR}/slang-generated-capability-defs-impl.h"
)
set(SLANG_CAPABILITY_GENERATED_SOURCE
    ${SLANG_CAPABILITY_GENERATED_HEADERS}
    "${SLANG_CAPABILITY_OUTPUT_DIR}/slang-lookup-capability-defs.cpp"
)
add_custom_command(
    OUTPUT ${SLANG_CAPABILITY_GENERATED_SOURCE}
    COMMAND ${CMAKE_COMMAND} -E make_directory ${SLANG_CAPABILITY_OUTPUT_DIR}
    COMMAND
        slang-capability-generator ${SLANG_CAPABILITY_SOURCE} --target-directory
        ${SLANG_CAPABILITY_OUTPUT_DIR} --doc
        "${slang_SOURCE_DIR}/docs/user-guide/a4-02-reference-capability-atoms.md"
    DEPENDS ${SLANG_CAPABILITY_SOURCE} slang-capability-generator
    WORKING_DIRECTORY ${CMAKE_CURRENT_LIST_DIR}
    VERBATIM
)
slang_add_target(
    slang-capability-defs
    OBJECT
    EXPORT_MACRO_PREFIX SLANG
    USE_EXTRA_WARNINGS
    EXPLICIT_SOURCE ${SLANG_CAPABILITY_GENERATED_HEADERS}
    EXPORT_TYPE_AS ${SLANG_LIB_TYPE}
    LINK_WITH_PRIVATE core
    INCLUDE_DIRECTORIES_PUBLIC
        "${SLANG_CAPABILITY_OUTPUT_DIR}"
        "${slang_SOURCE_DIR}/source/slang"
    EXCLUDE_FROM_ALL
    FOLDER generated
)
slang_add_target(
    slang-capability-lookup
    OBJECT
    EXPORT_MACRO_PREFIX SLANG
    USE_EXTRA_WARNINGS
    EXPLICIT_SOURCE ${SLANG_CAPABILITY_GENERATED_SOURCE}
    EXPORT_TYPE_AS ${SLANG_LIB_TYPE}
    LINK_WITH_PRIVATE core slang-capability-defs
    EXCLUDE_FROM_ALL
    FOLDER generated
)

#
# generated lookup tables
#

get_target_property(
    SLANG_SPIRV_HEADERS_INCLUDE_DIR
    SPIRV-Headers::SPIRV-Headers
    INTERFACE_INCLUDE_DIRECTORIES
)

set(SLANG_LOOKUP_GENERATOR_INPUT_JSON
    "${SLANG_SPIRV_HEADERS_INCLUDE_DIR}/spirv/unified1/extinst.glsl.std.450.grammar.json"
)
set(SLANG_LOOKUP_GENERATOR_OUTPUT_DIR
    "${CMAKE_CURRENT_BINARY_DIR}/slang-lookup-tables/"
)
set(SLANG_LOOKUP_GENERATED_SOURCE
    "${SLANG_LOOKUP_GENERATOR_OUTPUT_DIR}/slang-lookup-GLSLstd450.cpp"
)
set(SLANG_RECORD_REPLAY_SYSTEM
    "${slang_SOURCE_DIR}/source/slang-record-replay"
    "${slang_SOURCE_DIR}/source/slang-record-replay/proxy"
)

# When SLANG_ENABLE_RECORD_REPLAY is OFF we exclude the record-replay sources from both the slang
# library and the slang-common-objects object target. slang_add_target reports an error for a
# keyword given no values, so we omit the whole EXTRA_SOURCE_DIRS fragment rather than pass it an
# empty list.
if(SLANG_ENABLE_RECORD_REPLAY)
    set(slang_record_replay_source_args
        EXTRA_SOURCE_DIRS
        ${SLANG_RECORD_REPLAY_SYSTEM}
    )
else()
    set(slang_record_replay_source_args)
endif()

add_custom_command(
    OUTPUT ${SLANG_LOOKUP_GENERATED_SOURCE}
    COMMAND
        ${CMAKE_COMMAND} -E make_directory ${SLANG_LOOKUP_GENERATOR_OUTPUT_DIR}
    COMMAND
        slang-lookup-generator ${SLANG_LOOKUP_GENERATOR_INPUT_JSON}
        ${SLANG_LOOKUP_GENERATED_SOURCE} "GLSLstd450" "GLSLstd450"
        "spirv/unified1/GLSL.std.450.h"
    DEPENDS ${SLANG_LOOKUP_GENERATOR_INPUT_JSON} slang-lookup-generator
    VERBATIM
)

set(SLANG_SPIRV_CORE_SOURCE_JSON
    "${SLANG_SPIRV_HEADERS_INCLUDE_DIR}/spirv/unified1/spirv.core.grammar.json"
)
set(SLANG_SPIRV_CORE_GRAMMAR_SOURCE
    "${SLANG_LOOKUP_GENERATOR_OUTPUT_DIR}/slang-spirv-core-grammar-embed.cpp"
)
add_custom_command(
    OUTPUT ${SLANG_SPIRV_CORE_GRAMMAR_SOURCE}
    COMMAND
        ${CMAKE_COMMAND} -E make_directory ${SLANG_LOOKUP_GENERATOR_OUTPUT_DIR}
    COMMAND
        slang-spirv-embed-generator ${SLANG_SPIRV_CORE_SOURCE_JSON}
        ${SLANG_SPIRV_CORE_GRAMMAR_SOURCE}
    DEPENDS ${SLANG_SPIRV_CORE_SOURCE_JSON} slang-spirv-embed-generator
    VERBATIM
)

slang_add_target(
    slang-lookup-tables
    OBJECT
    EXPORT_MACRO_PREFIX SLANG
    USE_EXTRA_WARNINGS
    EXPLICIT_SOURCE
        ${SLANG_LOOKUP_GENERATED_SOURCE}
        ${SLANG_SPIRV_CORE_GRAMMAR_SOURCE}
    EXPORT_TYPE_AS ${SLANG_LIB_TYPE}
    LINK_WITH_PRIVATE core SPIRV-Headers::SPIRV-Headers
    EXCLUDE_FROM_ALL
    FOLDER generated
)

#
# Generate the version header
#

configure_file(
    ${slang_SOURCE_DIR}/slang-tag-version.h.in
    slang-version-header/slang-tag-version.h
)

#
# Copy headers into the build tree to support source linking
#
add_custom_target(
    copy_slang_headers
    COMMAND
        ${CMAKE_COMMAND} -E make_directory
        "${slang_BINARY_DIR}/$<CONFIG>/include"
    COMMAND
        ${CMAKE_COMMAND} -E copy_directory "${slang_SOURCE_DIR}/include"
        "${slang_BINARY_DIR}/$<CONFIG>/include"
    COMMAND
        ${CMAKE_COMMAND} -E copy
        "${CMAKE_CURRENT_BINARY_DIR}/slang-version-header/slang-tag-version.h"
        "${slang_BINARY_DIR}/$<CONFIG>/include/slang-tag-version.h"
)
set_target_properties(copy_slang_headers PROPERTIES FOLDER "generated")

#
# Slang itself
#

set(slang_build_args
    USE_EXTRA_WARNINGS
    EXTRA_COMPILE_OPTIONS_PRIVATE
    # a warning is disabled for a memset boundary check.
    # everything looked fine and it is unclear why the checking fails
    $<$<CXX_COMPILER_ID:GNU>:-Wno-error=stringop-overflow>
    INCLUDE_DIRECTORIES_PRIVATE
    ${CMAKE_CURRENT_BINARY_DIR}/slang-version-header
    ${CMAKE_CURRENT_BINARY_DIR}/../standard-modules/slang-standard-module-config-header
    ${slang_SOURCE_DIR}/tools
    EXPORT_MACRO_PREFIX
    SLANG
    EXPORT_TYPE_AS
    ${SLANG_LIB_TYPE}
    ${slang_record_replay_source_args}
    EXTRA_COMPILE_DEFINITIONS_PRIVATE
    SLANG_ENABLE_RECORD_REPLAY=$<BOOL:${SLANG_ENABLE_RECORD_REPLAY}>
    REQUIRES
    copy_slang_headers
    generate_standard_module_config_header
    PRECOMPILE_HEADERS
    ${slang_SOURCE_DIR}/source/core/slang-basic.h
    # slang-compiler.h transitively includes generated .fiddle headers whose macros are keyed on
    # __LINE__. GCC can restore inconsistent FIDDLE macro state from its PCH even in a clean build,
    # so keep those headers out of the GCC PCH. See #12227.
    "$<$<NOT:$<CXX_COMPILER_ID:GNU>>:${slang_SOURCE_DIR}/source/slang/slang-compiler.h>"
)
set(slang_link_args
    LINK_WITH_PRIVATE
    core
    prelude
    compiler-core
    slang-capability-defs
    slang-capability-lookup
    slang-fiddle-output
    slang-lookup-tables
    SPIRV-Headers::SPIRV-Headers
    libcmark-gfm
)
set(slang_interface_args INCLUDE_DIRECTORIES_PUBLIC ${slang_SOURCE_DIR}/include)
set(slang_public_lib_args
    PUBLIC_HEADERS
    ${slang_SOURCE_DIR}/include/slang*.h
    ${CMAKE_CURRENT_BINARY_DIR}/slang-version-header/*.h
    LINK_WITH_PRIVATE
    $<IF:$<BOOL:${SLANG_EMBED_CORE_MODULE}>,slang-embedded-core-module,slang-no-embedded-core-module>
    $<IF:$<BOOL:${SLANG_EMBED_CORE_MODULE_SOURCE}>,slang-embedded-core-module-source,slang-no-embedded-core-module-source>
    INSTALL
    EXPORT_SET_NAME
    SlangTargets
)

#
# Minimal static slang used in generating the embedded core module
#

#
# Slang itself
#

if(NOT SLANG_EMBED_CORE_MODULE)
    # If we're not embedding core module we can just do a normal build of slang,
    # including all the options, this can also serve as our no embedded core module
    # library for slang-bootstrap (not that we need that anyway)
    slang_add_target(
        .
        ${SLANG_LIB_TYPE}
        OUTPUT_NAME slang-compiler
        ${slang_build_args}
        ${slang_link_args}
        ${slang_interface_args}
        ${slang_public_lib_args}
        INSTALL_COMPONENT generators
    )
    add_library(slang-without-embedded-core-module ALIAS slang)
else()
    # However if we're embedding core module, we need to make two different
    # libraries, one with the embedded core module and one without, so first define
    # the shared objects as one target so we don't build them twice.
    slang_add_target(
        .
        OBJECT
        ${slang_build_args}
        ${slang_link_args}
        TARGET_NAME slang-common-objects
        EXCLUDE_FROM_ALL
    )
    slang_add_target(
        .
        ${SLANG_LIB_TYPE}
        EXPORT_MACRO_PREFIX SLANG
        ${slang_link_args}
        ${slang_interface_args}
        NO_SOURCE
        TARGET_NAME slang-without-embedded-core-module
        EXCLUDE_FROM_ALL
        LINK_WITH_PRIVATE
            slang-common-objects
            slang-no-embedded-core-module
            slang-embedded-core-module-source
        OUTPUT_DIR generators
        FOLDER generators
        INSTALL_COMPONENT generators
        EXPORT_SET_NAME SlangGeneratorTargets
    )
    slang_add_target(
        .
        ${SLANG_LIB_TYPE}
        OUTPUT_NAME slang-compiler
        EXPORT_MACRO_PREFIX SLANG
        ${slang_link_args}
        ${slang_interface_args}
        ${slang_public_lib_args}
        LINK_WITH_PRIVATE slang-common-objects
        NO_SOURCE
    )
endif()

set_target_properties(
    slang
    PROPERTIES
        VERSION 0.${SLANG_VERSION_NUMERIC}
        SOVERSION 0.${SLANG_VERSION_NUMERIC}
        MACHO_COMPATIBILITY_VERSION 0.0.0
        MACHO_CURRENT_VERSION ${SLANG_VERSION_NUMERIC}
)

# A non-embedded shared library normally creates this cache on the first global-session request.
# Generate it from the build's core archive after the shared library is linked so the first slangc
# invocation can load the same archive without compiling the core module again.
if(NOT SLANG_EMBED_CORE_MODULE AND SLANG_LIB_TYPE STREQUAL "SHARED")
    # Place the cache beside the shared library: DLLs use the runtime directory on Windows, while
    # shared libraries use the library directory on other platforms.
    if(WIN32)
        get_target_property(
            core_module_cache_dir
            slang
            RUNTIME_OUTPUT_DIRECTORY
        )
        set(core_module_cache_install_dir ${runtime_subdir})
    else()
        get_target_property(
            core_module_cache_dir
            slang
            LIBRARY_OUTPUT_DIRECTORY
        )
        set(core_module_cache_install_dir ${library_subdir})
    endif()
    set(core_module_cache "${core_module_cache_dir}/slang-core-module.bin")

    add_custom_target(
        generate_core_module_cache
        ALL
        COMMAND
            "$<TARGET_FILE:slang-core-module-cache>" "$<TARGET_FILE:slang>"
            "${core_module_archive_without_timestamp}" "${core_module_cache}"
        BYPRODUCTS "${core_module_cache}"
        DEPENDS slang-core-module-cache slang
        COMMENT "Generating timestamped core module cache"
        VERBATIM
    )
    add_dependencies(generate_core_module_cache generate_core_module)
    set_target_properties(
        generate_core_module_cache
        PROPERTIES FOLDER generated
    )

    # CMake installation preserves the shared library's timestamp, so this cache stays valid.
    # Other packaging must also preserve it; otherwise the runtime rejects and regenerates the
    # cache on first use.
    install(
        FILES "${core_module_cache}"
        DESTINATION ${core_module_cache_install_dir}
        COMPONENT generators
        EXCLUDE_FROM_ALL
    )
endif()

#
# Windows proxy DLL for backward compatibility
# Creates slang.dll that forwards all calls to slang-compiler.dll
#
if(WIN32 AND SLANG_LIB_TYPE STREQUAL "SHARED" AND SLANG_ENABLE_SLANG_PROXY)
    # Create a minimal C++ source file (some linkers require at least one source)
    set(SLANG_PROXY_STUB_CPP "${CMAKE_CURRENT_BINARY_DIR}/slang-proxy-stub.cpp")
    file(
        WRITE
        "${SLANG_PROXY_STUB_CPP}"
        "// Minimal stub file for slang.dll proxy\n"
        "// All exports are forwarded to slang-compiler.dll via the .def file\n"
    )

    # Generate the DEF file at build time from slang-compiler.dll
    set(SLANG_PROXY_DEF "${CMAKE_CURRENT_BINARY_DIR}/slang-proxy.def")

    # Create a wrapper script with the actual DLL path (since generator expressions
    # don't work with -P script mode). Use per-config wrapper to avoid file(GENERATE) conflicts.
    set(DEF_GEN_WRAPPER
        "${CMAKE_CURRENT_BINARY_DIR}/generate-def-wrapper-$<CONFIG>.cmake"
    )
    file(
        GENERATE OUTPUT
        "${DEF_GEN_WRAPPER}"
        CONTENT
            "
set(DLL_PATH \"$<TARGET_FILE:slang>\")
set(OUTPUT_DEF \"${SLANG_PROXY_DEF}\")
set(TARGET_DLL_NAME \"slang-compiler\")
include(\"${slang_SOURCE_DIR}/cmake/RegenerateDllExports.cmake\")
"
    )

    # Custom command to generate the DEF file from slang-compiler.dll exports
    add_custom_command(
        OUTPUT "${SLANG_PROXY_DEF}"
        COMMAND ${CMAKE_COMMAND} -P "${DEF_GEN_WRAPPER}"
        DEPENDS slang "$<TARGET_FILE:slang>"
        COMMENT "Generating slang-proxy.def from slang-compiler.dll exports"
        VERBATIM
    )

    # Create the proxy DLL target
    add_library(
        slang-proxy
        SHARED
        "${SLANG_PROXY_STUB_CPP}"
        "${SLANG_PROXY_DEF}"
    )

    # Link against the slang-compiler import library so symbols can be forwarded
    target_link_libraries(slang-proxy PRIVATE slang)

    # Get the output directories from the main slang target to match build locations
    get_target_property(slang_runtime_dir slang RUNTIME_OUTPUT_DIRECTORY)
    get_target_property(slang_archive_dir slang ARCHIVE_OUTPUT_DIRECTORY)

    # Set output name to slang (produces slang.dll) and match directories
    set_target_properties(
        slang-proxy
        PROPERTIES
            OUTPUT_NAME slang
            PDB_NAME slang-proxy
            RUNTIME_OUTPUT_DIRECTORY "${slang_runtime_dir}"
            ARCHIVE_OUTPUT_DIRECTORY "${slang_archive_dir}"
    )
    # slang-proxy outputs as "slang.dll", which makes MSVC name its incremental
    # link file "slang.ilk" — colliding with slang-dispatcher ("slang.exe" →
    # "slang.ilk") when Ninja links both in parallel. Redirect the .ilk to a
    # unique filename so both targets can use incremental linking without racing.
    target_link_options(
        slang-proxy
        PRIVATE
            "$<$<CXX_COMPILER_ID:MSVC>:/ILK:$<TARGET_FILE_DIR:slang-proxy>/slang-proxy.ilk>"
    )

    # Install the proxy DLL alongside slang-compiler.dll
    install(
        TARGETS slang-proxy
        RUNTIME DESTINATION bin
        ARCHIVE DESTINATION lib
        LIBRARY DESTINATION lib
    )

    message(
        STATUS
        "Windows proxy DLL (slang.dll) will be generated to forward to slang-compiler.dll"
    )
endif()

#
# Unix backward compatibility symlink (libslang -> libslang-compiler)
#
if(UNIX AND SLANG_LIB_TYPE STREQUAL "SHARED" AND SLANG_ENABLE_SLANG_PROXY)
    # Create symlink in build directory
    add_custom_command(
        TARGET slang
        POST_BUILD
        COMMAND
            ${CMAKE_COMMAND} -E create_symlink $<TARGET_FILE_NAME:slang>
            $<TARGET_FILE_DIR:slang>/libslang.$<IF:$<PLATFORM_ID:Darwin>,dylib,so>
        COMMENT
            "Creating backward compatibility symlink: libslang -> libslang-compiler"
        VERBATIM
    )

    # Install the symlink by copying it from the build directory
    install(
        FILES
            $<TARGET_FILE_DIR:slang>/libslang.$<IF:$<PLATFORM_ID:Darwin>,dylib,so>
        DESTINATION lib
    )

    message(
        STATUS
        "Unix backward compatibility symlink (libslang -> libslang-compiler) will be created during build and installation"
    )
endif()
