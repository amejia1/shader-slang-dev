#include "slang.h"

#include "core/slang-archive-file-system.h"
#include "core/slang-castable.h"
#include "core/slang-io.h"
#include "core/slang-performance-profiler.h"
#include "core/slang-platform.h"
#include "core/slang-shared-library.h"
#include "core/slang-string-util.h"
#include "core/slang-string.h"
#include "core/slang-type-convert-util.h"
#include "core/slang-type-text-util.h"
// Artifact
#include "compiler-core/slang-artifact-associated-impl.h"
#include "compiler-core/slang-artifact-container-util.h"
#include "compiler-core/slang-artifact-desc-util.h"
#include "compiler-core/slang-artifact-impl.h"
#include "compiler-core/slang-artifact-util.h"
#include "compiler-core/slang-source-loc.h"
#include "core/slang-file-system.h"
#include "core/slang-memory-file-system.h"
#include "core/slang-shared-library.h"
#include "core/slang-writer.h"
#include "slang-ast-dump.h"
#include "slang-check-impl.h"
#include "slang-check.h"
#include "slang-doc-ast.h"
#include "slang-doc-markdown-writer.h"
#include "slang-ir.h"
#include "slang-lookup.h"
#include "slang-lower-to-ir.h"
#include "slang-mangle.h"
#include "slang-module-library.h"
#include "slang-options.h"
#include "slang-parameter-binding.h"
#include "slang-parser.h"
#include "slang-preprocessor.h"
#include "slang-reflection-json.h"
#include "slang-repro.h"
#include "slang-serialize-ast.h"
#include "slang-serialize-container.h"
#include "slang-serialize-ir.h"
#include "slang-tag-version.h"
#include "slang-type-layout.h"

#include <cinttypes>
#include <cstdio>
#include <mutex>
#include <sys/stat.h>

// Used to print exception type names in internal-compiler-error messages
#include <typeinfo>

namespace Slang
{

const char* getBuildTagString()
{
    if (UnownedStringSlice(SLANG_TAG_VERSION) == "0.0.0-unknown")
    {
        // If the tag is unknown, then we will try to get the timestamp of the shared library
        // and use that as the version string, so that we can at least return something
        // that uniquely identifies the build.
        //
        // Use a static char buffer (BSS) instead of a heap String so MSVC
        // _CrtDumpMemoryLeaks() at exit does not false-report that allocation.
        static char timeStampBuffer[32] = {};
        static std::once_flag initFlag;
        std::call_once(
            initFlag,
            []()
            {
                uint64_t ts = SharedLibraryUtils::getSharedLibraryTimestamp((void*)spCreateSession);
                snprintf(timeStampBuffer, sizeof(timeStampBuffer), "%" PRIu64, ts);
            });
        return timeStampBuffer;
    }
    return SLANG_TAG_VERSION;
}

Profile getEffectiveTargetProfile(TargetRequest* target, CompilerOptionSet& optionSet)
{
    auto& targetOptionSet = target->getOptionSet();
    auto targetProfile = targetOptionSet.getProfile();
    bool isExplicitProfile = targetOptionSet.hasOption(CompilerOptionName::Profile);
    if (targetProfile.getFamily() == ProfileFamily::Unknown)
    {
        targetProfile = optionSet.getProfile();
        isExplicitProfile = optionSet.hasOption(CompilerOptionName::Profile);
    }

    // Depending on the target *format* we might have to restrict the
    // profile family to one that makes sense.
    //
    // TODO: Some of this should really be handled as validation at
    // the front-end. People shouldn't be allowed to ask for SPIR-V
    // output with Shader Model 5.0...
    switch (target->getTarget())
    {
    default:
        break;

    case CodeGenTarget::GLSL:
    case CodeGenTarget::SPIRV:
    case CodeGenTarget::SPIRVAssembly:
        if (targetProfile.getFamily() != ProfileFamily::GLSL)
        {
            targetProfile.setVersion(ProfileVersion::GLSL_150);
        }
        break;

    case CodeGenTarget::HLSL:
    case CodeGenTarget::DXBytecode:
    case CodeGenTarget::DXBytecodeAssembly:
        if (targetProfile.getFamily() != ProfileFamily::DX)
        {
            targetProfile.setVersion(ProfileVersion::DX_5_1);
        }
        break;

    case CodeGenTarget::DXIL:
    case CodeGenTarget::DXILAssembly:
        {
            // DXIL generation goes through DXC, which requires Shader Model 6.0 or later.
            // Apply this as the default only; keep explicit user DX profiles authoritative.
            auto minVersion = ProfileVersion::DX_6_0;

            if (optionSet.getBoolOption(CompilerOptionName::GenerateWholeProgram))
            {
                // DXC validation rejects lib_6_1 and lib_6_2, so default whole-program DXIL to
                // the first accepted DXIL library shader-model version. Preserve the stage here;
                // callers that must pass a lib_* profile to DXC clear the stage at that boundary.
                minVersion = ProfileVersion::DX_6_3;
            }

            if (targetProfile.getFamily() != ProfileFamily::DX)
            {
                targetProfile.setVersion(minVersion);
            }
            else if (!isExplicitProfile && targetProfile.getVersion() < minVersion)
            {
                targetProfile.setVersion(minVersion);
            }
        }
        break;
    case CodeGenTarget::Metal:
    case CodeGenTarget::MetalLib:
    case CodeGenTarget::MetalLibAssembly:
        if (targetProfile.getFamily() != ProfileFamily::METAL)
        {
            targetProfile.setVersion(ProfileVersion::METAL_2_3);
        }
        break;
    }

    return targetProfile;
}

Profile getEffectiveTargetProfile(TargetRequest* target)
{
    return getEffectiveTargetProfile(target, target->getOptionSet());
}

Profile getEffectiveProfile(EntryPoint* entryPoint, TargetRequest* target)
{
    auto entryPointProfile = entryPoint->getProfile();
    auto targetProfile = getEffectiveTargetProfile(target);

    auto entryPointProfileVersion = entryPointProfile.getVersion();
    auto targetProfileVersion = targetProfile.getVersion();

    // Default to the entry point profile, since we know that has the right stage.
    Profile effectiveProfile = entryPointProfile;

    // Ignore the input from the target profile if it is missing.
    if (targetProfile.getFamily() != ProfileFamily::Unknown)
    {
        // If the target comes from a different profile family, *or* it is from
        // the same family but has a greater version number, then use the target's version.
        if (targetProfile.getFamily() != entryPointProfile.getFamily() ||
            (targetProfileVersion > entryPointProfileVersion))
        {
            effectiveProfile.setVersion(targetProfileVersion);
        }
    }

    // Now consider the possibility that the chosen stage might force an "upgrade"
    // to the profile level.
    ProfileVersion stageMinVersion = ProfileVersion::Unknown;
    switch (effectiveProfile.getFamily())
    {
    case ProfileFamily::DX:
        switch (effectiveProfile.getStage())
        {
        default:
            break;

        case Stage::RayGeneration:
        case Stage::Intersection:
        case Stage::ClosestHit:
        case Stage::AnyHit:
        case Stage::Miss:
        case Stage::Callable:
            // The DirectX ray tracing stages implicitly
            // require Shader Model 6.3 or later.
            //
            stageMinVersion = ProfileVersion::DX_6_3;
            break;

            //  TODO: Add equivalent logic for geometry, tessellation, and compute stages.
        }
        break;

    case ProfileFamily::GLSL:
        switch (effectiveProfile.getStage())
        {
        default:
            break;

        case Stage::RayGeneration:
        case Stage::Intersection:
        case Stage::ClosestHit:
        case Stage::AnyHit:
        case Stage::Miss:
        case Stage::Callable:
            stageMinVersion = ProfileVersion::GLSL_460;
            break;

            //  TODO: Add equivalent logic for geometry, tessellation, and compute stages.
        }
        break;

    default:
        break;
    }

    if (stageMinVersion > effectiveProfile.getVersion())
    {
        effectiveProfile.setVersion(stageMinVersion);
    }

    return effectiveProfile;
}

} // namespace Slang
