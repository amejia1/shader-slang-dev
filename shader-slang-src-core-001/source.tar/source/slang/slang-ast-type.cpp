// slang-ast-type.cpp
#include "slang-ast-type.h"

#include "slang-ast-builder.h"
#include "slang-ast-dispatch.h"
#include "slang-ast-modifier.h"
#include "slang-check.h"
#include "slang-syntax.h"

#include <typeinfo>
namespace Slang
{

struct SemanticsContext;

bool isAbstractTypePack(Type* type)
{
    type = unwrapModifiedType(type);
    if (as<ExpandType>(type))
        return true;
    if (as<TrimFirstTypePack>(type))
        return true;
    if (as<TrimLastTypePack>(type))
        return true;
    if (isDeclRefTypeOf<GenericTypePackParamDecl>(type))
        return true;
    return false;
}

bool isTypePack(Type* type)
{
    type = unwrapModifiedType(type);
    if (as<ConcreteTypePack>(type))
        return true;
    return isAbstractTypePack(type);
}

bool isPackType(Type* type)
{
    type = unwrapModifiedType(type);
    if (isTypePack(type))
        return true;
    if (as<ValuePackType>(type))
        return true;
    return false;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! Type !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Type* Type::_createCanonicalTypeOverride()
{
    return as<Type>(defaultResolveImpl());
}

Val* Type::_substituteImplOverride(ASTBuilder* astBuilder, SubstitutionSet subst, int* ioDiff)
{
    int diff = 0;
    auto canonicalType = getCanonicalType();

    // If canonicalType is identical to this, then we shouldn't try to call
    // canonicalType->substituteImpl because that would lead to infinite recursion.
    if (canonicalType == this)
        return this;

    auto canSubst = canonicalType->substituteImpl(astBuilder, subst, &diff);

    // If nothing changed, then don't drop any sugar that is applied
    if (!diff)
        return this;

    // If the canonical type changed, then we return a canonical type,
    // rather than try to re-construct any amount of sugar
    (*ioDiff)++;
    return canSubst;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! OverloadGroupType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void OverloadGroupType::_toTextOverride(StringBuilder& out)
{
    out << toSlice("overload group");
}

Type* OverloadGroupType::_createCanonicalTypeOverride()
{
    return this;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! InitializerListType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void InitializerListType::_toTextOverride(StringBuilder& out)
{
    out << toSlice("initializer list");
}

Type* InitializerListType::_createCanonicalTypeOverride()
{
    return this;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ErrorType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void ErrorType::_toTextOverride(StringBuilder& out)
{
    out << toSlice("error");
}

Type* ErrorType::_createCanonicalTypeOverride()
{
    return this;
}

Val* ErrorType::_substituteImplOverride(
    ASTBuilder* /* astBuilder */,
    SubstitutionSet /*subst*/,
    int* /*ioDiff*/
)
{
    return this;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! BottomType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void BottomType::_toTextOverride(StringBuilder& out)
{
    out << toSlice("never");
}

Val* BottomType::_substituteImplOverride(
    ASTBuilder* /* astBuilder */,
    SubstitutionSet /*subst*/,
    int* /*ioDiff*/
)
{
    return this;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! DeclRefType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void DeclRefType::_toTextOverride(StringBuilder& out)
{
    out << getDeclRef();
}

Val* maybeSubstituteGenericParam(
    Val* paramVal,
    Decl* paramDecl,
    SubstitutionSet subst,
    int* ioDiff);

Val* DeclRefType::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    if (!subst)
        return this;
    int diff = 0;
    DeclRef<Decl> substDeclRef = getDeclRef().substituteImpl(astBuilder, subst, &diff);

    // If this declref type is a direct reference to ThisType or a Generic parameter,
    // and `subst` provides an argument for it, then we should just return that argument.
    //
    if (as<DirectDeclRef>(substDeclRef.declRefBase) || as<MemberDeclRef>(substDeclRef.declRefBase))
    {
        if (as<ThisTypeDecl>(substDeclRef.getDecl()))
        {
            auto lookupDeclRef = subst.findLookupDeclRef();
            if (lookupDeclRef && lookupDeclRef->getSupDecl() == substDeclRef.getDecl()->parentDecl)
            {
                (*ioDiff)++;
                return lookupDeclRef->getLookupSource();
            }
        }
        else if (isGenericParam(substDeclRef.getDecl()))
        {
            auto resultVal =
                maybeSubstituteGenericParam(nullptr, substDeclRef.getDecl(), subst, ioDiff);
            if (resultVal)
            {
                (*ioDiff)++;
                return resultVal;
            }
        }
    }

    // If this type is a reference to an associated type declaration,
    // and the substitutions provide a "this type" substitution for
    // the outer interface, then try to replace the type with the
    // actual value of the associated type for the given implementation.
    //
    if (auto satisfyingVal = substDeclRef.declRefBase->resolve())
    {
        if (satisfyingVal != substDeclRef.declRefBase)
        {
            *ioDiff += 1;
            if (auto satisfyingType = as<Type>(satisfyingVal))
                return satisfyingType;
            if (auto satisfyingDeclRef = as<DeclRefBase>(satisfyingVal))
                return DeclRefType::create(astBuilder, DeclRef<Decl>(satisfyingDeclRef));
        }
    }

    if (!diff)
        return this;

    // Make sure to record the difference!
    *ioDiff += diff;

    // Re-construct the type in case we are using a specialized sub-class
    return DeclRefType::create(astBuilder, substDeclRef);
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ArithmeticExpressionType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


BasicExpressionType* ArithmeticExpressionType::getScalarType(){
    SLANG_AST_NODE_VIRTUAL_CALL(ArithmeticExpressionType, getScalarType, ())}

BasicExpressionType* ArithmeticExpressionType::_getScalarTypeOverride()
{
    SLANG_UNEXPECTED("ArithmeticExpressionType::_getScalarTypeOverride not overridden");
    // return nullptr;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! BasicExpressionType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

BasicExpressionType* BasicExpressionType::_getScalarTypeOverride()
{
    return this;
}

static Val* _getGenericTypeArg(DeclRefBase* declRef, Index i)
{
    auto args = findInnerMostGenericArgs(SubstitutionSet(declRef));
    if (args.getCount() <= i)
        return nullptr;

    return args[i];
}

static Val* _getGenericTypeArg(DeclRefType* declRefType, Index i)
{
    return _getGenericTypeArg(declRefType->getDeclRefBase(), i);
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! TensorViewType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Type* TensorViewType::getElementType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! VectorExpressionType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Type* VectorExpressionType::getElementType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

IntVal* VectorExpressionType::getElementCount()
{
    return as<IntVal>(_getGenericTypeArg(this, 1));
}

void VectorExpressionType::_toTextOverride(StringBuilder& out)
{
    out << toSlice("vector<") << getElementType() << toSlice(",") << getElementCount()
        << toSlice(">");
}

BasicExpressionType* VectorExpressionType::_getScalarTypeOverride()
{
    return as<BasicExpressionType>(getElementType());
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! MatrixExpressionType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void MatrixExpressionType::_toTextOverride(StringBuilder& out)
{
    out << toSlice("matrix<") << getElementType() << toSlice(",") << getRowCount() << toSlice(",")
        << getColumnCount() << toSlice(">");
}

BasicExpressionType* MatrixExpressionType::_getScalarTypeOverride()
{
    return as<BasicExpressionType>(getElementType());
}

Type* MatrixExpressionType::getElementType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

IntVal* MatrixExpressionType::getRowCount()
{
    return as<IntVal>(_getGenericTypeArg(this, 1));
}

IntVal* MatrixExpressionType::getColumnCount()
{
    return as<IntVal>(_getGenericTypeArg(this, 2));
}

IntVal* MatrixExpressionType::getLayout()
{
    return as<IntVal>(_getGenericTypeArg(this, 3));
}

Type* MatrixExpressionType::getRowType()
{
    if (!rowType)
    {
        rowType = getCurrentASTBuilder()->getVectorType(getElementType(), getColumnCount());
    }
    return rowType;
}

static Type* getEffectiveDiffPairType(Type* primalType, SubtypeWitness* diffWitness)
{
    auto astBuilder = getCurrentASTBuilder();

    if (auto concretePack = as<ConcreteTypePack>(primalType))
    {
        // The differential pair of a type pack should be a type pack of differential pairs.
        if (auto witnessPack = as<TypePackSubtypeWitness>(diffWitness))
        {
            List<Type*> diffPairTypes;
            for (Index i = 0; i < concretePack->getTypeCount(); i++)
            {
                auto elemType = concretePack->getElementType(i);
                auto elemWitness = witnessPack->getWitness(i);
                auto diffPairType = getEffectiveDiffPairType(elemType, elemWitness);
                diffPairTypes.add(diffPairType);
            }
            return astBuilder->getTypePack(diffPairTypes.getArrayView());
        }
    }

    if (isAbstractTypePack(primalType))
    {
        // The differential pair of an abstract type pack P should be
        // `expand DiffPair<each P>`.
        auto eachType = astBuilder->getEachType(primalType);
        auto eachWitness =
            astBuilder->getEachSubtypeWitness(eachType, diffWitness->getSup(), diffWitness);
        auto diffPairEachType = getEffectiveDiffPairType(eachType, eachWitness);

        if (auto expandType = as<ExpandType>(primalType))
        {
            List<Val*> capturedTypePacks;
            for (Index i = 0; i < expandType->getCapturedPackCount(); i++)
                capturedTypePacks.add(expandType->getCapturedPack(i));
            return astBuilder->getExpandType(diffPairEachType, capturedTypePacks.getArrayView());
        }
        else
        {
            auto primalVal = (Val*)primalType;
            return astBuilder->getExpandType(diffPairEachType, makeArrayViewSingle(primalVal));
        }
    }

    if (diffWitness->getSup() == astBuilder->getDifferentiableInterfaceType())
    {
        return astBuilder->getDifferentialPairType(primalType, diffWitness);
    }
    else if (diffWitness->getSup() == astBuilder->getDifferentiableRefInterfaceType())
    {
        return astBuilder->getDifferentialPtrPairType(primalType, diffWitness);
    }
    else
    {
        SLANG_UNEXPECTED("Unsupported diff witness for differential pair type");
    }
}

static Type* getDifferentialValueTypeFromWitness(
    ASTBuilder* astBuilder,
    Type* primalType,
    SubtypeWitness* witness)
{
    if (witness && (witness->getSup() == astBuilder->getDifferentiableInterfaceType()))
    {
        if (auto declRefType = as<DeclRefType>(primalType))
            if (auto interfaceDeclRef = declRefType->getDeclRef().as<InterfaceDecl>())
                return witness->getSup();

        if (auto concretePack = as<ConcreteTypePack>(primalType))
        {
            // Construct a concrete type pack out of the .Differential
            // by going through each witness in the witness pack,
            // and performing the lookup.
            //
            auto differentialTypeRequirement =
                astBuilder->getSharedASTBuilder()->findBuiltinRequirementDecl(
                    BuiltinRequirementKind::DifferentialType);
            if (auto witnessPack = as<TypePackSubtypeWitness>(witness))
            {
                List<Type*> diffTypes;
                for (Index i = 0; i < concretePack->getTypeCount(); i++)
                {
                    auto elemType = concretePack->getElementType(i);
                    auto elemWitness = witnessPack->getWitness(i);
                    auto diffType = DeclRefType::create(
                        astBuilder,
                        astBuilder
                            ->getLookupDeclRef(elemType, elemWitness, differentialTypeRequirement));
                    diffTypes.add(diffType);
                }
                return astBuilder->getTypePack(diffTypes.getArrayView());
            }
        }

        if (isAbstractTypePack(primalType))
        {
            // Use ExpandType over EachSubtypeWitness(baseWitness)
            // to construct the .Differential type pack, which will expand out to the
            // correct number of elements
            //
            auto differentialTypeRequirement =
                astBuilder->getSharedASTBuilder()->findBuiltinRequirementDecl(
                    BuiltinRequirementKind::DifferentialType);
            auto eachType = astBuilder->getEachType(primalType);
            auto eachWitness =
                astBuilder->getEachSubtypeWitness(eachType, witness->getSup(), witness);
            auto diffEachType = DeclRefType::create(
                astBuilder,
                astBuilder->getLookupDeclRef(eachType, eachWitness, differentialTypeRequirement));
            if (auto expandType = as<ExpandType>(primalType))
            {
                List<Val*> capturedPacks;
                for (Index i = 0; i < expandType->getCapturedPackCount(); i++)
                    capturedPacks.add(expandType->getCapturedPack(i));
                return astBuilder->getExpandType(diffEachType, capturedPacks.getArrayView());
            }
            else
            {
                auto primalVal = (Val*)primalType;
                return astBuilder->getExpandType(diffEachType, makeArrayViewSingle(primalVal));
            }
        }

        // Simple case: we have a witness for a singular, non-existential type.
        auto differentialTypeRequirement =
            astBuilder->getSharedASTBuilder()->findBuiltinRequirementDecl(
                BuiltinRequirementKind::DifferentialType);
        return DeclRefType::create(
            astBuilder,
            astBuilder->getLookupDeclRef(primalType, witness, differentialTypeRequirement));
    }

    return nullptr;
}

static DeclRef<CallableDecl> getCallableDeclRefFromFuncTypeBase(Val* resolvedBase)
{
    if (auto declRefType = as<DeclRefType>(resolvedBase))
        return declRefType->getDeclRef().as<CallableDecl>();
    return DeclRef<CallableDecl>();
}

/// Returns the parameter mode produced by the backward-callable transformation.
///
/// This mapping is shared by ordinary parameters and an effective `this` parameter after the
/// latter's compatibility projection. An empty result denotes a mode for which differentiable
/// backward-callable parameters are unsupported.
static std::optional<ParamPassingMode> _getBackwardCallableParamMode(ParamPassingMode primalMode)
{
    switch (primalMode)
    {
    case ParamPassingMode::Out:
        return ParamPassingMode::In;
    case ParamPassingMode::In:
        return ParamPassingMode::Out;
    case ParamPassingMode::BorrowInOut:
        return ParamPassingMode::BorrowInOut;
    case ParamPassingMode::BorrowIn:
    case ParamPassingMode::RefReadWrite:
    case ParamPassingMode::RefReadOnly:
    case ParamPassingMode::RefWriteOnly:
        return std::nullopt;
    default:
        SLANG_UNEXPECTED("unhandled parameter-passing mode");
    }
}

Val* BwdCallableFuncType::_resolveImplOverride()
{
    // Resolve all three operands.
    // Operand 0: base function type
    // Operand 1: context type (not used for BwdCallable)
    // Operand 2: diff-type-info-witness
    auto resolvedBase = _getGenericTypeArg(this, 0)->resolve();
    auto resolvedCtxType = as<Type>(_getGenericTypeArg(this, 1)->resolve());
    auto resolvedWitness = _getGenericTypeArg(this, 2)->resolve();

    auto astBuilder = getCurrentASTBuilder();
    if (auto diffTypeWitness = as<DiffTypeInfoWitness>(resolvedWitness))
    {
        // If we have a concrete witness, we should be able to turn this into a concrete func-type.
        List<Type*> newParamTypes;

        auto baseFuncDeclRef = getCallableDeclRefFromFuncTypeBase(resolvedBase);
        auto funcType = getFuncType(astBuilder, baseFuncDeclRef);

        // First translate the this-type.
        // Get the differential value type and add it with flipped direction.
        auto thisParamType = diffTypeWitness->getThisParamType();
        if (thisParamType)
        {
            auto [thisParamValueType, thisParamDirection] =
                getParamInfoFromTypeWithModeWrapper(thisParamType);
            auto thisTypeDiffWitness = diffTypeWitness->getThisTypeDiffWitness();
            if (thisTypeDiffWitness)
            {
                if (auto diffThisType = getDifferentialValueTypeFromWitness(
                        astBuilder,
                        thisParamValueType,
                        thisTypeDiffWitness))
                {
                    auto differentiatedThisMode = _getBackwardCallableParamMode(
                        getDifferentiatedThisParamMode(thisParamDirection));
                    SLANG_RELEASE_ASSERT(differentiatedThisMode.has_value());
                    newParamTypes.add(getParamTypeWithModeWrapper(
                        astBuilder,
                        diffThisType,
                        *differentiatedThisMode));
                }
                else
                {
                    // We had a witness but not for a differentiable value type (most likely a
                    // differential pointer type).
                    newParamTypes.add(astBuilder->getNoneType());
                }
            }
            else
            {
                // Non-differentiable this type
                newParamTypes.add(astBuilder->getNoneType());
            }
        }

        // Then, go through and translate all types (parameter & result) to their
        // differential variants, flipping directions.
        for (Index i = 0; i < funcType->getParamCount(); ++i)
        {
            auto paramInfo = funcType->getParamInfo(i);
            auto diffWitness = diffTypeWitness->getParamTypeDiffWitness(i);

            auto diffValueType =
                getDifferentialValueTypeFromWitness(astBuilder, paramInfo.type, diffWitness);

            if (!diffValueType)
            {
                // Non-differentiable param
                newParamTypes.add(astBuilder->getNoneType());
            }
            else
            {
                auto differentiatedMode = _getBackwardCallableParamMode(paramInfo.mode);
                if (differentiatedMode)
                {
                    newParamTypes.add(getParamTypeWithModeWrapper(
                        astBuilder,
                        diffValueType,
                        *differentiatedMode));
                }
                else
                {
                    // We can't handle ConstRef and Ref properly for differentiable
                    // values in differentiable methods so we return an error type,
                    // and rely on diagnostics instead.
                    newParamTypes.add(astBuilder->getErrorType());
                }
            }
        }

        // Add the differential of the result type as a parameter at the end.
        if (auto resultDiffWitness = diffTypeWitness->getReturnTypeDiffWitness())
        {
            auto diffResultType = getDifferentialValueTypeFromWitness(
                astBuilder,
                funcType->getResultType(),
                resultDiffWitness);
            if (diffResultType)
            {
                newParamTypes.add(diffResultType);
            }
        }

        // Build a new func type with void return type.
        return astBuilder->getFuncType(
            newParamTypes.getArrayView(),
            astBuilder->getVoidType(),
            funcType->getErrorType());
    }
    else
    {
        Val* args[] = {as<Type>(resolvedBase), resolvedCtxType, as<Witness>(resolvedWitness)};
        return astBuilder->getSpecializedBuiltinType(makeArrayView(args), "BwdCallableFuncType");
    }
}

Val* ApplyForBwdFuncType::_resolveImplOverride()
{
    // Resolve all three operands.
    // Operand 0: base function type
    // Operand 1: context type (MinimalContextType in new design)
    // Operand 2: diff-type-info-witness
    auto resolvedBase = _getGenericTypeArg(this, 0)->resolve();
    auto resolvedCtxType = as<Type>(_getGenericTypeArg(this, 1)->resolve());
    auto resolvedWitness = _getGenericTypeArg(this, 2)->resolve();

    auto astBuilder = getCurrentASTBuilder();
    if (auto diffTypeWitness = as<DiffTypeInfoWitness>(resolvedWitness))
    {
        // If we have a concrete witness, we should be able to turn this into a concrete func-type.
        List<Type*> newParamTypes;

        auto baseFuncDeclRef = getCallableDeclRefFromFuncTypeBase(resolvedBase);
        auto funcType = getFuncType(astBuilder, baseFuncDeclRef);

        // The result type is Tuple<FuncResultType, MinimalContextType> when non-void,
        // or just MinimalContextType when the function returns void.
        auto funcResultType = funcType->getResultType();
        Type* resultType;
        if (funcResultType->equals(astBuilder->getVoidType()))
        {
            resultType = resolvedCtxType;
        }
        else
        {
            Type* tupleTypes[] = {funcResultType, resolvedCtxType};
            resultType = astBuilder->getTupleType(makeArrayView(tupleTypes));
        }
        auto errorType = funcType->getErrorType();

        // Get references to the differentiable interfaces to determine witness type.
        auto differentiableRefInterface = astBuilder->getDifferentiableRefInterfaceType();

        // Helper to check if witness is for IDifferentiablePtrType.
        auto isPtrTypeWitness = [&](SubtypeWitness* witness) -> bool
        {
            if (!witness)
                return false;
            return witness->getSup() == differentiableRefInterface;
        };

        // Process each parameter.
        // For ApplyForBwd, differentiable params get wrapped in DifferentialPtrPairType.
        for (Index i = 0; i < funcType->getParamCount(); ++i)
        {
            auto paramInfo = funcType->getParamInfo(i);
            auto diffWitness = diffTypeWitness->getParamTypeDiffWitness(i);

            if (diffWitness && isPtrTypeWitness(diffWitness))
            {
                // This is an IDifferentiablePtrType param - use DifferentialPtrPairType.
                auto ptrPairType =
                    astBuilder->getDifferentialPtrPairType(paramInfo.type, diffWitness);

                newParamTypes.add(
                    getParamTypeWithModeWrapper(astBuilder, ptrPairType, paramInfo.mode));
            }
            else
            {
                // Non-ptr-differentiable param - add as-is.
                // TODO: Probably need to wrap in no-diff
                newParamTypes.add(funcType->getParamTypeWithModeWrapper(i));
            }
        }

        return astBuilder->getFuncType(newParamTypes.getArrayView(), resultType, errorType);
    }
    else
    {
        Val* args[] = {as<Type>(resolvedBase), resolvedCtxType, as<Witness>(resolvedWitness)};
        return astBuilder->getSpecializedBuiltinType(makeArrayView(args), "ApplyForBwdFuncType");
    }
}

Val* RematFuncType::_resolveImplOverride()
{
    // Resolve all four operands.
    // Operand 0: base function type (FType)
    // Operand 1: MinimalCtxType
    // Operand 2: FullCtxType (BwdCallable)
    // Operand 3: diff-type-info-witness
    auto resolvedBase = _getGenericTypeArg(this, 0)->resolve();
    auto resolvedMinimalCtxType = as<Type>(_getGenericTypeArg(this, 1)->resolve());
    auto resolvedFullCtxType = as<Type>(_getGenericTypeArg(this, 2)->resolve());
    auto resolvedWitness = _getGenericTypeArg(this, 3)->resolve();

    auto astBuilder = getCurrentASTBuilder();
    if (auto diffTypeWitness = as<DiffTypeInfoWitness>(resolvedWitness))
    {
        List<Type*> newParamTypes;

        auto baseFuncDeclRef = getCallableDeclRefFromFuncTypeBase(resolvedBase);
        auto funcType = getFuncType(astBuilder, baseFuncDeclRef);

        // First parameter is always the MinimalCtxType.
        newParamTypes.add(resolvedMinimalCtxType);

        // For member methods, include the effective `this` parameter type as an explicit
        // parameter. Since remat is static, it has no effective `this` parameter of its own.
        auto thisParamType = diffTypeWitness->getThisParamType();
        if (thisParamType)
        {
            auto [thisParamValueType, thisParamMode] =
                getParamInfoFromTypeWithModeWrapper(thisParamType);
            auto differentiatedThisMode = getDifferentiatedThisParamMode(thisParamMode);
            newParamTypes.add(getParamTypeWithModeWrapper(
                astBuilder,
                thisParamValueType,
                differentiatedThisMode));
        }

        // Get references to the differentiable interfaces to determine witness type.
        auto differentiableRefInterface = astBuilder->getDifferentiableRefInterfaceType();

        // Helper to check if witness is for IDifferentiablePtrType.
        auto isPtrTypeWitness = [&](SubtypeWitness* witness) -> bool
        {
            if (!witness)
                return false;
            return witness->getSup() == differentiableRefInterface;
        };

        // Remaining parameters match apply_bwd's parameters
        // (DifferentialPtrPair-wrapped for differentiable params).
        for (Index i = 0; i < funcType->getParamCount(); ++i)
        {
            auto paramInfo = funcType->getParamInfo(i);
            auto diffWitness = diffTypeWitness->getParamTypeDiffWitness(i);

            if (diffWitness && isPtrTypeWitness(diffWitness))
            {
                auto ptrPairType =
                    astBuilder->getDifferentialPtrPairType(paramInfo.type, diffWitness);

                newParamTypes.add(
                    getParamTypeWithModeWrapper(astBuilder, ptrPairType, paramInfo.mode));
            }
            else
            {
                newParamTypes.add(funcType->getParamTypeWithModeWrapper(i));
            }
        }

        // Return type is the FullCtxType (BwdCallable).
        return astBuilder->getFuncType(
            newParamTypes.getArrayView(),
            resolvedFullCtxType,
            funcType->getErrorType());
    }
    else
    {
        Val* args[] = {
            as<Type>(resolvedBase),
            resolvedMinimalCtxType,
            resolvedFullCtxType,
            as<Witness>(resolvedWitness)};
        return astBuilder->getSpecializedBuiltinType(makeArrayView(args), "RematFuncType");
    }
}

static Type* _getNoDiffType(ASTBuilder* astBuilder, Type* type)
{
    if (doesTypeHaveNoDiffModifier(type))
        return type;

    return astBuilder->getModifiedType(type, {astBuilder->getNoDiffModifierVal()});
}

Val* BwdDiffFuncType::_resolveImplOverride()
{
    // Resolve all operands.
    auto resolvedBase = _getGenericTypeArg(this, 0)->resolve();
    auto resolvedWitness = _getGenericTypeArg(this, 1)->resolve();

    auto astBuilder = getCurrentASTBuilder();
    if (auto diffTypeWitness = as<DiffTypeInfoWitness>(resolvedWitness))
    {
        // If we have a concrete witness, we should be able to turn this into a concrete func-type.
        List<Type*> newParamTypes;

        auto baseFuncDeclRef = getCallableDeclRefFromFuncTypeBase(resolvedBase);
        auto funcType = getFuncType(astBuilder, baseFuncDeclRef);

        // The backward diff return type is void.
        auto resultType = astBuilder->getVoidType();
        auto errorType = funcType->getErrorType();

        // For methods, include the witness-provided this-type as an explicit parameter.
        auto thisParamType = diffTypeWitness->getThisParamType();
        if (thisParamType)
        {
            auto [thisParamValueType, thisParamDirection] =
                getParamInfoFromTypeWithModeWrapper(thisParamType);
            auto differentiatedThisMode = getDifferentiatedThisParamMode(thisParamDirection);
            if (auto thisTypeDiffWitness = diffTypeWitness->getThisTypeDiffWitness())
            {
                auto thisPairType =
                    getEffectiveDiffPairType(thisParamValueType, thisTypeDiffWitness);

                // A by-value receiver becomes writable storage when reverse-mode AD needs to
                // accumulate into a value pair. Pointer pairs already carry indirection, while the
                // remaining differentiated modes retain their parameter-passing behavior.
                if (differentiatedThisMode == ParamPassingMode::In &&
                    as<DifferentialPairType>(thisPairType))
                {
                    differentiatedThisMode = ParamPassingMode::BorrowInOut;
                }

                SLANG_RELEASE_ASSERT(differentiatedThisMode != ParamPassingMode::Out);
                newParamTypes.add(
                    getParamTypeWithModeWrapper(astBuilder, thisPairType, differentiatedThisMode));
            }
            else
            {
                // Non-differentiable this type gets no_diff modifier.
                auto noDiffThisType = _getNoDiffType(astBuilder, thisParamValueType);
                SLANG_RELEASE_ASSERT(differentiatedThisMode != ParamPassingMode::Out);
                newParamTypes.add(getParamTypeWithModeWrapper(
                    astBuilder,
                    noDiffThisType,
                    differentiatedThisMode));
            }
        }

        // Process each parameter according to backward diff rules.
        for (Index i = 0; i < funcType->getParamCount(); ++i)
        {
            auto paramInfo = funcType->getParamInfo(i);

            auto diffWitness = diffTypeWitness->getParamTypeDiffWitness(i);

            switch (paramInfo.mode)
            {
            case ParamPassingMode::Out:
                {
                    // For out params in backward diff, we need the differential value type.
                    auto diffValueType = getDifferentialValueTypeFromWitness(
                        astBuilder,
                        paramInfo.type,
                        diffWitness);
                    if (diffValueType)
                        newParamTypes.add(diffValueType);
                    break;
                }
            case ParamPassingMode::In:
                {
                    if (diffWitness)
                    {
                        auto pairType = getEffectiveDiffPairType(paramInfo.type, diffWitness);
                        // In parameters become inout differential pairs.
                        if (as<DifferentialPairType>(pairType))
                            newParamTypes.add(astBuilder->getBorrowInOutParamType(pairType));
                        else if (as<DifferentialPtrPairType>(pairType))
                            newParamTypes.add(pairType);
                    }
                    else
                    {
                        // Non-differentiable param gets no_diff modifier.
                        newParamTypes.add(_getNoDiffType(astBuilder, paramInfo.type));
                    }
                    break;
                }
            case ParamPassingMode::BorrowInOut:
                {
                    if (diffWitness)
                    {
                        auto pairType = getEffectiveDiffPairType(paramInfo.type, diffWitness);
                        newParamTypes.add(astBuilder->getBorrowInOutParamType(pairType));
                    }
                    else
                    {
                        newParamTypes.add(_getNoDiffType(astBuilder, paramInfo.type));
                    }
                    break;
                }
            case ParamPassingMode::BorrowIn:
                {
                    if (diffWitness)
                    {
                        auto pairType = getEffectiveDiffPairType(paramInfo.type, diffWitness);
                        newParamTypes.add(astBuilder->getConstRefParamType(pairType));
                    }
                    else
                    {
                        newParamTypes.add(astBuilder->getConstRefParamType(
                            _getNoDiffType(astBuilder, paramInfo.type)));
                    }
                    break;
                }
            case ParamPassingMode::RefReadWrite:
            case ParamPassingMode::RefReadOnly:
            case ParamPassingMode::RefWriteOnly:
                {
                    // Ref parameters not allowed in backward diff.
                    SLANG_UNEXPECTED("ref parameter not allowed in backward diff function");
                    break;
                }
            default:
                break;
            }
        }

        // Last parameter is the initial derivative of the original return type (dOut).
        if (auto resultDiffWitness = diffTypeWitness->getReturnTypeDiffWitness())
        {
            auto dOutType = getDifferentialValueTypeFromWitness(
                astBuilder,
                funcType->getResultType(),
                resultDiffWitness);
            if (dOutType)
                newParamTypes.add(dOutType);
        }

        return astBuilder->getFuncType(newParamTypes.getArrayView(), resultType, errorType);
    }
    else
    {
        Val* args[] = {as<Type>(resolvedBase), as<Witness>(resolvedWitness)};
        return astBuilder->getSpecializedBuiltinType(makeArrayView(args), "BwdDiffFuncType");
    }
}

Val* FwdDiffFuncType::_resolveImplOverride()
{
    // Resolve all operands.
    auto resolvedBase = _getGenericTypeArg(this, 0)->resolve();
    auto resolvedWitness = _getGenericTypeArg(this, 1)->resolve();

    if (auto diffTypeWitness = as<DiffTypeInfoWitness>(resolvedWitness))
    {
        // If we have a concrete witness, we should be able to turn this into a concrete func-type.
        List<Type*> newParamTypes;

        auto astBuilder = getCurrentASTBuilder();
        auto baseFuncDeclRef = getCallableDeclRefFromFuncTypeBase(resolvedBase);
        auto funcType = getFuncType(astBuilder, baseFuncDeclRef);

        auto thisParamType = diffTypeWitness->getThisParamType();
        if (thisParamType)
        {
            auto [thisParamValueType, thisParamDirection] =
                getParamInfoFromTypeWithModeWrapper(thisParamType);
            auto differentiatedThisMode = getDifferentiatedThisParamMode(thisParamDirection);
            if (auto thisTypeDiffWitness = diffTypeWitness->getThisTypeDiffWitness())
            {
                auto thisPairType =
                    getEffectiveDiffPairType(thisParamValueType, thisTypeDiffWitness);
                SLANG_RELEASE_ASSERT(differentiatedThisMode != ParamPassingMode::Out);
                newParamTypes.add(
                    getParamTypeWithModeWrapper(astBuilder, thisPairType, differentiatedThisMode));
            }
            else
            {
                // Non-differentiable this type
                auto noDiffThisType = _getNoDiffType(astBuilder, thisParamValueType);
                SLANG_RELEASE_ASSERT(differentiatedThisMode != ParamPassingMode::Out);
                newParamTypes.add(getParamTypeWithModeWrapper(
                    astBuilder,
                    noDiffThisType,
                    differentiatedThisMode));
            }
        }

        for (Index i = 0; i < funcType->getParamCount(); ++i)
        {
            auto paramInfo = funcType->getParamInfo(i);
            auto diffWitness = diffTypeWitness->getParamTypeDiffWitness(i);

            switch (paramInfo.mode)
            {
            case ParamPassingMode::In:
                {
                    if (diffWitness)
                    {
                        auto pairType = getEffectiveDiffPairType(paramInfo.type, diffWitness);
                        newParamTypes.add(pairType);
                    }
                    else
                    {
                        newParamTypes.add(_getNoDiffType(astBuilder, paramInfo.type));
                    }
                    break;
                }
            case ParamPassingMode::Out:
                {
                    if (diffWitness)
                    {
                        auto pairType = getEffectiveDiffPairType(paramInfo.type, diffWitness);
                        newParamTypes.add(getCurrentASTBuilder()->getOutParamType(pairType));
                    }
                    else
                    {
                        newParamTypes.add(getCurrentASTBuilder()->getOutParamType(
                            _getNoDiffType(astBuilder, paramInfo.type)));
                    }
                    break;
                }
            case ParamPassingMode::BorrowInOut:
                {
                    if (diffWitness)
                    {
                        auto pairType = getEffectiveDiffPairType(paramInfo.type, diffWitness);
                        newParamTypes.add(
                            getCurrentASTBuilder()->getBorrowInOutParamType(pairType));
                    }
                    else
                    {
                        newParamTypes.add(getCurrentASTBuilder()->getBorrowInOutParamType(
                            _getNoDiffType(astBuilder, paramInfo.type)));
                    }
                    break;
                }
            case ParamPassingMode::RefReadWrite:
            case ParamPassingMode::RefReadOnly:
            case ParamPassingMode::RefWriteOnly:
                {
                    // do not differentiate ref params
                    newParamTypes.add(getParamTypeWithModeWrapper(
                        getCurrentASTBuilder(),
                        paramInfo.type,
                        paramInfo.mode));
                    break;
                }
            case ParamPassingMode::BorrowIn:
                {
                    if (diffWitness)
                    {
                        auto pairType = getEffectiveDiffPairType(paramInfo.type, diffWitness);
                        newParamTypes.add(getCurrentASTBuilder()->getConstRefParamType(pairType));
                    }
                    else
                    {
                        newParamTypes.add(getCurrentASTBuilder()->getConstRefParamType(
                            _getNoDiffType(astBuilder, paramInfo.type)));
                    }
                    break;
                }
            default:
                SLANG_UNEXPECTED("Unhandled param passing mode");
                break;
            }
        }

        Type* newReturnType = funcType->getResultType();
        if (auto resultDiffWitness = diffTypeWitness->getReturnTypeDiffWitness())
        {
            newReturnType = getEffectiveDiffPairType(funcType->getResultType(), resultDiffWitness);
        }
        else if (!funcType->getResultType()->equals(getCurrentASTBuilder()->getVoidType()))
        {
            newReturnType = _getNoDiffType(astBuilder, funcType->getResultType());
        }

        return getCurrentASTBuilder()->getFuncType(
            newParamTypes.getArrayView(),
            newReturnType,
            funcType->getErrorType());
    }
    else
    {
        Val* args[] = {as<Type>(resolvedBase), as<Witness>(resolvedWitness)};
        return getCurrentASTBuilder()->getSpecializedBuiltinType(
            makeArrayView(args),
            "FwdDiffFuncType");
    }
}


// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! TupleType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Type* TupleType::getMember(Index i) const
{
    if (auto typePack = as<ConcreteTypePack>(_getGenericTypeArg(getDeclRefBase(), 0)))
        return typePack->getElementType(i);
    return nullptr;
}

Index TupleType::getMemberCount() const
{
    if (auto typePack = as<ConcreteTypePack>(_getGenericTypeArg(getDeclRefBase(), 0)))
        return typePack->getTypeCount();
    return 0;
}

Type* TupleType::getTypePack() const
{
    return as<Type>(_getGenericTypeArg(getDeclRefBase(), 0));
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ArrayExpressionType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Type* ArrayExpressionType::getElementType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

IntVal* ArrayExpressionType::getElementCount()
{
    return as<IntVal>(_getGenericTypeArg(this, 1));
}

void ArrayExpressionType::_toTextOverride(StringBuilder& out)
{
    out << getElementType();
    out.appendChar('[');
    if (!isUnsized())
    {
        out << getElementCount();
    }
    out.appendChar(']');
}

bool ArrayExpressionType::isUnsized()
{
    if (auto constSize = as<ConstantIntVal>(getElementCount()))
    {
        if (constSize->getValue() == kUnsizedArrayMagicLength)
            return true;
    }
    return false;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ConditionalType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Type* ConditionalType::getValueType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

IntVal* ConditionalType::getHasValue()
{
    return as<IntVal>(_getGenericTypeArg(this, 1));
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! AtomicType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Type* AtomicType::getElementType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! CoopVectorExpressionType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Type* CoopVectorExpressionType::getElementType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

IntVal* CoopVectorExpressionType::getElementCount()
{
    return as<IntVal>(_getGenericTypeArg(this, 1));
}

void CoopVectorExpressionType::_toTextOverride(StringBuilder& out)
{
    out << toSlice("CoopVector<") << getElementType() << toSlice(",") << getElementCount()
        << toSlice(">");
}

BasicExpressionType* CoopVectorExpressionType::_getScalarTypeOverride()
{
    return as<BasicExpressionType>(getElementType());
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! TypeType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void TypeType::_toTextOverride(StringBuilder& out)
{
    out << toSlice("typeof(") << getType() << toSlice(")");
}

Type* TypeType::_createCanonicalTypeOverride()
{
    return getCurrentASTBuilder()->getTypeType(getType()->getCanonicalType());
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! GenericDeclRefType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void GenericDeclRefType::_toTextOverride(StringBuilder& out)
{
    out << getDeclRef();
}

Type* GenericDeclRefType::_createCanonicalTypeOverride()
{
    return this;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! NamespaceType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void NamespaceType::_toTextOverride(StringBuilder& out)
{
    out << toSlice("namespace ") << getDeclRef();
}

Type* NamespaceType::_createCanonicalTypeOverride()
{
    return this;
}

Type* DifferentialPairType::getPrimalType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}


// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! PtrTypeBase !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Type* PtrTypeBase::getValueType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

Type* OptionalType::getValueType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

Type* NativeRefType::getValueType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}


Val* PtrTypeBase::getAccessQualifier()
{
    return _getGenericTypeArg(this, 1);
}

Val* PtrTypeBase::getAddressSpace()
{
    return _getGenericTypeArg(this, 2);
}

Type* PtrTypeBase::getDataLayout()
{
    return as<Type>(_getGenericTypeArg(this, 3));
}

std::optional<AccessQualifier> tryGetAccessQualifierValue(Val* val)
{
    if (auto cintVal = as<ConstantIntVal>(val))
    {
        return AccessQualifier(cintVal->getValue());
    }
    return std::optional<AccessQualifier>();
}

std::optional<AccessQualifier> PtrTypeBase::tryGetAccessQualifierValue()
{
    auto accessQualifierArg = this->getAccessQualifier();
    return Slang::tryGetAccessQualifierValue(accessQualifierArg);
}

AddressSpace tryGetAddressSpaceValue(Val* addrSpaceVal)
{
    AddressSpace addrSpace = AddressSpace::Generic;

    if (auto cintVal = as<ConstantIntVal>(addrSpaceVal))
    {
        addrSpace = (AddressSpace)(cintVal->getValue());
    }
    return addrSpace;
}

void maybePrintAddrSpaceOperand(StringBuilder& out, AddressSpace addrSpace)
{
    switch (addrSpace)
    {
    case AddressSpace::Generic:
        out << toSlice(", AddressSpace.Generic");
        break;
    case AddressSpace::UserPointer:
        // We expose UserPointer as Device to users
        out << toSlice(", AddressSpace.Device");
        break;
    case AddressSpace::GroupShared:
        out << toSlice(", AddressSpace.GroupShared");
        break;
    case AddressSpace::Global:
        out << toSlice(", AddressSpace.Global");
        break;
    case AddressSpace::ThreadLocal:
        out << toSlice(", AddressSpace.ThreadLocal");
        break;
    case AddressSpace::Uniform:
        out << toSlice(", AddressSpace.Uniform");
        break;
    default:
        break;
    }
}

void maybePrintAccessQualifierOperand(StringBuilder& out, AccessQualifier accessQualifier)
{
    switch (accessQualifier)
    {
    case AccessQualifier::ReadWrite:
        out << toSlice(", Access.ReadWrite");
        break;
    case AccessQualifier::Read:
        out << toSlice(", Access.Read");
        break;
    case AccessQualifier::Immutable:
        out << toSlice(", Access.Immutable");
        break;
    default:
        break;
    }
}

void maybePrintDataLayoutOperand(StringBuilder& out, Type* dataLayout)
{
    const char* name = "DefaultDataLayout";
    if (as<Std140DataLayoutType>(dataLayout))
        name = "Std140DataLayout";
    else if (as<Std430DataLayoutType>(dataLayout))
        name = "Std430DataLayout";
    else if (as<ScalarDataLayoutType>(dataLayout))
        name = "ScalarDataLayout";
    else if (as<CDataLayoutType>(dataLayout))
        name = "CDataLayout";

    out << toSlice(", ") << name;
}

void PtrType::_toTextOverride(StringBuilder& out)
{
    auto addrSpace = tryGetAddressSpaceValue(getAddressSpace());
    out << toSlice("Ptr<") << getValueType();
    if (auto optionalAccessQualifier = tryGetAccessQualifierValue())
        maybePrintAccessQualifierOperand(out, *optionalAccessQualifier);
    maybePrintAddrSpaceOperand(out, addrSpace);
    maybePrintDataLayoutOperand(out, getDataLayout());
    out << toSlice(">");
}

void ExplicitRefType::_toTextOverride(StringBuilder& out)
{
    auto addrSpace = tryGetAddressSpaceValue(getAddressSpace());
    out << toSlice("Ref<") << getValueType();
    if (auto optionalAccessQualifier = tryGetAccessQualifierValue())
        maybePrintAccessQualifierOperand(out, *optionalAccessQualifier);
    maybePrintAddrSpaceOperand(out, addrSpace);
    maybePrintDataLayoutOperand(out, getDataLayout());
    out << toSlice(">");
}

void OutParamType::_toTextOverride(StringBuilder& out)
{
    printParamPassingModePrefix(out, ParamPassingMode::Out);
    out << getValueType();
}

void BorrowInOutParamType::_toTextOverride(StringBuilder& out)
{
    printParamPassingModePrefix(out, ParamPassingMode::BorrowInOut);
    out << getValueType();
}

void RefParamType::_toTextOverride(StringBuilder& out)
{
    printParamPassingModePrefix(out, ParamPassingMode::RefReadWrite);
    out << getValueType();
}

void RefReadOnlyParamType::_toTextOverride(StringBuilder& out)
{
    printParamPassingModePrefix(out, ParamPassingMode::RefReadOnly);
    out << getValueType();
}

void RefWriteOnlyParamType::_toTextOverride(StringBuilder& out)
{
    printParamPassingModePrefix(out, ParamPassingMode::RefWriteOnly);
    out << getValueType();
}

void BorrowInParamType::_toTextOverride(StringBuilder& out)
{
    printParamPassingModePrefix(out, ParamPassingMode::BorrowIn);
    out << getValueType();
}


// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! NamedExpressionType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void NamedExpressionType::_toTextOverride(StringBuilder& out)
{
    if (getDeclRef().getDecl())
    {
        getDeclRef().declRefBase->toText(out);
    }
}

Type* NamedExpressionType::_createCanonicalTypeOverride()
{
    auto canType = getType(getCurrentASTBuilder(), getDeclRef());
    if (canType)
        return canType->getCanonicalType();
    return getCurrentASTBuilder()->getErrorType();
}

ParamPassingMode adjustParamPassingModeBasedOnParamType(
    ParamPassingMode originalMode,
    Type* paramType)
{
    // Type modifiers such as `no_diff` do not change whether passing the underlying value requires
    // a copy. Inspect the value type rather than letting its semantic annotations hide that fact.
    while (auto modifiedType = as<ModifiedType>(paramType))
        paramType = modifiedType->getBase();

    // A mesh-shader output's direction is intrinsic to its `MeshOutputType` (carried by
    // IRMeshOutputDecoration), so the `out` on the `out vertices T[N]` spelling must not
    // also wrap it in `IROutParamType`: that would diverge from the generic
    // `OutputVertices<T,N>` spelling and make the HLSL emitter print a doubled `out`.
    if (as<MeshOutputType>(paramType))
        originalMode = ParamPassingMode::In;

    // If the type is copyable, then the original mode is appropriate to use.
    if (isCopyableType(paramType))
        return originalMode;

    // A non-copyable value cannot use the copy-in implied by `in`, so borrow it instead.
    if (originalMode == ParamPassingMode::In)
        return ParamPassingMode::BorrowIn;

    return originalMode;
}

ParamPassingMode getDifferentiatedThisParamMode(ParamPassingMode effectiveMode)
{
    // Derivative signatures currently process an immutable borrow using the ordinary `In` rule and
    // a non-exclusive mutable reference using the `BorrowInOut` rule. That collapse may be a
    // mistake: ordinary parameters retain both distinctions. Keep it isolated as an explicit
    // compatibility projection so that each derivative use-case starts from the declaration's
    // complete mode and a future ABI change has a single, visible point of control.
    switch (effectiveMode)
    {
    case ParamPassingMode::BorrowIn:
        return ParamPassingMode::In;
    case ParamPassingMode::RefReadWrite:
        return ParamPassingMode::BorrowInOut;
    default:
        return effectiveMode;
    }
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! FuncType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

ParamPassingMode getParamPassingModeFromPossiblyWrappedParamType(Type* paramType)
{
    if (as<RefParamType>(paramType))
    {
        return ParamPassingMode::RefReadWrite;
    }
    else if (as<RefReadOnlyParamType>(paramType))
    {
        return ParamPassingMode::RefReadOnly;
    }
    else if (as<RefWriteOnlyParamType>(paramType))
    {
        return ParamPassingMode::RefWriteOnly;
    }
    else if (as<BorrowInParamType>(paramType))
    {
        return ParamPassingMode::BorrowIn;
    }
    else if (as<BorrowInOutParamType>(paramType))
    {
        return ParamPassingMode::BorrowInOut;
    }
    else if (as<OutType>(paramType))
    {
        return ParamPassingMode::Out;
    }
    else
    {
        return ParamPassingMode::In;
    }
}

ParamInfo getParamInfoFromTypeWithModeWrapper(Type* paramTypeWithModeWrapper)
{
    SLANG_RELEASE_ASSERT(paramTypeWithModeWrapper);

    ParamInfo result;
    result.mode = getParamPassingModeFromPossiblyWrappedParamType(paramTypeWithModeWrapper);
    if (auto wrappedParamType = as<ParamPassingModeType>(paramTypeWithModeWrapper))
        result.type = wrappedParamType->getValueType();
    else
        result.type = paramTypeWithModeWrapper;

    // A parameter's mode has exactly one representation in `ParamInfo`: the separate `mode`
    // field. Reject nested wrappers here so that decoding cannot silently preserve a second mode
    // inside the value type.
    SLANG_RELEASE_ASSERT(!as<ParamPassingModeType>(result.type));
    return result;
}

ParamInfo FuncType::getParamInfo(Index index)
{
    return getParamInfoFromTypeWithModeWrapper(getParamTypeWithModeWrapper(index));
}

ParamPassingMode FuncType::getParamPassingMode(Index index)
{
    return getParamInfo(index).mode;
}

Type* FuncType::getParamValueType(Index index)
{
    return getParamInfo(index).type;
}


void FuncType::_toTextOverride(StringBuilder& out)
{
    Index paramCount = getParamCount();
    out << toSlice("(");
    for (Index pp = 0; pp < paramCount; ++pp)
    {
        if (pp != 0)
        {
            out << toSlice(", ");
        }
        out << getParamTypeWithModeWrapper(pp);
    }
    out << ") -> " << getResultType();

    if (!getErrorType()->equals(getCurrentASTBuilder()->getBottomType()))
    {
        out << " throws " << getErrorType();
    }
}

Val* FuncType::_substituteImplOverride(ASTBuilder* astBuilder, SubstitutionSet subst, int* ioDiff)
{
    int diff = 0;

    // result type
    Type* substResultType = as<Type>(getResultType()->substituteImpl(astBuilder, subst, &diff));

    // error type
    Type* substErrorType = as<Type>(getErrorType()->substituteImpl(astBuilder, subst, &diff));

    // parameter types
    List<Type*> substParamTypes;
    for (Index pp = 0; pp < getParamCount(); pp++)
    {
        auto substParamType =
            as<Type>(getParamTypeWithModeWrapper(pp)->substituteImpl(astBuilder, subst, &diff));
        if (auto typePack = as<ConcreteTypePack>(substParamType))
        {
            // Unwrap the ConcreteTypePack and add each element as a parameter
            for (Index i = 0; i < typePack->getTypeCount(); ++i)
            {
                substParamTypes.add(typePack->getElementType(i));
            }
        }
        else
        {
            substParamTypes.add(substParamType);
        }
    }

    // early exit for no change...
    if (!diff)
        return this;

    (*ioDiff)++;
    FuncType* substType =
        astBuilder->getFuncType(substParamTypes.getArrayView(), substResultType, substErrorType);
    return substType;
}

Type* FuncType::_createCanonicalTypeOverride()
{
    // result type
    Type* canResultType = getResultType()->getCanonicalType();
    Type* canErrorType = getErrorType()->getCanonicalType();

    // parameter types
    List<Type*> canParamTypes;
    for (Index pp = 0; pp < getParamCount(); pp++)
    {
        canParamTypes.add(getParamTypeWithModeWrapper(pp)->getCanonicalType());
    }

    FuncType* canType = getCurrentASTBuilder()->getFuncType(
        canParamTypes.getArrayView(),
        canResultType,
        canErrorType);
    return canType;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! EachType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void EachType::_toTextOverride(StringBuilder& out)
{
    out << "each ";
    if (getElementType())
    {
        getElementType()->toText(out);
    }
    else
    {
        out << "<null>";
    }
}

Type* EachType::_createCanonicalTypeOverride()
{
    return this;
}

Val* EachType::_substituteImplOverride(ASTBuilder* astBuilder, SubstitutionSet subst, int* ioDiff)
{
    int diff = 0;
    auto substElementType = as<Type>(getElementType()->substituteImpl(astBuilder, subst, &diff));
    if (!diff)
        return this;
    if (auto typePack = as<ConcreteTypePack>(substElementType))
    {
        if (subst.packExpansionIndex >= 0 && subst.packExpansionIndex < typePack->getTypeCount())
        {
            (*ioDiff)++;
            return typePack->getElementType(subst.packExpansionIndex);
        }
    }
    else if (auto expandType = as<ExpandType>(substElementType))
    {
        if (auto innerEach = as<EachType>(expandType->getPatternType()))
        {
            (*ioDiff)++;
            return innerEach;
        }
    }
    (*ioDiff)++;
    return astBuilder->getEachType(substElementType);
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ExpandType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void ExpandType::_toTextOverride(StringBuilder& out)
{
    out << "expand ";
    getPatternType()->toText(out);
}

Type* ExpandType::_createCanonicalTypeOverride()
{
    auto canonicalPatternType = getPatternType()->getCanonicalType();
    if (canonicalPatternType == getPatternType())
        return this;
    ShortList<Val*> capturedPacks;
    for (Index i = 0; i < getCapturedPackCount(); i++)
    {
        capturedPacks.add(getCapturedPack(i));
    }
    return getCurrentASTBuilder()->getExpandType(
        canonicalPatternType,
        capturedPacks.getArrayView().arrayView);
}

Val* ExpandType::_substituteImplOverride(ASTBuilder* astBuilder, SubstitutionSet subst, int* ioDiff)
{
    int diff = 0;

    // Given ExpandType(PatternType, CapturedPacks), we first need to know
    // if all captured pack params can be substituted into concrete packs.
    // We can't expand the ExpandType if any captured pack is still abstract.
    //
    ShortList<Val*> capturedPacks;
    Index concretePackCount = 0;
    Index firstConcretePackSize = -1;
    for (Index i = 0; i < getCapturedPackCount(); i++)
    {
        auto substCapturedPack = getCapturedPack(i)->substituteImpl(astBuilder, subst, &diff);

        if (auto expandType = as<ExpandType>(substCapturedPack))
        {
            for (Index j = 0; j < expandType->getCapturedPackCount(); j++)
                capturedPacks.add(expandType->getCapturedPack(j));
        }
        else
        {
            capturedPacks.add(substCapturedPack);
            if (auto typePack = as<ConcreteTypePack>(substCapturedPack))
            {
                concretePackCount++;
                if (firstConcretePackSize < 0)
                    firstConcretePackSize = typePack->getTypeCount();
            }
            else if (auto valPack = as<ConcreteIntValPack>(substCapturedPack))
            {
                concretePackCount++;
                if (firstConcretePackSize < 0)
                    firstConcretePackSize = valPack->getCount();
            }
        }
    }

    if (!diff || concretePackCount != capturedPacks.getCount())
    {
        auto substPatternType = getPatternType()->substituteImpl(astBuilder, subst, &diff);
        if (!diff)
            return this;

        (*ioDiff)++;
        return astBuilder->getExpandType(
            as<Type>(substPatternType),
            capturedPacks.getArrayView().arrayView);
    }
    else
    {
        // All captured packs are now concrete, so we can expand the pattern
        // for each element index.
        ShortList<Type*> expandedTypes;
        SLANG_ASSERT(capturedPacks.getCount() != 0);
        SLANG_ASSERT(firstConcretePackSize >= 0);

        for (int i = 0; i < (int)firstConcretePackSize; i++)
        {
            subst.packExpansionIndex = i;
            auto substElementType = getPatternType()->substituteImpl(astBuilder, subst, &diff);
            expandedTypes.add(as<Type>(substElementType));
        }
        if (!diff)
            return this;
        (*ioDiff)++;
        return astBuilder->getTypePack(expandedTypes.getArrayView().arrayView);
    }
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! PackBranchType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void PackBranchType::_toTextOverride(StringBuilder& out)
{
    out << "__packBranch(";
    getPackOperand()->toText(out);
    out << ", ";
    getEmptyType()->toText(out);
    out << ", ";
    getNonEmptyType()->toText(out);
    out << ")";
}

Type* PackBranchType::_createCanonicalTypeOverride()
{
    // `__packBranch` stores its pack operand as a `Val*`, not always a `Type*`.
    // When the operand is a type pack we do want type canonicalization here, but
    // term-valued symbolic packs must continue to be treated as plain `Val`s.
    // Do not blindly call `getCanonicalType()` on the operand unless this path is
    // updated to use a helper like `_getCanonicalValue()`.
    auto canonicalPack = getPackOperand()->resolve();
    auto canonicalEmptyType = getEmptyType()->getCanonicalType();
    auto canonicalNonEmptyType = getNonEmptyType()->getCanonicalType();
    if (canonicalPack == getPackOperand() && canonicalEmptyType == getEmptyType() &&
        canonicalNonEmptyType == getNonEmptyType())
        return this;
    return getCurrentASTBuilder()->getPackBranchType(
        canonicalPack,
        canonicalEmptyType,
        canonicalNonEmptyType);
}

Val* PackBranchType::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    int diff = 0;
    auto substPackOperand = getPackOperand()->substituteImpl(astBuilder, subst, &diff);
    auto substEmptyType = as<Type>(getEmptyType()->substituteImpl(astBuilder, subst, &diff));
    auto substNonEmptyType = as<Type>(getNonEmptyType()->substituteImpl(astBuilder, subst, &diff));
    if (!diff)
        return this;
    (*ioDiff)++;
    return astBuilder->getPackBranchType(substPackOperand, substEmptyType, substNonEmptyType);
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! FirstType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void FirstPackElementType::_toTextOverride(StringBuilder& out)
{
    out << "__first(";
    getBasePack()->toText(out);
    out << ")";
}

Type* FirstPackElementType::_createCanonicalTypeOverride()
{
    auto canonicalBasePack = getBasePack()->getCanonicalType();
    if (canonicalBasePack == getBasePack())
        return this;
    return getCurrentASTBuilder()->getFirstElement(canonicalBasePack);
}

Val* FirstPackElementType::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    int diff = 0;
    auto substBasePack = as<Type>(getBasePack()->substituteImpl(astBuilder, subst, &diff));
    if (!diff)
        return this;
    (*ioDiff)++;
    return astBuilder->getFirstElement(substBasePack);
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! LastType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void LastPackElementType::_toTextOverride(StringBuilder& out)
{
    out << "__last(";
    getBasePack()->toText(out);
    out << ")";
}

Type* LastPackElementType::_createCanonicalTypeOverride()
{
    auto canonicalBasePack = getBasePack()->getCanonicalType();
    if (canonicalBasePack == getBasePack())
        return this;
    return getCurrentASTBuilder()->getLastElement(canonicalBasePack);
}

Val* LastPackElementType::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    int diff = 0;
    auto substBasePack = as<Type>(getBasePack()->substituteImpl(astBuilder, subst, &diff));
    if (!diff)
        return this;
    (*ioDiff)++;
    return astBuilder->getLastElement(substBasePack);
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! TrimFirstTypePack !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void TrimFirstTypePack::_toTextOverride(StringBuilder& out)
{
    out << "__trimFirst(";
    getBasePack()->toText(out);
    out << ")";
}

Type* TrimFirstTypePack::_createCanonicalTypeOverride()
{
    auto canonicalBasePack = getBasePack()->getCanonicalType();
    if (canonicalBasePack == getBasePack())
        return this;
    return getCurrentASTBuilder()->getTrimFirstPack(canonicalBasePack);
}

Val* TrimFirstTypePack::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    int diff = 0;
    auto substBasePack = as<Type>(getBasePack()->substituteImpl(astBuilder, subst, &diff));
    if (!diff)
        return this;
    (*ioDiff)++;
    return astBuilder->getTrimFirstPack(substBasePack);
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! TrimLastTypePack !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void TrimLastTypePack::_toTextOverride(StringBuilder& out)
{
    out << "__trimLast(";
    getBasePack()->toText(out);
    out << ")";
}

Type* TrimLastTypePack::_createCanonicalTypeOverride()
{
    auto canonicalBasePack = getBasePack()->getCanonicalType();
    if (canonicalBasePack == getBasePack())
        return this;
    return getCurrentASTBuilder()->getTrimLastPack(canonicalBasePack);
}

Val* TrimLastTypePack::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    int diff = 0;
    auto substBasePack = as<Type>(getBasePack()->substituteImpl(astBuilder, subst, &diff));
    if (!diff)
        return this;
    (*ioDiff)++;
    return astBuilder->getTrimLastPack(substBasePack);
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ConcreteTypePack !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void ConcreteTypePack::_toTextOverride(StringBuilder& out)
{
    for (Index i = 0; i < getTypeCount(); i++)
    {
        if (i != 0)
            out << ", ";
        getElementType(i)->toText(out);
    }
}

Type* ConcreteTypePack::_createCanonicalTypeOverride()
{
    ShortList<Type*> canonicalElementTypes;
    for (Index i = 0; i < getTypeCount(); i++)
    {
        canonicalElementTypes.add(getElementType(i)->getCanonicalType());
    }
    return getCurrentASTBuilder()->getTypePack(canonicalElementTypes.getArrayView().arrayView);
}

Val* ConcreteTypePack::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    int diff = 0;
    ShortList<Type*> substElementTypes;
    for (Index i = 0; i < getTypeCount(); i++)
    {
        auto substType = as<Type>(getElementType(i)->substituteImpl(astBuilder, subst, &diff));
        if (auto typePack = as<ConcreteTypePack>(substType))
        {
            // Unwrap the ConcreteTypePack and add each element as a parameter
            for (Index j = 0; j < typePack->getTypeCount(); ++j)
            {
                substElementTypes.add(typePack->getElementType(j));
            }
        }
        else
        {
            substElementTypes.add(substType);
        }
    }
    if (!diff)
        return this;
    (*ioDiff)++;
    return getCurrentASTBuilder()->getTypePack(substElementTypes.getArrayView().arrayView);
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ValuePackType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void ValuePackType::_toTextOverride(StringBuilder& out)
{
    out << "ValuePack<";
    getElementType()->toText(out);
    out << ">";
}

Type* ValuePackType::_createCanonicalTypeOverride()
{
    return getCurrentASTBuilder()->getOrCreate<ValuePackType>(getElementType()->getCanonicalType());
}

Val* ValuePackType::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    int diff = 0;
    auto newElementType = as<Type>(getElementType()->substituteImpl(astBuilder, subst, &diff));
    if (!diff)
        return this;
    (*ioDiff)++;
    return astBuilder->getOrCreate<ValuePackType>(newElementType);
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ExtractExistentialType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void ExtractExistentialType::_toTextOverride(StringBuilder& out)
{
    out << getDeclRef() << toSlice(".This");
}

Type* ExtractExistentialType::_createCanonicalTypeOverride()
{
    return this;
}

Val* ExtractExistentialType::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    int diff = 0;
    auto substDeclRef = getDeclRef().substituteImpl(astBuilder, subst, &diff);
    auto substOriginalInterfaceType =
        getOriginalInterfaceType()->substituteImpl(astBuilder, subst, &diff);
    auto substOriginalInterfaceDeclRef =
        getOriginalInterfaceDeclRef().substituteImpl(astBuilder, subst, &diff);
    if (!diff)
        return this;

    (*ioDiff)++;

    ExtractExistentialType* substValue = astBuilder->getOrCreate<ExtractExistentialType>(
        substDeclRef,
        as<Type>(substOriginalInterfaceType),
        substOriginalInterfaceDeclRef);
    return substValue;
}

SubtypeWitness* ExtractExistentialType::getSubtypeWitness()
{
    if (auto cachedValue = this->cachedSubtypeWitness)
        return cachedValue;

    ExtractExistentialSubtypeWitness* openedWitness =
        getCurrentASTBuilder()->getOrCreate<ExtractExistentialSubtypeWitness>(
            this,
            getOriginalInterfaceType(),
            getDeclRef());
    this->cachedSubtypeWitness = openedWitness;
    return openedWitness;
}

DeclRef<ThisTypeDecl> ExtractExistentialType::getThisTypeDeclRef()
{
    if (auto cachedValue = this->cachedThisTypeDeclRef)
        return cachedValue;

    auto interfaceDecl = getOriginalInterfaceDeclRef().getDecl();

    SubtypeWitness* openedWitness = getSubtypeWitness();

    ThisTypeDecl* thisTypeDecl = interfaceDecl->getThisTypeDecl();
    SLANG_ASSERT(thisTypeDecl);

    DeclRef<ThisTypeDecl> specialiedInterfaceDeclRef =
        getCurrentASTBuilder()->getLookupDeclRef(openedWitness, thisTypeDecl).as<ThisTypeDecl>();

    this->cachedThisTypeDeclRef = specialiedInterfaceDeclRef;
    return specialiedInterfaceDeclRef;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ExistentialSpecializedType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void ExistentialSpecializedType::_toTextOverride(StringBuilder& out)
{
    out << toSlice("__ExistentialSpecializedType(") << getBaseType();
    for (Index i = 0; i < getArgCount(); i++)
    {
        out << toSlice(", ") << getArg(i).val;
    }
    out << toSlice(")");
}

static Val* _getCanonicalValue(Val* val)
{
    if (!val)
        return nullptr;
    if (auto type = as<Type>(val))
    {
        return type->getCanonicalType();
    }
    // TODO: We may eventually need/want some sort of canonicalization
    // for non-type values, but for now there is nothing to do.
    return val;
}

Type* ExistentialSpecializedType::_createCanonicalTypeOverride()
{
    ExpandedSpecializationArgs newArgs;

    for (Index ii = 0; ii < getArgCount(); ++ii)
    {
        auto arg = getArg(ii);
        ExpandedSpecializationArg canArg;
        canArg.val = _getCanonicalValue(arg.val);
        canArg.witness = _getCanonicalValue(arg.witness);
        newArgs.add(canArg);
    }

    ExistentialSpecializedType* canType =
        getCurrentASTBuilder()->getOrCreate<ExistentialSpecializedType>(
            getBaseType()->getCanonicalType(),
            newArgs);

    return canType;
}

static Val* _substituteImpl(ASTBuilder* astBuilder, Val* val, SubstitutionSet subst, int* ioDiff)
{
    if (!val)
        return nullptr;
    return val->substituteImpl(astBuilder, subst, ioDiff);
}

Val* ExistentialSpecializedType::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    int diff = 0;

    auto substBaseType = as<Type>(getBaseType()->substituteImpl(astBuilder, subst, &diff));

    ExpandedSpecializationArgs substArgs;
    for (Index ii = 0; ii < getArgCount(); ++ii)
    {
        auto arg = getArg(ii);
        ExpandedSpecializationArg substArg;
        substArg.val = _substituteImpl(astBuilder, arg.val, subst, &diff);
        substArg.witness = _substituteImpl(astBuilder, arg.witness, subst, &diff);
        substArgs.add(substArg);
    }

    if (!diff)
        return this;

    (*ioDiff)++;

    ExistentialSpecializedType* substType =
        astBuilder->getOrCreate<ExistentialSpecializedType>(substBaseType, substArgs);
    return substType;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ThisType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

DeclRef<InterfaceDecl> ThisType::getInterfaceDeclRef()
{
    return DeclRef<Decl>(getDeclRefBase()->getParent()).template as<InterfaceDecl>();
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! AndType !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void AndType::_toTextOverride(StringBuilder& out)
{
    out << getLeft() << toSlice(" & ") << getRight();
}

Type* AndType::_createCanonicalTypeOverride()
{
    // TODO: proper canonicalization of an `&` type relies on
    // several different things:
    //
    // * We need to re-associate types that might involve
    //   nesting of `&`, such as `(A & B) & (C & D)`, into
    //   a canonical form where the nesting is consistent
    //   (i.e., always left- or right-associative).
    //
    // * We need to commute types so that they are in a
    //   consistent order, so that `A & B` and `B & A` both
    //   result in the same canonicalization. This requirement
    //   implies that we must invent a total order on types.
    //
    // * We need to canonicalize `&` types where one of the
    //   elements might be implied by another. E.g., if we
    //   have `interface IDerived : IBase`, then a type like
    //   `IDerived & IBase` is equivalent to just `IDerived`
    //   because the presence of an `IBase` conformance is
    //   implied. A special case of the above is the possibility
    //   of duplicates in the list of types (e.g., `A & B & A`).
    //
    // * The previous requirement raises the problem that
    //   the relationships between `interface`s might either
    //   evolve over time, or be subject to `extension`
    //   declarations in other modules. The canonicalization
    //   algorithm must be clear about what information it
    //   is allowed to make use of, as this can/will affect
    //   binary interfaces (via mangled names).
    //
    // We are going to completely ignore these issues for
    // right now, in the name of getting something up and running.
    //

    auto canLeft = getLeft()->getCanonicalType();
    auto canRight = getRight()->getCanonicalType();
    auto canType = getCurrentASTBuilder()->getAndType(canLeft, canRight);
    return canType;
}

Val* AndType::_substituteImplOverride(ASTBuilder* astBuilder, SubstitutionSet subst, int* ioDiff)
{
    int diff = 0;

    auto substLeft = as<Type>(getLeft()->substituteImpl(astBuilder, subst, &diff));
    auto substRight = as<Type>(getRight()->substituteImpl(astBuilder, subst, &diff));

    if (!diff)
        return this;

    (*ioDiff)++;

    auto substType = astBuilder->getAndType(substLeft, substRight);
    return substType;
}

// ModifiedType

void ModifiedType::_toTextOverride(StringBuilder& out)
{
    for (Index i = 0; i < getModifierCount(); i++)
    {
        getModifier(i)->toText(out);
        out.appendChar(' ');
    }
    getBase()->toText(out);
}

Type* ModifiedType::_createCanonicalTypeOverride()
{
    List<Val*> modifiers;
    for (Index i = 0; i < getModifierCount(); ++i)
    {
        auto modifier = this->getModifier(i);
        modifiers.add(modifier);
    }
    ModifiedType* canonical = getCurrentASTBuilder()->getOrCreate<ModifiedType>(
        getBase()->getCanonicalType(),
        modifiers.getArrayView());
    return canonical;
}

Val* ModifiedType::_substituteImplOverride(
    ASTBuilder* astBuilder,
    SubstitutionSet subst,
    int* ioDiff)
{
    int diff = 0;
    Type* substBase = as<Type>(getBase()->substituteImpl(astBuilder, subst, &diff));

    List<Val*> substModifiers;
    for (Index i = 0; i < getModifierCount(); ++i)
    {
        auto modifier = this->getModifier(i);
        auto substModifier = modifier->substituteImpl(astBuilder, subst, &diff);
        substModifiers.add(substModifier);
    }

    if (!diff)
        return this;

    *ioDiff = 1;

    ModifiedType* substType =
        getCurrentASTBuilder()->getOrCreate<ModifiedType>(substBase, substModifiers.getArrayView());
    return substType;
}

BaseType BasicExpressionType::getBaseType() const
{
    auto builtinType = getDeclRef().getDecl()->findModifier<BuiltinTypeModifier>();
    return builtinType->tag;
}

FeedbackType::Kind FeedbackType::getKind() const
{
    auto magicMod = getDeclRef().getDecl()->findModifier<MagicTypeModifier>();
    return FeedbackType::Kind(magicMod->tag);
}

SlangResourceShape ResourceType::getBaseShape()
{
    auto shape = _getGenericTypeArg(getDeclRefBase(), 1);
    if (as<TextureShape1DType>(shape))
        return SLANG_TEXTURE_1D;
    else if (as<TextureShape2DType>(shape))
        return SLANG_TEXTURE_2D;
    else if (as<TextureShape3DType>(shape))
        return SLANG_TEXTURE_3D;
    else if (as<TextureShapeCubeType>(shape))
        return SLANG_TEXTURE_CUBE;
    else if (as<TextureShapeBufferType>(shape))
        return SLANG_TEXTURE_BUFFER;

    return SLANG_RESOURCE_NONE;
}

SlangResourceShape ResourceType::getShape()
{
    auto baseShape = (SlangResourceShape)getBaseShape();
    if (isArray())
        baseShape = (SlangResourceShape)((uint32_t)baseShape | SLANG_TEXTURE_ARRAY_FLAG);
    if (isMultisample())
        baseShape = (SlangResourceShape)((uint32_t)baseShape | SLANG_TEXTURE_MULTISAMPLE_FLAG);
    if (isShadow())
        baseShape = (SlangResourceShape)((uint32_t)baseShape | SLANG_TEXTURE_SHADOW_FLAG);
    if (isFeedback())
        baseShape = (SlangResourceShape)((uint32_t)baseShape | SLANG_TEXTURE_FEEDBACK_FLAG);
    if (isCombined())
        baseShape = (SlangResourceShape)((uint32_t)baseShape | SLANG_TEXTURE_COMBINED_FLAG);
    return baseShape;
}

bool ResourceType::isArray()
{
    auto isArray = _getGenericTypeArg(this, kCoreModule_TextureIsArrayParameterIndex);
    if (auto constIntVal = as<ConstantIntVal>(isArray))
        return constIntVal->getValue() != 0;
    return false;
}

bool ResourceType::isMultisample()
{
    auto isMS = _getGenericTypeArg(this, kCoreModule_TextureIsMultisampleParameterIndex);
    if (auto constIntVal = as<ConstantIntVal>(isMS))
        return constIntVal->getValue() != 0;
    return false;
}

bool ResourceType::isShadow()
{
    auto isShadow = _getGenericTypeArg(this, kCoreModule_TextureIsShadowParameterIndex);
    if (auto constIntVal = as<ConstantIntVal>(isShadow))
        return constIntVal->getValue() != 0;
    return false;
}

bool ResourceType::isFeedback()
{
    auto access = _getGenericTypeArg(this, kCoreModule_TextureAccessParameterIndex);
    if (auto constIntVal = as<ConstantIntVal>(access))
        return constIntVal->getValue() == kCoreModule_ResourceAccessFeedback;
    return false;
}

bool ResourceType::isCombined()
{
    auto combined = _getGenericTypeArg(this, kCoreModule_TextureIsCombinedParameterIndex);
    if (auto constIntVal = as<ConstantIntVal>(combined))
        return constIntVal->getValue() != 0;
    return false;
}

Type* SubpassInputType::getElementType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

bool SubpassInputType::isMultisample()
{
    auto isMS = _getGenericTypeArg(this, 1);
    if (auto constIntVal = as<ConstantIntVal>(isMS))
        return constIntVal->getValue() != 0;
    return false;
}

SlangResourceAccess ResourceType::getAccess()
{
    auto access = _getGenericTypeArg(this, kCoreModule_TextureAccessParameterIndex);
    if (auto constIntVal = as<ConstantIntVal>(access))
    {
        switch (constIntVal->getValue())
        {
        case kCoreModule_ResourceAccessReadOnly:
            return SLANG_RESOURCE_ACCESS_READ;
        case kCoreModule_ResourceAccessReadWrite:
            return SLANG_RESOURCE_ACCESS_READ_WRITE;
        case kCoreModule_ResourceAccessWriteOnly:
            return SLANG_RESOURCE_ACCESS_WRITE;
        case kCoreModule_ResourceAccessRasterizerOrdered:
            return SLANG_RESOURCE_ACCESS_RASTER_ORDERED;
        case kCoreModule_ResourceAccessFeedback:
            return SLANG_RESOURCE_ACCESS_FEEDBACK;
        default:
            break;
        }
    }
    return SLANG_RESOURCE_ACCESS_NONE;
}

SamplerStateFlavor SamplerStateType::getFlavor() const
{
    auto magicMod = getDeclRef().getDecl()->findModifier<MagicTypeModifier>();
    return SamplerStateFlavor(magicMod->tag);
}

Type* BuiltinGenericType::getElementType() const
{
    return as<Type>(_getGenericTypeArg(getDeclRefBase(), 0));
}

Type* ResourceType::getElementType()
{
    return as<Type>(_getGenericTypeArg(this, 0));
}

void ResourceType::_toTextOverride(StringBuilder& out)
{
    auto tryPrintSimpleName = [&](String& outString) -> bool
    {
        StringBuilder resultSB;
        auto access = getAccess();
        switch (access)
        {
        case SLANG_RESOURCE_ACCESS_READ:
            break;
        case SLANG_RESOURCE_ACCESS_READ_WRITE:
            resultSB << "RW";
            ;
            break;
        case SLANG_RESOURCE_ACCESS_RASTER_ORDERED:
            resultSB << "RasterizerOrdered";
            break;
        case SLANG_RESOURCE_ACCESS_FEEDBACK:
            resultSB << "Feedback";
            break;
        default:
            return false;
        }
        auto combined = as<ConstantIntVal>(_getGenericTypeArg(this, 7));
        auto shapeVal = _getGenericTypeArg(this, 1);
        if (!as<TextureShapeType>(shapeVal))
            return false;
        auto shape = getBaseShape();
        if (!combined)
            return false;
        if (combined->getValue() != 0)
            resultSB << "Sampler";
        else
        {
            if (shape == SLANG_TEXTURE_BUFFER)
                resultSB << "Buffer";
            else
                resultSB << "Texture";
        }
        switch (shape)
        {
        case SLANG_TEXTURE_1D:
            resultSB << "1D";
            break;
        case SLANG_TEXTURE_2D:
            resultSB << "2D";
            break;
        case SLANG_TEXTURE_3D:
            resultSB << "3D";
            break;
        case SLANG_TEXTURE_CUBE:
            resultSB << "Cube";
            break;
        }
        auto isArrayVal = as<ConstantIntVal>(_getGenericTypeArg(this, 2));
        if (!isArrayVal)
            return false;
        if (isArray())
            resultSB << "Array";
        auto isMultisampleVal = as<ConstantIntVal>(_getGenericTypeArg(this, 3));
        if (!isMultisampleVal)
            return false;
        if (isMultisample())
            resultSB << "MS";
        auto isShadowVal = as<ConstantIntVal>(_getGenericTypeArg(this, 6));
        if (!isShadowVal)
            return false;
        if (isShadow())
            return false;
        auto elementType = getElementType();
        if (elementType)
        {
            resultSB << "<";
            resultSB << elementType->toString();
            auto sampleCount = _getGenericTypeArg(this, 4);
            if (auto constIntVal = as<ConstantIntVal>(sampleCount))
            {
                if (constIntVal->getValue() != 0)
                    resultSB << ", " << constIntVal->getValue();
            }
            else
            {
                return false;
            }
            resultSB << ">";
        }
        outString = resultSB.toString();
        return true;
    };

    String simpleName;

    if (tryPrintSimpleName(simpleName))
        out << simpleName;
    else
        DeclRefType::_toTextOverride(out);
}

Val* TextureTypeBase::getSampleCount()
{
    return as<Type>(_getGenericTypeArg(this, 4));
}

Val* TextureTypeBase::getFormat()
{
    return as<Type>(_getGenericTypeArg(this, 8));
}

bool isCopyableType(Type* type)
{
    return !isNonCopyableType(type);
}

bool isNonCopyableType(Type* type)
{
    auto declRefType = as<DeclRefType>(type);
    if (!declRefType)
        return false;
    if (declRefType->getDeclRef().getDecl()->findModifier<NonCopyableTypeAttribute>())
        return true;
    return false;
}

} // namespace Slang
