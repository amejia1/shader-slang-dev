// slang-ir-specialize.h
#pragma once

namespace Slang
{
struct IRModule;
struct IRInst;
struct IRFunc;
struct IRSpecialize;
struct SpecializationContext;
class DiagnosticSink;
class TargetProgram;

struct SpecializationOptions
{
    // Option that allows specializeModule to generate dynamic-dispatch code
    // wherever possible to open up more specialization opportunities.
    //
    bool lowerWitnessLookups = false;

    // Option to report dynamic dispatch sites.
    bool reportDynamicDispatchSites = false;
};

/// Specialize generic and interface-based code to use concrete types.
bool specializeModule(
    IRModule* module,
    TargetProgram* target,
    DiagnosticSink* sink,
    SpecializationOptions options);

void finalizeSpecialization(IRModule* module);

IRInst* specializeGeneric(
    SpecializationContext* context,
    IRSpecialize* specInst,
    bool queueFollowUpWork = true);
IRInst* specializeGeneric(IRSpecialize* specInst);

/// Run local specialization opportunities exposed under an already-materialized IR value.
bool specializeChildInsts(SpecializationContext* context, IRInst* rootInst);

} // namespace Slang
