#include "slang-syntax.h"

#include "slang-ast-print.h"
#include "slang-check.h"
#include "slang-compiler.h"
#include "slang-visitor.h"

#include <typeinfo>

namespace Slang
{
bool SyntaxClassBase::isSubClassOf(SyntaxClassBase const& other) const
{
    auto selfInfo = getInfo();
    auto otherInfo = other.getInfo();
    if (!selfInfo || !otherInfo)
        return false;
    return unsigned((int)selfInfo->firstTag - (int)otherInfo->firstTag) <
           unsigned(otherInfo->tagCount);
}

UnownedTerminatedStringSlice SyntaxClassBase::getName() const
{
    return _info ? UnownedTerminatedStringSlice(_info->name) : UnownedTerminatedStringSlice();
}

void* SyntaxClassBase::createInstanceImpl(ASTBuilder* astBuilder) const
{
    if (!_info)
        return nullptr;
    if (!_info->createFunc)
        return nullptr;

    return _info->createFunc(astBuilder);
}

void SyntaxClassBase::destructInstanceImpl(void* instance) const
{
    if (!_info)
        return;
    if (!_info->destructFunc)
        return;

    return _info->destructFunc(instance);
}


/* static */ const TypeExp TypeExp::empty;

bool tryGetConstantIntVal(Val* val, IntegerLiteralValue& outValue)
{
    auto intVal = as<IntVal>(val);
    if (auto constantIntVal = intVal ? as<ConstantIntVal>(intVal->resolve()) : nullptr)
    {
        outValue = constantIntVal->getValue();
        return true;
    }
    return false;
}

bool tryFindProvableDuplicateOrderIndices(
    ConcreteIntValPack* orderPack,
    Index& outFirstPosition,
    Index& outSecondPosition,
    IntegerLiteralValue& outConcreteIndex,
    bool& outHasConcreteIndex)
{
    for (Index i = 0; i < orderPack->getCount(); ++i)
    {
        for (Index j = 0; j < i; ++j)
        {
            if (!orderPack->getElement(i)->equals(orderPack->getElement(j)))
                continue;

            outFirstPosition = j;
            outSecondPosition = i;
            outHasConcreteIndex = tryGetConstantIntVal(orderPack->getElement(i), outConcreteIndex);
            return true;
        }
    }
    return false;
}

bool areProvablyDifferentShapeElements(Val* left, Val* right)
{
    IntegerLiteralValue leftValue = 0;
    IntegerLiteralValue rightValue = 0;
    return tryGetConstantIntVal(left, leftValue) && tryGetConstantIntVal(right, rightValue) &&
           leftValue != rightValue;
}

bool hasAnyPotentialConcatAxis(ConcreteIntValPack* leftPack, ConcreteIntValPack* rightPack)
{
    SLANG_ASSERT(leftPack->getCount() == rightPack->getCount());
    for (Index axis = 0; axis < leftPack->getCount(); ++axis)
    {
        bool isPossibleAxis = true;
        for (Index i = 0; i < leftPack->getCount(); ++i)
        {
            if (i != axis && areProvablyDifferentShapeElements(
                                 leftPack->getElement(i),
                                 rightPack->getElement(i)))
            {
                isPossibleAxis = false;
                break;
            }
        }
        if (isPossibleAxis)
            return true;
    }
    return false;
}

const char* getPackQueryName(PackQueryExpr* expr)
{
    if (as<FirstExpr>(expr))
        return "__first";
    if (as<LastExpr>(expr))
        return "__last";
    if (as<TrimFirstExpr>(expr))
        return "__trimFirst";
    if (as<TrimLastExpr>(expr))
        return "__trimLast";
    SLANG_UNEXPECTED("unknown PackQueryExpr subtype");
    UNREACHABLE_RETURN("");
}

const char* getShapePackTransformName(ShapePackTransformExpr* expr)
{
    if (as<ShapeConcatExpr>(expr))
        return "__shapeConcat";
    if (as<ShapePermuteExpr>(expr))
        return "__shapePermute";
    if (as<ShapeSwapExpr>(expr))
        return "__shapeSwap";
    if (as<ShapeReduceExpr>(expr))
        return "__shapeReduce";
    SLANG_UNEXPECTED("unknown ShapePackTransformExpr subtype");
    UNREACHABLE_RETURN("");
}

VariadicPackCardinality getKnownPackCardinality(Val* packOperand)
{
    return getPackCardinalityFromStructure(
        packOperand,
        [](Val* operand) { return getKnownPackCardinality(operand); });
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!! DiagnosticSink impls !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

void printDiagnosticArg(StringBuilder& sb, Decl* decl)
{
    if (!decl)
        return;
    // Unwrap GenericDecl to check for constructors inside.
    auto innerDecl = maybeGetInner(decl);
    if (as<ConstructorDecl>(innerDecl))
    {
        // Print constructors as "TypeName.init" instead of the internal "$init" name.
        // Walk up through parent chain, skipping GenericDecl wrappers, to find the
        // containing type declaration.
        for (auto parent = decl->parentDecl; parent; parent = parent->parentDecl)
        {
            if (as<GenericDecl>(parent))
                continue;
            if (parent->getName() && parent->getName()->text.getLength())
            {
                sb << getText(parent->getName()) << ".";
            }
            else if (auto extDecl = as<ExtensionDecl>(parent))
            {
                // ExtensionDecl has no name; recover the type name from targetType.
                if (auto declRefType = as<DeclRefType>(extDecl->targetType.type))
                {
                    auto typeDecl = declRefType->getDeclRef().getDecl();
                    if (typeDecl && typeDecl->getName() && typeDecl->getName()->text.getLength())
                    {
                        sb << getText(typeDecl->getName()) << ".";
                    }
                }
            }
            break;
        }
        sb << "init";
        return;
    }
    // We need to print a name the user can recognize. Legacy `cbuffer` parsing and HLSL
    // compatibility desugaring assign internal names to shader parameters, so we use the
    // original name recorded in `ParameterGroupReflectionName` when it is available.
    if (auto parameter = as<VarDecl>(decl))
    {
        if (auto reflectionName = parameter->findModifier<ParameterGroupReflectionName>())
        {
            sb << getText(reflectionName->nameAndLoc.name);
            return;
        }
    }
    if (decl->getName() && decl->getName()->text.getLength())
        sb << getText(decl->getName());
    else
        printDiagnosticArg(sb, decl->astNodeType);
}

void printDiagnosticArg(StringBuilder& sb, DeclRefBase* declRefBase)
{
    if (!declRefBase)
        return;
    printDiagnosticArg(sb, declRefBase->getDecl());
}

void printDiagnosticArg(StringBuilder& sb, ASTNodeType nodeType)
{
    // TODO: this can be generated.

    switch (nodeType)
    {
    case ASTNodeType::Decl:
        sb << "Decl";
        break;
    case ASTNodeType::UnresolvedDecl:
        sb << "UnresolvedDecl";
        break;
    case ASTNodeType::ContainerDecl:
        sb << "ContainerDecl";
        break;
    case ASTNodeType::AggTypeDeclBase:
        sb << "AggTypeDeclBase";
        break;
    case ASTNodeType::ExtensionDecl:
        sb << "extension";
        break;
    case ASTNodeType::AggTypeDecl:
        sb << "AggTypeDecl";
        break;
    case ASTNodeType::StructDecl:
        sb << "struct";
        break;
    case ASTNodeType::ClassDecl:
        sb << "class";
        break;
    case ASTNodeType::HLSLClassDecl:
        sb << "HLSL-style class";
        break;
    case ASTNodeType::GLSLInterfaceBlockDecl:
        sb << "GLSL interface block";
        break;
    case ASTNodeType::EnumDecl:
        sb << "enum";
        break;
    case ASTNodeType::ThisTypeDecl:
        sb << "This";
        break;
    case ASTNodeType::InterfaceDecl:
        sb << "interface";
        break;
    case ASTNodeType::AssocTypeDecl:
        sb << "associatedtype";
        break;
    case ASTNodeType::GlobalGenericParamDecl:
        sb << "global generic param";
        break;
    case ASTNodeType::ScopeDecl:
        sb << "scope";
        break;
    case ASTNodeType::CallableDecl:
        sb << "CallableDecl";
        break;
    case ASTNodeType::FunctionDeclBase:
        sb << "FunctionDeclBase";
        break;
    case ASTNodeType::ConstructorDecl:
        sb << "__init";
        break;
    case ASTNodeType::AccessorDecl:
        sb << "accessor";
        break;
    case ASTNodeType::GetterDecl:
        sb << "getter";
        break;
    case ASTNodeType::SetterDecl:
        sb << "setter";
        break;
    case ASTNodeType::RefAccessorDecl:
        sb << "ref accessor";
        break;
    case ASTNodeType::FuncDecl:
        sb << "function";
        break;
    case ASTNodeType::SubscriptDecl:
        sb << "__subscript";
        break;
    case ASTNodeType::PropertyDecl:
        sb << "property";
        break;
    case ASTNodeType::NamespaceDeclBase:
        sb << "NamespaceDeclBase";
        break;
    case ASTNodeType::NamespaceDecl:
        sb << "namespace";
        break;
    case ASTNodeType::ModuleDecl:
        sb << "module";
        break;
    case ASTNodeType::FileDecl:
        sb << "included file";
        break;
    case ASTNodeType::GenericDecl:
        sb << "generic";
        break;
    case ASTNodeType::AttributeDecl:
        sb << "attribute";
        break;
    case ASTNodeType::VarDeclBase:
        sb << "variable definition";
        break;
    case ASTNodeType::VarDecl:
        sb << "variable definition";
        break;
    case ASTNodeType::LetDecl:
        sb << "immutable value definition";
        break;
    case ASTNodeType::GlobalGenericValueParamDecl:
        sb << "GlobalGenericValueParamDecl";
        break;
    case ASTNodeType::ParamDecl:
        sb << "parameter";
        break;
    case ASTNodeType::ModernParamDecl:
        sb << "parameter";
        break;
    case ASTNodeType::GenericValueParamDecl:
        sb << "GenericValueParamDecl";
        break;
    case ASTNodeType::EnumCaseDecl:
        sb << "enum case";
        break;
    case ASTNodeType::TypeConstraintDecl:
        sb << "TypeConstraintDecl";
        break;
    case ASTNodeType::ThisTypeConstraintDecl:
        sb << "ThisTypeConstraintDecl";
        break;
    case ASTNodeType::InheritanceDecl:
        sb << "InheritanceDecl";
        break;
    case ASTNodeType::GenericTypeConstraintDecl:
        sb << "GenericTypeConstraintDecl";
        break;
    case ASTNodeType::NonEmptyPackConstraintDecl:
        sb << "NonEmptyPackConstraintDecl";
        break;
    case ASTNodeType::GenericVariadicPackCountConstraintDecl:
        sb << "GenericVariadicPackCountConstraintDecl";
        break;
    case ASTNodeType::HasDiffTypeInfoConstraintDecl:
        sb << "__hasDiffTypeInfo";
        break;
    case ASTNodeType::SimpleTypeDecl:
        sb << "SimpleTypeDecl";
        break;
    case ASTNodeType::TypeDefDecl:
        sb << "typedef";
        break;
    case ASTNodeType::TypeAliasDecl:
        sb << "typealias";
        break;
    case ASTNodeType::GenericTypeParamDecl:
        sb << "GenericTypeParamDecl";
        break;
    case ASTNodeType::UsingDecl:
        sb << "using";
        break;
    case ASTNodeType::FileReferenceDeclBase:
        sb << "FileReferenceDeclBase";
        break;
    case ASTNodeType::ImportDecl:
        sb << "import";
        break;
    case ASTNodeType::IncludeDeclBase:
        sb << "IncludeDeclBase";
        break;
    case ASTNodeType::IncludeDecl:
        sb << "__include";
        break;
    case ASTNodeType::ImplementingDecl:
        sb << "implementing";
        break;
    case ASTNodeType::ModuleDeclarationDecl:
        sb << "module";
        break;
    case ASTNodeType::EmptyDecl:
        sb << "empty";
        break;
    case ASTNodeType::SyntaxDecl:
        sb << "syntax";
        break;
    case ASTNodeType::DeclGroup:
        sb << "decl-group";
        break;
    case ASTNodeType::RequireCapabilityDecl:
        sb << "__require_capability";
        break;
    case ASTNodeType::DiscardStmt:
        sb << "discard";
        break;
    default:
        if (SyntaxClass<NodeBase>(nodeType).isSubClassOf<Expr>())
            sb << "expression";
        else if (SyntaxClass<NodeBase>(nodeType).isSubClassOf<Stmt>())
            sb << "statement";
        else if (SyntaxClass<NodeBase>(nodeType).isSubClassOf<Decl>())
            sb << "decl";
        else if (SyntaxClass<NodeBase>(nodeType).isSubClassOf<Val>())
            sb << "val";
        else
            sb << "node";
        break;
    }
}

void printDiagnosticArg(StringBuilder& sb, Type* type)
{
    if (!type)
        return;
    type->toText(sb);
}

void printDiagnosticArg(StringBuilder& sb, Val* val)
{
    if (!val)
        return;
    val->toText(sb);
}

void printDiagnosticArg(StringBuilder& sb, TypeExp const& type)
{
    if (type.type)
        type.type->toText(sb);
    else
        sb << "<null>";
}

void printDiagnosticArg(StringBuilder& sb, QualType const& type)
{
    if (type.type)
        type.type->toText(sb);
    else
        sb << "<null>";
}

void printDiagnosticArg(StringBuilder& sb, QualifiedDeclPath path)
{
    ASTPrinter printer(getCurrentASTBuilder());
    printer.addDeclPath(path.declRef);
    sb << printer.getString();
}

SourceLoc getDiagnosticPos(SyntaxNode const* syntax)
{
    if (!syntax)
        return SourceLoc();
    return syntax->loc;
}

SourceLoc getDiagnosticPos(TypeExp const& typeExp)
{
    if (!typeExp.exp)
        return SourceLoc();
    return typeExp.exp->loc;
}

SourceLoc getDiagnosticPos(DeclRefBase* declRef)
{
    if (!declRef)
        return SourceLoc();
    return getDiagnosticPos(declRef->getDecl());
}

SourceLoc getDiagnosticPos(Decl* decl)
{
    if (!decl)
        return SourceLoc();
    if (decl->getNameLoc().isValid())
    {
        return decl->getNameLoc();
    }
    return decl->loc;
}

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!  Free functions !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Decl* const* adjustFilterCursorImpl(
    const ReflectClassInfo& clsInfo,
    MemberFilterStyle filterStyle,
    Decl* const* ptr,
    Decl* const* end)
{
    switch (filterStyle)
    {
    default:
    case MemberFilterStyle::All:
        {
            for (; ptr != end; ptr++)
            {
                Decl* decl = *ptr;
                if (decl->getClass().isSubClassOf(clsInfo))
                {
                    return ptr;
                }
            }
            break;
        }
    case MemberFilterStyle::Instance:
        {
            for (; ptr != end; ptr++)
            {
                Decl* decl = *ptr;
                if (decl->getClass().isSubClassOf(clsInfo) &&
                    !decl->hasModifier<HLSLStaticModifier>())
                {
                    return ptr;
                }
            }
            break;
        }
    case MemberFilterStyle::Static:
        {
            for (; ptr != end; ptr++)
            {
                Decl* decl = *ptr;
                if (decl->getClass().isSubClassOf(clsInfo) &&
                    decl->hasModifier<HLSLStaticModifier>())
                {
                    return ptr;
                }
            }
            break;
        }
    }
    return end;
}

Decl* const* getFilterCursorByIndexImpl(
    const ReflectClassInfo& clsInfo,
    MemberFilterStyle filterStyle,
    Decl* const* ptr,
    Decl* const* end,
    Index index)
{
    switch (filterStyle)
    {
    default:
    case MemberFilterStyle::All:
        {
            for (; ptr != end; ptr++)
            {
                Decl* decl = *ptr;
                if (decl->getClass().isSubClassOf(clsInfo))
                {
                    if (index <= 0)
                    {
                        return ptr;
                    }
                    index--;
                }
            }
            break;
        }
    case MemberFilterStyle::Instance:
        {
            for (; ptr != end; ptr++)
            {
                Decl* decl = *ptr;
                if (decl->getClass().isSubClassOf(clsInfo) &&
                    !decl->hasModifier<HLSLStaticModifier>())
                {
                    if (index <= 0)
                    {
                        return ptr;
                    }
                    index--;
                }
            }
            break;
        }
    case MemberFilterStyle::Static:
        {
            for (; ptr != end; ptr++)
            {
                Decl* decl = *ptr;
                if (decl->getClass().isSubClassOf(clsInfo) &&
                    decl->hasModifier<HLSLStaticModifier>())
                {
                    if (index <= 0)
                    {
                        return ptr;
                    }
                    index--;
                }
            }
            break;
        }
    }
    return nullptr;
}

Index getFilterCountImpl(
    const SyntaxClassBase& clsInfo,
    MemberFilterStyle filterStyle,
    Decl* const* ptr,
    Decl* const* end)
{
    Index count = 0;
    switch (filterStyle)
    {
    default:
    case MemberFilterStyle::All:
        {
            for (; ptr != end; ptr++)
            {
                Decl* decl = *ptr;
                count += Index(decl->getClass().isSubClassOf(clsInfo));
            }
            break;
        }
    case MemberFilterStyle::Instance:
        {
            for (; ptr != end; ptr++)
            {
                Decl* decl = *ptr;
                count += Index(
                    decl->getClass().isSubClassOf(clsInfo) &&
                    !decl->hasModifier<HLSLStaticModifier>());
            }
            break;
        }
    case MemberFilterStyle::Static:
        {
            for (; ptr != end; ptr++)
            {
                Decl* decl = *ptr;
                count += Index(
                    decl->getClass().isSubClassOf(clsInfo) &&
                    decl->hasModifier<HLSLStaticModifier>());
            }
            break;
        }
    }
    return count;
}

// TypeExp

bool TypeExp::equals(Type* other)
{
    return type->equals(other);
}

//
// RequirementWitness
//

RequirementWitness::RequirementWitness(Val* val)
    : m_flavor(Flavor::val), m_val(val)
{
}


RequirementWitness::RequirementWitness(RefPtr<WitnessTable> witnessTable)
    : m_flavor(Flavor::witnessTable), m_obj(witnessTable)
{
}

RefPtr<WitnessTable> RequirementWitness::getWitnessTable()
{
    SLANG_ASSERT(getFlavor() == Flavor::witnessTable);
    return m_obj.as<WitnessTable>();
}

RefPtr<WitnessTable> WitnessTable::specialize(ASTBuilder* astBuilder, SubstitutionSet const& subst)
{
    auto newBaseType = baseType->substitute(astBuilder, subst);
    auto newWitnessedType = witnessedType->substitute(astBuilder, subst);
    if (newBaseType == baseType && newWitnessedType == witnessedType)
        return this;
    RefPtr<WitnessTable> result = new WitnessTable();
    result->baseType = as<Type>(newBaseType);
    result->witnessedType = as<Type>(newWitnessedType);
    for (auto requirement : m_requirementDictionary)
    {
        auto newRequirement = requirement.value.specialize(astBuilder, subst);
        result->add(requirement.key, newRequirement);
    }
    return result;
}

RequirementWitness RequirementWitness::specialize(
    ASTBuilder* astBuilder,
    SubstitutionSet const& subst)
{
    switch (getFlavor())
    {
    default:
        SLANG_UNEXPECTED("unknown requirement witness flavor");
    case RequirementWitness::Flavor::none:
        return RequirementWitness();

    case RequirementWitness::Flavor::witnessTable:
        return RequirementWitness(this->getWitnessTable()->specialize(astBuilder, subst));

    case RequirementWitness::Flavor::declRef:
        {
            int diff = 0;
            return RequirementWitness(getDeclRef().substituteImpl(astBuilder, subst, &diff));
        }

    case RequirementWitness::Flavor::val:
        {
            auto val = getVal();
            SLANG_ASSERT(val);

            return RequirementWitness(val->substitute(astBuilder, subst));
        }
    }
}

//
// WitnessTable
//

InterfaceRequirementKey::InterfaceRequirementKey(Decl* requirementDecl)
    : InterfaceRequirementKey(requirementDecl, nullptr)
{
}

InterfaceRequirementKey InterfaceRequirementKey::createWithGenericWrapperCount(
    Decl* requirementDecl,
    UCount& outGenericWrapperCount)
{
    return InterfaceRequirementKey(requirementDecl, &outGenericWrapperCount);
}

InterfaceRequirementKey::InterfaceRequirementKey(
    Decl* requirementDecl,
    UCount* outGenericWrapperCount)
{
    SLANG_RELEASE_ASSERT(requirementDecl);
    UCount genericWrapperCount = 0;
    while (auto genericDecl = as<GenericDecl>(requirementDecl))
    {
        genericWrapperCount++;
        requirementDecl = genericDecl->inner;
    }
    if (outGenericWrapperCount)
        *outGenericWrapperCount = genericWrapperCount;
    m_decl = requirementDecl;
}

void WitnessTable::add(Decl* requirementDecl, RequirementWitness const& witness)
{
    add(InterfaceRequirementKey(requirementDecl), witness);
}

void WitnessTable::add(InterfaceRequirementKey key, RequirementWitness const& witness)
{
    m_requirementDictionary.add(key.getDecl(), witness);
}

void WitnessTable::removeRequirement(InterfaceRequirementKey key)
{
    m_requirementDictionary.remove(key.getDecl());
    m_requirementCheckStates.remove(key.getDecl());
}

// TODO: need to figure out how to unify this with the logic
// in the generic case...
Type* DeclRefType::create(ASTBuilder* astBuilder, DeclRef<Decl> declRef)
{
    if (declRef.getDecl()->findModifier<BuiltinTypeModifier>())
    {
        // Always create builtin types in global AST builder.
        if (astBuilder->getSharedASTBuilder()->getInnerASTBuilder() != astBuilder)
            return DeclRefType::create(
                astBuilder->getSharedASTBuilder()->getInnerASTBuilder(),
                declRef);

        declRef = createDefaultSubstitutionsIfNeeded(astBuilder, nullptr, declRef);
        auto type = astBuilder->getOrCreate<BasicExpressionType>(declRef.declRefBase);
        return type;
    }
    else if (auto magicMod = declRef.getDecl()->findModifier<MagicTypeModifier>())
    {
        if (!magicMod->magicNodeType)
        {
            SLANG_UNEXPECTED("unhandled type");
        }

        declRef = createDefaultSubstitutionsIfNeeded(astBuilder, nullptr, declRef);
        ValNodeDesc nodeDesc = {};
        nodeDesc.type = magicMod->magicNodeType;
        nodeDesc.operands.add(ValNodeOperand(declRef));
        nodeDesc.init();
        NodeBase* type = astBuilder->_getOrCreateImpl(_Move(nodeDesc));
        if (!type)
        {
            SLANG_UNEXPECTED("constructor failure");
        }

        auto declRefType = dynamicCast<DeclRefType>(type);
        if (!declRefType)
        {
            SLANG_UNEXPECTED("expected a declaration reference type");
        }
        return declRefType;
    }
    else if (as<ThisTypeDecl>(declRef.getDecl()))
    {
        // A reference to a `ThisTypeDecl` must always be represented as a `ThisType`,
        // never as a plain `DeclRefType`. Otherwise the same logical `This` type can
        // exist as two distinct `Type*`s (e.g. a `ThisType` built from a `DirectDeclRef`
        // vs. a `DeclRefType` built from a `MemberDeclRef` for a substituted interface),
        // breaking type-identity comparison. See issue #11465.
        if (auto lookupDeclRef = as<LookupDeclRef>(declRef.declRefBase))
        {
            return lookupDeclRef->getWitness()->getSub();
        }
        declRef = createDefaultSubstitutionsIfNeeded(astBuilder, nullptr, declRef);
        return astBuilder->getOrCreate<ThisType>(declRef.declRefBase);
    }
    else if (auto typedefDecl = as<TypeDefDecl>(declRef.getDecl()))
    {
        if (typedefDecl->type.type)
            return as<Type>(
                typedefDecl->type.type->substitute(astBuilder, SubstitutionSet(declRef)));
        return astBuilder->getErrorType();
    }

    declRef = createDefaultSubstitutionsIfNeeded(astBuilder, nullptr, declRef);
    return astBuilder->getOrCreate<DeclRefType>(declRef.declRefBase);
}

//

Val::OperandView<Val> findInnerMostGenericArgs(SubstitutionSet subst)
{
    if (!subst.declRef)
        return Val::OperandView<Val>();
    if (auto genApp = subst.findGenericAppDeclRef())
        return genApp->getArgs();
    return Val::OperandView<Val>();
}

SubstExpr<Expr> substituteExpr(SubstitutionSet const& substs, Expr* expr)
{
    return SubstExpr<Expr>(expr, substs);
}

DeclRef<Decl> substituteDeclRef(
    SubstitutionSet const& substs,
    ASTBuilder* astBuilder,
    DeclRef<Decl> const& declRef)
{
    if (!substs)
        return declRef;

    int diff = 0;
    auto declRefBase = declRef.substituteImpl(astBuilder, substs, &diff);
    return declRefBase;
}

Type* substituteType(SubstitutionSet const& substs, ASTBuilder* astBuilder, Type* type)
{
    if (!type)
        return nullptr;
    if (!substs)
        return type;

    SLANG_ASSERT(type);

    return Slang::as<Type>(type->substitute(astBuilder, substs));
}

InterfaceDecl* findOuterInterfaceDecl(Decl* decl)
{
    Decl* dd = decl;
    while (dd)
    {
        if (auto interfaceDecl = as<InterfaceDecl>(dd))
            return interfaceDecl;

        dd = dd->parentDecl;
    }
    return nullptr;
}

// IntVal

IntegerLiteralValue getIntVal(IntVal* val)
{
    if (auto constantVal = as<ConstantIntVal>(val))
    {
        return constantVal->getValue();
    }
    SLANG_UNEXPECTED("needed a known integer value");
    // return 0;
}

//

// HLSLPatchType

Val* getGenericArg(DeclRef<Decl> declRef, Index index)
{
    auto subst = SubstitutionSet(declRef).findGenericAppDeclRef();
    if (index < subst->getArgs().getCount())
        return subst->getArgs()[index];
    return nullptr;
}

Type* HLSLPatchType::getElementType()
{
    return as<Type>(getGenericArg(getDeclRef(), 0));
}

IntVal* HLSLPatchType::getElementCount()
{
    return as<IntVal>(getGenericArg(getDeclRef(), 1));
}

// MeshOutputType
// There's a subtle distinction between this and HLSLPatchType, the size
// here is the max possible size of the array, it's free to change at
// runtime. There's probably no circumstance where you'd want to be generic
// between the two, so we don't deduplicate this code.

Type* MeshOutputType::getElementType()
{
    return as<Type>(getGenericArg(getDeclRef(), 0));
}

IntVal* MeshOutputType::getMaxElementCount()
{
    return as<IntVal>(getGenericArg(getDeclRef(), 1));
}

// Constructors for types

ArrayExpressionType* getArrayType(ASTBuilder* astBuilder, Type* elementType, IntVal* elementCount)
{
    return astBuilder->getArrayType(elementType, elementCount);
}

ArrayExpressionType* getArrayType(ASTBuilder* astBuilder, Type* elementType)
{
    return astBuilder->getArrayType(elementType, nullptr);
}

NamedExpressionType* getNamedType(ASTBuilder* astBuilder, DeclRef<TypeDefDecl> const& declRef)
{
    DeclRef<TypeDefDecl> specializedDeclRef =
        createDefaultSubstitutionsIfNeeded(astBuilder, nullptr, declRef).as<TypeDefDecl>();

    return astBuilder->getOrCreate<NamedExpressionType>(specializedDeclRef);
}

std::optional<ParamInfo> findEffectiveThisParamInfo(ASTBuilder* astBuilder, DeclRef<Decl> declRef)
{
    SLANG_RELEASE_ASSERT(astBuilder);
    SLANG_RELEASE_ASSERT(declRef);

    auto decl = declRef.getDecl();
    SLANG_RELEASE_ASSERT(decl->isChecked(DeclCheckState::SignatureChecked));

    auto attribute = decl->findModifier<ThisParamInfoAttribute>();
    if (auto lookupDeclRef = as<LookupDeclRef>(declRef.declRefBase))
    {
        if (auto callableDeclRef = isDeclRefTypeOf<CallableDecl>(lookupDeclRef->getLookupSource()))
        {
            // Consider `apply_bwd`, an interface requirement looked up through a function-as-type.
            // Its declaration's receiver is the interface `This`, but its callable ABI follows the
            // function used as the lookup source: a free function has no effective `this`
            // parameter, while a method has the same one as its primal declaration. Delegate to
            // that callable's checked information so this query preserves both possibilities. A
            // receiverless requirement has no attribute and remains receiverless regardless of
            // the callable used as its lookup source.
            SLANG_RELEASE_ASSERT(
                callableDeclRef.getDecl()->isChecked(DeclCheckState::SignatureChecked));
            if (attribute)
                return findEffectiveThisParamInfo(astBuilder, DeclRef<Decl>(callableDeclRef));
        }
    }

    if (!attribute)
        return std::nullopt;

    ParamInfo result = attribute->info;
    SLANG_RELEASE_ASSERT(result.type);
    result.type = declRef.substitute(astBuilder, result.type);
    return result;
}

ParamInfo getEffectiveThisParamInfo(ASTBuilder* astBuilder, DeclRef<Decl> declRef)
{
    auto result = findEffectiveThisParamInfo(astBuilder, declRef);
    SLANG_RELEASE_ASSERT(result.has_value());
    return *result;
}

bool isThisExprWritable(DeclRef<CallableDecl> callableDeclRef, ParamInfo const& thisParamInfo)
{
    if (doesParamPassingModeIndicateWritableStorage(thisParamInfo.mode))
        return true;

    return callableDeclRef.is<SetterDecl>() &&
           isDeclRefTypeOf<ClassDecl>(unwrapModifiedType(thisParamInfo.type));
}

bool doesTypeHaveNoDiffModifier(Type* type)
{
    if (auto modifiedType = as<ModifiedType>(type))
    {
        if (modifiedType->findModifier<NoDiffModifierVal>())
            return true;
        return doesTypeHaveNoDiffModifier(modifiedType->getBase());
    }

    return false;
}

List<DeclRef<ParamDecl>> getParametersForCallableSignature(
    ASTBuilder* astBuilder,
    DeclRef<CallableDecl> declRef)
{
    List<DeclRef<ParamDecl>> result;

    if (declRef.as<AccessorDecl>())
    {
        if (auto callableParent = declRef.getParent().as<CallableDecl>())
        {
            for (auto paramDeclRef : getParameters(astBuilder, callableParent))
                result.add(paramDeclRef);
        }
    }

    for (auto paramDeclRef : getParameters(astBuilder, declRef))
        result.add(paramDeclRef);

    return result;
}

FuncType* getFuncType(ASTBuilder* astBuilder, DeclRef<CallableDecl> const& declRef)
{
    List<Type*> paramTypes;
    auto resultType = getResultType(astBuilder, declRef);

    if (!resultType)
        resultType = astBuilder->getErrorType();

    auto errorType = getErrorCodeType(astBuilder, declRef);
    auto visitParamDecl = [&](DeclRef<ParamDecl> paramDeclRef)
    {
        auto paramInfo = getParamInfo(astBuilder, paramDeclRef);
        if (!paramInfo.type)
            paramInfo.type = astBuilder->getErrorType();
        paramTypes.add(getParamTypeWithModeWrapper(astBuilder, paramInfo));
    };
    for (auto paramDeclRef : getParametersForCallableSignature(astBuilder, declRef))
        visitParamDecl(paramDeclRef);

    auto funcType = astBuilder->getFuncType(paramTypes.getArrayView(), resultType, errorType);
    return as<FuncType>(funcType->substitute(astBuilder, SubstitutionSet(declRef))->resolve());
}

GenericDeclRefType* getGenericDeclRefType(
    ASTBuilder* astBuilder,
    DeclRef<GenericDecl> const& declRef)
{
    return astBuilder->getOrCreate<GenericDeclRefType>(declRef);
}

NamespaceType* getNamespaceType(ASTBuilder* astBuilder, DeclRef<NamespaceDeclBase> const& declRef)
{
    auto type = astBuilder->getOrCreate<NamespaceType>(declRef);
    return type;
}

SamplerStateType* getSamplerStateType(ASTBuilder* astBuilder)
{
    return astBuilder->getSamplerStateType();
}

SubtypeWitness* findThisTypeWitness(SubstitutionSet substs, InterfaceDecl* interfaceDecl)
{
    auto lookupDeclRef = substs.findLookupDeclRef();
    if (!lookupDeclRef)
        return nullptr;
    if (lookupDeclRef->getSupDecl() == interfaceDecl)
    {
        return lookupDeclRef->getWitness();
    }
    return nullptr;
}

Val* _tryLookupConcreteAssociatedTypeFromThisTypeSubst(ASTBuilder* builder, DeclRef<Decl> declRef)
{
    auto substDeclRef = declRef.as<AssocTypeDecl>();
    if (!substDeclRef)
        return nullptr;

    auto substAssocTypeDecl = substDeclRef.getDecl();

    if (auto lookupDeclRef = SubstitutionSet(substDeclRef).findLookupDeclRef())
    {
        if (auto interfaceDecl = as<InterfaceDecl>(substAssocTypeDecl->parentDecl))
        {
            if (lookupDeclRef->getSupDecl() == interfaceDecl)
            {
                // We need to look up the declaration that satisfies
                // the requirement named by the associated type.
                Decl* requirementKey = substAssocTypeDecl;
                RequirementWitness requirementWitness = tryLookUpRequirementWitness(
                    builder,
                    lookupDeclRef->getWitness(),
                    requirementKey);
                switch (requirementWitness.getFlavor())
                {
                default:
                    // No usable value was found, so there is nothing we can do.
                    break;

                case RequirementWitness::Flavor::val:
                    {
                        auto satisfyingVal = requirementWitness.getVal();
                        return satisfyingVal;
                    }
                    break;
                }

                // Hard code implementation of T.Differential.Differential == T.Differential rule.
                auto foldResult = [&]() -> Val*
                {
                    auto builtinReq =
                        substDeclRef.getDecl()->findModifier<BuiltinRequirementModifier>();
                    if (!builtinReq)
                        return nullptr;
                    if (builtinReq->kind != BuiltinRequirementKind::DifferentialType)
                        return nullptr;
                    // Is the concrete type a Differential associated type?
                    auto innerDeclRefType = as<DeclRefType>(lookupDeclRef->getWitness()->getSub());
                    if (!innerDeclRefType)
                        return nullptr;
                    auto innerBuiltinReq = innerDeclRefType->getDeclRef()
                                               .getDecl()
                                               ->findModifier<BuiltinRequirementModifier>();
                    if (!innerBuiltinReq)
                        return nullptr;
                    if (innerBuiltinReq->kind != BuiltinRequirementKind::DifferentialType)
                        return nullptr;
                    if (!innerDeclRefType->getDeclRef().equals(declRef))
                    {
                        auto result = _tryLookupConcreteAssociatedTypeFromThisTypeSubst(
                            builder,
                            innerDeclRefType->getDeclRef());
                        if (result)
                            return result;
                    }
                    return innerDeclRefType;
                }();
                if (foldResult)
                    return foldResult;
            }
        }
    }
    return nullptr;
}

Type* UniformParameterGroupType::getLayoutType()
{
    return as<Type>(getGenericArg(getDeclRef(), 1));
}

ModuleDecl* getModuleDecl(Decl* decl)
{
    for (auto dd = decl; dd; dd = dd->parentDecl)
    {
        if (auto moduleDecl = as<ModuleDecl>(dd))
            return moduleDecl;
    }
    return nullptr;
}

Module* getModule(Decl* decl)
{
    auto moduleDecl = getModuleDecl(decl);
    if (!moduleDecl)
        return nullptr;

    return moduleDecl->module;
}

ModuleDecl* getModuleDecl(Scope* scope)
{
    for (; scope; scope = scope->parent)
    {
        if (scope->containerDecl)
            return getModuleDecl(scope->containerDecl);
    }
    return nullptr;
}

EnumDecl* isUnscopedEnum(Decl* decl)
{
    EnumDecl* enumDecl = as<EnumDecl>(decl);
    if (!enumDecl)
        return nullptr;
    for (auto mod : enumDecl->modifiers)
    {
        if (as<UnscopedEnumAttribute>(mod))
        {
            return enumDecl;
        }
        else if (auto uncheckedAttribute = as<UncheckedAttribute>(mod))
        {
            // TODO: This unchecked, string-based attribute match exists only so that this
            // predicate can be used during parsing, before attributes are checked. It is
            // both ugly and fragile, and we should aspire to remove the need for it -- e.g.
            // by not requiring an enum's unscoped-ness to be known at parse time -- so that
            // "is this enum unscoped" can rely solely on the checked `UnscopedEnumAttribute`
            // handled above.
            if (getText(uncheckedAttribute->keywordName) == "UnscopedEnum")
            {
                return enumDecl;
            }
        }
    }
    return nullptr;
}

ContainerDecl* getParentDecl(Decl* decl)
{
    auto parentDecl = decl->parentDecl;
    while (auto genericDecl = as<GenericDecl>(parentDecl))
        parentDecl = genericDecl->parentDecl;
    return parentDecl;
}

AggTypeDecl* getParentAggTypeDecl(Decl* decl)
{
    decl = decl->parentDecl;
    while (decl)
    {
        if (auto found = as<AggTypeDecl>(decl))
            return found;
        decl = decl->parentDecl;
    }
    return nullptr;
}

AggTypeDeclBase* getParentAggTypeDeclBase(Decl* decl)
{
    decl = decl->parentDecl;
    while (decl)
    {
        if (auto found = as<AggTypeDeclBase>(decl))
            return found;
        decl = decl->parentDecl;
    }
    return nullptr;
}

ExtensionDecl* getParentExtensionDecl(Decl* decl)
{
    decl = decl->parentDecl;
    while (decl)
    {
        if (auto found = as<ExtensionDecl>(decl))
            return found;
        decl = decl->parentDecl;
    }
    return nullptr;
}

FunctionDeclBase* getParentFunc(Decl* decl)
{
    while (decl)
    {
        if (auto found = as<FunctionDeclBase>(decl))
            return found;
        decl = decl->parentDecl;
    }
    return nullptr;
}

static const ImageFormatInfo kImageFormatInfos[] = {
#define SLANG_IMAGE_FORMAT_INFO(TYPE, COUNT, SIZE) \
    SLANG_SCALAR_TYPE_##TYPE, uint8_t(COUNT), uint8_t(SIZE)
#define SLANG_FORMAT(NAME, OTHER) \
    {SLANG_IMAGE_FORMAT_INFO OTHER, UnownedStringSlice::fromLiteral(#NAME)},
#include "slang-image-format-defs.h"
#undef SLANG_FORMAT
#undef SLANG_IMAGE_FORMAT_INFO
};

bool findImageFormatByName(const UnownedStringSlice& name, ImageFormat* outFormat)
{
    for (Index i = 0; i < SLANG_COUNT_OF(kImageFormatInfos); ++i)
    {
        const auto& info = kImageFormatInfos[i];
        if (info.name == name)
        {
            *outFormat = ImageFormat(i);
            return true;
        }
    }
    return false;
}

// https://github.com/microsoft/DirectXShaderCompiler/blob/main/docs/SPIR-V.rst#id71
// clang-format off
#define SLANG_VK_TO_IMAGE_FORMAT(x) \
    x(r11g11b10f, r11f_g11f_b10f) \
    x(rgb10a2, rgb10_a2) \
    x(rgb10a2ui, rgb10_a2ui)
// clang-format on

struct VkImageFormatInfo
{
    UnownedStringSlice name;
    ImageFormat format;
};
static const VkImageFormatInfo kVkImageFormatInfos[] = {
#define SLANG_VK_IMAGE_FORMAT_INFO(name, format) {toSlice(#name), ImageFormat::format},
    SLANG_VK_TO_IMAGE_FORMAT(SLANG_VK_IMAGE_FORMAT_INFO)};

static const auto kSNorm = UnownedStringSlice::fromLiteral("snorm");

bool findVkImageFormatByName(const UnownedStringSlice& name, ImageFormat* outFormat)
{
    // Handle names ending in snorm
    if (name.endsWith(kSNorm))
    {
        StringBuilder buf;
        auto prefix = name.head(name.getLength() - kSNorm.getLength());
        buf << prefix;
        // format names end with snormal after a '_', so add an underscore
        // if the prefix doesn't already end with one
        if (prefix.getLength() == 0 || prefix[prefix.getLength() - 1] != '_')
        {
            buf << "_";
        }
        buf << kSNorm;
        return findImageFormatByName(buf.getUnownedSlice(), outFormat);
    }

    // Handle the special cases
    for (const auto& vkInfo : kVkImageFormatInfos)
    {
        if (vkInfo.name == name)
        {
            *outFormat = vkInfo.format;
            return true;
        }
    }

    // Default to the regular lookup mechanism for everything else
    return findImageFormatByName(name, outFormat);
}

char const* getGLSLNameForImageFormat(ImageFormat format)
{
    return kImageFormatInfos[Index(format)].name.begin();
}

const ImageFormatInfo& getImageFormatInfo(ImageFormat format)
{
    return kImageFormatInfos[Index(format)];
}

char const* getTryClauseTypeName(TryClauseType c)
{
    switch (c)
    {
    case TryClauseType::None:
        return "None";
    case TryClauseType::Standard:
        return "Standard";
    case TryClauseType::Optional:
        return "Optional";
    case TryClauseType::Assert:
        return "Assert";
    default:
        return "Unknown";
    }
}

ModifiedType* getTypeWithModifier(Type* baseType, Val* typeModifier)
{
    // If the type is not a modified type already, just create one.
    // If the type already has modifiers:
    //   if the modifier already exists on the type, just return the regular type.
    //   otherwise, pull them into a list, add the new modifier, and create a new modified type.
    //
    auto astBuilder = getCurrentASTBuilder();

    if (auto modifiedType = as<ModifiedType>(baseType))
    {
        // Check if the modifier already exists
        for (Index i = 0; i < modifiedType->getModifierCount(); i++)
        {
            if (modifiedType->getModifier(i) == typeModifier)
            {
                // Modifier already exists, return the type as is
                return modifiedType;
            }
        }

        // Collect all existing modifiers and add the new one
        List<Val*> modifiers;
        for (Index i = 0; i < modifiedType->getModifierCount(); i++)
        {
            modifiers.add(modifiedType->getModifier(i));
        }
        modifiers.add(typeModifier);

        // Create a new modified type with all modifiers
        return as<ModifiedType>(astBuilder->getModifiedType(modifiedType->getBase(), modifiers));
    }
    else
    {
        // Type is not a modified type, create one with the single modifier
        return as<ModifiedType>(astBuilder->getModifiedType(baseType, 1, &typeModifier));
    }
}

} // namespace Slang
