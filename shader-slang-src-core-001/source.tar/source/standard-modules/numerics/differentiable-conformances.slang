implementing differentiable;

#define SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(METHOD, ADAPTER)              \
    [Differentiable] [ForceInline]                                              \
    This METHOD() { return ADAPTER(this); }

#define SLANG_NUMERICS_DIFFERENTIABLE_BINARY_REQUIREMENT(METHOD, ADAPTER)             \
    [Differentiable] [ForceInline]                                              \
    This METHOD(This other) { return ADAPTER(this, other); }

#define SLANG_NUMERICS_DIFFERENTIABLE_CORE_UNARY_REQUIREMENT(METHOD, CORE_METHOD)     \
    [Differentiable] [ForceInline]                                              \
    This METHOD() { return this.CORE_METHOD(); }

#define SLANG_NUMERICS_DIFFERENTIABLE_CORE_BINARY_REQUIREMENT(METHOD, CORE_METHOD)    \
    [Differentiable] [ForceInline]                                              \
    This METHOD(This other) { return this.CORE_METHOD(other); }

#define SLANG_NUMERICS_DIFFERENTIABLE_FRACTIONAL_REQUIREMENTS                         \
    SLANG_NUMERICS_DIFFERENTIABLE_CORE_BINARY_REQUIREMENT(plus, add)             \
    SLANG_NUMERICS_DIFFERENTIABLE_CORE_BINARY_REQUIREMENT(minus, sub)            \
    SLANG_NUMERICS_DIFFERENTIABLE_CORE_BINARY_REQUIREMENT(multipliedBy, mul)     \
    SLANG_NUMERICS_DIFFERENTIABLE_CORE_BINARY_REQUIREMENT(dividedBy, div)        \
    SLANG_NUMERICS_DIFFERENTIABLE_CORE_UNARY_REQUIREMENT(negated, neg)           \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        absoluteValue, __differentiableNumericsAbs)                             \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        reciprocal, __differentiableNumericsRcp)

#define SLANG_NUMERICS_DIFFERENTIABLE_FLOATING_POINT_REQUIREMENTS                     \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        fractionalPart, __differentiableNumericsFractionalPart)                 \
    SLANG_NUMERICS_DIFFERENTIABLE_BINARY_REQUIREMENT(                                 \
        remainderWhenDividedBy, __differentiableNumericsRemainder)              \
    SLANG_NUMERICS_DIFFERENTIABLE_BINARY_REQUIREMENT(                                 \
        copyingSignFrom, __differentiableNumericsCopySign)

#define SLANG_NUMERICS_DIFFERENTIABLE_EXPONENTIAL_REQUIREMENTS                        \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        exponential, __differentiableNumericsExp)                                     \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        exponentialWithBase2, __differentiableNumericsExp2)                          \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        exponentialWithBase10, __differentiableNumericsExp10)                        \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        logarithm, __differentiableNumericsLog)                                       \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        logarithmWithBase2, __differentiableNumericsLog2)                            \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        logarithmWithBase10, __differentiableNumericsLog10)                     \
    SLANG_NUMERICS_DIFFERENTIABLE_BINARY_REQUIREMENT(                                 \
        raisedToThePowerOf, __differentiableNumericsPow)

#define SLANG_NUMERICS_DIFFERENTIABLE_TRIGONOMETRIC_REQUIREMENTS                      \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(sin, __differentiableNumericsSin) \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(cos, __differentiableNumericsCos) \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(tan, __differentiableNumericsTan) \
    [Differentiable] [ForceInline]                                              \
    void sincos(out This sineResult, out This cosineResult)                      \
    {                                                                            \
        __differentiableNumericsSinCos(this, sineResult, cosineResult);          \
    }

#define SLANG_NUMERICS_DIFFERENTIABLE_INVERSE_TRIGONOMETRIC_REQUIREMENTS              \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(asin, __differentiableNumericsAsin) \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(acos, __differentiableNumericsAcos) \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(atan, __differentiableNumericsAtan) \
    SLANG_NUMERICS_DIFFERENTIABLE_BINARY_REQUIREMENT(                                 \
        atan2, __differentiableNumericsAtan2)

#define SLANG_NUMERICS_DIFFERENTIABLE_HYPERBOLIC_REQUIREMENTS                         \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(sinh, __differentiableNumericsSinh) \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(cosh, __differentiableNumericsCosh) \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(tanh, __differentiableNumericsTanh) \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        asinh, __differentiableNumericsAsinh)                                   \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        acosh, __differentiableNumericsAcosh)                                   \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        atanh, __differentiableNumericsAtanh)

#define SLANG_NUMERICS_DIFFERENTIABLE_ROOT_REQUIREMENTS                               \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(squareRoot, __differentiableNumericsSqrt) \
    SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT(                                  \
        reciprocalSquareRoot, __differentiableNumericsRsqrt)

#define SLANG_NUMERICS_DIFFERENTIABLE_ORDERING_REQUIREMENTS                           \
    SLANG_NUMERICS_DIFFERENTIABLE_BINARY_REQUIREMENT(                                 \
        minimum, __differentiableNumericsMinimum)                               \
    SLANG_NUMERICS_DIFFERENTIABLE_BINARY_REQUIREMENT(                                 \
        maximum, __differentiableNumericsMaximum)

// These nominal joins share the inherited associated-type witnesses between the differentiable
// and dot-product branches. See the corresponding base conformances and #12874.
interface __IScalarDifferentiableFloatingPointDotProduct
    : IDifferentiableDotProduct, IScalarDifferentiableFloatingPoint
{}

#define SLANG_NUMERICS_DIFFERENTIABLE_SCALAR_CONFORMANCES(TYPE)                       \
    public extension TYPE : __IScalarDifferentiableFloatingPointDotProduct       \
    {                                                                            \
        [Differentiable] [ForceInline]                                           \
        static This fromScalar(Scalar value) { return value; }                   \
                                                                                 \
        [Differentiable] [ForceInline]                                           \
        __init<TSource : __BuiltinFloatingPointType>(TSource value)              \
        {                                                                        \
            this = __differentiableNumericsConstructFromFloatingPoint<TYPE>(value); \
        }                                                                        \
        SLANG_NUMERICS_DIFFERENTIABLE_FRACTIONAL_REQUIREMENTS                         \
        SLANG_NUMERICS_DIFFERENTIABLE_FLOATING_POINT_REQUIREMENTS                     \
        [ForceInline]                                                            \
        static DifferentialPair<TYPE> forwardDifferentiateDotProduct(            \
            DifferentialPair<TYPE> left, DifferentialPair<TYPE> right)           \
        {                                                                        \
            return diffPair(                                                     \
                left.p.mul(right.p),                                             \
                left.d.mul(right.p).add(left.p.mul(right.d)));                   \
        }                                                                        \
        [ForceInline]                                                            \
        static void backwardDifferentiateDotProduct(                             \
            inout DifferentialPair<TYPE> left,                                   \
            inout DifferentialPair<TYPE> right,                                  \
            TYPE.Differential outputDifferential)                               \
        {                                                                        \
            let leftPrimal = left.p;                                             \
            let rightPrimal = right.p;                                           \
            left = diffPair(                                                     \
                leftPrimal, rightPrimal.mul(outputDifferential));                \
            right = diffPair(                                                    \
                rightPrimal, leftPrimal.mul(outputDifferential));                \
        }                                                                        \
    }                                                                            \
                                                                                 \
    public extension TYPE : IDifferentiableExponentialFunctions                 \
    {                                                                            \
        SLANG_NUMERICS_DIFFERENTIABLE_EXPONENTIAL_REQUIREMENTS                        \
    }                                                                            \
                                                                                 \
    public extension TYPE : IDifferentiableTrigonometricFunctions               \
    {                                                                            \
        SLANG_NUMERICS_DIFFERENTIABLE_TRIGONOMETRIC_REQUIREMENTS                      \
    }                                                                            \
                                                                                 \
    public extension TYPE : IDifferentiableInverseTrigonometricFunctions        \
    {                                                                            \
        SLANG_NUMERICS_DIFFERENTIABLE_INVERSE_TRIGONOMETRIC_REQUIREMENTS              \
    }                                                                            \
                                                                                 \
    public extension TYPE : IDifferentiableHyperbolicFunctions                  \
    {                                                                            \
        SLANG_NUMERICS_DIFFERENTIABLE_HYPERBOLIC_REQUIREMENTS                         \
    }                                                                            \
                                                                                 \
    public extension TYPE : IDifferentiableRootFunctions                        \
    {                                                                            \
        SLANG_NUMERICS_DIFFERENTIABLE_ROOT_REQUIREMENTS                               \
    }                                                                            \
                                                                                 \
    public extension TYPE : IDifferentiableRealOrderingFunctions                \
    {                                                                            \
        SLANG_NUMERICS_DIFFERENTIABLE_ORDERING_REQUIREMENTS                           \
    }

SLANG_NUMERICS_DIFFERENTIABLE_SCALAR_CONFORMANCES(half)
SLANG_NUMERICS_DIFFERENTIABLE_SCALAR_CONFORMANCES(float)
SLANG_NUMERICS_DIFFERENTIABLE_SCALAR_CONFORMANCES(double)

#undef SLANG_NUMERICS_DIFFERENTIABLE_SCALAR_CONFORMANCES

interface __IDifferentiableFloatingPointVectorDotProduct
    : IDifferentiableDotProduct, IDifferentiableFloatingPoint
{}

public extension<
    T : __BuiltinFloatingPointType & IScalarDifferentiableFloatingPoint,
    let N : int>
    vector<T, N> : __IDifferentiableFloatingPointVectorDotProduct
{
    [Differentiable] [ForceInline]
    static This fromScalar(Scalar value)
    {
        return __differentiableNumericsConstructVectorFromFloatingPoint<T, T, N>(value);
    }

    [Differentiable] [ForceInline]
    __init<TSource : __BuiltinFloatingPointType>(TSource value)
    {
        this = __differentiableNumericsConstructVectorFromFloatingPoint<T, TSource, N>(value);
    }

    SLANG_NUMERICS_DIFFERENTIABLE_FRACTIONAL_REQUIREMENTS
    SLANG_NUMERICS_DIFFERENTIABLE_FLOATING_POINT_REQUIREMENTS

    [ForceInline]
    static DifferentialPair<T> forwardDifferentiateDotProduct(
        DifferentialPair<This> left,
        DifferentialPair<This> right)
    {
        return fwd_diff(__differentiableNumericsDot<T, N>)(left, right);
    }

    [ForceInline]
    static void backwardDifferentiateDotProduct(
        inout DifferentialPair<This> left,
        inout DifferentialPair<This> right,
        T.Differential outputDifferential)
    {
        bwd_diff(__differentiableNumericsDot<T, N>)(left, right, outputDifferential);
    }
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableExponentialFunctions,
    let N : int>
    vector<T, N> : IDifferentiableExponentialFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_EXPONENTIAL_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableTrigonometricFunctions,
    let N : int>
    vector<T, N> : IDifferentiableTrigonometricFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_TRIGONOMETRIC_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableInverseTrigonometricFunctions,
    let N : int>
    vector<T, N> : IDifferentiableInverseTrigonometricFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_INVERSE_TRIGONOMETRIC_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableHyperbolicFunctions,
    let N : int>
    vector<T, N> : IDifferentiableHyperbolicFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_HYPERBOLIC_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableRootFunctions,
    let N : int>
    vector<T, N> : IDifferentiableRootFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_ROOT_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IScalarDifferentiableReal,
    let N : int>
    vector<T, N> : IDifferentiableRealOrderingFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_ORDERING_REQUIREMENTS
}

#define SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(METHOD, ADAPTER)       \
    [Differentiable] [ForceInline]                                              \
    This METHOD()                                                               \
    {                                                                            \
        This result;                                                             \
        [ForceUnroll] for (int row = 0; row < R; ++row)                         \
            [ForceUnroll] for (int column = 0; column < C; ++column)            \
                result[row][column] = ADAPTER(this[row][column]);                \
        return result;                                                           \
    }

#define SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_BINARY_REQUIREMENT(METHOD, ADAPTER)      \
    [Differentiable] [ForceInline]                                              \
    This METHOD(This other)                                                     \
    {                                                                            \
        This result;                                                             \
        [ForceUnroll] for (int row = 0; row < R; ++row)                         \
            [ForceUnroll] for (int column = 0; column < C; ++column)            \
                result[row][column] =                                           \
                    ADAPTER(this[row][column], other[row][column]);              \
        return result;                                                           \
    }

#define SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_FRACTIONAL_REQUIREMENTS                  \
    SLANG_NUMERICS_DIFFERENTIABLE_CORE_BINARY_REQUIREMENT(plus, add)             \
    SLANG_NUMERICS_DIFFERENTIABLE_CORE_BINARY_REQUIREMENT(minus, sub)            \
    SLANG_NUMERICS_DIFFERENTIABLE_CORE_BINARY_REQUIREMENT(multipliedBy, mul)     \
    SLANG_NUMERICS_DIFFERENTIABLE_CORE_BINARY_REQUIREMENT(dividedBy, div)        \
    SLANG_NUMERICS_DIFFERENTIABLE_CORE_UNARY_REQUIREMENT(negated, neg)           \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        absoluteValue, __differentiableNumericsAbs)                             \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        reciprocal, __differentiableNumericsRcp)

#define SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_FLOATING_POINT_REQUIREMENTS              \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        fractionalPart, __differentiableNumericsFractionalPart)                 \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_BINARY_REQUIREMENT(                          \
        remainderWhenDividedBy, __differentiableNumericsRemainder)              \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_BINARY_REQUIREMENT(                          \
        copyingSignFrom, __differentiableNumericsCopySign)

#define SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_EXPONENTIAL_REQUIREMENTS                 \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        exponential, __differentiableNumericsExp)                                     \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        exponentialWithBase2, __differentiableNumericsExp2)                          \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        exponentialWithBase10, __differentiableNumericsExp10)                        \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        logarithm, __differentiableNumericsLog)                                       \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        logarithmWithBase2, __differentiableNumericsLog2)                            \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        logarithmWithBase10, __differentiableNumericsLog10)                          \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_BINARY_REQUIREMENT(                          \
        raisedToThePowerOf, __differentiableNumericsPow)

#define SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_TRIGONOMETRIC_REQUIREMENTS               \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(sin, __differentiableNumericsSin) \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(cos, __differentiableNumericsCos) \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(tan, __differentiableNumericsTan) \
    [Differentiable] [ForceInline]                                              \
    void sincos(out This sineResult, out This cosineResult)                      \
    {                                                                            \
        [ForceUnroll] for (int row = 0; row < R; ++row)                         \
            [ForceUnroll] for (int column = 0; column < C; ++column)            \
                __differentiableNumericsSinCos(                                 \
                    this[row][column],                                           \
                    sineResult[row][column],                                     \
                    cosineResult[row][column]);                                  \
    }

#define SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_INVERSE_REQUIREMENTS                     \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(asin, __differentiableNumericsAsin) \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(acos, __differentiableNumericsAcos) \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(atan, __differentiableNumericsAtan) \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_BINARY_REQUIREMENT(atan2, __differentiableNumericsAtan2)

#define SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_HYPERBOLIC_REQUIREMENTS                  \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(sinh, __differentiableNumericsSinh) \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(cosh, __differentiableNumericsCosh) \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(tanh, __differentiableNumericsTanh) \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(asinh, __differentiableNumericsAsinh) \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(acosh, __differentiableNumericsAcosh) \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(atanh, __differentiableNumericsAtanh)

#define SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_ROOT_REQUIREMENTS                        \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        squareRoot, __differentiableNumericsSqrt)                                     \
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT(                           \
        reciprocalSquareRoot, __differentiableNumericsRsqrt)

// The extrema adapters accept a complete matrix, including its layout parameter. We therefore
// use the direct binary requirement rather than mapping the operation over scalar elements.
#define SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_ORDERING_REQUIREMENTS                    \
    SLANG_NUMERICS_DIFFERENTIABLE_BINARY_REQUIREMENT(                                 \
        minimum, __differentiableNumericsMinimum)                               \
    SLANG_NUMERICS_DIFFERENTIABLE_BINARY_REQUIREMENT(                                 \
        maximum, __differentiableNumericsMaximum)

public extension<
    T : __BuiltinFloatingPointType & IScalarDifferentiableFloatingPoint,
    let R : int,
    let C : int,
    let L : MatrixLayoutMode>
    matrix<T, R, C, L> : IDifferentiableFloatingPoint
{
    [Differentiable] [ForceInline]
    static This fromScalar(Scalar value)
    {
        return __differentiableNumericsConstructMatrixFromFloatingPoint<T, T, R, C, L>(value);
    }

    [Differentiable] [ForceInline]
    __init<TSource : __BuiltinFloatingPointType>(TSource value)
    {
        this = __differentiableNumericsConstructMatrixFromFloatingPoint<
            T, TSource, R, C, L>(value);
    }

    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_FRACTIONAL_REQUIREMENTS
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_FLOATING_POINT_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableExponentialFunctions,
    let R : int,
    let C : int,
    let L : MatrixLayoutMode>
    matrix<T, R, C, L> : IDifferentiableExponentialFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_EXPONENTIAL_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableTrigonometricFunctions,
    let R : int,
    let C : int,
    let L : MatrixLayoutMode>
    matrix<T, R, C, L> : IDifferentiableTrigonometricFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_TRIGONOMETRIC_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableInverseTrigonometricFunctions,
    let R : int,
    let C : int,
    let L : MatrixLayoutMode>
    matrix<T, R, C, L> : IDifferentiableInverseTrigonometricFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_INVERSE_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableHyperbolicFunctions,
    let R : int,
    let C : int,
    let L : MatrixLayoutMode>
    matrix<T, R, C, L> : IDifferentiableHyperbolicFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_HYPERBOLIC_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableRootFunctions,
    let R : int,
    let C : int,
    let L : MatrixLayoutMode>
    matrix<T, R, C, L> : IDifferentiableRootFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_ROOT_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IScalarDifferentiableReal,
    let R : int,
    let C : int,
    let L : MatrixLayoutMode>
    matrix<T, R, C, L> : IDifferentiableRealOrderingFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_ORDERING_REQUIREMENTS
}

// Cooperative vectors already provide differentiable core arithmetic and element access. Define
// the numerics witnesses in terms of those operations and the differentiated scalar adapters so
// that every component follows the corresponding scalar derivative.
#define SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(METHOD, ADAPTER)      \
    [Differentiable] [ForceInline] [require(cooperative_vector)]                 \
    This METHOD()                                                               \
    {                                                                            \
        This result;                                                             \
        [ForceUnroll]                                                            \
        for (int index = 0; index < N; ++index)                                 \
            result[index] = ADAPTER(this[index]);                                \
        return result;                                                           \
    }

#define SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_BINARY_REQUIREMENT(METHOD, ADAPTER)     \
    [Differentiable] [ForceInline] [require(cooperative_vector)]                 \
    This METHOD(This other)                                                     \
    {                                                                            \
        This result;                                                             \
        [ForceUnroll]                                                            \
        for (int index = 0; index < N; ++index)                                 \
            result[index] = ADAPTER(this[index], other[index]);                  \
        return result;                                                           \
    }

#define SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_CORE_BINARY_REQUIREMENT(METHOD, CORE_METHOD) \
    [Differentiable] [ForceInline] [require(cooperative_vector)]                 \
    This METHOD(This other) { return this.CORE_METHOD(other); }

#define SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_FRACTIONAL_REQUIREMENTS                \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_CORE_BINARY_REQUIREMENT(plus, add)          \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_CORE_BINARY_REQUIREMENT(minus, sub)         \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_CORE_BINARY_REQUIREMENT(multipliedBy, mul)  \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_CORE_BINARY_REQUIREMENT(dividedBy, div)     \
    [Differentiable] [ForceInline] [require(cooperative_vector)]                 \
    This negated() { return this.neg(); }                                        \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        absoluteValue, __differentiableNumericsAbs)                             \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        reciprocal, __differentiableNumericsRcp)

#define SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_EXPONENTIAL_REQUIREMENTS               \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        exponential, __differentiableNumericsExp)                              \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        exponentialWithBase2, __differentiableNumericsExp2)                    \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        exponentialWithBase10, __differentiableNumericsExp10)                  \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        logarithm, __differentiableNumericsLog)                                \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        logarithmWithBase2, __differentiableNumericsLog2)                      \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        logarithmWithBase10, __differentiableNumericsLog10)                    \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_BINARY_REQUIREMENT(                        \
        raisedToThePowerOf, __differentiableNumericsPow)

#define SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_TRIGONOMETRIC_REQUIREMENTS             \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        sin, __differentiableNumericsSin)                                      \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        cos, __differentiableNumericsCos)                                      \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        tan, __differentiableNumericsTan)                                      \
    [Differentiable] [ForceInline] [require(cooperative_vector)]                 \
    void sincos(out This sineResult, out This cosineResult)                      \
    {                                                                            \
        [ForceUnroll]                                                            \
        for (int index = 0; index < N; ++index)                                 \
            __differentiableNumericsSinCos(                                     \
                this[index], sineResult[index], cosineResult[index]);            \
    }

#define SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_INVERSE_REQUIREMENTS                   \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        asin, __differentiableNumericsAsin)                                    \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        acos, __differentiableNumericsAcos)                                    \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        atan, __differentiableNumericsAtan)                                    \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_BINARY_REQUIREMENT(                        \
        atan2, __differentiableNumericsAtan2)

#define SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_HYPERBOLIC_REQUIREMENTS                \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        sinh, __differentiableNumericsSinh)                                    \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        cosh, __differentiableNumericsCosh)                                    \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        tanh, __differentiableNumericsTanh)                                    \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        asinh, __differentiableNumericsAsinh)                                  \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        acosh, __differentiableNumericsAcosh)                                  \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        atanh, __differentiableNumericsAtanh)

#define SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_ROOT_REQUIREMENTS                      \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        squareRoot, __differentiableNumericsSqrt)                              \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT(                         \
        reciprocalSquareRoot, __differentiableNumericsRsqrt)

#define SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_ORDERING_REQUIREMENTS                  \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_BINARY_REQUIREMENT(                        \
        minimum, __differentiableNumericsMinimum)                              \
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_BINARY_REQUIREMENT(                        \
        maximum, __differentiableNumericsMaximum)

// Keep this conformance separate so it owns the differentiated `fromScalar` witness. Reusing the
// inherited `INumericShapedType` conformance would select the base, non-differentiable witness.
public extension<T : __BuiltinFloatingPointType & IScalarDifferentiableFractional, let N : int>
    CoopVec<T, N> : IDifferentiableNumericShapedType
{
    typealias Scalar = T;
    typealias Mask = vector<bool, N>;

    [Differentiable] [ForceInline] [require(cooperative_vector)]
    static This fromScalar(Scalar value)
    {
        This result;
        [ForceUnroll]
        for (int index = 0; index < N; ++index)
            result[index] = value;
        return result;
    }
}

public extension<T : __BuiltinFloatingPointType & IScalarDifferentiableFractional, let N : int>
    CoopVec<T, N> : IDifferentiableFractional
{
    [Differentiable] [ForceInline] [require(cooperative_vector)]
    __init<TSource : __BuiltinFloatingPointType>(TSource value)
    {
        this = This.fromScalar(
            __differentiableNumericsConstructFromFloatingPoint<T>(value));
    }

    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_FRACTIONAL_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableExponentialFunctions,
    let N : int>
    CoopVec<T, N> : IDifferentiableExponentialFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_EXPONENTIAL_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableTrigonometricFunctions,
    let N : int>
    CoopVec<T, N> : IDifferentiableTrigonometricFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_TRIGONOMETRIC_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableInverseTrigonometricFunctions,
    let N : int>
    CoopVec<T, N> : IDifferentiableInverseTrigonometricFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_INVERSE_REQUIREMENTS
}

public extension<
    T : __BuiltinFloatingPointType & IDifferentiableHyperbolicFunctions,
    let N : int>
    CoopVec<T, N> : IDifferentiableHyperbolicFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_HYPERBOLIC_REQUIREMENTS
}

public extension<T : __BuiltinFloatingPointType & IDifferentiableRootFunctions, let N : int>
    CoopVec<T, N> : IDifferentiableRootFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_ROOT_REQUIREMENTS
}

public extension<T : __BuiltinFloatingPointType & IScalarDifferentiableReal, let N : int>
    CoopVec<T, N> : IDifferentiableRealOrderingFunctions
{
    SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_ORDERING_REQUIREMENTS
}

#undef SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_ORDERING_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_ROOT_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_HYPERBOLIC_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_INVERSE_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_TRIGONOMETRIC_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_EXPONENTIAL_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_FRACTIONAL_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_CORE_BINARY_REQUIREMENT
#undef SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_BINARY_REQUIREMENT
#undef SLANG_NUMERICS_DIFFERENTIABLE_COOPVEC_UNARY_REQUIREMENT

#undef SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_ORDERING_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_ROOT_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_HYPERBOLIC_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_INVERSE_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_TRIGONOMETRIC_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_EXPONENTIAL_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_FLOATING_POINT_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_FRACTIONAL_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_BINARY_REQUIREMENT
#undef SLANG_NUMERICS_DIFFERENTIABLE_MATRIX_UNARY_REQUIREMENT
#undef SLANG_NUMERICS_DIFFERENTIABLE_ORDERING_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_ROOT_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_HYPERBOLIC_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_INVERSE_TRIGONOMETRIC_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_TRIGONOMETRIC_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_EXPONENTIAL_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_FLOATING_POINT_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_FRACTIONAL_REQUIREMENTS
#undef SLANG_NUMERICS_DIFFERENTIABLE_CORE_BINARY_REQUIREMENT
#undef SLANG_NUMERICS_DIFFERENTIABLE_CORE_UNARY_REQUIREMENT
#undef SLANG_NUMERICS_DIFFERENTIABLE_BINARY_REQUIREMENT
#undef SLANG_NUMERICS_DIFFERENTIABLE_UNARY_REQUIREMENT
