implementing differentiable;

/// Supports differentiable construction of a scalar or shaped numeric value from its logical
/// scalar.
public interface IDifferentiableNumericShapedType : INumericShapedType, IDifferentiable
{
    __constraint Scalar : IDifferentiable;

    /// Constructs a value whose every logical component is `value` and propagates derivatives
    /// through that scalar repetition.
    [Differentiable]
    static This fromScalar(Scalar value);
}

/// Supports a differentiable dot product between values with the same logical shape.
///
/// Conforming types provide first-order forward- and backward-mode rules that the generic `dot`
/// overload uses during automatic differentiation.
public interface IDifferentiableDotProduct : IDotProduct, IDifferentiableNumericShapedType
{
    __constraint Scalar : IDifferentiable;

    // Slang cannot currently associate custom derivative declarations with an interface
    // requirement. Keep the JVP and VJP as explicit requirements, and associate them with the
    // user-facing free-function wrapper instead.

    /// Evaluates the dot product and its forward derivative for `left` and `right`.
    static DifferentialPair<Scalar> forwardDifferentiateDotProduct(
        DifferentialPair<This> left,
        DifferentialPair<This> right);

    /// Propagates `outputDifferential` backward through the dot product to `left` and `right`.
    static void backwardDifferentiateDotProduct(
        inout DifferentialPair<This> left,
        inout DifferentialPair<This> right,
        Scalar.Differential outputDifferential);
}

/// Supports differentiable signed arithmetic with division.
///
/// This interface refines the representation-independent `IFractional` contract without making
/// differentiability a cost of using that base interface. It re-declares the operations that Slang
/// can differentiate for builtin floating-point scalar and shaped types.
public interface IDifferentiableFractional : IFractional, IDifferentiableNumericShapedType
{
    __constraint Scalar : IScalarDifferentiableFractional;

    /// Constructs a value from any builtin floating-point representation.
    [Differentiable]
    __init<TSource : IBuiltinScalarFloatingPointType>(TSource value);

    [Differentiable]
    This plus(This other);

    [Differentiable]
    This minus(This other);

    [Differentiable]
    This multipliedBy(This other);

    [Differentiable]
    This dividedBy(This other);

    [Differentiable]
    This negated();

    [Differentiable]
    This absoluteValue();

    [Differentiable]
    This reciprocal();
}

/// Scalar refinement of `IDifferentiableFractional`.
public interface IScalarDifferentiableFractional
    : IDifferentiableFractional, IScalarFractional
{
}

/// Supports the differentiable subset of floating-point representation operations.
///
/// Operations such as `floor`, `round`, and classification remain available through
/// `IFloatingPoint`, but this interface does not claim they are differentiable.
public interface IDifferentiableFloatingPoint : IFloatingPoint, IDifferentiableFractional
{
    __constraint Scalar : IScalarDifferentiableFloatingPoint;

    [Differentiable]
    This fractionalPart();

    [Differentiable]
    This remainderWhenDividedBy(This divisor);

    [Differentiable]
    This copyingSignFrom(This signSource);
}

/// Scalar refinement of `IDifferentiableFloatingPoint`.
public interface IScalarDifferentiableFloatingPoint
    : IDifferentiableFloatingPoint, IScalarFloatingPoint, IScalarDifferentiableFractional
{
}

/// Supports differentiable exponential, logarithmic, and power functions.
public interface IDifferentiableExponentialFunctions : IExponentialFunctions, IDifferentiable
{
    [Differentiable]
    This exponential();

    [Differentiable]
    This exponentialWithBase2();

    [Differentiable]
    This exponentialWithBase10();

    [Differentiable]
    This logarithm();

    [Differentiable]
    This logarithmWithBase2();

    [Differentiable]
    This logarithmWithBase10();

    [Differentiable]
    This raisedToThePowerOf(This exponent);
}

/// Supports differentiable trigonometric functions.
public interface IDifferentiableTrigonometricFunctions : ITrigonometricFunctions, IDifferentiable
{
    [Differentiable]
    This sin();

    [Differentiable]
    This cos();

    [Differentiable]
    This tan();

    [Differentiable]
    void sincos(out This sineResult, out This cosineResult);
}

/// Supports differentiable inverse trigonometric functions.
public interface IDifferentiableInverseTrigonometricFunctions
    : IInverseTrigonometricFunctions, IDifferentiable
{
    [Differentiable]
    This asin();

    [Differentiable]
    This acos();

    [Differentiable]
    This atan();

    [Differentiable]
    This atan2(This denominator);
}

/// Supports differentiable hyperbolic and inverse hyperbolic functions.
public interface IDifferentiableHyperbolicFunctions : IHyperbolicFunctions, IDifferentiable
{
    [Differentiable]
    This sinh();

    [Differentiable]
    This cosh();

    [Differentiable]
    This tanh();

    [Differentiable]
    This asinh();

    [Differentiable]
    This acosh();

    [Differentiable]
    This atanh();
}

/// Supports differentiable square-root functions.
public interface IDifferentiableRootFunctions : IRootFunctions, IDifferentiable
{
    [Differentiable]
    This squareRoot();

    [Differentiable]
    This reciprocalSquareRoot();
}

/// Supports the differentiable variants of all elementary-function families.
public typealias IDifferentiableElementaryFunctions =
    IDifferentiableExponentialFunctions &
    IDifferentiableTrigonometricFunctions &
    IDifferentiableInverseTrigonometricFunctions &
    IDifferentiableHyperbolicFunctions &
    IDifferentiableRootFunctions;

/// Scalar refinement of `IDifferentiableElementaryFunctions`.
public typealias IScalarDifferentiableElementaryFunctions =
    IDifferentiableElementaryFunctions & IScalarShapedType;

/// Supports differentiable operations that depend on a real ordering.
///
/// `step` remains available through `IRealOrderingFunctions` without a differentiability claim.
public interface IDifferentiableRealOrderingFunctions : IRealOrderingFunctions, IDifferentiable
{
    [Differentiable]
    This minimum(This other);

    [Differentiable]
    This maximum(This other);
}

/// Supports differentiable fractional arithmetic, elementary functions, and real-ordering
/// operations.
public typealias IDifferentiableReal =
    IDifferentiableFractional &
    IDifferentiableElementaryFunctions &
    IComponentwiseOrdered &
    IDifferentiableRealOrderingFunctions;

/// Scalar refinement of `IDifferentiableReal`.
public typealias IScalarDifferentiableReal =
    IDifferentiableReal & IScalarDifferentiableFractional & IPartiallyOrdered;
