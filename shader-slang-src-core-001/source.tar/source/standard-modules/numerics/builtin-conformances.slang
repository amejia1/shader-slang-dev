implementing numerics;

// These conformances are owned by `slang.numerics`, so importing this experimental module opts the
// builtin scalar types into its public numeric hierarchy without adding a dependency from `core`.
public extension bool : IBooleanMask
{
    [__unsafeForceInlineEarly] This logicalNot() { return !this; }
    [__unsafeForceInlineEarly] This logicalAnd(This other) { return this && other; }
    [__unsafeForceInlineEarly] This logicalOr(This other) { return this || other; }
    [__unsafeForceInlineEarly] bool any() { return this; }
    [__unsafeForceInlineEarly] bool all() { return this; }
}

// The nominal joins below let each conformance publish one unambiguous set of Scalar, Mask, and
// fromScalar witnesses for interface branches that share INumericShapedType. Equivalent
// conjunction aliases currently fail during conformance checking; see #12874.
interface __IScalarNumericDotProduct : IDotProduct, IScalarNumeric {}

#define SLANG_NUMERICS_SCALAR_CONFORMANCE(TYPE)                                       \
    public extension TYPE                                                       \
        : IComponentwiseOrdered, IPartiallyOrdered, __IScalarNumericDotProduct  \
    {                                                                            \
        typealias Scalar = TYPE;                                                 \
        typealias Mask = bool;                                                   \
                                                                                 \
        [__unsafeForceInlineEarly]                                               \
        static This fromScalar(Scalar value) { return value; }                   \
        [__unsafeForceInlineEarly]                                               \
        __init<TSource : __BuiltinIntegerType>(TSource value)                    \
        {                                                                        \
            this = __numericsBuiltinConstructFromInteger<TYPE>(value);           \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        static This zero() { return This(0); }                                   \
        [__unsafeForceInlineEarly]                                               \
        static This one() { return This(1); }                                    \
        [__unsafeForceInlineEarly]                                               \
        bool isEqualTo(This other)                                               \
        {                                                                        \
            return __numericsBuiltinEqual(this, other);                          \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        bool isLessThan(This other)                                              \
        {                                                                        \
            return __numericsBuiltinLess(this, other);                           \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        bool isLessThanOrEqualTo(This other)                                     \
        {                                                                        \
            return __numericsBuiltinLessEqual(this, other);                      \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        This plus(This other) { return this + other; }                           \
        [__unsafeForceInlineEarly]                                               \
        This minus(This other) { return this - other; }                          \
        [__unsafeForceInlineEarly]                                               \
        This multipliedBy(This other) { return this * other; }                   \
        [__unsafeForceInlineEarly]                                               \
        Scalar dotProductWith(This other) { return this * other; }               \
    }

SLANG_NUMERICS_SCALAR_CONFORMANCE(int8_t)
SLANG_NUMERICS_SCALAR_CONFORMANCE(int16_t)
SLANG_NUMERICS_SCALAR_CONFORMANCE(int)
SLANG_NUMERICS_SCALAR_CONFORMANCE(int64_t)
SLANG_NUMERICS_SCALAR_CONFORMANCE(intptr_t)
SLANG_NUMERICS_SCALAR_CONFORMANCE(uint8_t)
SLANG_NUMERICS_SCALAR_CONFORMANCE(uint16_t)
SLANG_NUMERICS_SCALAR_CONFORMANCE(uint)
SLANG_NUMERICS_SCALAR_CONFORMANCE(uint64_t)
SLANG_NUMERICS_SCALAR_CONFORMANCE(uintptr_t)
SLANG_NUMERICS_SCALAR_CONFORMANCE(half)
SLANG_NUMERICS_SCALAR_CONFORMANCE(float)
SLANG_NUMERICS_SCALAR_CONFORMANCE(double)

#undef SLANG_NUMERICS_SCALAR_CONFORMANCE

#define SLANG_NUMERICS_SIGNED_INTEGER_CONFORMANCE(TYPE)                               \
    public extension TYPE : IScalarSignedNumeric                                \
    {                                                                            \
        [__unsafeForceInlineEarly]                                               \
        This negated() { return -this; }                                         \
        [__unsafeForceInlineEarly]                                               \
        This absoluteValue() { return __numericInterfaceBuiltinAbs(this); }      \
    }

SLANG_NUMERICS_SIGNED_INTEGER_CONFORMANCE(int8_t)
SLANG_NUMERICS_SIGNED_INTEGER_CONFORMANCE(int16_t)
SLANG_NUMERICS_SIGNED_INTEGER_CONFORMANCE(int)
SLANG_NUMERICS_SIGNED_INTEGER_CONFORMANCE(int64_t)
SLANG_NUMERICS_SIGNED_INTEGER_CONFORMANCE(intptr_t)

#undef SLANG_NUMERICS_SIGNED_INTEGER_CONFORMANCE

#define SLANG_NUMERICS_INTEGER_CONFORMANCE(TYPE)                                      \
    public extension TYPE : ITotallyOrdered, INumericExtrema                     \
    {                                                                            \
        [__unsafeForceInlineEarly]                                               \
        This minimum(This other)                                                 \
        {                                                                        \
            return __numericsBuiltinMinimum(this, other);                       \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        This maximum(This other)                                                 \
        {                                                                        \
            return __numericsBuiltinMaximum(this, other);                       \
        }                                                                        \
    }                                                                            \
                                                                                 \
    public extension TYPE : IScalarIntegerType                                  \
    {                                                                            \
        typealias ShiftAmount = int;                                             \
                                                                                 \
        [__unsafeForceInlineEarly]                                               \
        This quotientWhenDividedBy(This divisor)                                 \
        {                                                                        \
            return __numericsBuiltinIntegerDivide(this, divisor);                \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        This remainderWhenDividedBy(This divisor)                                \
        {                                                                        \
            return __numericsBuiltinIntegerRemainder(this, divisor);             \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        This bitwiseAnd(This other)                                              \
        {                                                                        \
            return __numericsBuiltinBitAnd(this, other);                         \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        This bitwiseOr(This other)                                               \
        {                                                                        \
            return __numericsBuiltinBitOr(this, other);                          \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        This bitwiseXor(This other)                                              \
        {                                                                        \
            return __numericsBuiltinBitXor(this, other);                         \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        This bitwiseNot() { return __numericsBuiltinBitNot(this); }              \
        [__unsafeForceInlineEarly]                                               \
        This shiftedLeftBy(int amount)                                           \
        {                                                                        \
            return __numericsBuiltinShiftLeft(this, amount);                     \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        This shiftedRightBy(int amount)                                          \
        {                                                                        \
            return __numericsBuiltinShiftRight(this, amount);                    \
        }                                                                        \
    }

SLANG_NUMERICS_INTEGER_CONFORMANCE(int8_t)
SLANG_NUMERICS_INTEGER_CONFORMANCE(int16_t)
SLANG_NUMERICS_INTEGER_CONFORMANCE(int)
SLANG_NUMERICS_INTEGER_CONFORMANCE(int64_t)
SLANG_NUMERICS_INTEGER_CONFORMANCE(intptr_t)
SLANG_NUMERICS_INTEGER_CONFORMANCE(uint8_t)
SLANG_NUMERICS_INTEGER_CONFORMANCE(uint16_t)
SLANG_NUMERICS_INTEGER_CONFORMANCE(uint)
SLANG_NUMERICS_INTEGER_CONFORMANCE(uint64_t)
SLANG_NUMERICS_INTEGER_CONFORMANCE(uintptr_t)

#undef SLANG_NUMERICS_INTEGER_CONFORMANCE

#define SLANG_NUMERICS_SIGNED_INTEGER_REFINEMENT(TYPE)                                \
    public extension TYPE : IScalarSignedIntegerType                            \
    {}

SLANG_NUMERICS_SIGNED_INTEGER_REFINEMENT(int8_t)
SLANG_NUMERICS_SIGNED_INTEGER_REFINEMENT(int16_t)
SLANG_NUMERICS_SIGNED_INTEGER_REFINEMENT(int)
SLANG_NUMERICS_SIGNED_INTEGER_REFINEMENT(int64_t)
SLANG_NUMERICS_SIGNED_INTEGER_REFINEMENT(intptr_t)

#undef SLANG_NUMERICS_SIGNED_INTEGER_REFINEMENT

#define SLANG_NUMERICS_UNSIGNED_INTEGER_REFINEMENT(TYPE)                              \
    public extension TYPE : IScalarUnsignedIntegerType                          \
    {}

SLANG_NUMERICS_UNSIGNED_INTEGER_REFINEMENT(uint8_t)
SLANG_NUMERICS_UNSIGNED_INTEGER_REFINEMENT(uint16_t)
SLANG_NUMERICS_UNSIGNED_INTEGER_REFINEMENT(uint)
SLANG_NUMERICS_UNSIGNED_INTEGER_REFINEMENT(uint64_t)
SLANG_NUMERICS_UNSIGNED_INTEGER_REFINEMENT(uintptr_t)

#undef SLANG_NUMERICS_UNSIGNED_INTEGER_REFINEMENT

#define SLANG_NUMERICS_FRACTIONAL_SCALAR_CONFORMANCE(TYPE)                            \
    public extension TYPE : IScalarFractional                                   \
    {                                                                            \
        [__unsafeForceInlineEarly]                                               \
        __init<TSource : __BuiltinFloatingPointType>(TSource value)              \
        {                                                                        \
            this = __numericsBuiltinConstructFromFloatingPoint<TYPE>(value);     \
        }                                                                        \
        [__unsafeForceInlineEarly]                                               \
        This plus(This other) { return this + other; }                           \
        [__unsafeForceInlineEarly]                                               \
        This minus(This other) { return this - other; }                          \
        [__unsafeForceInlineEarly]                                               \
        This multipliedBy(This other) { return this * other; }                   \
        [__unsafeForceInlineEarly]                                               \
        This dividedBy(This other) { return this / other; }                      \
        [__unsafeForceInlineEarly]                                               \
        This negated() { return -this; }                                         \
        [__unsafeForceInlineEarly]                                               \
        This absoluteValue() { return __numericInterfaceBuiltinAbs(this); }      \
        [__unsafeForceInlineEarly]                                               \
        This reciprocal() { return __numericInterfaceBuiltinRcp(this); }         \
    }

SLANG_NUMERICS_FRACTIONAL_SCALAR_CONFORMANCE(half)
SLANG_NUMERICS_FRACTIONAL_SCALAR_CONFORMANCE(float)
SLANG_NUMERICS_FRACTIONAL_SCALAR_CONFORMANCE(double)

#undef SLANG_NUMERICS_FRACTIONAL_SCALAR_CONFORMANCE

public extension<let N : int> vector<bool, N> : IBooleanMask
{
    [__unsafeForceInlineEarly]
    This logicalNot()
    {
        This result;
        [ForceUnroll]
        for (int index = 0; index < N; ++index)
            result[index] = !this[index];
        return result;
    }

    [__unsafeForceInlineEarly]
    This logicalAnd(This other)
    {
        This result;
        [ForceUnroll]
        for (int index = 0; index < N; ++index)
            result[index] = this[index] && other[index];
        return result;
    }

    [__unsafeForceInlineEarly]
    This logicalOr(This other)
    {
        This result;
        [ForceUnroll]
        for (int index = 0; index < N; ++index)
            result[index] = this[index] || other[index];
        return result;
    }

    [__unsafeForceInlineEarly] bool any() { return __numericsBuiltinAny(this); }
    [__unsafeForceInlineEarly] bool all() { return __numericsBuiltinAll(this); }
}

public extension<let R : int, let C : int, let L : MatrixLayoutMode>
    matrix<bool, R, C, L> : IBooleanMask
{
    [__unsafeForceInlineEarly]
    This logicalNot()
    {
        This result;
        [ForceUnroll]
        for (int row = 0; row < R; ++row)
        {
            [ForceUnroll]
            for (int column = 0; column < C; ++column)
                result[row][column] = !this[row][column];
        }
        return result;
    }

    [__unsafeForceInlineEarly]
    This logicalAnd(This other)
    {
        This result;
        [ForceUnroll]
        for (int row = 0; row < R; ++row)
        {
            [ForceUnroll]
            for (int column = 0; column < C; ++column)
                result[row][column] = this[row][column] && other[row][column];
        }
        return result;
    }

    [__unsafeForceInlineEarly]
    This logicalOr(This other)
    {
        This result;
        [ForceUnroll]
        for (int row = 0; row < R; ++row)
        {
            [ForceUnroll]
            for (int column = 0; column < C; ++column)
                result[row][column] = this[row][column] || other[row][column];
        }
        return result;
    }

    [__unsafeForceInlineEarly]
    bool any()
    {
        return __numericsBuiltinAny(this);
    }

    [__unsafeForceInlineEarly]
    bool all()
    {
        return __numericsBuiltinAll(this);
    }
}

// This extension owns the common shape witnesses for every vector whose element satisfies the
// builtin arithmetic dispatch marker and scalar numeric contract. The conjunction is spelled out
// deliberately so that this dot-product conformance does not inherit unrelated capabilities if a
// broader public alias gains more requirements.
//
// Unlike the scalar conformances above, vectors publish `IDotProduct` separately instead of joining
// it with each narrower numeric refinement. All extensions on the same `vector<T, N>` contribute to
// one member set, so the integer and floating-point refinements below can satisfy their inherited
// Scalar, Mask, and fromScalar requirements with the witnesses published here. Giving each
// refinement a parallel joined conformance and another copy of those witnesses would instead
// recreate the ambiguity tracked by #12874.
public extension<T : __BuiltinArithmeticType & IScalarNumeric, let N : int>
    vector<T, N> : IDotProduct
{
    typealias Scalar = T;
    typealias Mask = vector<bool, N>;

    [__unsafeForceInlineEarly] static This fromScalar(Scalar value) { return This(value); }
    [__unsafeForceInlineEarly]
    Scalar dotProductWith(This other) { return __numericsBuiltinDot(this, other); }
}

public extension<T : __BuiltinIntegerType & IScalarIntegerType, let N : int>
    vector<T, N> : IIntegerType, INumericExtrema
{
    typealias ShiftAmount = vector<int, N>;

    [__unsafeForceInlineEarly]
    __init<TSource : __BuiltinIntegerType>(TSource value)
    {
        this = This.fromScalar(__numericsBuiltinConstructFromInteger<T>(value));
    }
    [__unsafeForceInlineEarly] static This zero() { return This(Scalar.zero()); }
    [__unsafeForceInlineEarly] static This one() { return This(Scalar.one()); }
    [__unsafeForceInlineEarly]
    Mask isEqualTo(This other) { return __numericsBuiltinEqual(this, other); }
    [__unsafeForceInlineEarly]
    Mask isLessThan(This other) { return __numericsBuiltinLess(this, other); }
    [__unsafeForceInlineEarly]
    Mask isLessThanOrEqualTo(This other)
    {
        return __numericsBuiltinLessEqual(this, other);
    }
    [__unsafeForceInlineEarly]
    This plus(This other) { return this.add(other); }
    [__unsafeForceInlineEarly]
    This minus(This other) { return this.sub(other); }
    [__unsafeForceInlineEarly]
    This multipliedBy(This other) { return this.mul(other); }
    [__unsafeForceInlineEarly]
    This minimum(This other) { return __numericsBuiltinMinimum(this, other); }
    [__unsafeForceInlineEarly]
    This maximum(This other) { return __numericsBuiltinMaximum(this, other); }
    [__unsafeForceInlineEarly]
    This quotientWhenDividedBy(This divisor)
    {
        return __numericsBuiltinIntegerDivide(this, divisor);
    }
    [__unsafeForceInlineEarly]
    This remainderWhenDividedBy(This divisor)
    {
        return __numericsBuiltinIntegerRemainder(this, divisor);
    }
    [__unsafeForceInlineEarly]
    This bitwiseAnd(This other) { return __numericsBuiltinBitAnd(this, other); }
    [__unsafeForceInlineEarly]
    This bitwiseOr(This other) { return __numericsBuiltinBitOr(this, other); }
    [__unsafeForceInlineEarly]
    This bitwiseXor(This other) { return __numericsBuiltinBitXor(this, other); }
    [__unsafeForceInlineEarly]
    This bitwiseNot() { return __numericsBuiltinBitNot(this); }
    [__unsafeForceInlineEarly]
    This shiftedLeftBy(ShiftAmount amount)
    {
        return __numericsBuiltinShiftLeft(this, amount);
    }
    [__unsafeForceInlineEarly]
    This shiftedRightBy(ShiftAmount amount)
    {
        return __numericsBuiltinShiftRight(this, amount);
    }
}

public extension<
    T : __BuiltinIntegerType & IScalarIntegerType,
    let R : int,
    let C : int,
    let L : MatrixLayoutMode> matrix<T, R, C, L> : INumericExtrema
{
    [__unsafeForceInlineEarly]
    This minimum(This other) { return __numericsBuiltinMinimum(this, other); }
    [__unsafeForceInlineEarly]
    This maximum(This other) { return __numericsBuiltinMaximum(this, other); }
}

public extension<
    T : __BuiltinIntegerType & __BuiltinSignedArithmeticType & IScalarSignedIntegerType,
    let N : int>
    vector<T, N> : ISignedIntegerType
{
    [__unsafeForceInlineEarly]
    This negated() { return this.neg(); }
    [__unsafeForceInlineEarly]
    This absoluteValue() { return __numericInterfaceBuiltinAbs(this); }
}

public extension<T : __BuiltinIntegerType & IScalarUnsignedIntegerType, let N : int>
    vector<T, N> : IUnsignedIntegerType
{}

public extension<T : __BuiltinFloatingPointType & IScalarFractional, let N : int>
    vector<T, N> : IComponentwiseOrdered
{
    [__unsafeForceInlineEarly]
    Mask isEqualTo(This other) { return __numericsBuiltinEqual(this, other); }
    [__unsafeForceInlineEarly]
    Mask isLessThan(This other) { return __numericsBuiltinLess(this, other); }
    [__unsafeForceInlineEarly]
    Mask isLessThanOrEqualTo(This other)
    {
        return __numericsBuiltinLessEqual(this, other);
    }
}

public extension<T : __BuiltinFloatingPointType & IScalarFractional, let N : int>
    vector<T, N> : IFractional
{
    [__unsafeForceInlineEarly]
    __init<TSource : __BuiltinIntegerType>(TSource value)
    {
        this = This.fromScalar(__numericsBuiltinConstructFromInteger<T>(value));
    }
    [__unsafeForceInlineEarly]
    __init<TSource : __BuiltinFloatingPointType>(TSource value)
    {
        this = This.fromScalar(__numericsBuiltinConstructFromFloatingPoint<T>(value));
    }
    [__unsafeForceInlineEarly] static This zero() { return This(T.zero()); }
    [__unsafeForceInlineEarly] static This one() { return This(T.one()); }
    [__unsafeForceInlineEarly]
    This plus(This other) { return this.add(other); }
    [__unsafeForceInlineEarly]
    This minus(This other) { return this.sub(other); }
    [__unsafeForceInlineEarly]
    This multipliedBy(This other) { return this.mul(other); }
    [__unsafeForceInlineEarly]
    This dividedBy(This other) { return this.div(other); }
    [__unsafeForceInlineEarly]
    This negated() { return this.neg(); }
    [__unsafeForceInlineEarly]
    This absoluteValue() { return __numericInterfaceBuiltinAbs(this); }
    [__unsafeForceInlineEarly]
    This reciprocal() { return __numericInterfaceBuiltinRcp(this); }
}

public extension<
    T : __BuiltinFloatingPointType & IScalarFractional,
    let R : int,
    let C : int,
    let L : MatrixLayoutMode>
    matrix<T, R, C, L> : IComponentwiseOrdered
{
    typealias Scalar = T;
    typealias Mask = matrix<bool, R, C, L>;

    [__unsafeForceInlineEarly] static This fromScalar(Scalar value) { return This(value); }

    [__unsafeForceInlineEarly]
    Mask isEqualTo(This other)
    {
        Mask result;
        [ForceUnroll]
        for (int row = 0; row < R; ++row)
        {
            [ForceUnroll]
            for (int column = 0; column < C; ++column)
            {
                result[row][column] =
                    __numericsBuiltinEqual(this[row][column], other[row][column]);
            }
        }
        return result;
    }

    [__unsafeForceInlineEarly]
    Mask isLessThan(This other)
    {
        Mask result;
        [ForceUnroll]
        for (int row = 0; row < R; ++row)
        {
            [ForceUnroll]
            for (int column = 0; column < C; ++column)
            {
                result[row][column] =
                    __numericsBuiltinLess(this[row][column], other[row][column]);
            }
        }
        return result;
    }

    [__unsafeForceInlineEarly]
    Mask isLessThanOrEqualTo(This other)
    {
        Mask result;
        [ForceUnroll]
        for (int row = 0; row < R; ++row)
        {
            [ForceUnroll]
            for (int column = 0; column < C; ++column)
            {
                result[row][column] =
                    __numericsBuiltinLessEqual(this[row][column], other[row][column]);
            }
        }
        return result;
    }
}

public extension<
    T : __BuiltinFloatingPointType & IScalarFractional,
    let R : int,
    let C : int,
    let L : MatrixLayoutMode>
    matrix<T, R, C, L> : IFractional
{
    [__unsafeForceInlineEarly]
    __init<TSource : __BuiltinIntegerType>(TSource value)
    {
        this = This.fromScalar(__numericsBuiltinConstructFromInteger<T>(value));
    }
    [__unsafeForceInlineEarly]
    __init<TSource : __BuiltinFloatingPointType>(TSource value)
    {
        this = This.fromScalar(__numericsBuiltinConstructFromFloatingPoint<T>(value));
    }
    [__unsafeForceInlineEarly] static This zero() { return This(T.zero()); }
    [__unsafeForceInlineEarly] static This one() { return This(T.one()); }

    [__unsafeForceInlineEarly]
    This plus(This other) { return this.add(other); }
    [__unsafeForceInlineEarly]
    This minus(This other) { return this.sub(other); }
    [__unsafeForceInlineEarly]
    This multipliedBy(This other) { return this.mul(other); }
    [__unsafeForceInlineEarly]
    This dividedBy(This other) { return this.div(other); }
    [__unsafeForceInlineEarly]
    This negated() { return this.neg(); }

    [__unsafeForceInlineEarly]
    This absoluteValue()
    {
        This result;
        [ForceUnroll]
        for (int row = 0; row < R; ++row)
        {
            [ForceUnroll]
            for (int column = 0; column < C; ++column)
                result[row][column] = __numericInterfaceBuiltinAbs(this[row][column]);
        }
        return result;
    }

    [__unsafeForceInlineEarly]
    This reciprocal()
    {
        This result;
        [ForceUnroll]
        for (int row = 0; row < R; ++row)
        {
            [ForceUnroll]
            for (int column = 0; column < C; ++column)
                result[row][column] = __numericInterfaceBuiltinRcp(this[row][column]);
        }
        return result;
    }
}
