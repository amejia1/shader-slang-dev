// Copyright (c) 2017 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Tests validation rules of GLSL.450.std and OpenCL.std extended instructions.
// Doesn't test OpenCL.std vector size 2, 3, 4, 8 or 16 rules (not supported
// by standard SPIR-V).

#include <sstream>
#include <string>
#include <vector>

#include "gmock/gmock.h"
#include "spirv-tools/libspirv.h"
#include "spirv/unified1/NonSemanticShaderDebugInfo.h"
#include "spirv/unified1/NonSemanticShaderDebugInfo100.h"
#include "test/unit_spirv.h"
#include "test/val/val_fixtures.h"

// Verify that the frozen NonSemanticShaderDebugInfo100.h opcode values match
// the version-agnostic NonSemanticShaderDebugInfo.h values. The two headers
// use different enum type names but must have identical opcode numbers.
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugInfoNone) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugInfoNone));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugCompilationUnit) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugCompilationUnit));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeBasic) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeBasic));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypePointer) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypePointer));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeQualifier) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeQualifier));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeArray) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeArray));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeVector) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeVector));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypedef) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypedef));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeFunction) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeFunction));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeEnum) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeEnum));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeComposite) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeComposite));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeMember) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeMember));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeInheritance) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeInheritance));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypePtrToMember) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypePtrToMember));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeTemplate) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeTemplate));
static_assert(static_cast<uint32_t>(
                  NonSemanticShaderDebugInfo100DebugTypeTemplateParameter) ==
              static_cast<uint32_t>(
                  NonSemanticShaderDebugInfoDebugTypeTemplateParameter));
static_assert(
    static_cast<uint32_t>(
        NonSemanticShaderDebugInfo100DebugTypeTemplateTemplateParameter) ==
    static_cast<uint32_t>(
        NonSemanticShaderDebugInfoDebugTypeTemplateTemplateParameter));
static_assert(
    static_cast<uint32_t>(
        NonSemanticShaderDebugInfo100DebugTypeTemplateParameterPack) ==
    static_cast<uint32_t>(
        NonSemanticShaderDebugInfoDebugTypeTemplateParameterPack));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugGlobalVariable) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugGlobalVariable));
static_assert(
    static_cast<uint32_t>(
        NonSemanticShaderDebugInfo100DebugFunctionDeclaration) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugFunctionDeclaration));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugFunction) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugFunction));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugLexicalBlock) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugLexicalBlock));
static_assert(
    static_cast<uint32_t>(
        NonSemanticShaderDebugInfo100DebugLexicalBlockDiscriminator) ==
    static_cast<uint32_t>(
        NonSemanticShaderDebugInfoDebugLexicalBlockDiscriminator));
static_assert(static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugScope) ==
              static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugScope));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugNoScope) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugNoScope));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugInlinedAt) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugInlinedAt));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugLocalVariable) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugLocalVariable));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugInlinedVariable) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugInlinedVariable));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugDeclare) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugDeclare));
static_assert(static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugValue) ==
              static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugValue));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugOperation) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugOperation));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugExpression) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugExpression));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugMacroDef) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugMacroDef));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugMacroUndef) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugMacroUndef));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugImportedEntity) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugImportedEntity));
static_assert(static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugSource) ==
              static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugSource));
static_assert(
    static_cast<uint32_t>(
        NonSemanticShaderDebugInfo100DebugFunctionDefinition) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugFunctionDefinition));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugSourceContinued) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugSourceContinued));
static_assert(static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugLine) ==
              static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugLine));
static_assert(static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugNoLine) ==
              static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugNoLine));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugBuildIdentifier) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugBuildIdentifier));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugStoragePath) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugStoragePath));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugEntryPoint) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugEntryPoint));
static_assert(
    static_cast<uint32_t>(NonSemanticShaderDebugInfo100DebugTypeMatrix) ==
    static_cast<uint32_t>(NonSemanticShaderDebugInfoDebugTypeMatrix));

namespace spvtools {
namespace val {
namespace {

using ::testing::Eq;
using ::testing::HasSubstr;
using ::testing::Not;

using ValidateOldDebugInfo = spvtest::ValidateBase<std::string>;
using ValidateOpenCL100DebugInfo = spvtest::ValidateBase<std::string>;
using ValidateXDebugInfo = spvtest::ValidateBase<std::string>;
using ValidateLocalDebugInfoOutOfFunction = spvtest::ValidateBase<std::string>;
using ValidateOpenCL100DebugInfoDebugTypedef =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugTypedef =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugTypeEnum =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugTypeEnum =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugTypeComposite =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugTypeComposite =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugTypeMember =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugTypeMember =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugTypeInheritance =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugFunction =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugFunction =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugFunctionDeclaration =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugFunctionDeclaration =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugLexicalBlock =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugLexicalBlock =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugLocalVariable =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugLocalVariable =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugGlobalVariable =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugGlobalVariable =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugDeclare =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugDeclare =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateOpenCL100DebugInfoDebugValue =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfoDebugValue =
    spvtest::ValidateBase<std::pair<std::string, std::string>>;
using ValidateVulkan100DebugInfo = spvtest::ValidateBase<std::string>;
using ValidateVulkan101DebugInfo = spvtest::ValidateBase<std::string>;

const static std::string shader_extension_100 = R"(
OpExtension "SPV_KHR_non_semantic_info"
%DbgExt = OpExtInstImport "NonSemantic.Shader.DebugInfo.100"
)";

const static std::string shader_extension_101 = R"(
OpExtension "SPV_KHR_non_semantic_info"
%DbgExt = OpExtInstImport "NonSemantic.Shader.DebugInfo.101"
)";

// Extension string for a future NSDI version; exercises forward-compatibility.
const static std::string shader_extension_9999 = R"(
OpExtension "SPV_KHR_non_semantic_info"
%DbgExt = OpExtInstImport "NonSemantic.Shader.DebugInfo.9999"
)";

const static std::string opencl_extension = R"(
%DbgExt = OpExtInstImport "OpenCL.DebugInfo.100"
)";

std::string GenerateShaderCodeForDebugInfo(
    const std::string& op_string_instructions,
    const std::string& op_const_instructions,
    const std::string& debug_instructions_before_main, const std::string& body,
    const std::string& capabilities_and_extensions = "",
    const std::string& execution_model = "Fragment") {
  std::ostringstream ss;
  ss << R"(
OpCapability Shader
OpCapability Float16
OpCapability Float64
OpCapability Int16
OpCapability Int64
)";

  ss << capabilities_and_extensions;
  ss << "%extinst = OpExtInstImport \"GLSL.std.450\"\n";
  ss << "OpMemoryModel Logical GLSL450\n";
  ss << "OpEntryPoint " << execution_model << " %main \"main\""
     << " %f32_output" << " %f32vec2_output" << " %u32_output"
     << " %u32vec2_output" << " %u64_output" << " %f32_input"
     << " %f32vec2_input" << " %u32_input" << " %u32vec2_input" << " %u64_input"
     << "\n";
  if (execution_model == "Fragment") {
    ss << "OpExecutionMode %main OriginUpperLeft\n";
  }

  ss << "%main_name = OpString \"main\"\n";
  ss << op_string_instructions;

  ss << R"(
%void = OpTypeVoid
%func = OpTypeFunction %void
%bool = OpTypeBool
%f16 = OpTypeFloat 16
%f32 = OpTypeFloat 32
%f64 = OpTypeFloat 64
%u32 = OpTypeInt 32 0
%s32 = OpTypeInt 32 1
%u64 = OpTypeInt 64 0
%s64 = OpTypeInt 64 1
%u16 = OpTypeInt 16 0
%s16 = OpTypeInt 16 1
%f32vec2 = OpTypeVector %f32 2
%f32vec3 = OpTypeVector %f32 3
%f32vec4 = OpTypeVector %f32 4
%f64vec2 = OpTypeVector %f64 2
%f64vec3 = OpTypeVector %f64 3
%f64vec4 = OpTypeVector %f64 4
%u32vec2 = OpTypeVector %u32 2
%u32vec3 = OpTypeVector %u32 3
%s32vec2 = OpTypeVector %s32 2
%u32vec4 = OpTypeVector %u32 4
%s32vec4 = OpTypeVector %s32 4
%u64vec2 = OpTypeVector %u64 2
%s64vec2 = OpTypeVector %s64 2
%f64mat22 = OpTypeMatrix %f64vec2 2
%f32mat22 = OpTypeMatrix %f32vec2 2
%f32mat23 = OpTypeMatrix %f32vec2 3
%f32mat32 = OpTypeMatrix %f32vec3 2
%f32mat33 = OpTypeMatrix %f32vec3 3

%f32_0 = OpConstant %f32 0
%f32_1 = OpConstant %f32 1
%f32_2 = OpConstant %f32 2
%f32_3 = OpConstant %f32 3
%f32_4 = OpConstant %f32 4
%f32_h = OpConstant %f32 0.5
%f32vec2_01 = OpConstantComposite %f32vec2 %f32_0 %f32_1
%f32vec2_12 = OpConstantComposite %f32vec2 %f32_1 %f32_2
%f32vec3_012 = OpConstantComposite %f32vec3 %f32_0 %f32_1 %f32_2
%f32vec3_123 = OpConstantComposite %f32vec3 %f32_1 %f32_2 %f32_3
%f32vec4_0123 = OpConstantComposite %f32vec4 %f32_0 %f32_1 %f32_2 %f32_3
%f32vec4_1234 = OpConstantComposite %f32vec4 %f32_1 %f32_2 %f32_3 %f32_4

%f64_0 = OpConstant %f64 0
%f64_1 = OpConstant %f64 1
%f64_2 = OpConstant %f64 2
%f64_3 = OpConstant %f64 3
%f64vec2_01 = OpConstantComposite %f64vec2 %f64_0 %f64_1
%f64vec3_012 = OpConstantComposite %f64vec3 %f64_0 %f64_1 %f64_2
%f64vec4_0123 = OpConstantComposite %f64vec4 %f64_0 %f64_1 %f64_2 %f64_3

%f16_0 = OpConstant %f16 0
%f16_1 = OpConstant %f16 1
%f16_h = OpConstant %f16 0.5

%u32_0 = OpConstant %u32 0
%u32_1 = OpConstant %u32 1
%u32_2 = OpConstant %u32 2
%u32_3 = OpConstant %u32 3
%u32_4 = OpConstant %u32 4
%u32_5 = OpConstant %u32 5
%u32_32 = OpConstant %u32 32

%s32_0 = OpConstant %s32 0
%s32_1 = OpConstant %s32 1
%s32_2 = OpConstant %s32 2
%s32_3 = OpConstant %s32 3

%u64_0 = OpConstant %u64 0
%u64_1 = OpConstant %u64 1
%u64_2 = OpConstant %u64 2
%u64_3 = OpConstant %u64 3

%s64_0 = OpConstant %s64 0
%s64_1 = OpConstant %s64 1
%s64_2 = OpConstant %s64 2
%s64_3 = OpConstant %s64 3
)";

  ss << op_const_instructions;

  ss << R"(
%s32vec2_01 = OpConstantComposite %s32vec2 %s32_0 %s32_1
%u32vec2_01 = OpConstantComposite %u32vec2 %u32_0 %u32_1

%s32vec2_12 = OpConstantComposite %s32vec2 %s32_1 %s32_2
%u32vec2_12 = OpConstantComposite %u32vec2 %u32_1 %u32_2

%s32vec4_0123 = OpConstantComposite %s32vec4 %s32_0 %s32_1 %s32_2 %s32_3
%u32vec4_0123 = OpConstantComposite %u32vec4 %u32_0 %u32_1 %u32_2 %u32_3

%s64vec2_01 = OpConstantComposite %s64vec2 %s64_0 %s64_1
%u64vec2_01 = OpConstantComposite %u64vec2 %u64_0 %u64_1

%f32mat22_1212 = OpConstantComposite %f32mat22 %f32vec2_12 %f32vec2_12
%f32mat23_121212 = OpConstantComposite %f32mat23 %f32vec2_12 %f32vec2_12 %f32vec2_12

%f32_ptr_output = OpTypePointer Output %f32
%f32vec2_ptr_output = OpTypePointer Output %f32vec2

%u32_ptr_output = OpTypePointer Output %u32
%u32vec2_ptr_output = OpTypePointer Output %u32vec2

%u64_ptr_output = OpTypePointer Output %u64

%f32_output = OpVariable %f32_ptr_output Output
%f32vec2_output = OpVariable %f32vec2_ptr_output Output

%u32_output = OpVariable %u32_ptr_output Output
%u32vec2_output = OpVariable %u32vec2_ptr_output Output

%u64_output = OpVariable %u64_ptr_output Output

%f32_ptr_input = OpTypePointer Input %f32
%f32vec2_ptr_input = OpTypePointer Input %f32vec2

%u32_ptr_input = OpTypePointer Input %u32
%u32vec2_ptr_input = OpTypePointer Input %u32vec2

%u64_ptr_input = OpTypePointer Input %u64

%f32_ptr_function = OpTypePointer Function %f32

%f32_input = OpVariable %f32_ptr_input Input
%f32vec2_input = OpVariable %f32vec2_ptr_input Input

%u32_input = OpVariable %u32_ptr_input Input
%u32vec2_input = OpVariable %u32vec2_ptr_input Input

%u64_input = OpVariable %u64_ptr_input Input

%u32_ptr_function = OpTypePointer Function %u32

%struct_f16_u16 = OpTypeStruct %f16 %u16
%struct_f32_f32 = OpTypeStruct %f32 %f32
%struct_f32_f32_f32 = OpTypeStruct %f32 %f32 %f32
%struct_f32_u32 = OpTypeStruct %f32 %u32
%struct_f32_u32_f32 = OpTypeStruct %f32 %u32 %f32
%struct_u32_f32 = OpTypeStruct %u32 %f32
%struct_u32_u32 = OpTypeStruct %u32 %u32
%struct_f32_f64 = OpTypeStruct %f32 %f64
%struct_f32vec2_f32vec2 = OpTypeStruct %f32vec2 %f32vec2
%struct_f32vec2_u32vec2 = OpTypeStruct %f32vec2 %u32vec2
)";

  ss << debug_instructions_before_main;

  ss << R"(
%main = OpFunction %void None %func
%main_entry = OpLabel
)";

  ss << body;

  ss << R"(
OpReturn
OpFunctionEnd)";

  return ss.str();
}

TEST_F(ValidateOldDebugInfo, UseDebugInstructionOutOfFunction) {
  const std::string src = R"(
%code = OpString "main() {}"
)";

  const std::string dbg_inst = R"(
%cu = OpExtInst %void %DbgExt DebugCompilationUnit %code 1 1
)";

  const std::string extension = R"(
%DbgExt = OpExtInstImport "DebugInfo"
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(src, "", dbg_inst, "",
                                                     extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, UseDebugInstructionOutOfFunction) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const std::string dbg_inst = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugSourceInFunction) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const std::string dbg_inst = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", "", dbg_inst, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_LAYOUT, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("Debug info extension instructions other than DebugScope, "
                "DebugNoScope, DebugDeclare, DebugValue must appear between "
                "section 9 (types, constants, global variables) and section 10 "
                "(function declarations)"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceInFunction) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const std::string dbg_inst = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", "", dbg_inst, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_LAYOUT, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("Debug info extension instructions other than DebugScope, "
                "DebugNoScope, DebugDeclare, DebugValue must appear between "
                "section 9 (types, constants, global variables) and section 10 "
                "(function declarations)"));
}

TEST_P(ValidateLocalDebugInfoOutOfFunction, OpenCLDebugInfo100DebugScope) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%void_name = OpString "void"
%int_name = OpString "int"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%int_info = OpExtInst %void %DbgExt DebugTypeBasic %int_name %u32_0 Signed
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 1 %main
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %int_info %dbg_src 1 1 %main_info FlagIsLocal
%expr = OpExtInst %void %DbgExt DebugExpression
)";

  const std::string body = R"(
%foo = OpVariable %u32_ptr_function Function
%foo_val = OpLoad %u32 %foo
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header + GetParam(), body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_LAYOUT, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugScope, DebugNoScope, DebugDeclare, DebugValue "
                        "of debug info extension must appear in a function "
                        "body"));
}

TEST_P(ValidateLocalDebugInfoOutOfFunction, VulkanDebugInfo100DebugScope) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%void_name = OpString "void"
%int_name = OpString "int"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%int_info = OpExtInst %void %DbgExt DebugTypeBasic %int_name %u32_0 %u32_1 %u32_0
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %int_info %dbg_src %u32_1 %u32_1 %main_info %u32_4
%expr = OpExtInst %void %DbgExt DebugExpression
)";

  const std::string body = R"(
%foo = OpVariable %u32_ptr_function Function
%main_def = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info %main
%foo_val = OpLoad %u32 %foo
)";

  CompileSuccessfully(
      GenerateShaderCodeForDebugInfo(src, "", dbg_inst_header + GetParam(),
                                     body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_LAYOUT, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugScope, DebugNoScope, DebugDeclare, DebugValue "
                        "of debug info extension must appear in a function "
                        "body"));
}

INSTANTIATE_TEST_SUITE_P(
    AllLocalDebugInfo, ValidateLocalDebugInfoOutOfFunction,
    ::testing::ValuesIn(std::vector<std::string>{
        "%main_scope = OpExtInst %void %DbgExt DebugScope %main_info",
        "%no_scope = OpExtInst %void %DbgExt DebugNoScope",
    }));

TEST_F(ValidateOpenCL100DebugInfo, DebugFunctionForwardReference) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%void_name = OpString "void"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 1 %main
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %main_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugFunctionMissingOpFunction) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%void_name = OpString "void"
)";

  const std::string dbg_inst_header = R"(
%dbgNone = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 1 %dbgNone
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %main_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugScopeBeforeOpVariableInFunction) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info 4
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %v4float_info %float_info
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 13 %main
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %main_info
%foo = OpVariable %f32_ptr_function Function
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeCompositeSizeDebugInfoNone) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%ty_name = OpString "struct VS_OUTPUT"
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%opaque = OpExtInst %void %DbgExt DebugTypeComposite %ty_name Class %dbg_src 1 1 %comp_unit %ty_name %dbg_none FlagIsPublic
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeCompositeForwardReference) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
  float4 color : COLOR;
};
main() {}
"
%VS_OUTPUT_name = OpString "struct VS_OUTPUT"
%float_name = OpString "float"
%VS_OUTPUT_pos_name = OpString "pos : SV_POSITION"
%VS_OUTPUT_color_name = OpString "color : COLOR"
%VS_OUTPUT_linkage_name = OpString "VS_OUTPUT"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
%int_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%VS_OUTPUT_info = OpExtInst %void %DbgExt DebugTypeComposite %VS_OUTPUT_name Structure %dbg_src 1 1 %comp_unit %VS_OUTPUT_linkage_name %int_128 FlagIsPublic %VS_OUTPUT_pos_info %VS_OUTPUT_color_info
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info 4
%VS_OUTPUT_pos_info = OpExtInst %void %DbgExt DebugTypeMember %VS_OUTPUT_pos_name %v4float_info %dbg_src 2 3 %VS_OUTPUT_info %u32_0 %int_128 FlagIsPublic
%VS_OUTPUT_color_info = OpExtInst %void %DbgExt DebugTypeMember %VS_OUTPUT_color_name %v4float_info %dbg_src 3 3 %VS_OUTPUT_info %int_128 %int_128 FlagIsPublic
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeCompositeMissingReference) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
  float4 color : COLOR;
};
main() {}
"
%VS_OUTPUT_name = OpString "struct VS_OUTPUT"
%float_name = OpString "float"
%VS_OUTPUT_pos_name = OpString "pos : SV_POSITION"
%VS_OUTPUT_color_name = OpString "color : COLOR"
%VS_OUTPUT_linkage_name = OpString "VS_OUTPUT"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
%int_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%VS_OUTPUT_info = OpExtInst %void %DbgExt DebugTypeComposite %VS_OUTPUT_name Structure %dbg_src 1 1 %comp_unit %VS_OUTPUT_linkage_name %int_128 FlagIsPublic %VS_OUTPUT_pos_info %VS_OUTPUT_color_info
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info 4
%VS_OUTPUT_pos_info = OpExtInst %void %DbgExt DebugTypeMember %VS_OUTPUT_pos_name %v4float_info %dbg_src 2 3 %VS_OUTPUT_info %u32_0 %int_128 FlagIsPublic
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_ID, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("forward referenced IDs have not been defined"));
}

TEST_P(ValidateXDebugInfo, DebugSourceWrongResultType) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const std::string dbg_inst = R"(
%dbg_src = OpExtInst %bool %DbgExt DebugSource %src %code
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(src, "", dbg_inst, "",
                                                     GetParam(), "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected result type must be a result id of "
                        "OpTypeVoid"));
}

TEST_P(ValidateXDebugInfo, DebugSourceFailFile) {
  const std::string src = R"(
%code = OpString "main() {}"
)";

  const std::string dbg_inst = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %DbgExt %code
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(src, "", dbg_inst, "",
                                                     GetParam(), "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand File must be a result id of "
                        "OpString"));
}

TEST_P(ValidateXDebugInfo, DebugSourceFailSource) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
)";

  const std::string dbg_inst = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %DbgExt
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(src, "", dbg_inst, "",
                                                     GetParam(), "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Text must be a result id of "
                        "OpString"));
}

TEST_P(ValidateXDebugInfo, DebugSourceNoText) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
)";

  const std::string dbg_inst = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(src, "", dbg_inst, "",
                                                     GetParam(), "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

INSTANTIATE_TEST_SUITE_P(OpenCLAndVkDebugInfo100, ValidateXDebugInfo,
                         ::testing::ValuesIn(std::vector<std::string>{
                             R"(
%DbgExt = OpExtInstImport "OpenCL.DebugInfo.100"
)",
                             R"(
OpExtension "SPV_KHR_non_semantic_info"
%DbgExt = OpExtInstImport "NonSemantic.Shader.DebugInfo.100"
)",
                         }));

TEST_F(ValidateOpenCL100DebugInfo, DebugCompilationUnit) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const std::string dbg_inst = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugCompilationUnitFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const std::string dbg_inst = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %src HLSL
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Source must be a result id of "
                        "DebugSource"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugCompilationUnitFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const std::string dbg_inst = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %src %u32_5
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Source must be a result id of "
                        "DebugSource"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeBasicFailName) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %int_32 %int_32 Float
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Name must be a result id of "
                        "OpString"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeBasicFailName) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %u32_32 %u32_32 %u32_3 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Name must be a result id of "
                        "OpString"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeBasicFailSize) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %float_name Float
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Size must be a result id of "
                        "OpConstant"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeBasicFailSize) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %float_name %u32_3 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Size must be a result id of "
                        "OpConstant"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeBasicFailFlags) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%f32_32 = OpConstant %f32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_3 %u32_3 %f32_32
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Flags must be a result id of 32-bit "
                        "unsigned OpConstant"));
}

// https://github.com/KhronosGroup/SPIRV-Tools/issues/5897
TEST_F(ValidateVulkan100DebugInfo, DebugTypeBasicFailFlagsConstantNull) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%u32_null = OpConstantNull %u32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_null
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Flags must be a result id of 32-bit "
                        "unsigned OpConstant"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypePointer) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%pfloat_info = OpExtInst %void %DbgExt DebugTypePointer %float_info Function FlagIsLocal
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypePointerFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%pfloat_info = OpExtInst %void %DbgExt DebugTypePointer %dbg_src Function FlagIsLocal
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("expected operand Base Type is not a valid debug type"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeQualifier) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%cfloat_info = OpExtInst %void %DbgExt DebugTypeQualifier %float_info ConstType
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeQualifierFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%cfloat_info = OpExtInst %void %DbgExt DebugTypeQualifier %comp_unit ConstType
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("expected operand Base Type is not a valid debug type"));
}
TEST_F(ValidateVulkan100DebugInfo, DebugTypeQualifier) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%cfloat_info = OpExtInst %void %DbgExt DebugTypeQualifier %float_info %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeQualifierFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float4 main(float arg) {
  float foo;
  return float4(0, 0, 0, 0);
}
"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%cfloat_info = OpExtInst %void %DbgExt DebugTypeQualifier %comp_unit %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("expected operand Base Type is not a valid debug type"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeArray) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %int_32
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeArrayWithVariableSize) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%int_name = OpString "int"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%uint_info = OpExtInst %void %DbgExt DebugTypeBasic %int_name %int_32 Unsigned
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 1 %main
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %uint_info %dbg_src 1 1 %main_info FlagIsLocal
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %foo_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeArrayFailBaseType) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %comp_unit %int_32
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Base Type is not a valid debug "
                        "type"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeArrayFailComponentCount) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %float_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be OpConstant with a 32- or "
                        "64-bits integer scalar type or DebugGlobalVariable or "
                        "DebugLocalVariable with a 32- or 64-bits unsigned "
                        "integer scalar type"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeArrayFailComponentCountFloat) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %f32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be OpConstant with a 32- or "
                        "64-bits integer scalar type or DebugGlobalVariable or "
                        "DebugLocalVariable with a 32- or 64-bits unsigned "
                        "integer scalar type"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeArrayFailComponentCountZero) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be OpConstant with a 32- or "
                        "64-bits integer scalar type or DebugGlobalVariable or "
                        "DebugLocalVariable with a 32- or 64-bits unsigned "
                        "integer scalar type"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeArrayFailVariableSizeTypeFloat) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 1 %main
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %float_info %dbg_src 1 1 %main_info FlagIsLocal
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %foo_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be OpConstant with a 32- or "
                        "64-bits integer scalar type or DebugGlobalVariable or "
                        "DebugLocalVariable with a 32- or 64-bits unsigned "
                        "integer scalar type"));
}

TEST_F(ValidateOpenCL100DebugInfo,
       DebugTypeArrayOpSpecConstantComponentCountFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
%spec_u32 = OpSpecConstant %u32 4
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %spec_u32
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be OpConstant with a 32- or "
                        "64-bits integer scalar type or DebugGlobalVariable or "
                        "DebugLocalVariable with a 32- or 64-bits unsigned "
                        "integer scalar type"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeArray) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %u32_32
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeArrayWithVariableSize) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%uint_name = OpString "uint"
%foo_name = OpString "foo"
)";

  const std::string constants = R"(
%u32_6 = OpConstant %u32 6
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%uint_info = OpExtInst %void %DbgExt DebugTypeBasic %uint_name %u32_32 %u32_6 %u32_0
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %uint_info %dbg_src %u32_1 %u32_1 %main_info %u32_4
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %foo_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeArrayFailBaseType) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %comp_unit %u32_32
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Base Type is not a valid debug "
                        "type"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeArrayFailComponentCount) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %float_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be a constant instruction with a "
                        "32- or 64-bits integer scalar type or "
                        "DebugGlobalVariable or DebugLocalVariable with a 32- "
                        "or 64-bits unsigned integer scalar type"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeArrayFailComponentCountFloat) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %f32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be a constant instruction with a "
                        "32- or 64-bits integer scalar type or "
                        "DebugGlobalVariable or DebugLocalVariable with a 32- "
                        "or 64-bits unsigned integer scalar type"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeArrayComponentCountZero) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeArrayFailVariableSizeTypeFloat) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string constants = R"(
%u32_6 = OpConstant %u32 6
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %float_info %dbg_src %u32_1 %u32_1 %main_info %u32_4
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %foo_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be a constant instruction with a "
                        "32- or 64-bits integer scalar type or "
                        "DebugGlobalVariable or DebugLocalVariable with a 32- "
                        "or 64-bits unsigned integer scalar type"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeArrayOpSpecConstantComponentCount) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%spec_u32 = OpSpecConstant %u32 4
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %spec_u32
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo,
       DebugTypeArrayOpSpecConstantOpComponentCount) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%spec_a = OpSpecConstant %u32 2
%spec_b = OpSpecConstant %u32 2
%spec_op = OpSpecConstantOp %u32 IMul %spec_a %spec_b
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%float_arr_info = OpExtInst %void %DbgExt DebugTypeArray %float_info %spec_op
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeVector) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info 4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeVectorOfTypedef) {
  const std::string src = R"(
%src = OpString "vector.c"
%code = OpString "typedef unsigned int uint; typedef uint uint4;"
%uint_name = OpString "uint"
%uint4_name = OpString "uint4"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 1 4 %dbg_src HLSL
%uint_basic = OpExtInst %void %DbgExt DebugTypeBasic %uint_name %int_32 Unsigned
%uint_info = OpExtInst %void %DbgExt DebugTypedef %uint_name %uint_basic %dbg_src 1 0 %comp_unit
%uint4_info = OpExtInst %void %DbgExt DebugTypeVector %uint_info 4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeVectorFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %dbg_src 4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Base Type is not a valid debug "
                        "type"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeVectorFailComponentZero) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info 0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be positive "
                        "integer less than or equal to 4"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeVectorFailComponentFive) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info 5
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be positive "
                        "integer less than or equal to 4"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeVector) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeVectorOfTypedef) {
  const std::string src = R"(
%src = OpString "vector.c"
%code = OpString "typedef unsigned int uint; typedef uint uint4;"
%uint_name = OpString "uint"
%uint4_name = OpString "uint4"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_1 %u32_4 %dbg_src %u32_0
%uint_basic = OpExtInst %void %DbgExt DebugTypeBasic %uint_name %u32_32 %u32_2 %u32_0
%uint_info = OpExtInst %void %DbgExt DebugTypedef %uint_name %uint_basic %dbg_src %u32_1 %u32_0 %comp_unit
%uint4_info = OpExtInst %void %DbgExt DebugTypeVector %uint_info %u32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeVectorFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %dbg_src %u32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Base Type is not a valid debug "
                        "type"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeVectorFailComponentZero) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be positive "
                        "integer less than or equal to 4"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeVectorFailComponentFive) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_5
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be positive "
                        "integer less than or equal to 4"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeMatrix) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%true = OpConstantTrue %bool
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%mfloat_info = OpExtInst %void %DbgExt DebugTypeMatrix %vfloat_info %u32_4 %true
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeMatrixFailVectorTypeType) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%true = OpConstantTrue %bool
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%mfloat_info = OpExtInst %void %DbgExt DebugTypeMatrix %dbg_src %u32_4 %true
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Vector Type must be a result id of "
                        "DebugTypeVector"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeMatrixFailVectorCountType) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%true = OpConstantTrue %bool
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%mfloat_info = OpExtInst %void %DbgExt DebugTypeMatrix %vfloat_info %dbg_src %true
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Vector Count must be a result id of "
                        "32-bit unsigned OpConstant"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeMatrixFailVectorCountZero) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%true = OpConstantTrue %bool
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%mfloat_info = OpExtInst %void %DbgExt DebugTypeMatrix %vfloat_info %u32_0 %true
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Vector Count must be positive "
                        "integer less than or equal to 4"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeMatrixFailVectorCountFive) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%true = OpConstantTrue %bool
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vfloat_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%mfloat_info = OpExtInst %void %DbgExt DebugTypeMatrix %vfloat_info %u32_5 %true
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Vector Count must be positive "
                        "integer less than or equal to 4"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypedef) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo_info = OpExtInst %void %DbgExt DebugTypedef %foo_name %float_info %dbg_src 1 1 %comp_unit
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypedefOfVector) {
  const std::string src = R"(
%src = OpString "vector.c"
%code = OpString "typedef int v4si __attribute__((vector_size(16)));"
%int_name = OpString "int"
%v4si_name = OpString "v4si"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 1 4 %dbg_src HLSL
%int_info = OpExtInst %void %DbgExt DebugTypeBasic %int_name %int_32 Signed
%v4si_vec = OpExtInst %void %DbgExt DebugTypeVector %int_info 4
%v4si_info = OpExtInst %void %DbgExt DebugTypedef %v4si_name %v4si_vec %dbg_src 1 0 %comp_unit
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateOpenCL100DebugInfoDebugTypedef, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo_info = OpExtInst %void %DbgExt DebugTypedef )";
  ss << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, ss.str(), "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  if (param.second == "Base Type") {
    EXPECT_THAT(getDiagnosticString(),
                HasSubstr("expected operand Base Type is not a valid debug "
                          "type"));
  } else {
    EXPECT_THAT(getDiagnosticString(),
                HasSubstr("expected operand " + param.second +
                          " must be a result id of "));
  }
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugTypedef,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(R"(%dbg_src %float_info %dbg_src 1 1 %comp_unit)",
                       "Name"),
        std::make_pair(R"(%foo_name %dbg_src %dbg_src 1 1 %comp_unit)",
                       "Base Type"),
        std::make_pair(R"(%foo_name %float_info %comp_unit 1 1 %comp_unit)",
                       "Source"),
        std::make_pair(R"(%foo_name %float_info %dbg_src 1 1 %dbg_src)",
                       "Parent"),
    }));

TEST_F(ValidateVulkan100DebugInfo, DebugTypedef) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo_info = OpExtInst %void %DbgExt DebugTypedef %foo_name %float_info %dbg_src %u32_1 %u32_1 %comp_unit
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypedefOfVector) {
  const std::string src = R"(
%src = OpString "vector.c"
%code = OpString "typedef int v4si __attribute__((vector_size(16)));"
%int_name = OpString "int"
%v4si_name = OpString "v4si"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_1 %u32_4 %dbg_src %u32_0
%int_info = OpExtInst %void %DbgExt DebugTypeBasic %int_name %u32_32 %u32_4 %u32_0
%v4si_vec = OpExtInst %void %DbgExt DebugTypeVector %int_info %u32_4
%v4si_info = OpExtInst %void %DbgExt DebugTypedef %v4si_name %v4si_vec %dbg_src %u32_1 %u32_0 %comp_unit
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateVulkan100DebugInfoDebugTypedef, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo_info = OpExtInst %void %DbgExt DebugTypedef )";
  ss << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", ss.str(), "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  if (param.second == "Base Type") {
    EXPECT_THAT(getDiagnosticString(),
                HasSubstr("expected operand Base Type is not a valid debug "
                          "type"));
  } else {
    EXPECT_THAT(getDiagnosticString(),
                HasSubstr("expected operand " + param.second +
                          " must be a result id of "));
  }
}

INSTANTIATE_TEST_SUITE_P(
    AllVulkan100DebugInfoFail, ValidateVulkan100DebugInfoDebugTypedef,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%dbg_src %float_info %dbg_src %u32_1 %u32_1 %comp_unit)",
            "Name"),
        std::make_pair(
            R"(%foo_name %dbg_src %dbg_src %u32_1 %u32_1 %comp_unit)",
            "Base Type"),
        std::make_pair(
            R"(%foo_name %float_info %comp_unit %u32_1 %u32_1 %comp_unit)",
            "Source"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src %u32_1 %u32_1 %dbg_src)",
            "Parent"),
    }));

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeFunction) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%main_type_info1 = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_type_info2 = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %float_info
%main_type_info3 = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %float_info %float_info
%main_type_info4 = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void %float_info %float_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeFunctionFailReturn) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %dbg_src %float_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("expected operand Return Type is not a valid debug type"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeFunctionFailParam) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %float_info %void
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("expected operand Parameter Types is not a valid debug type"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeFunctionAndParams) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%main_type_info1 = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_type_info2 = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %float_info
%main_type_info3 = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %float_info %float_info
%main_type_info4 = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void %float_info %float_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeFunctionFailReturn) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %dbg_src %float_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("expected operand Return Type is not a valid debug type"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeFunctionFailParam) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %float_info %void
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("expected operand Parameter Types is not a valid debug type"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeEnum) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%none = OpExtInst %void %DbgExt DebugInfoNone
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo_info1 = OpExtInst %void %DbgExt DebugTypeEnum %foo_name %float_info %dbg_src 1 1 %comp_unit %int_32 FlagIsPublic %u32_0 %foo_name %u32_1 %foo_name
%foo_info2 = OpExtInst %void %DbgExt DebugTypeEnum %foo_name %none %dbg_src 1 1 %comp_unit %int_32 FlagIsPublic %u32_0 %foo_name %u32_1 %foo_name
%foo_info3 = OpExtInst %void %DbgExt DebugTypeEnum %foo_name %none %dbg_src 1 1 %comp_unit %int_32 FlagIsPublic
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateOpenCL100DebugInfoDebugTypeEnum, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo_info = OpExtInst %void %DbgExt DebugTypeEnum )";
  ss << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, ss.str(), "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugTypeEnum,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%dbg_src %float_info %dbg_src 1 1 %comp_unit %int_32 FlagIsPublic %u32_0 %foo_name)",
            "Name"),
        std::make_pair(
            R"(%foo_name %dbg_src %dbg_src 1 1 %comp_unit %int_32 FlagIsPublic %u32_0 %foo_name)",
            "Underlying Types"),
        std::make_pair(
            R"(%foo_name %float_info %comp_unit 1 1 %comp_unit %int_32 FlagIsPublic %u32_0 %foo_name)",
            "Source"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src 1 1 %dbg_src %int_32 FlagIsPublic %u32_0 %foo_name)",
            "Parent"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src 1 1 %comp_unit %void FlagIsPublic %u32_0 %foo_name)",
            "Size"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src 1 1 %comp_unit %u32_0 FlagIsPublic %u32_0 %foo_name)",
            "Size"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src 1 1 %comp_unit %int_32 FlagIsPublic %foo_name %foo_name)",
            "Value"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src 1 1 %comp_unit %int_32 FlagIsPublic %u32_0 %u32_1)",
            "Name"),
    }));

TEST_F(ValidateVulkan100DebugInfo, DebugTypeEnum) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%none = OpExtInst %void %DbgExt DebugInfoNone
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo_info1 = OpExtInst %void %DbgExt DebugTypeEnum %foo_name %float_info %dbg_src %u32_1 %u32_1 %comp_unit %u32_32 %u32_3 %u32_0 %foo_name %u32_1 %foo_name
%foo_info2 = OpExtInst %void %DbgExt DebugTypeEnum %foo_name %none %dbg_src %u32_1 %u32_1 %comp_unit %u32_32 %u32_3 %u32_0 %foo_name %u32_1 %foo_name
%foo_info3 = OpExtInst %void %DbgExt DebugTypeEnum %foo_name %none %dbg_src %u32_1 %u32_1 %comp_unit %u32_32 %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateVulkan100DebugInfoDebugTypeEnum, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo_info = OpExtInst %void %DbgExt DebugTypeEnum )";
  ss << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", ss.str(), "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllVulkan100DebugInfoFail, ValidateVulkan100DebugInfoDebugTypeEnum,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%dbg_src %float_info %dbg_src %u32_1 %u32_1 %comp_unit %u32_32 %u32_3 %u32_0 %foo_name)",
            "Name"),
        std::make_pair(
            R"(%foo_name %dbg_src %dbg_src %u32_1 %u32_1 %comp_unit %u32_32 %u32_3 %u32_0 %foo_name)",
            "Underlying Types"),
        std::make_pair(
            R"(%foo_name %float_info %comp_unit %u32_1 %u32_1 %comp_unit %u32_32 %u32_3 %u32_0 %foo_name)",
            "Source"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src %u32_1 %u32_1 %dbg_src %u32_32 %u32_3 %u32_0 %foo_name)",
            "Parent"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src %u32_1 %u32_1 %comp_unit %void %u32_3 %u32_0 %foo_name)",
            "Size"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src %u32_1 %u32_1 %comp_unit %u32_0 %u32_3 %u32_0 %foo_name)",
            "Size"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src %u32_1 %u32_1 %comp_unit %u32_32 %u32_3 %foo_name %foo_name)",
            "Value"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src %u32_1 %u32_1 %comp_unit %u32_32 %u32_3 %u32_0 %u32_1)",
            "Name"),
    }));

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeCompositeFunctionAndInheritance) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
};
struct foo : VS_OUTPUT {
};
main() {}
"
%VS_OUTPUT_name = OpString "struct VS_OUTPUT"
%float_name = OpString "float"
%foo_name = OpString "foo"
%VS_OUTPUT_pos_name = OpString "pos : SV_POSITION"
%VS_OUTPUT_linkage_name = OpString "VS_OUTPUT"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
%int_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%VS_OUTPUT_info = OpExtInst %void %DbgExt DebugTypeComposite %VS_OUTPUT_name Structure %dbg_src 1 1 %comp_unit %VS_OUTPUT_linkage_name %int_128 FlagIsPublic %VS_OUTPUT_pos_info %main_info %child
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info 4
%VS_OUTPUT_pos_info = OpExtInst %void %DbgExt DebugTypeMember %VS_OUTPUT_pos_name %v4float_info %dbg_src 2 3 %VS_OUTPUT_info %u32_0 %int_128 FlagIsPublic
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %v4float_info %float_info
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 6 1 %comp_unit %main_name FlagIsPublic 13 %main
%foo_info = OpExtInst %void %DbgExt DebugTypeComposite %foo_name Structure %dbg_src 1 1 %comp_unit %foo_name %u32_0 FlagIsPublic
%child = OpExtInst %void %DbgExt DebugTypeInheritance %foo_info %VS_OUTPUT_info %int_128 %int_128 FlagIsPublic
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateOpenCL100DebugInfoDebugTypeComposite, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
};
struct foo : VS_OUTPUT {
};
main() {}
"
%VS_OUTPUT_name = OpString "struct VS_OUTPUT"
%float_name = OpString "float"
%foo_name = OpString "foo"
%VS_OUTPUT_pos_name = OpString "pos : SV_POSITION"
%VS_OUTPUT_linkage_name = OpString "VS_OUTPUT"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
%int_128 = OpConstant %u32 128
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%VS_OUTPUT_info = OpExtInst %void %DbgExt DebugTypeComposite )";
  ss << param.first;
  ss << R"(
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info 4
%VS_OUTPUT_pos_info = OpExtInst %void %DbgExt DebugTypeMember %VS_OUTPUT_pos_name %v4float_info %dbg_src 2 3 %VS_OUTPUT_info %u32_0 %int_128 FlagIsPublic
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %v4float_info %float_info
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 13 %main
%foo_info = OpExtInst %void %DbgExt DebugTypeComposite %foo_name Structure %dbg_src 1 1 %comp_unit %foo_name %u32_0 FlagIsPublic
%child = OpExtInst %void %DbgExt DebugTypeInheritance %foo_info %VS_OUTPUT_info %int_128 %int_128 FlagIsPublic
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, ss.str(), "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second + " must be "));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugTypeComposite,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%dbg_src Structure %dbg_src 1 1 %comp_unit %VS_OUTPUT_linkage_name %int_128 FlagIsPublic %VS_OUTPUT_pos_info %main_info %child)",
            "Name"),
        std::make_pair(
            R"(%VS_OUTPUT_name Structure %comp_unit 1 1 %comp_unit %VS_OUTPUT_linkage_name %int_128 FlagIsPublic %VS_OUTPUT_pos_info %main_info %child)",
            "Source"),
        std::make_pair(
            R"(%VS_OUTPUT_name Structure %dbg_src 1 1 %dbg_src %VS_OUTPUT_linkage_name %int_128 FlagIsPublic %VS_OUTPUT_pos_info %main_info %child)",
            "Parent"),
        std::make_pair(
            R"(%VS_OUTPUT_name Structure %dbg_src 1 1 %comp_unit %int_128 %int_128 FlagIsPublic %VS_OUTPUT_pos_info %main_info %child)",
            "Linkage Name"),
        std::make_pair(
            R"(%VS_OUTPUT_name Structure %dbg_src 1 1 %comp_unit %VS_OUTPUT_linkage_name %dbg_src FlagIsPublic %VS_OUTPUT_pos_info %main_info %child)",
            "Size"),
        std::make_pair(
            R"(%VS_OUTPUT_name Structure %dbg_src 1 1 %comp_unit %VS_OUTPUT_linkage_name %int_128 FlagIsPublic %dbg_src %main_info %child)",
            "Members"),
        std::make_pair(
            R"(%VS_OUTPUT_name Structure %dbg_src 1 1 %comp_unit %VS_OUTPUT_linkage_name %int_128 FlagIsPublic %VS_OUTPUT_pos_info %dbg_src %child)",
            "Members"),
        std::make_pair(
            R"(%VS_OUTPUT_name Structure %dbg_src 1 1 %comp_unit %VS_OUTPUT_linkage_name %int_128 FlagIsPublic %VS_OUTPUT_pos_info %main_info %dbg_src)",
            "Members"),
    }));

TEST_P(ValidateOpenCL100DebugInfoDebugTypeMember, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float pos : SV_POSITION;
};
main() {}
"
%VS_OUTPUT_name = OpString "struct VS_OUTPUT"
%float_name = OpString "float"
%VS_OUTPUT_pos_name = OpString "pos : SV_POSITION"
%VS_OUTPUT_linkage_name = OpString "VS_OUTPUT"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%VS_OUTPUT_info = OpExtInst %void %DbgExt DebugTypeComposite %VS_OUTPUT_name Structure %dbg_src 1 1 %comp_unit %VS_OUTPUT_linkage_name %int_32 FlagIsPublic %VS_OUTPUT_pos_info
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%VS_OUTPUT_pos_info = OpExtInst %void %DbgExt DebugTypeMember )";
  ss << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, ss.str(), "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  if (!param.second.empty()) {
    EXPECT_THAT(getDiagnosticString(),
                HasSubstr("expected operand " + param.second +
                          " must be a result id of "));
  }
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugTypeMember,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%dbg_src %float_info %dbg_src 2 3 %VS_OUTPUT_info %u32_0 %int_32 FlagIsPublic)",
            "Name"),
        std::make_pair(
            R"(%VS_OUTPUT_pos_name %dbg_src %dbg_src 2 3 %VS_OUTPUT_info %u32_0 %int_32 FlagIsPublic)",
            ""),
        std::make_pair(
            R"(%VS_OUTPUT_pos_name %float_info %float_info 2 3 %VS_OUTPUT_info %u32_0 %int_32 FlagIsPublic)",
            "Source"),
        std::make_pair(
            R"(%VS_OUTPUT_pos_name %float_info %dbg_src 2 3 %float_info %u32_0 %int_32 FlagIsPublic)",
            "Parent"),
        std::make_pair(
            R"(%VS_OUTPUT_pos_name %float_info %dbg_src 2 3 %VS_OUTPUT_info %void %int_32 FlagIsPublic)",
            "Offset"),
        std::make_pair(
            R"(%VS_OUTPUT_pos_name %float_info %dbg_src 2 3 %VS_OUTPUT_info %u32_0 %void FlagIsPublic)",
            "Size"),
    }));

TEST_P(ValidateOpenCL100DebugInfoDebugTypeInheritance, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {};
struct foo : VS_OUTPUT {};
"
%VS_OUTPUT_name = OpString "struct VS_OUTPUT"
%foo_name = OpString "foo"
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%VS_OUTPUT_info = OpExtInst %void %DbgExt DebugTypeComposite %VS_OUTPUT_name Structure %dbg_src 1 1 %comp_unit %VS_OUTPUT_name %u32_0 FlagIsPublic %child
%foo_info = OpExtInst %void %DbgExt DebugTypeComposite %foo_name Structure %dbg_src 1 1 %comp_unit %foo_name %u32_0 FlagIsPublic
%bar_info = OpExtInst %void %DbgExt DebugTypeComposite %foo_name Union %dbg_src 1 1 %comp_unit %foo_name %u32_0 FlagIsPublic
%child = OpExtInst %void %DbgExt DebugTypeInheritance )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", ss.str(), "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugTypeInheritance,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(R"(%dbg_src %VS_OUTPUT_info %u32_0 %u32_0 FlagIsPublic)",
                       "Child must be a result id of"),
        std::make_pair(R"(%foo_info %dbg_src %u32_0 %u32_0 FlagIsPublic)",
                       "Parent must be a result id of"),
        std::make_pair(
            R"(%bar_info %VS_OUTPUT_info %u32_0 %u32_0 FlagIsPublic)",
            "Child must be class or struct debug type"),
        std::make_pair(R"(%foo_info %bar_info %u32_0 %u32_0 FlagIsPublic)",
                       "Parent must be class or struct debug type"),
        std::make_pair(R"(%foo_info %VS_OUTPUT_info %void %u32_0 FlagIsPublic)",
                       "Offset"),
        std::make_pair(R"(%foo_info %VS_OUTPUT_info %u32_0 %void FlagIsPublic)",
                       "Size"),
    }));

TEST_F(ValidateVulkan100DebugInfo, DebugTypeComposite) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
};
struct foo : VS_OUTPUT {
};
main() {}
"
%VS_OUTPUT_name = OpString "struct VS_OUTPUT"
%float_name = OpString "float"
%foo_name = OpString "foo"
%VS_OUTPUT_pos_name = OpString "pos : SV_POSITION"
%VS_OUTPUT_linkage_name = OpString "VS_OUTPUT"
)";

  const std::string constants = R"(
%u32_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%VS_OUTPUT_pos_info = OpExtInst %void %DbgExt DebugTypeMember %VS_OUTPUT_pos_name %v4float_info %dbg_src %u32_2 %u32_3 %u32_0 %u32_128 %u32_3
%VS_OUTPUT_info = OpExtInst %void %DbgExt DebugTypeComposite %VS_OUTPUT_name %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %VS_OUTPUT_linkage_name %u32_128 %u32_3 %VS_OUTPUT_pos_info
%foo_info = OpExtInst %void %DbgExt DebugTypeComposite %foo_name %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %foo_name %u32_0 %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateVulkan100DebugInfoDebugTypeComposite, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
};
struct foo : VS_OUTPUT {
};
main() {}
"
%VS_OUTPUT_name = OpString "struct VS_OUTPUT"
%float_name = OpString "float"
%foo_name = OpString "foo"
%VS_OUTPUT_pos_name = OpString "pos : SV_POSITION"
%VS_OUTPUT_linkage_name = OpString "VS_OUTPUT"
)";

  const std::string constants = R"(
%u32_128 = OpConstant %u32 128
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%VS_OUTPUT_pos_info = OpExtInst %void %DbgExt DebugTypeMember %VS_OUTPUT_pos_name %v4float_info %dbg_src %u32_2 %u32_3 %u32_0 %u32_128 %u32_3
%VS_OUTPUT_info = OpExtInst %void %DbgExt DebugTypeComposite )";
  ss << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, ss.str(), "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second + " must be "));
}

INSTANTIATE_TEST_SUITE_P(
    AllVulkan100DebugInfoFail, ValidateVulkan100DebugInfoDebugTypeComposite,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%dbg_src %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %VS_OUTPUT_linkage_name %u32_128 %u32_3 %VS_OUTPUT_pos_info)",
            "Name"),
        std::make_pair(
            R"(%VS_OUTPUT_name %u32_1 %comp_unit %u32_1 %u32_1 %comp_unit %VS_OUTPUT_linkage_name %u32_128 %u32_3 %VS_OUTPUT_pos_info)",
            "Source"),
        std::make_pair(
            R"(%VS_OUTPUT_name %u32_1 %dbg_src %u32_1 %u32_1 %dbg_src %VS_OUTPUT_linkage_name %u32_128 %u32_3 %VS_OUTPUT_pos_info)",
            "Parent"),
        std::make_pair(
            R"(%VS_OUTPUT_name %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %u32_128 %u32_128 %u32_3 %VS_OUTPUT_pos_info)",
            "Linkage Name"),
        std::make_pair(
            R"(%VS_OUTPUT_name %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %VS_OUTPUT_linkage_name %dbg_src %u32_3 %VS_OUTPUT_pos_info)",
            "Size"),
        std::make_pair(
            R"(%VS_OUTPUT_name %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %VS_OUTPUT_linkage_name %u32_128 %dbg_src %VS_OUTPUT_pos_info)",
            "Flags"),
        std::make_pair(
            R"(%VS_OUTPUT_name %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %VS_OUTPUT_linkage_name %u32_128 %u32_3 %dbg_src)",
            "Members"),
    }));

TEST_P(ValidateVulkan100DebugInfoDebugTypeMember, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float pos : SV_POSITION;
};
main() {}
"
%VS_OUTPUT_name = OpString "struct VS_OUTPUT"
%float_name = OpString "float"
%VS_OUTPUT_pos_name = OpString "pos : SV_POSITION"
%VS_OUTPUT_linkage_name = OpString "VS_OUTPUT"
)";

  const std::string constants = R"(
%u32_128 = OpConstant %u32 128
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%VS_OUTPUT_pos_info = OpExtInst %void %DbgExt DebugTypeMember )";
  ss << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, ss.str(), "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  if (!param.second.empty()) {
    EXPECT_THAT(getDiagnosticString(),
                HasSubstr("expected operand " + param.second +
                          " must be a result id of "));
  }
}

INSTANTIATE_TEST_SUITE_P(
    AllVulkan100DebugInfoFail, ValidateVulkan100DebugInfoDebugTypeMember,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%dbg_src %float_info %dbg_src %u32_2 %u32_3 %u32_0 %u32_32 %u32_3)",
            "Name"),
        std::make_pair(
            R"(%VS_OUTPUT_pos_name %dbg_src %dbg_src %u32_2 %u32_3 %u32_0 %u32_32 %u32_3)",
            ""),
        std::make_pair(
            R"(%VS_OUTPUT_pos_name %float_info %float_info %u32_2 %u32_3 %u32_0 %u32_32 %u32_3)",
            "Source"),
        std::make_pair(
            R"(%VS_OUTPUT_pos_name %float_info %dbg_src %u32_2 %u32_3 %void %u32_32 %u32_3)",
            "Offset"),
        std::make_pair(
            R"(%VS_OUTPUT_pos_name %float_info %dbg_src %u32_2 %u32_3 %u32_0 %void %u32_3)",
            "Size"),
        std::make_pair(
            R"(%VS_OUTPUT_pos_name %float_info %dbg_src %u32_2 %u32_3 %u32_0 %u32_32 %void)",
            "Flags"),
    }));

TEST_F(ValidateOpenCL100DebugInfo, DebugFunctionDeclaration) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
};
main() {}
"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_decl = OpExtInst %void %DbgExt DebugFunctionDeclaration %main_name %main_type_info %dbg_src 4 1 %comp_unit %main_name FlagIsPublic
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 4 1 %comp_unit %main_name FlagIsPublic 13 %main)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateOpenCL100DebugInfoDebugFunction, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
};
main() {}
"
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_decl = OpExtInst %void %DbgExt DebugFunctionDeclaration %main_name %main_type_info %dbg_src 4 1 %comp_unit %main_name FlagIsPublic
%main_info = OpExtInst %void %DbgExt DebugFunction )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", ss.str(), "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugFunction,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%u32_0 %main_type_info %dbg_src 4 1 %comp_unit %main_name FlagIsPublic 13 %main)",
            "Name"),
        std::make_pair(
            R"(%main_name %dbg_src %dbg_src 4 1 %comp_unit %main_name FlagIsPublic 13 %main)",
            "Type"),
        std::make_pair(
            R"(%main_name %main_type_info %comp_unit 4 1 %comp_unit %main_name FlagIsPublic 13 %main)",
            "Source"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src 4 1 %dbg_src %main_name FlagIsPublic 13 %main)",
            "Parent"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src 4 1 %comp_unit %void FlagIsPublic 13 %main)",
            "Linkage Name"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src 4 1 %comp_unit %main_name FlagIsPublic 13 %void)",
            "Function"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src 4 1 %comp_unit %main_name FlagIsPublic 13 %main %dbg_src)",
            "Declaration"),
    }));

TEST_P(ValidateOpenCL100DebugInfoDebugFunctionDeclaration, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
};
main() {}
"
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_decl = OpExtInst %void %DbgExt DebugFunctionDeclaration )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", ss.str(), "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail,
    ValidateOpenCL100DebugInfoDebugFunctionDeclaration,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%u32_0 %main_type_info %dbg_src 4 1 %comp_unit %main_name FlagIsPublic)",
            "Name"),
        std::make_pair(
            R"(%main_name %dbg_src %dbg_src 4 1 %comp_unit %main_name FlagIsPublic)",
            "Type"),
        std::make_pair(
            R"(%main_name %main_type_info %comp_unit 4 1 %comp_unit %main_name FlagIsPublic)",
            "Source"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src 4 1 %dbg_src %main_name FlagIsPublic)",
            "Parent"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src 4 1 %comp_unit %void FlagIsPublic)",
            "Linkage Name"),
    }));

TEST_F(ValidateVulkan100DebugInfo, DebugFunctionDeclaration) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
};
main() {}
"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_decl = OpExtInst %void %DbgExt DebugFunctionDeclaration %main_name %main_type_info %dbg_src %u32_4 %u32_1 %comp_unit %main_name %u32_3
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_4 %u32_1 %comp_unit %main_name %u32_3 %u32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateVulkan100DebugInfoDebugFunction, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
};
main() {}
"
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_decl = OpExtInst %void %DbgExt DebugFunctionDeclaration %main_name %main_type_info %dbg_src %u32_4 %u32_1 %comp_unit %main_name %u32_3
%main_info = OpExtInst %void %DbgExt DebugFunction )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", ss.str(), "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllVulkan100DebugInfoFail, ValidateVulkan100DebugInfoDebugFunction,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%u32_0 %main_type_info %dbg_src %u32_4 %u32_1 %comp_unit %main_name %u32_3 %u32_4)",
            "Name"),
        std::make_pair(
            R"(%main_name %dbg_src %dbg_src %u32_4 %u32_1 %comp_unit %main_name %u32_3 %u32_4)",
            "Type"),
        std::make_pair(
            R"(%main_name %main_type_info %comp_unit %u32_4 %u32_1 %comp_unit %main_name %u32_3 %u32_4)",
            "Source"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src %u32_4 %u32_1 %dbg_src %main_name %u32_3 %u32_4)",
            "Parent"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src %u32_4 %u32_1 %comp_unit %void %u32_3 %u32_4)",
            "Linkage Name"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src %u32_4 %u32_1 %comp_unit %main_name %u32_3 %u32_4 %dbg_src)",
            "Declaration"),
    }));

TEST_P(ValidateVulkan100DebugInfoDebugFunctionDeclaration, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "struct VS_OUTPUT {
  float4 pos : SV_POSITION;
};
main() {}
"
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_decl = OpExtInst %void %DbgExt DebugFunctionDeclaration )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", ss.str(), "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllVulkan100DebugInfoFail,
    ValidateVulkan100DebugInfoDebugFunctionDeclaration,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%u32_0 %main_type_info %dbg_src %u32_4 %u32_1 %comp_unit %main_name %u32_3)",
            "Name"),
        std::make_pair(
            R"(%main_name %dbg_src %dbg_src %u32_4 %u32_1 %comp_unit %main_name %u32_3)",
            "Type"),
        std::make_pair(
            R"(%main_name %main_type_info %comp_unit %u32_4 %u32_1 %comp_unit %main_name %u32_3)",
            "Source"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src %u32_4 %u32_1 %dbg_src %main_name %u32_3)",
            "Parent"),
        std::make_pair(
            R"(%main_name %main_type_info %dbg_src %u32_4 %u32_1 %comp_unit %void %u32_3)",
            "Linkage Name"),
    }));

TEST_F(ValidateVulkan100DebugInfo, DebugFunctionType) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%uint_name = OpString "uint"
)";

  const std::string constants = R"(
%u32_6 = OpConstant %u32 6
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%uint_info = OpExtInst %void %DbgExt DebugTypeBasic %uint_name %u32_32 %u32_6 %u32_0
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %uint_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugFunction: expected operand Type must be a result "
                        "id of DebugTypeFunction"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugLexicalBlock) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%main_block = OpExtInst %void %DbgExt DebugLexicalBlock %dbg_src 1 1 %comp_unit %main_name)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateOpenCL100DebugInfoDebugLexicalBlock, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%main_block = OpExtInst %void %DbgExt DebugLexicalBlock )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", ss.str(), "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugLexicalBlock,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(R"(%comp_unit 1 1 %comp_unit %main_name)", "Source"),
        std::make_pair(R"(%dbg_src 1 1 %dbg_src %main_name)", "Parent"),
        std::make_pair(R"(%dbg_src 1 1 %comp_unit %void)", "Name"),
    }));

TEST_F(ValidateOpenCL100DebugInfo, DebugScopeFailScope) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %dbg_src
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(), HasSubstr("expected operand Scope"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugScopeFailInlinedAt) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %comp_unit %dbg_src
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(), HasSubstr("expected operand Inlined At"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLexicalBlock) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_block = OpExtInst %void %DbgExt DebugLexicalBlock %dbg_src %u32_1 %u32_1 %comp_unit %main_name
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateVulkan100DebugInfoDebugLexicalBlock, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_block = OpExtInst %void %DbgExt DebugLexicalBlock )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", ss.str(), "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllVulkan100DebugInfoFail, ValidateVulkan100DebugInfoDebugLexicalBlock,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(R"(%comp_unit %u32_1 %u32_1 %comp_unit %main_name)",
                       "Source"),
        std::make_pair(R"(%dbg_src %u32_1 %u32_1 %dbg_src %main_name)",
                       "Parent"),
        std::make_pair(R"(%dbg_src %u32_1 %u32_1 %comp_unit %void)", "Name"),
    }));

TEST_F(ValidateVulkan100DebugInfo, DebugScopeFailScope) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %dbg_src
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(), HasSubstr("expected operand Scope"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugScopeFailInlinedAt) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %comp_unit %dbg_src
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(), HasSubstr("expected operand Inlined At"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugLocalVariable) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %float_info %dbg_src 1 10 %comp_unit FlagIsLocal 0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateOpenCL100DebugInfoDebugLocalVariable, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo = OpExtInst %void %DbgExt DebugLocalVariable )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, ss.str(), "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugLocalVariable,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%void %float_info %dbg_src 1 10 %comp_unit FlagIsLocal 0)",
            "Name"),
        std::make_pair(
            R"(%foo_name %dbg_src %dbg_src 1 10 %comp_unit FlagIsLocal 0)",
            "Type"),
        std::make_pair(
            R"(%foo_name %float_info %comp_unit 1 10 %comp_unit FlagIsLocal 0)",
            "Source"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src 1 10 %dbg_src FlagIsLocal 0)",
            "Parent"),
    }));

TEST_F(ValidateVulkan100DebugInfo, DebugLocalVariable) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string constants = R"(
%u32_10 = OpConstant %u32 10
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %float_info %dbg_src %u32_1 %u32_10 %comp_unit %u32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateVulkan100DebugInfoDebugLocalVariable, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string constants = R"(
%u32_10 = OpConstant %u32 10
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo = OpExtInst %void %DbgExt DebugLocalVariable )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, ss.str(), "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllVulkan100DebugInfoFail, ValidateVulkan100DebugInfoDebugLocalVariable,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%void %float_info %dbg_src %u32_1 %u32_10 %comp_unit %u32_3 %u32_0)",
            "Name"),
        std::make_pair(
            R"(%foo_name %dbg_src %dbg_src %u32_1 %u32_10 %comp_unit %u32_3 %u32_0)",
            "Type"),
        std::make_pair(
            R"(%foo_name %float_info %comp_unit %u32_1 %u32_10 %comp_unit %u32_3 %u32_0)",
            "Source"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src %u32_1 %u32_10 %dbg_src %u32_3 %u32_0)",
            "Parent"),
    }));

TEST_F(ValidateOpenCL100DebugInfo, DebugDeclare) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %float_info %dbg_src 1 10 %comp_unit FlagIsLocal 0
)";

  const std::string body = R"(
%foo = OpVariable %f32_ptr_function Function
%decl = OpExtInst %void %DbgExt DebugDeclare %foo_info %foo %null_expr
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugDeclareParam) {
  CompileSuccessfully(R"(
               OpCapability Shader
          %1 = OpExtInstImport "OpenCL.DebugInfo.100"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Vertex %main "main" %in_var_COLOR
          %4 = OpString "test.hlsl"
               OpSource HLSL 620 %4 "#line 1 \"test.hlsl\"
void main(float foo:COLOR) {}
"
         %11 = OpString "#line 1 \"test.hlsl\"
void main(float foo:COLOR) {}
"
         %14 = OpString "float"
         %17 = OpString "src.main"
         %20 = OpString "foo"
               OpName %in_var_COLOR "in.var.COLOR"
               OpName %main "main"
               OpName %param_var_foo "param.var.foo"
               OpName %src_main "src.main"
               OpName %foo "foo"
               OpName %bb_entry "bb.entry"
               OpDecorate %in_var_COLOR Location 0
       %uint = OpTypeInt 32 0
    %uint_32 = OpConstant %uint 32
      %float = OpTypeFloat 32
%_ptr_Input_float = OpTypePointer Input %float
       %void = OpTypeVoid
         %23 = OpTypeFunction %void
%_ptr_Function_float = OpTypePointer Function %float
         %29 = OpTypeFunction %void %_ptr_Function_float
               OpLine %4 1 21
%in_var_COLOR = OpVariable %_ptr_Input_float Input
         %10 = OpExtInst %void %1 DebugExpression
         %12 = OpExtInst %void %1 DebugSource %4 %11
         %13 = OpExtInst %void %1 DebugCompilationUnit 1 4 %12 HLSL
         %15 = OpExtInst %void %1 DebugTypeBasic %14 %uint_32 Float
         %16 = OpExtInst %void %1 DebugTypeFunction FlagIsProtected|FlagIsPrivate %void %15
         %18 = OpExtInst %void %1 DebugFunction %17 %16 %12 1 1 %13 %17 FlagIsProtected|FlagIsPrivate 1 %src_main
         %21 = OpExtInst %void %1 DebugLocalVariable %20 %15 %12 1 17 %18 FlagIsLocal 0
         %22 = OpExtInst %void %1 DebugLexicalBlock %12 1 20 %18
               OpLine %4 1 1
       %main = OpFunction %void None %23
         %24 = OpLabel
               OpLine %4 1 17
%param_var_foo = OpVariable %_ptr_Function_float Function
         %27 = OpLoad %float %in_var_COLOR
               OpLine %4 1 1
         %28 = OpFunctionCall %void %src_main %param_var_foo
               OpReturn
               OpFunctionEnd
   %src_main = OpFunction %void None %29
               OpLine %4 1 17
        %foo = OpFunctionParameter %_ptr_Function_float
         %31 = OpExtInst %void %1 DebugDeclare %21 %foo %10
   %bb_entry = OpLabel
               OpLine %4 1 29
               OpReturn
               OpFunctionEnd
)");
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateOpenCL100DebugInfoDebugDeclare, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %float_info %dbg_src 1 10 %comp_unit FlagIsLocal 0
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%foo = OpVariable %f32_ptr_function Function
%decl = OpExtInst %void %DbgExt DebugDeclare )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, ss.str(), opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugDeclare,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(R"(%dbg_src %foo %null_expr)", "Local Variable"),
        std::make_pair(R"(%foo_info %void %null_expr)", "Variable"),
        std::make_pair(R"(%foo_info %foo %dbg_src)", "Expression"),
    }));

TEST_F(ValidateVulkan100DebugInfo, DebugDeclare) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string constants = R"(
%u32_10 = OpConstant %u32 10
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %float_info %dbg_src %u32_1 %u32_10 %comp_unit %u32_4
)";

  const std::string body = R"(
%foo = OpVariable %f32_ptr_function Function
%decl = OpExtInst %void %DbgExt DebugDeclare %foo_info %foo %null_expr
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugDeclareParam) {
  CompileSuccessfully(R"(
               OpCapability Shader
               OpExtension "SPV_KHR_non_semantic_info"
          %1 = OpExtInstImport "NonSemantic.Shader.DebugInfo.100"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Vertex %main "main" %in_var_COLOR
          %4 = OpString "test.hlsl"
               OpSource HLSL 620 %4 "#line 1 \"test.hlsl\"
void main(float foo:COLOR) {}
"
         %11 = OpString "#line 1 \"test.hlsl\"
void main(float foo:COLOR) {}
"
         %14 = OpString "float"
         %17 = OpString "src.main"
         %20 = OpString "foo"
               OpName %in_var_COLOR "in.var.COLOR"
               OpName %main "main"
               OpName %param_var_foo "param.var.foo"
               OpName %src_main "src.main"
               OpName %foo "foo"
               OpName %bb_entry "bb.entry"
               OpDecorate %in_var_COLOR Location 0
       %uint = OpTypeInt 32 0
      %u32_0 = OpConstant %uint 0
      %u32_1 = OpConstant %uint 1
      %u32_2 = OpConstant %uint 2
      %u32_3 = OpConstant %uint 3
      %u32_4 = OpConstant %uint 4
      %u32_5 = OpConstant %uint 5
     %u32_10 = OpConstant %uint 10
     %u32_17 = OpConstant %uint 17
     %u32_32 = OpConstant %uint 32
    %uint_32 = OpConstant %uint 32
      %float = OpTypeFloat 32
%_ptr_Input_float = OpTypePointer Input %float
       %void = OpTypeVoid
         %23 = OpTypeFunction %void
%_ptr_Function_float = OpTypePointer Function %float
         %29 = OpTypeFunction %void %_ptr_Function_float
               OpLine %4 1 21
%in_var_COLOR = OpVariable %_ptr_Input_float Input
         %10 = OpExtInst %void %1 DebugExpression
         %12 = OpExtInst %void %1 DebugSource %4 %11
         %13 = OpExtInst %void %1 DebugCompilationUnit %u32_1 %u32_4 %12 %u32_5
         %15 = OpExtInst %void %1 DebugTypeBasic %14 %uint_32 %u32_3 %u32_0
         %16 = OpExtInst %void %1 DebugTypeFunction %u32_3 %void %15
         %18 = OpExtInst %void %1 DebugFunction %17 %16 %12 %u32_1 %u32_1 %13 %17 %u32_3 %u32_1
         %21 = OpExtInst %void %1 DebugLocalVariable %20 %15 %12 %u32_1 %u32_17 %18 %u32_4 %u32_0
         %22 = OpExtInst %void %1 DebugLexicalBlock %12 %u32_1 %u32_4 %18
       %main = OpFunction %void None %23
         %24 = OpLabel
%param_var_foo = OpVariable %_ptr_Function_float Function
         %27 = OpLoad %float %in_var_COLOR
         %28 = OpFunctionCall %void %src_main %param_var_foo
               OpReturn
               OpFunctionEnd
   %src_main = OpFunction %void None %29
        %foo = OpFunctionParameter %_ptr_Function_float
         %31 = OpExtInst %void %1 DebugDeclare %21 %foo %10
   %bb_entry = OpLabel
               OpReturn
               OpFunctionEnd
)");
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateVulkan100DebugInfoDebugDeclare, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string constants = R"(
%u32_10 = OpConstant %u32 10
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %float_info %dbg_src %u32_1 %u32_10 %comp_unit %u32_4
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%foo = OpVariable %f32_ptr_function Function
%decl = OpExtInst %void %DbgExt DebugDeclare )"
     << param.first;

  CompileSuccessfully(
      GenerateShaderCodeForDebugInfo(src, constants, dbg_inst_header, ss.str(),
                                     shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllVulkan100DebugInfoFail, ValidateVulkan100DebugInfoDebugDeclare,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(R"(%dbg_src %foo %null_expr)", "Local Variable"),
        std::make_pair(R"(%foo_info %void %null_expr)", "Variable"),
        std::make_pair(R"(%foo_info %foo %dbg_src)", "Expression"),
    }));

TEST_F(ValidateOpenCL100DebugInfo, DebugExpression) {
  const std::string dbg_inst_header = R"(
%op0 = OpExtInst %void %DbgExt DebugOperation Deref
%op1 = OpExtInst %void %DbgExt DebugOperation Plus
%null_expr = OpExtInst %void %DbgExt DebugExpression %op0 %op1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      "", "", dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugExpressionFail) {
  const std::string dbg_inst_header = R"(
%op = OpExtInst %void %DbgExt DebugOperation Deref
%null_expr = OpExtInst %void %DbgExt DebugExpression %op %void
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      "", "", dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr(
          "expected operand Operation must be a result id of DebugOperation"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugExpression) {
  const std::string dbg_inst_header = R"(
%op0 = OpExtInst %void %DbgExt DebugOperation %u32_0
%op1 = OpExtInst %void %DbgExt DebugOperation %u32_1
%null_expr = OpExtInst %void %DbgExt DebugExpression %op0 %op1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      "", "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugExpressionFail) {
  const std::string dbg_inst_header = R"(
%op = OpExtInst %void %DbgExt DebugOperation %u32_0
%null_expr = OpExtInst %void %DbgExt DebugExpression %op %void
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      "", "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr(
          "expected operand Operation must be a result id of DebugOperation"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeTemplate) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
%int_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%opaque = OpExtInst %void %DbgExt DebugTypeComposite %ty_name Class %dbg_src 1 1 %comp_unit %ty_name %dbg_none FlagIsPublic
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src 0 0
%temp = OpExtInst %void %DbgExt DebugTypeTemplate %opaque %param
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeTemplateUsedForVariableType) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
%int_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%opaque = OpExtInst %void %DbgExt DebugTypeComposite %ty_name Class %dbg_src 1 1 %comp_unit %ty_name %dbg_none FlagIsPublic
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src 0 0
%temp = OpExtInst %void %DbgExt DebugTypeTemplate %opaque %param
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %temp %dbg_src 0 0 %comp_unit %foo_name %f32_input FlagIsProtected|FlagIsPrivate
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeTemplateFunction) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
%int_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src 0 0
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %param %param
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 1 %main
%temp = OpExtInst %void %DbgExt DebugTypeTemplate %main_info %param
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeTemplateFailTarget) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
%int_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src 0 0
%temp = OpExtInst %void %DbgExt DebugTypeTemplate %float_info %param
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Target must be DebugTypeComposite or "
                        "DebugFunction"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugTypeTemplateFailParam) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
%int_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src 0 0
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %param %param
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 1 %main
%temp = OpExtInst %void %DbgExt DebugTypeTemplate %main_info %float_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr(
          "expected operand Parameters must be DebugTypeTemplateParameter or "
          "DebugTypeTemplateTemplateParameter"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeTemplate) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%opaque = OpExtInst %void %DbgExt DebugTypeComposite %ty_name %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %ty_name %dbg_none %u32_3
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src %u32_0 %u32_0
%temp = OpExtInst %void %DbgExt DebugTypeTemplate %opaque %param
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeTemplateUsedForVariableType) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%opaque = OpExtInst %void %DbgExt DebugTypeComposite %ty_name %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %ty_name %dbg_none %u32_3
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src %u32_0 %u32_0
%temp = OpExtInst %void %DbgExt DebugTypeTemplate %opaque %param
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %temp %dbg_src %u32_0 %u32_0 %comp_unit %foo_name %f32_input %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeTemplateFunction) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src %u32_0 %u32_0
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %param %param
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
%temp = OpExtInst %void %DbgExt DebugTypeTemplate %main_info %param
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeTemplateFailTarget) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src %u32_0 %u32_0
%temp = OpExtInst %void %DbgExt DebugTypeTemplate %float_info %param
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Target must be DebugTypeComposite or "
                        "DebugFunction"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeTemplateFailParam) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "OpaqueType foo;
main() {}
"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%opaque = OpExtInst %void %DbgExt DebugTypeComposite %ty_name %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %ty_name %dbg_none %u32_3
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src %u32_0 %u32_0
%temp = OpExtInst %void %DbgExt DebugTypeTemplate %opaque %float_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr(
          "expected operand Parameters must be DebugTypeTemplateParameter or "
          "DebugTypeTemplateTemplateParameter"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugGlobalVariable) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %float_info %dbg_src 0 0 %comp_unit %foo_name %f32_input FlagIsProtected|FlagIsPrivate
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugGlobalVariableStaticMember) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%t = OpExtInst %void %DbgExt DebugTypeComposite %foo_name Class %dbg_src 0 0 %comp_unit %foo_name %int_32 FlagIsPublic %a
%a = OpExtInst %void %DbgExt DebugTypeMember %foo_name %float_info %dbg_src 0 0 %t %u32_0 %int_32 FlagIsPublic
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %float_info %dbg_src 0 0 %comp_unit %foo_name %f32_input FlagIsProtected|FlagIsPrivate %a
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugGlobalVariableDebugInfoNone) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbgNone = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %float_info %dbg_src 0 0 %comp_unit %foo_name %dbgNone FlagIsProtected|FlagIsPrivate
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugGlobalVariableDebugExpressionFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%expr = OpExtInst %void %DbgExt DebugExpression
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %float_info %dbg_src 0 0 %comp_unit %foo_name %expr FlagIsProtected|FlagIsPrivate
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Variable must be a result id of "
                        "OpVariable, OpConstant variant, OpSpecConstant "
                        "variant or DebugInfoNone"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugGlobalVariableConst) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %float_info %dbg_src 0 0 %comp_unit %foo_name %int_32 FlagIsProtected|FlagIsPrivate
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateOpenCL100DebugInfoDebugGlobalVariable, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo = OpExtInst %void %DbgExt DebugGlobalVariable )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, ss.str(), "", opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugGlobalVariable,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%void %float_info %dbg_src 0 0 %comp_unit %foo_name %f32_input FlagIsProtected|FlagIsPrivate)",
            "Name"),
        std::make_pair(
            R"(%foo_name %dbg_src %dbg_src 0 0 %comp_unit %foo_name %f32_input FlagIsProtected|FlagIsPrivate)",
            "Type"),
        std::make_pair(
            R"(%foo_name %float_info %comp_unit 0 0 %comp_unit %foo_name %f32_input FlagIsProtected|FlagIsPrivate)",
            "Source"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src 0 0 %dbg_src %foo_name %f32_input FlagIsProtected|FlagIsPrivate)",
            "Scope"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src 0 0 %comp_unit %void %f32_input FlagIsProtected|FlagIsPrivate)",
            "Linkage Name"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src 0 0 %comp_unit %foo_name %void FlagIsProtected|FlagIsPrivate)",
            "Variable"),
    }));

TEST_F(ValidateVulkan100DebugInfo, DebugGlobalVariable) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %float_info %dbg_src %u32_0 %u32_0 %comp_unit %foo_name %f32_input %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugGlobalVariableStaticMember) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%a = OpExtInst %void %DbgExt DebugTypeMember %foo_name %float_info %dbg_src %u32_0 %u32_0 %u32_0 %u32_32 %u32_3
%t = OpExtInst %void %DbgExt DebugTypeComposite %foo_name %u32_1 %dbg_src %u32_0 %u32_0 %comp_unit %foo_name %u32_32 %u32_3 %a
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %t %dbg_src %u32_0 %u32_0 %comp_unit %foo_name %f32_input %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugGlobalVariableDebugInfoNone) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbgNone = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %float_info %dbg_src %u32_0 %u32_0 %comp_unit %foo_name %dbgNone %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugGlobalVariableConst) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %float_info %dbg_src %u32_0 %u32_0 %comp_unit %foo_name %u32_32 %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugGlobalVariableDebugExpression) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "static const float foo = 1.0; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string consts = R"(
%u32_7 = OpConstant %u32 7
%u32_8 = OpConstant %u32 8
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%const_op = OpExtInst %void %DbgExt DebugOperation %u32_8 %u32_1
%stack_op = OpExtInst %void %DbgExt DebugOperation %u32_7
%expr = OpExtInst %void %DbgExt DebugExpression %const_op %stack_op
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %float_info %dbg_src %u32_0 %u32_0 %comp_unit %foo_name %expr %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, consts, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateVulkan100DebugInfoDebugGlobalVariable, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "float foo; void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo = OpExtInst %void %DbgExt DebugGlobalVariable )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", ss.str(), "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateVulkan100DebugInfoDebugGlobalVariable,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(
            R"(%void %float_info %dbg_src %u32_0 %u32_0 %comp_unit %foo_name %f32_input %u32_3)",
            "Name"),
        std::make_pair(
            R"(%foo_name %dbg_src %dbg_src %u32_0 %u32_0 %comp_unit %foo_name %f32_input %u32_3)",
            "Type"),
        std::make_pair(
            R"(%foo_name %float_info %comp_unit %u32_0 %u32_0 %comp_unit %foo_name %f32_input %u32_3)",
            "Source"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src %u32_0 %u32_0 %dbg_src %foo_name %f32_input %u32_3)",
            "Scope"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src %u32_0 %u32_0 %comp_unit %void %f32_input %u32_3)",
            "Linkage Name"),
        std::make_pair(
            R"(%foo_name %float_info %dbg_src %u32_0 %u32_0 %comp_unit %foo_name %void %u32_3)",
            "Variable"),
    }));

TEST_F(ValidateOpenCL100DebugInfo, DebugInlinedAt) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%void_name = OpString "void"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 1 %main
%inlined_at = OpExtInst %void %DbgExt DebugInlinedAt 0 %main_info
%inlined_at_recursive = OpExtInst %void %DbgExt DebugInlinedAt 0 %main_info %inlined_at
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %main_info %inlined_at
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugInlinedAtFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%void_name = OpString "void"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 1 %main
%inlined_at = OpExtInst %void %DbgExt DebugInlinedAt 0 %main_info
%inlined_at_recursive = OpExtInst %void %DbgExt DebugInlinedAt 0 %inlined_at
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %main_info %inlined_at
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(), HasSubstr("expected operand Scope"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugInlinedAtFail2) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%void_name = OpString "void"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction FlagIsPublic %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src 1 1 %comp_unit %main_name FlagIsPublic 1 %main
%inlined_at = OpExtInst %void %DbgExt DebugInlinedAt 0 %main_info
%inlined_at_recursive = OpExtInst %void %DbgExt DebugInlinedAt 0 %main_info %main_info
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %main_info %inlined_at
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(), HasSubstr("expected operand Inlined"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugInlinedAt) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%void_name = OpString "void"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
%inlined_at = OpExtInst %void %DbgExt DebugInlinedAt %u32_0 %main_info
%inlined_at_recursive = OpExtInst %void %DbgExt DebugInlinedAt %u32_0 %main_info %inlined_at
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %main_info %inlined_at
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugInlinedAtFail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%void_name = OpString "void"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
%inlined_at = OpExtInst %void %DbgExt DebugInlinedAt %u32_0 %main_info
%inlined_at_recursive = OpExtInst %void %DbgExt DebugInlinedAt %u32_0 %inlined_at %inlined_at
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %main_info %inlined_at
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(), HasSubstr("expected operand Scope"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugInlinedAtFail2) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%void_name = OpString "void"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
%inlined_at = OpExtInst %void %DbgExt DebugInlinedAt %u32_0 %main_info
%inlined_at_recursive = OpExtInst %void %DbgExt DebugInlinedAt %u32_0 %main_info %main_info
)";

  const std::string body = R"(
%main_scope = OpExtInst %void %DbgExt DebugScope %main_info %inlined_at
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(), HasSubstr("expected operand Inlined"));
}

TEST_F(ValidateOpenCL100DebugInfo, DebugValue) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_3 = OpConstant %u32 3
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info 4
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %v4float_info %dbg_src 1 10 %comp_unit FlagIsLocal 0
)";

  const std::string body = R"(
%value = OpExtInst %void %DbgExt DebugValue %foo_info %int_32 %null_expr %int_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateOpenCL100DebugInfo, DebugValueWithVariableIndex) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%int_name = OpString "int"
%foo_name = OpString "foo"
%len_name = OpString "length"
)";

  const std::string size_const = R"(
%int_3 = OpConstant %u32 3
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%int_info = OpExtInst %void %DbgExt DebugTypeBasic %int_name %int_32 Signed
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info 4
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %v4float_info %dbg_src 1 10 %comp_unit FlagIsLocal
%len_info = OpExtInst %void %DbgExt DebugLocalVariable %len_name %int_info %dbg_src 0 0 %comp_unit FlagIsLocal
)";

  const std::string body = R"(
%value = OpExtInst %void %DbgExt DebugValue %foo_info %int_32 %null_expr %len_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, body, opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateOpenCL100DebugInfoDebugValue, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string size_const = R"(
%int_32 = OpConstant %u32 32
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit 2 4 %dbg_src HLSL
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %int_32 Float
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %float_info %dbg_src 1 10 %comp_unit FlagIsLocal 0
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%decl = OpExtInst %void %DbgExt DebugValue )"
     << param.first;

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, size_const, dbg_inst_header, ss.str(), opencl_extension, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateOpenCL100DebugInfoDebugValue,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(R"(%dbg_src %int_32 %null_expr)", "Local Variable"),
        std::make_pair(R"(%foo_info %int_32 %dbg_src)", "Expression"),
        std::make_pair(R"(%foo_info %int_32 %null_expr %dbg_src)", "Indexes"),
    }));

TEST_F(ValidateVulkan100DebugInfo, DebugValue) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string constants = R"(
%u32_10 = OpConstant %u32 10
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %v4float_info %dbg_src %u32_1 %u32_10 %comp_unit %u32_4
)";

  const std::string body = R"(
%value = OpExtInst %void %DbgExt DebugValue %foo_info %u32_32 %null_expr %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugValueWithVariableIndex) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%int_name = OpString "int"
%foo_name = OpString "foo"
%len_name = OpString "length"
)";

  const std::string constants = R"(
%u32_10 = OpConstant %u32 10
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%int_info = OpExtInst %void %DbgExt DebugTypeBasic %int_name %u32_32 %u32_4 %u32_0
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %v4float_info %dbg_src %u32_1 %u32_10 %comp_unit %u32_4 %u32_0
%len_info = OpExtInst %void %DbgExt DebugLocalVariable %len_name %int_info %dbg_src %u32_0 %u32_0 %comp_unit %u32_4
)";

  const std::string body = R"(
%value = OpExtInst %void %DbgExt DebugValue %foo_info %u32_32 %null_expr %len_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_P(ValidateVulkan100DebugInfoDebugValue, Fail) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string constants = R"(
%u32_10 = OpConstant %u32 10
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %v4float_info %dbg_src %u32_1 %u32_10 %comp_unit %u32_4 %u32_0
)";

  const auto& param = GetParam();

  std::ostringstream ss;
  ss << R"(
%decl = OpExtInst %void %DbgExt DebugValue )"
     << param.first;

  CompileSuccessfully(
      GenerateShaderCodeForDebugInfo(src, constants, dbg_inst_header, ss.str(),
                                     shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand " + param.second));
}

INSTANTIATE_TEST_SUITE_P(
    AllOpenCL100DebugInfoFail, ValidateVulkan100DebugInfoDebugValue,
    ::testing::ValuesIn(std::vector<std::pair<std::string, std::string>>{
        std::make_pair(R"(%dbg_src %u32_32 %null_expr %u32_3)",
                       "Local Variable"),
        std::make_pair(R"(%foo_info %u32_32 %dbg_src %u32_3)", "Expression"),
        std::make_pair(R"(%foo_info %u32_32 %null_expr %dbg_src)", "Indexes"),
    }));

TEST_F(ValidateVulkan100DebugInfo, VulkanDebugInfoSample) {
  std::ostringstream ss;
  ss << R"(
               OpCapability Shader
               OpExtension "SPV_KHR_non_semantic_info"
          %id_1 = OpExtInstImport "NonSemantic.Shader.DebugInfo.100"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %id_MainPs "MainPs" %id_in_var_TEXCOORD2 %id_out_var_SV_Target0
               OpExecutionMode %id_MainPs OriginUpperLeft
          %id_7 = OpString "foo.frag"
         %id_27 = OpString "float"
         %id_32 = OpString "vColor"
         %id_36 = OpString "PS_OUTPUT"
         %id_42 = OpString "vTextureCoords"
         %id_46 = OpString "PS_INPUT"
         %id_49 = OpString "MainPs"
         %id_50 = OpString ""
         %id_55 = OpString "ps_output"
         %id_59 = OpString "i"
         %id_63 = OpString "@type.sampler"
         %id_64 = OpString "type.sampler"
         %id_66 = OpString "g_sAniso"
         %id_69 = OpString "@type.2d.image"
         %id_70 = OpString "type.2d.image"
         %id_72 = OpString "TemplateParam"
         %id_75 = OpString "g_tColor"
               OpName %id_type_2d_image "type.2d.image"
               OpName %id_g_tColor "g_tColor"
               OpName %id_type_sampler "type.sampler"
               OpName %id_g_sAniso "g_sAniso"
               OpName %id_in_var_TEXCOORD2 "in.var.TEXCOORD2"
               OpName %id_out_var_SV_Target0 "out.var.SV_Target0"
               OpName %id_MainPs "MainPs"
               OpName %id_PS_INPUT "PS_INPUT"
               OpMemberName %id_PS_INPUT 0 "vTextureCoords"
               OpName %id_param_var_i "param.var.i"
               OpName %id_PS_OUTPUT "PS_OUTPUT"
               OpMemberName %id_PS_OUTPUT 0 "vColor"
               OpName %id_src_MainPs "src.MainPs"
               OpName %id_i "i"
               OpName %id_bb_entry "bb.entry"
               OpName %id_ps_output "ps_output"
               OpName %id_type_sampled_image "type.sampled.image"
               OpDecorate %id_in_var_TEXCOORD2 Location 0
               OpDecorate %id_out_var_SV_Target0 Location 0
               OpDecorate %id_g_tColor DescriptorSet 0
               OpDecorate %id_g_tColor Binding 0
               OpDecorate %id_g_sAniso DescriptorSet 0
               OpDecorate %id_g_sAniso Binding 1
        %id_int = OpTypeInt 32 1
      %id_int_0 = OpConstant %id_int 0
       %id_uint = OpTypeInt 32 0
    %id_uint_32 = OpConstant %id_uint 32
      %id_float = OpTypeFloat 32
%id_type_2d_image = OpTypeImage %id_float 2D 2 0 0 1 Unknown
%id__ptr_UniformConstant_type_2d_image = OpTypePointer UniformConstant %id_type_2d_image
%id_type_sampler = OpTypeSampler
%id__ptr_UniformConstant_type_sampler = OpTypePointer UniformConstant %id_type_sampler
    %id_v2float = OpTypeVector %id_float 2
%id__ptr_Input_v2float = OpTypePointer Input %id_v2float
    %id_v4float = OpTypeVector %id_float 4
%id__ptr_Output_v4float = OpTypePointer Output %id_v4float
       %id_void = OpTypeVoid
     %id_uint_1 = OpConstant %id_uint 1
     %id_uint_4 = OpConstant %id_uint 4
     %id_uint_5 = OpConstant %id_uint 5
     %id_uint_3 = OpConstant %id_uint 3
     %id_uint_0 = OpConstant %id_uint 0
   %id_uint_128 = OpConstant %id_uint 128
    %id_uint_12 = OpConstant %id_uint 12
    %id_uint_10 = OpConstant %id_uint 10
     %id_uint_8 = OpConstant %id_uint 8
     %id_uint_2 = OpConstant %id_uint 2
    %id_uint_64 = OpConstant %id_uint 64
     %id_uint_7 = OpConstant %id_uint 7
    %id_uint_15 = OpConstant %id_uint 15
    %id_uint_16 = OpConstant %id_uint 16
    %id_uint_17 = OpConstant %id_uint 17
    %id_uint_29 = OpConstant %id_uint 29
    %id_uint_14 = OpConstant %id_uint 14
    %id_uint_11 = OpConstant %id_uint 11
         %id_78 = OpTypeFunction %id_void
   %id_PS_INPUT = OpTypeStruct %id_v2float
%id__ptr_Function_PS_INPUT = OpTypePointer Function %id_PS_INPUT
  %id_PS_OUTPUT = OpTypeStruct %id_v4float
         %id_89 = OpTypeFunction %id_PS_OUTPUT %id__ptr_Function_PS_INPUT
%id__ptr_Function_PS_OUTPUT = OpTypePointer Function %id_PS_OUTPUT
    %id_uint_20 = OpConstant %id_uint 20
    %id_uint_19 = OpConstant %id_uint 19
    %id_uint_26 = OpConstant %id_uint 26
    %id_uint_46 = OpConstant %id_uint 46
%id__ptr_Function_v2float = OpTypePointer Function %id_v2float
    %id_uint_57 = OpConstant %id_uint 57
    %id_uint_78 = OpConstant %id_uint 78
%id_type_sampled_image = OpTypeSampledImage %id_type_2d_image
    %id_uint_81 = OpConstant %id_uint 81
%id__ptr_Function_v4float = OpTypePointer Function %id_v4float
   %id_g_tColor = OpVariable %id__ptr_UniformConstant_type_2d_image UniformConstant
   %id_g_sAniso = OpVariable %id__ptr_UniformConstant_type_sampler UniformConstant
%id_in_var_TEXCOORD2 = OpVariable %id__ptr_Input_v2float Input
%id_out_var_SV_Target0 = OpVariable %id__ptr_Output_v4float Output
         %id_22 = OpExtInst %id_void %id_1 DebugSource %id_7
         %id_23 = OpExtInst %id_void %id_1 DebugCompilationUnit %id_uint_1 %id_uint_4 %id_22 %id_uint_5
         %id_28 = OpExtInst %id_void %id_1 DebugTypeBasic %id_27 %id_uint_32 %id_uint_3 %id_uint_0
         %id_31 = OpExtInst %id_void %id_1 DebugTypeVector %id_28 %id_uint_4
         %id_34 = OpExtInst %id_void %id_1 DebugTypeMember %id_32 %id_31 %id_22 %id_uint_12 %id_uint_12 %id_uint_0 %id_uint_128 %id_uint_3
         %id_37 = OpExtInst %id_void %id_1 DebugTypeComposite %id_36 %id_uint_1 %id_22 %id_uint_10 %id_uint_8 %id_23 %id_36 %id_uint_128 %id_uint_3 %id_34
         %id_40 = OpExtInst %id_void %id_1 DebugTypeVector %id_28 %id_uint_2
         %id_44 = OpExtInst %id_void %id_1 DebugTypeMember %id_42 %id_40 %id_22 %id_uint_7 %id_uint_12 %id_uint_0 %id_uint_64 %id_uint_3
         %id_47 = OpExtInst %id_void %id_1 DebugTypeComposite %id_46 %id_uint_1 %id_22 %id_uint_5 %id_uint_8 %id_23 %id_46 %id_uint_64 %id_uint_3 %id_44
         %id_48 = OpExtInst %id_void %id_1 DebugTypeFunction %id_uint_3 %id_37 %id_47
         %id_51 = OpExtInst %id_void %id_1 DebugFunction %id_49 %id_48 %id_22 %id_uint_15 %id_uint_1 %id_23 %id_50 %id_uint_3 %id_uint_16
         %id_54 = OpExtInst %id_void %id_1 DebugLexicalBlock %id_22 %id_uint_16 %id_uint_1 %id_51
         %id_56 = OpExtInst %id_void %id_1 DebugLocalVariable %id_55 %id_37 %id_22 %id_uint_17 %id_uint_15 %id_54 %id_uint_4
         %id_58 = OpExtInst %id_void %id_1 DebugExpression
         %id_60 = OpExtInst %id_void %id_1 DebugLocalVariable %id_59 %id_47 %id_22 %id_uint_15 %id_uint_29 %id_51 %id_uint_4 %id_uint_1
         %id_62 = OpExtInst %id_void %id_1 DebugInfoNone
         %id_65 = OpExtInst %id_void %id_1 DebugTypeComposite %id_63 %id_uint_1 %id_22 %id_uint_0 %id_uint_0 %id_23 %id_64 %id_62 %id_uint_3
         %id_67 = OpExtInst %id_void %id_1 DebugGlobalVariable %id_66 %id_65 %id_22 %id_uint_3 %id_uint_14 %id_23 %id_66 %id_g_sAniso %id_uint_8
         %id_71 = OpExtInst %id_void %id_1 DebugTypeComposite %id_69 %id_uint_0 %id_22 %id_uint_0 %id_uint_0 %id_23 %id_70 %id_62 %id_uint_3
         %id_73 = OpExtInst %id_void %id_1 DebugTypeTemplateParameter %id_72 %id_31 %id_62 %id_22 %id_uint_0 %id_uint_0
         %id_74 = OpExtInst %id_void %id_1 DebugTypeTemplate %id_71 %id_73
         %id_76 = OpExtInst %id_void %id_1 DebugGlobalVariable %id_75 %id_74 %id_22 %id_uint_1 %id_uint_11 %id_23 %id_75 %id_g_tColor %id_uint_8
     %id_MainPs = OpFunction %id_void None %id_78
         %id_79 = OpLabel
%id_param_var_i = OpVariable %id__ptr_Function_PS_INPUT Function
         %id_83 = OpLoad %id_v2float %id_in_var_TEXCOORD2
         %id_84 = OpCompositeConstruct %id_PS_INPUT %id_83
               OpStore %id_param_var_i %id_84
         %id_86 = OpFunctionCall %id_PS_OUTPUT %id_src_MainPs %id_param_var_i
         %id_88 = OpCompositeExtract %id_v4float %id_86 0
               OpStore %id_out_var_SV_Target0 %id_88
               OpReturn
               OpFunctionEnd
 %id_src_MainPs = OpFunction %id_PS_OUTPUT None %id_89
          %id_i = OpFunctionParameter %id__ptr_Function_PS_INPUT
   %id_bb_entry = OpLabel
  %id_ps_output = OpVariable %id__ptr_Function_PS_OUTPUT Function
         %id_94 = OpExtInst %id_void %id_1 DebugScope %id_51
         %id_97 = OpExtInst %id_void %id_1 DebugDeclare %id_60 %id_i %id_58
         %id_99 = OpExtInst %id_void %id_1 DebugFunctionDefinition %id_51 %id_src_MainPs
        %id_100 = OpExtInst %id_void %id_1 DebugScope %id_54
        %id_102 = OpExtInst %id_void %id_1 DebugDeclare %id_56 %id_ps_output %id_58
        %id_106 = OpLoad %id_type_2d_image %id_g_tColor
        %id_109 = OpLoad %id_type_sampler %id_g_sAniso
        %id_114 = OpAccessChain %id__ptr_Function_v2float %id_i %id_int_0
        %id_115 = OpLoad %id_v2float %id_114
        %id_119 = OpSampledImage %id_type_sampled_image %id_106 %id_109
        %id_120 = OpImageSampleImplicitLod %id_v4float %id_119 %id_115 None
        %id_123 = OpAccessChain %id__ptr_Function_v4float %id_ps_output %id_int_0
               OpStore %id_123 %id_120
        %id_125 = OpLoad %id_PS_OUTPUT %id_ps_output
               OpReturnValue %id_125
               OpFunctionEnd
)";

  CompileSuccessfully(ss.str());
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugFunctionDefinition) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  const std::string body = R"(
%main_def = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info %main
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugFunctionDefinitionFailFunction) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  const std::string body = R"(
%main_def = OpExtInst %void %DbgExt DebugFunctionDefinition %main_type_info %main
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugFunctionDefinition: expected operand Function "
                        "must be a result id of DebugFunction"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugFunctionDefinitionFailDefinition) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  const std::string body = R"(
%main_def = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info %main_name
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugFunctionDefinition: expected operand Definition "
                        "must be a result id of OpFunction"));
}

// TODO - Need to track in function scope
TEST_F(ValidateVulkan100DebugInfo, DISABLED_DebugFunctionDefinitionDuplicate) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info1 = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
%main_info2 = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  const std::string body = R"(
%main_def1 = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info1 %main
%main_def2 = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info2 %main
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugFunctionDefinition: Was used multiple times in "
                        "single function block"));
}

// TODO - Need to track in function scope
TEST_F(ValidateVulkan100DebugInfo,
       DISABLED_DebugFunctionDefinitionDuplicateReference) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  const std::string body = R"(
%main_def = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info %main
OpReturn
OpFunctionEnd

%foo = OpFunction %void None %func
%foo_entry = OpLabel
%foo_def = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info %foo
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugFunctionDefinition: Was referenced a "
                        "DebugFunction that was already referenced before"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugFunctionDefinitionWrongDefinition) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
%foo_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  const std::string body = R"(
%main_def = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info %main
OpReturn
OpFunctionEnd

%foo = OpFunction %void None %func
%foo_entry = OpLabel
%foo_def = OpExtInst %void %DbgExt DebugFunctionDefinition %foo_info %main
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugFunctionDefinition: operand Definition must "
                        "point to the OpFunction it is inside"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugFunctionDefinitionNonEntryBlock) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string constants = R"(
%false = OpConstantFalse %bool
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  const std::string body = R"(
OpSelectionMerge %merge_block None
OpBranchConditional %false %second_block %merge_block
%second_block = OpLabel
OpReturn
%merge_block = OpLabel
%main_def = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info %main
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugFunctionDefinition: must be in the entry basic "
                        "block of the function"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugFunctionDefinitionMultiFunctions) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
%foo_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  const std::string body = R"(
%main_def = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info %main
OpReturn
OpFunctionEnd

%foo = OpFunction %void None %func
%foo_entry = OpLabel
%foo_def = OpExtInst %void %DbgExt DebugFunctionDefinition %foo_info %foo
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {
}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_1 %u32_2 %u32_0 %u32_0
%line2 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_1 %u32_2 %u32_0 %u32_0
%no_line = OpExtInst %void %DbgExt DebugNoLine
%line3 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_1 %u32_2 %u32_0 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugNoLineOutOfBlock) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%no_line = OpExtInst %void %DbgExt DebugNoLine
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_LAYOUT, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("debug info extension must appear in a function body"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineOutOfBlock) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%line = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_1 %u32_2 %u32_0 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_LAYOUT, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("debug info extension must appear in a function body"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineSource) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
%int_name = OpString "int"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%int_info = OpExtInst %void %DbgExt DebugTypeBasic %int_name %u32_0 %u32_1 %u32_0
)";

  const std::string body = R"(
%line = OpExtInst %void %DbgExt DebugLine %int_info %u32_2 %u32_2 %u32_0 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: expected operand Source must be a result "
                        "id of DebugSource"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineFloat) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %f32_1 %u32_2 %u32_0 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: expected operand Line Start must be a "
                        "result id of 32-bit unsigned OpConstant"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineInt64) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u64_1 %u64_1 %u32_0 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: expected operand Line Start must be a "
                        "result id of 32-bit unsigned OpConstant"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineSpecConstant) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%spec_int = OpSpecConstant %u32 2
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %spec_int %u32_1 %u32_0 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: expected operand Line Start must be a "
                        "result id of 32-bit unsigned OpConstant"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineLineStartZero) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_0 %u32_0 %u32_0 %u32_5
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineLineStartZeroMultiline) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_0 %u32_1 %u32_32 %u32_5
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineLineStartZeroColumnEndOutOfBounds) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "1
123"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_0 %u32_1 %u32_0 %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: operand Column End (3) is larger then Line "
                        "1 column length of 2 found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineLineEndSmaller) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_2 %u32_1 %u32_0 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("DebugLine: operand Line End (1) is less than Line Start (2)"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineColumnEndSmaller) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_1 %u32_1 %u32_1 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: operand Column End (0) is less than Column "
                        "Start (1) when Line Start equals Line End"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineColumnEndSmallerMultiline) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {
}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_1 %u32_2 %u32_1 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineOutOfBounds) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "// line 1
int main() {
}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_4 %u32_4 %u32_0 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: operand Line End (4) is larger then the 3 "
                        "lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineColumnOutOfBounds) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "// line 1
123"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_2 %u32_2 %u32_1 %u32_5
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: operand Column End (5) is larger then Line "
                        "2 column length of 4 found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineColumnOutOfBoundsEmptyLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "next line is empty

line 3"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_2 %u32_2 %u32_2 %u32_2
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: operand Column End (2) is larger then Line "
                        "2 column length of 1 found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineColumnEmptyLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "next line is empty

line 3"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_2 %u32_2 %u32_1 %u32_1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineColumnStartOutOfBounds) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "1
123
line 3"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_1 %u32_2 %u32_3 %u32_1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("DebugLine: operand Column Start (3) is larger then Line 1 "
                "column length of 2 found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineColumnEndOutOfBounds) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "1
123
line 3"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_1 %u32_2 %u32_1 %u32_5
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: operand Column End (5) is larger then Line "
                        "2 column length of 4 found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineDebugSourceContinuedSuccess) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "line 1
line 2
line 3
"
%code2 = OpString "line 4
line 5"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%dbg_src2 = OpExtInst %void %DbgExt DebugSourceContinued %code2
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_4 %u32_5 %u32_1 %u32_1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineDebugSourceContinued) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "line 1
line 2
"
%code2 = OpString "line 3
line 4"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%dbg_src2 = OpExtInst %void %DbgExt DebugSourceContinued %code2
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_4 %u32_5 %u32_1 %u32_1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: operand Line End (5) is larger then the 4 "
                        "lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo,
       DebugLineMultipleDebugSourceContinuedSuccess) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "line 1
"
%code2 = OpString "line 2
line 3
"
%code3 = OpString "line 4
5"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%dbg_src2 = OpExtInst %void %DbgExt DebugSourceContinued %code2
%dbg_src3 = OpExtInst %void %DbgExt DebugSourceContinued %code3
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_5 %u32_5 %u32_1 %u32_2
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugLineMultipleDebugSourceContinued) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "line 1
"
%code2 = OpString "line 2
line 3
"
%code3 = OpString "line 4
5"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%dbg_src2 = OpExtInst %void %DbgExt DebugSourceContinued %code2
%dbg_src3 = OpExtInst %void %DbgExt DebugSourceContinued %code3
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_5 %u32_5 %u32_1 %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugLine: operand Column End (3) is larger then Line "
                        "5 column length of 2 found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceLineNoText) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src
)";

  const std::string body = R"(
%line1 = OpExtInst %void %DbgExt DebugLine %dbg_src %u32_5 %u32_5 %u32_1 %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugTypeMemberLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "line 1
line 2
line 3"
%uint_name = OpString "uint"
%member_name = OpString "x"
)";

  const std::string constants = R"(
%u32_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%uint_info = OpExtInst %void %DbgExt DebugTypeBasic %uint_name %u32_32 %u32_4 %u32_0
%x = OpExtInst %void %DbgExt DebugTypeMember %member_name %uint_info %dbg_src %u32_4 %u32_1 %u32_0 %u32_128 %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugTypeMember: operand Line (4) is larger then the "
                        "3 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugTypeMemberColumn) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "line 1
line 2
3"
%uint_name = OpString "uint"
%member_name = OpString "x"
)";

  const std::string constants = R"(
%u32_128 = OpConstant %u32 128
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%uint_info = OpExtInst %void %DbgExt DebugTypeBasic %uint_name %u32_32 %u32_4 %u32_0
%x = OpExtInst %void %DbgExt DebugTypeMember %member_name %uint_info %dbg_src %u32_3 %u32_3 %u32_0 %u32_128 %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("DebugTypeMember: operand Column End (3) is larger then Line 3 "
                "column length of 2 found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugFunctionLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_2 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  const std::string body = R"(
%main_def = OpExtInst %void %DbgExt DebugFunctionDefinition %main_info %main
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugFunction: operand Line (2) is larger then the "
                        "1 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugFunctionDeclarationLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() { }"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_type_info = OpExtInst %void %DbgExt DebugTypeFunction %u32_3 %void
%main_decl = OpExtInst %void %DbgExt DebugFunctionDeclaration %main_name %main_type_info %dbg_src %u32_2 %u32_1 %comp_unit %main_name %u32_3
%main_info = OpExtInst %void %DbgExt DebugFunction %main_name %main_type_info %dbg_src %u32_1 %u32_1 %comp_unit %main_name %u32_3 %u32_1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("DebugFunctionDeclaration: operand Line (2) is larger then the "
                "1 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugLexicalBlockLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%main_block = OpExtInst %void %DbgExt DebugLexicalBlock %dbg_src %u32_2 %u32_1 %comp_unit %main_name
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("DebugLexicalBlock: operand Line (2) is larger then the "
                "1 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugTypedefLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo_info = OpExtInst %void %DbgExt DebugTypedef %foo_name %float_info %dbg_src %u32_2 %u32_1 %comp_unit
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugTypedef: operand Line (2) is larger then the "
                        "1 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugEnumLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%none = OpExtInst %void %DbgExt DebugInfoNone
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%foo_info1 = OpExtInst %void %DbgExt DebugTypeEnum %foo_name %float_info %dbg_src %u32_2 %u32_1 %comp_unit %u32_32 %u32_3 %u32_0 %foo_name %u32_1 %foo_name
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugTypeEnum: operand Line (2) is larger then the "
                        "1 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugTypeCompositeLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%a = OpExtInst %void %DbgExt DebugTypeMember %foo_name %float_info %dbg_src %u32_0 %u32_0 %u32_0 %u32_32 %u32_3
%t = OpExtInst %void %DbgExt DebugTypeComposite %foo_name %u32_1 %dbg_src %u32_2 %u32_0 %comp_unit %foo_name %u32_32 %u32_3 %a
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("DebugTypeComposite: operand Line (2) is larger then the "
                "1 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugGlobalVariableLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() {}"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%a = OpExtInst %void %DbgExt DebugTypeMember %foo_name %float_info %dbg_src %u32_0 %u32_0 %u32_0 %u32_32 %u32_3
%t = OpExtInst %void %DbgExt DebugTypeComposite %foo_name %u32_1 %dbg_src %u32_1 %u32_0 %comp_unit %foo_name %u32_32 %u32_3 %a
%foo = OpExtInst %void %DbgExt DebugGlobalVariable %foo_name %t %dbg_src %u32_2 %u32_0 %comp_unit %foo_name %f32_input %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("DebugGlobalVariable: operand Line (2) is larger then the "
                "1 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugLocalVariableLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "void main() { float foo; }"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%null_expr = OpExtInst %void %DbgExt DebugExpression
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%v4float_info = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%foo_info = OpExtInst %void %DbgExt DebugLocalVariable %foo_name %v4float_info %dbg_src %u32_2 %u32_1 %comp_unit %u32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("DebugLocalVariable: operand Line (2) is larger then the "
                "1 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceDebugTypeTemplateParameterLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
%ty_name = OpString "Texture"
%t_name = OpString "T"
)";

  const std::string dbg_inst_header = R"(
%dbg_none = OpExtInst %void %DbgExt DebugInfoNone
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%opaque = OpExtInst %void %DbgExt DebugTypeComposite %ty_name %u32_1 %dbg_src %u32_1 %u32_1 %comp_unit %ty_name %dbg_none %u32_3
%param = OpExtInst %void %DbgExt DebugTypeTemplateParameter %t_name %float_info %dbg_none %dbg_src %u32_2 %u32_1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr(
          "DebugTypeTemplateParameter: operand Line (2) is larger then the "
          "1 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeBasicExtraOperand) {
  // A module declaring NSDI version 9999 may add an optional trailing operand
  // to DebugTypeBasic. The parser absorbs it via the VARIABLE_ID sentinel;
  // the validator accepts it because nsdi_version > kNSDIKnownVersion.
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0 %u32_1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_9999, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, UnknownInstructionAccepted) {
  // Opcode 20000 is not defined in NSDI 100 (highest known opcode is 108).
  // Both the text assembler and binary decoder handle it via the VARIABLE_ID
  // fallback for unknown non-semantic opcodes; the validator's switch falls
  // through to SPV_SUCCESS.
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%unknown_inst = OpExtInst %void %DbgExt 20000 %u32_0 %u32_1 %u32_2 %u32_3
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeBasicTwoExtraOperands) {
  // Two extra trailing operands on an NSDI 9999 module; confirms the
  // VARIABLE_ID sentinel re-expands as many times as needed, not just once.
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0 %u32_1 %u32_2
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_9999, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugSourceExtraOperand) {
  // DebugSource already has one optional operand (Text) in NSDI 100.  An
  // additional trailing operand tests the VARIABLE_ID sentinel when a
  // grammar-defined OPTIONAL_ID is also present.
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code %u32_0
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, UnknownInstructionNoOperands) {
  // Opcode 20000 with zero operands; tests the zero-operand edge case.
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%unknown_inst = OpExtInst %void %DbgExt 20000
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, UnknownInstructionManyOperands) {
  // Opcode 20000 with eight operands; tests that no loop limit is exceeded.
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%unknown_inst = OpExtInst %void %DbgExt 20000 %u32_0 %u32_1 %u32_2 %u32_3 %u32_4 %u32_5 %u32_0 %u32_1
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugNoScopeExtraOperandInBody) {
  // DebugNoScope is allowed in function bodies and has zero required operands.
  // An extra trailing operand exercises the VARIABLE_ID sentinel in the body
  // context, where isStartOfNewInst() uses the startsWithOp() fast path
  // rather than the '%result = OpXxx' lookahead used at global scope.
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "int main() {}"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
)";

  const std::string body = R"(
%no_scope = OpExtInst %void %DbgExt DebugNoScope %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, body, shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

// From
// https://github.com/KhronosGroup/SPIRV-Tools/pull/5986#issuecomment-4156843064
TEST_F(ValidateVulkan100DebugInfo,
       DebugLineDebugSourceContinuedEmptyNewLineGood) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "line 1
line 2
"
%code2 = OpString "line 3
line 4 is really long and hold 32char here"

%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%dbg_src2 = OpExtInst %void %DbgExt DebugSourceContinued %code2
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%a = OpExtInst %void %DbgExt DebugTypeMember %foo_name %float_info %dbg_src %u32_0 %u32_0 %u32_0 %u32_32 %u32_3
%t = OpExtInst %void %DbgExt DebugTypeComposite %foo_name %u32_1 %dbg_src %u32_4 %u32_32 %comp_unit %foo_name %u32_32 %u32_3 %a
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

// From
// https://github.com/KhronosGroup/SPIRV-Tools/pull/6623#issuecomment-4206751217
TEST_F(ValidateVulkan100DebugInfo, DebugLineDebugSourceContinuedSameLine) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code0 = OpString "line 1 here
"
%code1 = OpString "line 2 here"
%code2 = OpString " still on line 2"
%code3 = OpString " still on line 2 and its long
line 3
"
%code4 = OpString "line 4"
%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src0 = OpExtInst %void %DbgExt DebugSource %src %code0
%dbg_src1 = OpExtInst %void %DbgExt DebugSourceContinued %code1
%dbg_src2 = OpExtInst %void %DbgExt DebugSourceContinued %code2
%dbg_src3 = OpExtInst %void %DbgExt DebugSourceContinued %code3
%dbg_src4 = OpExtInst %void %DbgExt DebugSourceContinued %code4
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src0 %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%a = OpExtInst %void %DbgExt DebugTypeMember %foo_name %float_info %dbg_src0 %u32_0 %u32_0 %u32_0 %u32_32 %u32_3
%t = OpExtInst %void %DbgExt DebugTypeComposite %foo_name %u32_1 %dbg_src0 %u32_2 %u32_32 %comp_unit %foo_name %u32_32 %u32_3 %a
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

// From
// https://github.com/KhronosGroup/SPIRV-Tools/pull/5986#issuecomment-4156843064
TEST_F(ValidateVulkan100DebugInfo,
       DebugLineDebugSourceContinuedEmptyNewLineBad) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "line 1
line 2
" ; ignored
%code2 = OpString "line 3
line 4 and there is no line 5"

%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%dbg_src2 = OpExtInst %void %DbgExt DebugSourceContinued %code2
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%a = OpExtInst %void %DbgExt DebugTypeMember %foo_name %float_info %dbg_src %u32_0 %u32_0 %u32_0 %u32_32 %u32_3
%t = OpExtInst %void %DbgExt DebugTypeComposite %foo_name %u32_1 %dbg_src %u32_5 %u32_1 %comp_unit %foo_name %u32_32 %u32_3 %a
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugTypeComposite: operand Line (5) is larger then "
                        "the 4 lines found in the DebugSource text"));
}

TEST_F(ValidateVulkan100DebugInfo,
       DebugLineDebugSourceContinuedCombinedLineColumnCount) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "line 1" ; 6 column length
%code2 = OpString "still line 1" ; 12 char
%code3 = OpString "still line 1" ; 12 char + end-line

%float_name = OpString "float"
%foo_name = OpString "foo"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%dbg_src2 = OpExtInst %void %DbgExt DebugSourceContinued %code2
%dbg_src3 = OpExtInst %void %DbgExt DebugSourceContinued %code3
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%a = OpExtInst %void %DbgExt DebugTypeMember %foo_name %float_info %dbg_src %u32_0 %u32_0 %u32_0 %u32_32 %u32_3
%t = OpExtInst %void %DbgExt DebugTypeComposite %foo_name %u32_1 %dbg_src %u32_1 %u32_32 %comp_unit %foo_name %u32_32 %u32_3 %a
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(
      getDiagnosticString(),
      HasSubstr("DebugTypeComposite: operand Column End (32) is larger then "
                "Line 1 column length of 31 found in the DebugSource text"));
}

// Tests for NonSemantic.Shader.DebugInfo.101 instructions

TEST_F(ValidateVulkan101DebugInfo, DebugTypeVectorIdEXT) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vecid_info = OpExtInst %void %DbgExt DebugTypeVectorIdEXT %float_info %u32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_101, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan101DebugInfo, DebugTypeVectorIdEXTWithSpecConst) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%spec_count = OpSpecConstant %u32 4
%vecid_info = OpExtInst %void %DbgExt DebugTypeVectorIdEXT %float_info %spec_count
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_101, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan101DebugInfo, DebugTypeCooperativeMatrixKHR) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%u32_8 = OpConstant %u32 8
%u32_16 = OpConstant %u32 16
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%coopmtx_info = OpExtInst %void %DbgExt DebugTypeCooperativeMatrixKHR %float_info %u32_3 %u32_8 %u32_16 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_101, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan101DebugInfo, DebugTypeCooperativeMatrixKHRWithSpecConst) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%spec_scope = OpSpecConstant %u32 3
%spec_rows = OpSpecConstant %u32 8
%spec_cols = OpSpecConstant %u32 16
%spec_use = OpSpecConstant %u32 0
%coopmtx_info = OpExtInst %void %DbgExt DebugTypeCooperativeMatrixKHR %float_info %spec_scope %spec_rows %spec_cols %spec_use
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_101, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan101DebugInfo, DebugTypeBasicWithFPEncoding) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%u32_8 = OpConstant %u32 8
%u32_4214 = OpConstant %u32 4214
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%fp8_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_8 %u32_3 %u32_0 %u32_4214
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_101, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeVectorIdEXTFailVersion) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vecid_info = OpExtInst %void %DbgExt DebugTypeVectorIdEXT %float_info %u32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugTypeVectorIdEXT: requires "
                        "NonSemantic.Shader.DebugInfo version"));
}

TEST_F(ValidateVulkan101DebugInfo, DebugTypeVectorIdEXTFailComponentType) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%float_vec = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%vecid_info = OpExtInst %void %DbgExt DebugTypeVectorIdEXT %float_vec %u32_4
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_101, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Component Type must be a result id "
                        "of DebugTypeBasic"));
}

TEST_F(ValidateVulkan101DebugInfo, DebugTypeVectorIdEXTFailComponentCount) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%vecid_info = OpExtInst %void %DbgExt DebugTypeVectorIdEXT %float_info %float_info
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, "", dbg_inst_header, "", shader_extension_101, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Component Count must be a result id of a 32-bit "
                        "unsigned integer constant or specialization "
                        "constant"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypeCooperativeMatrixKHRFailVersion) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%u32_8 = OpConstant %u32 8
%u32_16 = OpConstant %u32 16
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%coopmtx_info = OpExtInst %void %DbgExt DebugTypeCooperativeMatrixKHR %float_info %u32_3 %u32_8 %u32_16 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("DebugTypeCooperativeMatrixKHR: requires "
                        "NonSemantic.Shader.DebugInfo version"));
}

TEST_F(ValidateVulkan101DebugInfo,
       DebugTypeCooperativeMatrixKHRFailComponentType) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%u32_8 = OpConstant %u32 8
%u32_16 = OpConstant %u32 16
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%float_vec = OpExtInst %void %DbgExt DebugTypeVector %float_info %u32_4
%coopmtx_info = OpExtInst %void %DbgExt DebugTypeCooperativeMatrixKHR %float_vec %u32_3 %u32_8 %u32_16 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_101, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("expected operand Component Type must be a result id "
                        "of DebugTypeBasic"));
}

TEST_F(ValidateVulkan101DebugInfo,
       DebugTypeCooperativeMatrixKHRFailScopeNotConst) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%u32_8 = OpConstant %u32 8
%u32_16 = OpConstant %u32 16
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%float_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_32 %u32_3 %u32_0
%coopmtx_info = OpExtInst %void %DbgExt DebugTypeCooperativeMatrixKHR %float_info %dbg_src %u32_8 %u32_16 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_101, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("Scope must be a result id of a 32-bit unsigned "
                        "integer constant or specialization constant"));
}

TEST_F(ValidateVulkan101DebugInfo, DebugTypeBasicFPEncodingFailNotConst) {
  const std::string src = R"(
%src = OpString "simple.hlsl"
%code = OpString "main() {}"
%float_name = OpString "float"
)";

  const std::string constants = R"(
%u32_8 = OpConstant %u32 8
)";

  const std::string dbg_inst_header = R"(
%dbg_src = OpExtInst %void %DbgExt DebugSource %src %code
%comp_unit = OpExtInst %void %DbgExt DebugCompilationUnit %u32_2 %u32_4 %dbg_src %u32_5
%fp8_info = OpExtInst %void %DbgExt DebugTypeBasic %float_name %u32_8 %u32_3 %u32_0 %dbg_src
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      src, constants, dbg_inst_header, "", shader_extension_101, "Vertex"));
  ASSERT_EQ(SPV_ERROR_INVALID_DATA, ValidateInstructions());
  EXPECT_THAT(getDiagnosticString(),
              HasSubstr("FPEncoding must be a result id of 32-bit unsigned "
                        "OpConstant"));
}

TEST_F(ValidateVulkan100DebugInfo, DebugTypePointerNone) {
  const std::string constants = R"(
%u32_7 = OpConstant %u32 7
)";
  const std::string dbg_inst_header = R"(
        %none = OpExtInst %void %DbgExt DebugInfoNone
        %voidptr = OpExtInst %void %DbgExt DebugTypePointer %none %u32_7 %u32_0
)";

  CompileSuccessfully(GenerateShaderCodeForDebugInfo(
      "", constants, dbg_inst_header, "", shader_extension_100, "Vertex"));
  ASSERT_EQ(SPV_SUCCESS, ValidateInstructions());
}

}  // namespace
}  // namespace val
}  // namespace spvtools
