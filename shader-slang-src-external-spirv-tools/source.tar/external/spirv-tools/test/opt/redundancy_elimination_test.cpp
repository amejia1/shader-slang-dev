// Copyright (c) 2017 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <string>

#include "gmock/gmock.h"
#include "test/opt/assembly_builder.h"
#include "test/opt/pass_fixture.h"
#include "test/opt/pass_utils.h"

namespace spvtools {
namespace opt {
namespace {

using ::testing::HasSubstr;
using ::testing::MatchesRegex;
using RedundancyEliminationTest = PassTest<::testing::Test>;

// Test that it can get a simple case of local redundancy elimination.
// The rest of the test check for extra functionality.
TEST_F(RedundancyEliminationTest, RemoveRedundantLocalAdd) {
  const std::string text = R"(
               OpCapability Shader
          %1 = OpExtInstImport "GLSL.std.450"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %2 "main"
               OpExecutionMode %2 OriginUpperLeft
               OpSource GLSL 430
          %3 = OpTypeVoid
          %4 = OpTypeFunction %3
          %5 = OpTypeFloat 32
          %6 = OpTypePointer Function %5
          %2 = OpFunction %3 None %4
          %7 = OpLabel
          %8 = OpVariable %6 Function
          %9 = OpLoad %5 %8
         %10 = OpFAdd %5 %9 %9
; CHECK: OpFAdd
; CHECK-NOT: OpFAdd
         %11 = OpFAdd %5 %9 %9
               OpReturn
               OpFunctionEnd
  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, false);
}

// Remove a redundant add across basic blocks.
TEST_F(RedundancyEliminationTest, RemoveRedundantAdd) {
  const std::string text = R"(
               OpCapability Shader
          %1 = OpExtInstImport "GLSL.std.450"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %2 "main"
               OpExecutionMode %2 OriginUpperLeft
               OpSource GLSL 430
          %3 = OpTypeVoid
          %4 = OpTypeFunction %3
          %5 = OpTypeFloat 32
          %6 = OpTypePointer Function %5
          %2 = OpFunction %3 None %4
          %7 = OpLabel
          %8 = OpVariable %6 Function
          %9 = OpLoad %5 %8
         %10 = OpFAdd %5 %9 %9
               OpBranch %11
         %11 = OpLabel
; CHECK: OpFAdd
; CHECK-NOT: OpFAdd
         %12 = OpFAdd %5 %9 %9
               OpReturn
               OpFunctionEnd
  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, false);
}

// Remove a redundant add with flipped arguments.
TEST_F(RedundancyEliminationTest, RemoveRedundantAddFlipped) {
  const std::string text = R"(
               OpCapability Shader
          %1 = OpExtInstImport "GLSL.std.450"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %2 "main"
               OpExecutionMode %2 OriginUpperLeft
               OpSource GLSL 430
          %3 = OpTypeVoid
          %4 = OpTypeFunction %3
          %5 = OpTypeFloat 32
          %6 = OpTypePointer Function %5
          %2 = OpFunction %3 None %4
          %7 = OpLabel
          %8 = OpVariable %6 Function
          %9 = OpLoad %5 %8
         %10 = OpFMul %5 %9 %9
         %11 = OpFAdd %5 %9 %10
; CHECK: OpFAdd
; CHECK-NEXT: OpReturn
         %12 = OpFAdd %5 %10 %9
               OpReturn
               OpFunctionEnd
  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, false);
}

// Remove a redundant add going through a multiple basic blocks.
TEST_F(RedundancyEliminationTest, RemoveRedundantAddDiamond) {
  const std::string text = R"(
               OpCapability Shader
          %1 = OpExtInstImport "GLSL.std.450"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %2 "main"
               OpExecutionMode %2 OriginUpperLeft
               OpSource GLSL 430
          %3 = OpTypeVoid
          %4 = OpTypeFunction %3
          %5 = OpTypeFloat 32
          %6 = OpTypePointer Function %5
          %7 = OpTypeBool
          %8 = OpConstantTrue %7
          %2 = OpFunction %3 None %4
          %9 = OpLabel
         %10 = OpVariable %6 Function
         %11 = OpLoad %5 %10
         %12 = OpFAdd %5 %11 %11
; CHECK: OpFAdd
; CHECK-NOT: OpFAdd
               OpBranchConditional %8 %13 %14
         %13 = OpLabel
               OpBranch %15
         %14 = OpLabel
               OpBranch %15
         %15 = OpLabel
         %16 = OpFAdd %5 %11 %11
               OpReturn
               OpFunctionEnd

  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, false);
}

// Remove a redundant add in a side node.
TEST_F(RedundancyEliminationTest, RemoveRedundantAddInSideNode) {
  const std::string text = R"(
               OpCapability Shader
          %1 = OpExtInstImport "GLSL.std.450"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %2 "main"
               OpExecutionMode %2 OriginUpperLeft
               OpSource GLSL 430
          %3 = OpTypeVoid
          %4 = OpTypeFunction %3
          %5 = OpTypeFloat 32
          %6 = OpTypePointer Function %5
          %7 = OpTypeBool
          %8 = OpConstantTrue %7
          %2 = OpFunction %3 None %4
          %9 = OpLabel
         %10 = OpVariable %6 Function
         %11 = OpLoad %5 %10
         %12 = OpFAdd %5 %11 %11
; CHECK: OpFAdd
; CHECK-NOT: OpFAdd
               OpBranchConditional %8 %13 %14
         %13 = OpLabel
               OpBranch %15
         %14 = OpLabel
         %16 = OpFAdd %5 %11 %11
               OpBranch %15
         %15 = OpLabel
               OpReturn
               OpFunctionEnd

  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, false);
}

// Inherit dominating values in every sibling, keeping branch-local values
// confined to that branch's descendants.
TEST_F(RedundancyEliminationTest,
       PreserveInheritedValuesAcrossSiblingSubtrees) {
  const std::string text = R"(
               OpCapability Shader
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %main "main" %input %output
               OpExecutionMode %main OriginUpperLeft
               OpDecorate %input Location 0
               OpDecorate %output Location 0
       %void = OpTypeVoid
       %bool = OpTypeBool
      %float = OpTypeFloat 32
         %fn = OpTypeFunction %void
   %inputptr = OpTypePointer Input %float
  %outputptr = OpTypePointer Output %float
      %input = OpVariable %inputptr Input
     %output = OpVariable %outputptr Output
       %zero = OpConstant %float 0
       %main = OpFunction %void None %fn
      %entry = OpLabel
      %value = OpLoad %float %input
     %parent = OpFAdd %float %value %value
; CHECK: [[parent:%\w+]] = OpFAdd
       %cond = OpFOrdGreaterThan %bool %value %zero
               OpSelectionMerge %merge None
               OpBranchConditional %cond %left %right
; CHECK: OpBranchConditional {{%\w+}} [[left:%\w+]] [[right:%\w+]]
       %left = OpLabel
; CHECK-NEXT: [[left]] = OpLabel
   %left_mul = OpFMul %float %value %value
; CHECK-NEXT: [[left_mul:%\w+]] = OpFMul
               OpBranch %left_tail
; CHECK-NEXT: OpBranch [[left_tail:%\w+]]
  %left_tail = OpLabel
; CHECK-NEXT: [[left_tail]] = OpLabel
   %left_add = OpFAdd %float %value %value
  %left_copy = OpFMul %float %value %value
               OpStore %output %left_add
; CHECK-NEXT: OpStore [[output:%\w+]] [[parent]]
               OpStore %output %left_copy
; CHECK-NEXT: OpStore [[output]] [[left_mul]]
               OpBranch %merge
; CHECK-NEXT: OpBranch [[merge:%\w+]]
      %right = OpLabel
; CHECK-NEXT: [[right]] = OpLabel
  %right_mul = OpFMul %float %value %value
; CHECK-NEXT: [[right_mul:%\w+]] = OpFMul
               OpBranch %right_tail
; CHECK-NEXT: OpBranch [[right_tail:%\w+]]
 %right_tail = OpLabel
; CHECK-NEXT: [[right_tail]] = OpLabel
  %right_add = OpFAdd %float %value %value
 %right_copy = OpFMul %float %value %value
               OpStore %output %right_add
; CHECK-NEXT: OpStore [[output]] [[parent]]
               OpStore %output %right_copy
; CHECK-NEXT: OpStore [[output]] [[right_mul]]
               OpBranch %merge
; CHECK-NEXT: OpBranch [[merge]]
      %merge = OpLabel
; CHECK-NEXT: [[merge]] = OpLabel
  %merge_add = OpFAdd %float %value %value
  %merge_mul = OpFMul %float %value %value
; CHECK-NEXT: [[merge_mul:%\w+]] = OpFMul
               OpStore %output %merge_add
; CHECK-NEXT: OpStore [[output]] [[parent]]
               OpStore %output %merge_mul
; CHECK-NEXT: OpStore [[output]] [[merge_mul]]
               OpReturn
; CHECK-NEXT: OpReturn
               OpFunctionEnd
  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, true);
}

// Remove a redundant add whose value is in the result of a phi node.
TEST_F(RedundancyEliminationTest, RemoveRedundantAddWithPhi) {
  const std::string text = R"(
               OpCapability Shader
          %1 = OpExtInstImport "GLSL.std.450"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %2 "main"
               OpExecutionMode %2 OriginUpperLeft
               OpSource GLSL 430
          %3 = OpTypeVoid
          %4 = OpTypeFunction %3
          %5 = OpTypeFloat 32
          %6 = OpTypePointer Function %5
          %7 = OpTypeBool
          %8 = OpConstantTrue %7
          %2 = OpFunction %3 None %4
          %9 = OpLabel
         %10 = OpVariable %6 Function
         %11 = OpLoad %5 %10
               OpBranchConditional %8 %13 %14
         %13 = OpLabel
         %add1 = OpFAdd %5 %11 %11
; CHECK: OpFAdd
               OpBranch %15
         %14 = OpLabel
         %add2 = OpFAdd %5 %11 %11
; CHECK: OpFAdd
               OpBranch %15
         %15 = OpLabel
; CHECK: OpPhi
          %phi = OpPhi %5 %add1 %13 %add2 %14
; CHECK-NOT: OpFAdd
         %16 = OpFAdd %5 %11 %11
               OpReturn
               OpFunctionEnd

  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, false);
}

// Keep the add because it is redundant on some paths, but not all paths.
TEST_F(RedundancyEliminationTest, KeepPartiallyRedundantAdd) {
  const std::string text = R"(
               OpCapability Shader
          %1 = OpExtInstImport "GLSL.std.450"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %2 "main"
               OpExecutionMode %2 OriginUpperLeft
               OpSource GLSL 430
          %3 = OpTypeVoid
          %4 = OpTypeFunction %3
          %5 = OpTypeFloat 32
          %6 = OpTypePointer Function %5
          %7 = OpTypeBool
          %8 = OpConstantTrue %7
          %2 = OpFunction %3 None %4
          %9 = OpLabel
         %10 = OpVariable %6 Function
         %11 = OpLoad %5 %10
               OpBranchConditional %8 %13 %14
         %13 = OpLabel
        %add = OpFAdd %5 %11 %11
               OpBranch %15
         %14 = OpLabel
               OpBranch %15
         %15 = OpLabel
         %16 = OpFAdd %5 %11 %11
               OpReturn
               OpFunctionEnd

  )";
  auto result = SinglePassRunAndDisassemble<RedundancyEliminationPass>(
      text, /* skip_nop = */ true, /* do_validation = */ false);
  EXPECT_EQ(Pass::Status::SuccessWithoutChange, std::get<1>(result));
}

// Keep the add.  Even if it is redundant on all paths, there is no single id
// whose definition dominates the add and contains the same value.
TEST_F(RedundancyEliminationTest, KeepRedundantAddWithoutPhi) {
  const std::string text = R"(
               OpCapability Shader
          %1 = OpExtInstImport "GLSL.std.450"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %2 "main"
               OpExecutionMode %2 OriginUpperLeft
               OpSource GLSL 430
          %3 = OpTypeVoid
          %4 = OpTypeFunction %3
          %5 = OpTypeFloat 32
          %6 = OpTypePointer Function %5
          %7 = OpTypeBool
          %8 = OpConstantTrue %7
          %2 = OpFunction %3 None %4
          %9 = OpLabel
         %10 = OpVariable %6 Function
         %11 = OpLoad %5 %10
               OpBranchConditional %8 %13 %14
         %13 = OpLabel
         %add1 = OpFAdd %5 %11 %11
               OpBranch %15
         %14 = OpLabel
         %add2 = OpFAdd %5 %11 %11
               OpBranch %15
         %15 = OpLabel
         %16 = OpFAdd %5 %11 %11
               OpReturn
               OpFunctionEnd

  )";
  auto result = SinglePassRunAndDisassemble<RedundancyEliminationPass>(
      text, /* skip_nop = */ true, /* do_validation = */ false);
  EXPECT_EQ(Pass::Status::SuccessWithoutChange, std::get<1>(result));
}

// Test that it can get a simple case of local redundancy elimination
// when it has OpenCL.DebugInfo.100 instructions.
TEST_F(RedundancyEliminationTest, OpenCLDebugInfo100) {
  // When three redundant DebugValues exist, only one DebugValue must remain.
  const std::string text = R"(
               OpCapability Shader
          %1 = OpExtInstImport "OpenCL.DebugInfo.100"
          %2 = OpExtInstImport "GLSL.std.450"
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %3 "main"
               OpExecutionMode %3 OriginUpperLeft
               OpSource GLSL 430
          %4 = OpString "ps.hlsl"
          %5 = OpString "float"
          %6 = OpString "s0"
          %7 = OpString "main"
       %void = OpTypeVoid
          %9 = OpTypeFunction %void
      %float = OpTypeFloat 32
       %uint = OpTypeInt 32 0
     %uint_0 = OpConstant %uint 0
    %uint_32 = OpConstant %uint 32
%_ptr_Function_float = OpTypePointer Function %float
         %15 = OpExtInst %void %1 DebugExpression
         %16 = OpExtInst %void %1 DebugSource %4
         %17 = OpExtInst %void %1 DebugCompilationUnit 1 4 %16 HLSL
         %18 = OpExtInst %void %1 DebugTypeBasic %5 %uint_32 Float
         %19 = OpExtInst %void %1 DebugTypeVector %18 4
         %20 = OpExtInst %void %1 DebugTypeFunction FlagIsProtected|FlagIsPrivate %19
         %21 = OpExtInst %void %1 DebugFunction %7 %20 %16 4 1 %17 %7 FlagIsProtected|FlagIsPrivate 4 %3
; CHECK:     [[dbg_local_var:%\w+]] = OpExtInst %void {{%\w+}} DebugLocalVariable
         %22 = OpExtInst %void %1 DebugLocalVariable %6 %19 %16 0 0 %21 FlagIsLocal
         %14 = OpExtInst %void %1 DebugLocalVariable %6 %19 %16 0 0 %21 FlagIsLocal
          %3 = OpFunction %void None %9
         %23 = OpLabel
         %24 = OpExtInst %void %1 DebugScope %21
         %25 = OpVariable %_ptr_Function_float Function
         %26 = OpLoad %float %25
               OpLine %4 0 0
; Two `OpFAdd %float %26 %26` are the same. One must be removed.
; After removing one `OpFAdd %float %26 %26`, two DebugValues are the same.
; One must be removed.
;
; CHECK:      OpLine {{%\w+}} 0 0
; CHECK-NEXT: [[add:%\w+]] = OpFAdd %float [[value:%\w+]]
; CHECK-NEXT: DebugValue [[dbg_local_var]] [[add]]
; CHECK-NEXT: OpLine {{%\w+}} 1 0
; CHECK-NEXT: OpFAdd %float [[add]] [[value]]
; CHECK-NEXT: OpReturn
         %27 = OpFAdd %float %26 %26
         %28 = OpExtInst %void %1 DebugValue %22 %27 %15 %uint_0
               OpLine %4 1 0
         %29 = OpFAdd %float %26 %26
         %30 = OpExtInst %void %1 DebugValue %14 %29 %15 %uint_0
         %31 = OpExtInst %void %1 DebugValue %22 %29 %15 %uint_0
         %32 = OpFAdd %float %29 %26
         %33 = OpFAdd %float %27 %26
               OpReturn
               OpFunctionEnd
  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, false);
}

TEST_F(RedundancyEliminationTest, FunctionDeclaration) {
  // Make sure the pass works with a function declaration that is called.
  const std::string text = R"(OpCapability Addresses
OpCapability Linkage
OpCapability Kernel
OpCapability Int8
%1 = OpExtInstImport "OpenCL.std"
OpMemoryModel Physical64 OpenCL
OpEntryPoint Kernel %2 "_Z23julia__1166_kernel_77094Bool"
OpExecutionMode %2 ContractionOff
OpSource Unknown 0
OpDecorate %3 LinkageAttributes "julia_error_7712" Import
%void = OpTypeVoid
%5 = OpTypeFunction %void
%3 = OpFunction %void None %5
OpFunctionEnd
%2 = OpFunction %void None %5
%6 = OpLabel
%7 = OpFunctionCall %void %3
OpReturn
OpFunctionEnd
)";

  SinglePassRunAndCheck<RedundancyEliminationPass>(text, text, false);
}

TEST_F(RedundancyEliminationTest, PreserveLoadYieldingImage) {
  // This is more strict than needed.
  // This is sufficient to ensure that the load of an image
  // occurs in the same basic block as its use.
  const std::string text = R"(
               OpCapability Shader
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %main "main"
               OpExecutionMode %main OriginLowerLeft
               OpName %main "main"
               OpName %load_ty "load_ty"
               OpDecorate %var DescriptorSet 0
               OpDecorate %var Binding 0
       %void = OpTypeVoid
          %6 = OpTypeFunction %void
      %float = OpTypeFloat 32
    %load_ty = OpTypeImage %float 2D 0 0 0 2 Rgba32f
%ptr_load_ty = OpTypePointer UniformConstant %load_ty
        %var = OpVariable %ptr_load_ty UniformConstant
       %main = OpFunction %void None %6
       ; CHECK: OpLoad %load_ty
       ; CHECK: OpLoad %load_ty
         %15 = OpLabel
         %16 = OpLoad %load_ty %var
         %17 = OpLoad %load_ty %var
               OpReturn
               OpFunctionEnd
  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, false);
}

TEST_F(RedundancyEliminationTest, PreserveLoadYieldingSampler) {
  const std::string text = R"(
               OpCapability Shader
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %main "main"
               OpExecutionMode %main OriginLowerLeft
               OpName %main "main"
               OpName %load_ty "load_ty"
               OpDecorate %var DescriptorSet 0
               OpDecorate %var Binding 0
       %void = OpTypeVoid
          %6 = OpTypeFunction %void
    %load_ty = OpTypeSampler
%ptr_load_ty = OpTypePointer UniformConstant %load_ty
        %var = OpVariable %ptr_load_ty UniformConstant
       %main = OpFunction %void None %6
       ; CHECK: OpLoad %load_ty
       ; CHECK: OpLoad %load_ty
         %15 = OpLabel
         %16 = OpLoad %load_ty %var
         %17 = OpLoad %load_ty %var
               OpReturn
               OpFunctionEnd
  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, false);
}

TEST_F(RedundancyEliminationTest, PreserveLoadYieldingSampledImage) {
  const std::string text = R"(
               OpCapability Shader
               OpMemoryModel Logical GLSL450
               OpEntryPoint Fragment %main "main"
               OpExecutionMode %main OriginLowerLeft
               OpName %main "main"
               OpName %load_ty "load_ty"
               OpDecorate %var DescriptorSet 0
               OpDecorate %var Binding 0
       %void = OpTypeVoid
          %6 = OpTypeFunction %void
      %float = OpTypeFloat 32
       %i_ty = OpTypeImage %float 2D 0 0 0 2 Rgba32f
    %load_ty = OpTypeSampledImage %i_ty
%ptr_load_ty = OpTypePointer UniformConstant %load_ty
        %var = OpVariable %ptr_load_ty UniformConstant
       %main = OpFunction %void None %6
       ; CHECK: OpLoad %load_ty
       ; CHECK: OpLoad %load_ty
         %15 = OpLabel
         %16 = OpLoad %load_ty %var
         %17 = OpLoad %load_ty %var
               OpReturn
               OpFunctionEnd
  )";
  SinglePassRunAndMatch<RedundancyEliminationPass>(text, false);
}

}  // namespace
}  // namespace opt
}  // namespace spvtools
