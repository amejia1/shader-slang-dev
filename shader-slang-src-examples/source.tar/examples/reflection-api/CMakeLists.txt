example(reflection-api)
