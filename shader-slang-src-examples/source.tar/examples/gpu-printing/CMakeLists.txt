example(gpu-printing)
