example(cpu-hello-world)
