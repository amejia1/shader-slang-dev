example(cpu-com-example)
