example(shader-object)
