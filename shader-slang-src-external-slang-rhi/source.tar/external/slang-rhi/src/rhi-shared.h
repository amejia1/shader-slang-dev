#pragma once

#include <slang-rhi.h>

#include "slang-context.h"
#include "resource-desc-utils.h"
#include "command-list.h"

#include "core/common.h"
#include "core/short_vector.h"
#include "reference.h"

#include "rhi-shared-fwd.h"

#include "device.h"
#include "command-buffer.h"
#include "shader-object.h"
#include "shader.h"
#include "pipeline.h"

#include <cstddef>
#include <map>
#include <memory>
#include <mutex>
#include <set>
#include <string>
#include <string_view>
#include <unordered_map>

namespace rhi {

class Device;
class CommandEncoder;
class CommandList;

/// Common prefix for structures linked through a `next` chain.
struct ChainedStructHeader
{
    StructType type;
    const void* next;
};

/// Finds the first structure of type `T` in a `next` chain, or returns null.
template<typename T>
const T* findStructInChain(const void* chain)
{
    for (auto* header = static_cast<const ChainedStructHeader*>(chain); header;
         header = static_cast<const ChainedStructHeader*>(header->next))
    {
        if (header->type == T::kStructType)
            return reinterpret_cast<const T*>(header);
    }
    return nullptr;
}

class Fence : public IFence, public DeviceChild
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    IFence* getInterface(const Guid& guid);

public:
    Fence(Device* device, const FenceDesc& desc);

protected:
    FenceDesc m_desc;
    StructHolder m_descHolder;
    NativeHandle m_sharedHandle = {};
};

class Resource : public DeviceChild
{
public:
    Resource(Device* device)
        : DeviceChild(device)
    {
        ++testing::gResourceCount;
    }

    virtual ~Resource() { --testing::gResourceCount; }
};

class Buffer : public IBuffer, public Resource
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    IResource* getInterface(const Guid& guid);

public:
    Buffer(Device* device, const BufferDesc& desc);

    BufferRange resolveBufferRange(const BufferRange& range);

    // IBuffer interface
    virtual SLANG_NO_THROW BufferDesc& SLANG_MCALL getDesc() override { return m_desc; }
    virtual SLANG_NO_THROW Result SLANG_MCALL getSharedHandle(NativeHandle* outHandle) override;
    virtual SLANG_NO_THROW Result SLANG_MCALL getDescriptorHandle(
        DescriptorHandleAccess access,
        Format format,
        BufferRange range,
        DescriptorHandle* outHandle
    ) override;

    // IResource interface
    virtual SLANG_NO_THROW Result SLANG_MCALL getNativeHandle(NativeHandle* outHandle) override;

public:
    BufferDesc m_desc;
    StructHolder m_descHolder;
    NativeHandle m_sharedHandle;
};

struct SubResourceLayout
{
    Extent3D size;
    Size strideY;
    Size strideZ;
};

// Shared helper to calculate the layout of a subresource region from
// a texture description given a minimum row alignment.
Result calcSubresourceRegionLayout(
    const TextureDesc& desc,
    uint32_t mip,
    Offset3D offset,
    Extent3D extent,
    Size rowAlignment,
    SubresourceLayout* outLayout
);

class Sampler;

class Texture : public ITexture, public Resource
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    IResource* getInterface(const Guid& guid);

public:
    Texture(Device* device, const TextureDesc& desc);
    ~Texture();

    SubresourceRange resolveSubresourceRange(const SubresourceRange& range);
    bool isEntireTexture(const SubresourceRange& range);

    // Get layout the target requires for a given region within a given sub resource
    // of this texture. Supply offset==0 and extent==kRemainingTextureSize to indicate whole sub resource.
    // If rowAlignment is kDefaultAlignment, implementation uses Device::getTextureRowAlignment for alignment.
    virtual Result getSubresourceRegionLayout(
        uint32_t mip,
        Offset3D offset,
        Extent3D extent,
        size_t rowAlignment,
        SubresourceLayout* outLayout
    );

    // ITexture interface
    virtual SLANG_NO_THROW TextureDesc& SLANG_MCALL getDesc() override { return m_desc; };
    virtual SLANG_NO_THROW Result SLANG_MCALL getSharedHandle(NativeHandle* outHandle) override;
    virtual SLANG_NO_THROW Result SLANG_MCALL createView(
        const TextureViewDesc& desc,
        ITextureView** outTextureView
    ) override;
    virtual SLANG_NO_THROW Result SLANG_MCALL getDefaultView(ITextureView** outTextureView) override;

    virtual SLANG_NO_THROW Result SLANG_MCALL getSubresourceLayout(
        uint32_t mip,
        size_t rowAlignment,
        SubresourceLayout* outLayout
    ) override
    {
        return getSubresourceRegionLayout(mip, {0, 0, 0}, Extent3D::kWholeTexture, rowAlignment, outLayout);
    }

    // IResource interface
    virtual SLANG_NO_THROW Result SLANG_MCALL getNativeHandle(NativeHandle* outHandle) override;

public:
    TextureDesc m_desc;
    StructHolder m_descHolder;
    InternalRefPtr<Sampler> m_sampler;
    NativeHandle m_sharedHandle;

protected:
    // Called at the start of each backend destructor, before releasing native storage.
    void destroyDefaultView();

private:
    friend class TextureView;
    // Owns the wrapper's storage, not a consumer reference. Published once; removed
    // only during destruction. Atomic publication permits concurrent getDefaultView().
    std::atomic<TextureView*> m_defaultView = nullptr;
};

class TextureView : public ITextureView, public Resource
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    ITextureView* getInterface(const Guid& guid);

public:
    TextureView(Texture* texture, const TextureViewDesc& desc);

    // Each consumer reference retains the texture with the same ownership kind.
    uint32_t addReference() override final;
    uint32_t releaseReference() override final;
    uint32_t addInternalReference() override final;
    uint32_t releaseInternalReference() override final;
    void deleteThis() override final;

    // ITextureView interface
    virtual SLANG_NO_THROW const TextureViewDesc& SLANG_MCALL getDesc() override { return m_desc; }
    virtual SLANG_NO_THROW Result getDescriptorHandle(
        DescriptorHandleAccess access,
        DescriptorHandle* outHandle
    ) override;
    virtual SLANG_NO_THROW Result SLANG_MCALL getCombinedTextureSamplerDescriptorHandle(
        DescriptorHandle* outHandle
    ) override;

    // IResource interface
    virtual SLANG_NO_THROW Result SLANG_MCALL getNativeHandle(NativeHandle* outHandle) override;

protected:
    // External view references retain the device through the texture.
    RefObject* getLifetimeOwner() const noexcept override final { return nullptr; }

public:
    TextureViewDesc m_desc;
    StructHolder m_descHolder;
    InternalRefPtr<Sampler> m_sampler;
};

class Sampler : public ISampler, public Resource
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    ISampler* getInterface(const Guid& guid);

public:
    Sampler(Device* device, const SamplerDesc& desc);

    // ISampler interface
    virtual SLANG_NO_THROW const SamplerDesc& SLANG_MCALL getDesc() override { return m_desc; }
    virtual SLANG_NO_THROW Result SLANG_MCALL getDescriptorHandle(DescriptorHandle* outHandle) override;

    // IResource interface
    virtual SLANG_NO_THROW Result SLANG_MCALL getNativeHandle(NativeHandle* outHandle) override;

public:
    SamplerDesc m_desc;
    StructHolder m_descHolder;
};

class AccelerationStructure : public IAccelerationStructure, public Resource
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    IAccelerationStructure* getInterface(const Guid& guid);

public:
    AccelerationStructure(Device* device, const AccelerationStructureDesc& desc);

    // IAccelerationStructure interface
    virtual SLANG_NO_THROW const AccelerationStructureDesc& SLANG_MCALL getDesc() override { return m_desc; }
    virtual SLANG_NO_THROW AccelerationStructureHandle SLANG_MCALL getHandle() override;
    virtual SLANG_NO_THROW Result SLANG_MCALL getDescriptorHandle(DescriptorHandle* outHandle) override;

public:
    AccelerationStructureDesc m_desc;
    StructHolder m_descHolder;
};

class Micromap : public IMicromap, public Resource
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    IMicromap* getInterface(const Guid& guid);

public:
    Micromap(Device* device, const MicromapDesc& desc);

    // IMicromap interface
    virtual SLANG_NO_THROW const MicromapDesc& SLANG_MCALL getDesc() override { return m_desc; }

public:
    MicromapDesc m_desc;
    StructHolder m_descHolder;
};

class InputLayout : public IInputLayout, public ComObject
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    IInputLayout* getInterface(const Guid& guid);
};

class QueryPool : public IQueryPool, public DeviceChild
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    IQueryPool* getInterface(const Guid& guid);

public:
    QueryPool(Device* device, const QueryPoolDesc& desc);

    virtual SLANG_NO_THROW const QueryPoolDesc& SLANG_MCALL getDesc() override { return m_desc; }
    virtual SLANG_NO_THROW Result SLANG_MCALL getResultState(
        uint32_t queryIndex,
        uint32_t count,
        QueryResultState* outState
    ) override;
    virtual SLANG_NO_THROW Result SLANG_MCALL reset() override;
    virtual SLANG_NO_THROW Result SLANG_MCALL reset(uint32_t queryIndex, uint32_t count) override;

    struct QueryRangeInfo
    {
        QueryResultState state = QueryResultState::Reset;
        uint64_t submissionID = 0;
    };

    bool isValidQueryRange(uint32_t queryIndex, uint32_t count) const;
    void markQueryRangeSubmitted(uint32_t queryIndex, uint32_t count, uint64_t submissionID);
    void markQueryRangeResolved(uint32_t queryIndex, uint32_t count, uint64_t completedSubmissionID);
    QueryRangeInfo getQueryRangeInfo(uint32_t queryIndex, uint32_t count) const;

public:
    struct QuerySlotState
    {
        static constexpr uint64_t kStateShift = 62;
        static constexpr uint64_t kStateMask = uint64_t(3) << kStateShift;
        static constexpr uint64_t kSubmissionIDMask = (uint64_t(1) << kStateShift) - 1;

        uint64_t packedState = 0;

        void set(QueryResultState state, uint64_t submissionID)
        {
            SLANG_RHI_ASSERT((submissionID & ~kSubmissionIDMask) == 0);
            packedState = (uint64_t(state) << kStateShift) | (submissionID & kSubmissionIDMask);
        }

        QueryResultState getState() const { return QueryResultState((packedState & kStateMask) >> kStateShift); }

        uint64_t getSubmissionID() const { return packedState & kSubmissionIDMask; }
    };

    static_assert(sizeof(QuerySlotState) == 8, "QuerySlotState should remain compact.");

    QueryPoolDesc m_desc;
    StructHolder m_descHolder;
    std::vector<QuerySlotState> m_querySlotStates;
    mutable std::mutex m_queryStateMutex;
};

class ShaderTable : public IShaderTable, public DeviceChild
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    IShaderTable* getInterface(const Guid& guid);

public:
    ShaderTable(Device* device, const ShaderTableDesc& desc);

public:
    uint32_t m_rayGenShaderCount;
    uint32_t m_missShaderCount;
    uint32_t m_hitGroupCount;
    uint32_t m_callableShaderCount;

    std::vector<std::string> m_rayGenShaderEntryPointNames;
    std::vector<std::string> m_missShaderEntryPointNames;
    std::vector<std::string> m_hitGroupNames;
    std::vector<std::string> m_callableShaderEntryPointNames;

    std::vector<ShaderRecordOverwrite> m_rayGenRecordOverwrites;
    std::vector<ShaderRecordOverwrite> m_missRecordOverwrites;
    std::vector<ShaderRecordOverwrite> m_hitGroupRecordOverwrites;
    std::vector<ShaderRecordOverwrite> m_callableRecordOverwrites;
    uint32_t m_rayGenRecordOverwriteMaxSize = 0;
    uint32_t m_missRecordOverwriteMaxSize = 0;
    uint32_t m_hitGroupRecordOverwriteMaxSize = 0;
    uint32_t m_callableRecordOverwriteMaxSize = 0;
};

class Surface : public ISurface, public ComObject
{
public:
    SLANG_COM_OBJECT_IUNKNOWN_ALL
    ISurface* getInterface(const Guid& guid);

public:
    virtual SLANG_NO_THROW const SurfaceInfo& SLANG_MCALL getInfo() override { return m_info; }
    virtual SLANG_NO_THROW const SurfaceConfig* SLANG_MCALL getConfig() override
    {
        return m_configured ? &m_config : nullptr;
    }

public:
    void setInfo(const SurfaceInfo& info);
    void setConfig(const SurfaceConfig& config);
    Result validateConfig(const SurfaceConfig& config) const;

    SurfaceInfo m_info;
    StructHolder m_infoHolder;
    SurfaceConfig m_config;
    StructHolder m_configHolder;
    bool m_configured = false;
};

inline Device* getDiagnosticDevice(Device* device)
{
    return device;
}

inline Device* getDiagnosticDevice(std::nullptr_t)
{
    return nullptr;
}

inline Device* getDiagnosticDevice(DeviceChild* deviceChild)
{
    return deviceChild ? deviceChild->getDevice() : nullptr;
}

bool isDepthFormat(Format format);
bool isStencilFormat(Format format);

inline uint32_t widthInBlocks(const FormatInfo& formatInfo, uint32_t size)
{
    return formatInfo.isCompressed ? (size + formatInfo.blockWidth - 1) / formatInfo.blockWidth : size;
}

inline uint32_t heightInBlocks(const FormatInfo& formatInfo, uint32_t size)
{
    return formatInfo.isCompressed ? (size + formatInfo.blockHeight - 1) / formatInfo.blockHeight : size;
}

bool isDebugLayersEnabled();

} // namespace rhi
