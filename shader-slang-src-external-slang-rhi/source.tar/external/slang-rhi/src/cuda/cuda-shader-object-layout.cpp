#include "cuda-shader-object-layout.h"
#include "shader.h"
#include "synthetic-resource-bindings.h"

#include <limits>

namespace rhi::cuda {

ShaderObjectLayoutImpl::ShaderObjectLayoutImpl(
    Device* device,
    slang::ISession* session,
    slang::TypeLayoutReflection* layout
)
{
    m_elementTypeLayout = _unwrapParameterGroups(layout, m_containerType);

    initBase(device, session, m_elementTypeLayout);

    // Compute the binding ranges that are used to store
    // the logical contents of the object in memory. These will relate
    // to the descriptor ranges in the various sets, but not always
    // in a one-to-one fashion.

    SlangInt bindingRangeCount = m_elementTypeLayout->getBindingRangeCount();
    for (SlangInt r = 0; r < bindingRangeCount; ++r)
    {
        slang::BindingType slangBindingType = m_elementTypeLayout->getBindingRangeType(r);
        SlangInt count = m_elementTypeLayout->getBindingRangeBindingCount(r);
        slang::TypeLayoutReflection* slangLeafTypeLayout = m_elementTypeLayout->getBindingRangeLeafTypeLayout(r);

        SlangInt descriptorSetIndex = m_elementTypeLayout->getBindingRangeDescriptorSetIndex(r);
        SlangInt rangeIndexInDescriptorSet = m_elementTypeLayout->getBindingRangeFirstDescriptorRangeIndex(r);

        // TODO: This logic assumes that for any binding range that might consume
        // multiple kinds of resources, the descriptor range for its uniform
        // usage will be the first one in the range.
        //
        // We need to decide whether that assumption is one we intend to support
        // applications making, or whether they should be forced to perform a
        // linear search over the descriptor ranges for a specific binding range.
        //
        auto uniformOffset = m_elementTypeLayout->getDescriptorSetDescriptorRangeIndexOffset(
            descriptorSetIndex,
            rangeIndexInDescriptorSet
        );

        uint32_t slotIndex = 0;
        uint32_t subObjectIndex = 0;

        switch (slangBindingType)
        {
        case slang::BindingType::ConstantBuffer:
        case slang::BindingType::ParameterBlock:
        case slang::BindingType::ExistentialValue:
            subObjectIndex = m_subObjectCount;
            m_subObjectCount += count;
            break;
        case slang::BindingType::RawBuffer:
        case slang::BindingType::MutableRawBuffer:
            if (slangLeafTypeLayout->getType()->getElementType() != nullptr)
            {
                // A structured buffer occupies both a resource slot and
                // a sub-object slot.
                subObjectIndex = m_subObjectCount;
                m_subObjectCount += count;
            }
            slotIndex = m_slotCount;
            m_slotCount += count;
            break;
        default:
            slotIndex = m_slotCount;
            m_slotCount += count;
            break;
        }

        BindingRangeInfo bindingRangeInfo;
        bindingRangeInfo.bindingType = slangBindingType;
        bindingRangeInfo.count = count;
        bindingRangeInfo.slotIndex = slotIndex;
        bindingRangeInfo.uniformOffset = uniformOffset;
        bindingRangeInfo.subObjectIndex = subObjectIndex;
        bindingRangeInfo.isSpecializable = m_elementTypeLayout->isBindingRangeSpecializable(r);
        m_bindingRanges.push_back(bindingRangeInfo);
    }

    SlangInt subObjectRangeCount = m_elementTypeLayout->getSubObjectRangeCount();
    for (SlangInt r = 0; r < subObjectRangeCount; ++r)
    {
        SlangInt bindingRangeIndex = m_elementTypeLayout->getSubObjectRangeBindingRangeIndex(r);
        auto slangBindingType = m_elementTypeLayout->getBindingRangeType(bindingRangeIndex);
        slang::TypeLayoutReflection* slangLeafTypeLayout =
            m_elementTypeLayout->getBindingRangeLeafTypeLayout(bindingRangeIndex);

        // A sub-object range can either represent a sub-object of a known
        // type, like a `ConstantBuffer<Foo>` or `ParameterBlock<Foo>`
        // (in which case we can pre-compute a layout to use, based on
        // the type `Foo`) *or* it can represent a sub-object of some
        // existential type (e.g., `IBar`) in which case we cannot
        // know the appropriate type/layout of sub-object to allocate.
        //
        RefPtr<ShaderObjectLayoutImpl> subObjectLayout;
        if (slangBindingType != slang::BindingType::ExistentialValue)
        {
            subObjectLayout = new ShaderObjectLayoutImpl(device, session, slangLeafTypeLayout->getElementTypeLayout());
        }

        SubObjectRangeInfo subObjectRange;
        subObjectRange.bindingRangeIndex = bindingRangeIndex;
        subObjectRange.layout = subObjectLayout;
        m_subObjectRanges.push_back(subObjectRange);
    }
}

// Compute the size of the entry point parameters passed to cuLaunchKernel.
// There is an issue in Slang where the entry point parameters seem to be treated as having C struct
// layout rules. While this matches how CUDA expects parameters to be layed out, CUDA expects *NO* padding
// at the end of the parameter buffer. Therefore we compute the size manually here.
inline size_t computeEntryPointParamsSize(slang::EntryPointReflection* entryPointReflection)
{
    size_t paramsSize = 0;
    for (unsigned int i = 0; i < entryPointReflection->getParameterCount(); ++i)
    {
        slang::VariableLayoutReflection* variableLayout = entryPointReflection->getParameterByIndex(i);
        size_t offset = variableLayout->getOffset();
        size_t size = variableLayout->getTypeLayout()->getSize();
        paramsSize = std::max(paramsSize, offset + size);
    }
    return paramsSize;
}

RootShaderObjectLayoutImpl::RootShaderObjectLayoutImpl(Device* device, slang::ProgramLayout* programLayout)
    : ShaderObjectLayoutImpl(device, programLayout->getSession(), programLayout->getGlobalParamsTypeLayout())
    , m_programLayout(programLayout)
{
    for (SlangUInt i = 0; i < programLayout->getEntryPointCount(); i++)
    {
        EntryPointInfo entryPointInfo;
        entryPointInfo.layout = new ShaderObjectLayoutImpl(
            device,
            programLayout->getSession(),
            programLayout->getEntryPointByIndex(i)->getTypeLayout()
        );
        entryPointInfo.paramsSize = computeEntryPointParamsSize(programLayout->getEntryPointByIndex(i));
        m_entryPoints.push_back(entryPointInfo);
    }
}

Result RootShaderObjectLayoutImpl::create(
    Device* device,
    slang::ProgramLayout* programLayout,
    SyntheticResourceBindingState* syntheticResources,
    RootShaderObjectLayoutImpl** outLayout
)
{
    RefPtr<RootShaderObjectLayoutImpl> layout = new RootShaderObjectLayoutImpl(device, programLayout);
    if (syntheticResources)
        SLANG_RETURN_ON_FAIL(layout->_addSyntheticResources(syntheticResources));
    returnRefPtr(outLayout, layout);
    return SLANG_OK;
}

Result RootShaderObjectLayoutImpl::_addSyntheticResources(SyntheticResourceBindingState* syntheticResources)
{
    std::vector<SyntheticBindingLocation> syntheticLocations;
    for (const auto& resource : syntheticResources->getInputs())
    {
        if (resource.scope != SyntheticResourceScope::Global)
            return SLANG_E_NOT_IMPLEMENTED;
        int32_t minimumStride = sizeof(uint64_t);
        switch (resource.bindingType)
        {
        case slang::BindingType::RawBuffer:
        case slang::BindingType::MutableRawBuffer:
            // Raw/structured buffers marshal a device pointer and an element count.
            minimumStride = 2 * sizeof(uint64_t);
            break;
        case slang::BindingType::TypedBuffer:
        case slang::BindingType::MutableTypedBuffer:
            // Typed buffers require texture/surface handles, which the CUDA
            // buffer binding writer does not implement. Extra storage cannot
            // make its device-pointer representation a usable typed binding.
            return SLANG_E_NOT_IMPLEMENTED;
        case slang::BindingType::Texture:
        case slang::BindingType::MutableTexture:
        case slang::BindingType::CombinedTextureSampler:
        case slang::BindingType::RayTracingAccelerationStructure:
            break;
        default:
            return SLANG_E_NOT_IMPLEMENTED;
        }
        if (resource.uniformOffset < 0)
            return SLANG_E_INVALID_ARG;
        if (resource.uniformStride < minimumStride)
            return SLANG_E_INVALID_ARG;
        if (resource.arraySize == 0)
            return SLANG_E_INVALID_ARG;
        if (resource.arraySize > (std::numeric_limits<uint32_t>::max() - m_slotCount))
            return SLANG_E_INVALID_ARG;

        const size_t uniformOffset = (size_t)resource.uniformOffset;
        const size_t uniformStride = (size_t)resource.uniformStride;
        const size_t arraySize = (size_t)resource.arraySize;
        if (uniformOffset > std::numeric_limits<uint32_t>::max())
            return SLANG_E_INVALID_ARG;
        if (arraySize > (std::numeric_limits<size_t>::max() - uniformOffset) / uniformStride)
            return SLANG_E_INVALID_ARG;

        BindingRangeInfo bindingRangeInfo = {};
        bindingRangeInfo.bindingType = resource.bindingType;
        bindingRangeInfo.count = resource.arraySize;
        bindingRangeInfo.slotIndex = m_slotCount;
        bindingRangeInfo.uniformOffset = static_cast<uint32_t>(uniformOffset);
        bindingRangeInfo.subObjectIndex = 0;
        bindingRangeInfo.isSpecializable = false;

        uint32_t bindingRangeIndex = (uint32_t)m_bindingRanges.size();
        m_bindingRanges.push_back(bindingRangeInfo);
        m_slotCount += resource.arraySize;

        // The synthetic resource's binding data lives at `uniformOffset` in
        // the global parameter buffer. Slang's element-type-layout for the
        // global scope does not account for synthesized resources, so widen
        // the layout's required uniform buffer size here. ShaderObject::init
        // and BindingDataBuilder::writeObjectData both consult this.
        const size_t requiredSize = uniformOffset + uniformStride * arraySize;
        if (requiredSize > m_uniformBufferSize)
            m_uniformBufferSize = requiredSize;

        SyntheticBindingLocation location = {};
        location.syntheticResourceID = resource.id;
        location.bindingType = resource.bindingType;
        location.arraySize = resource.arraySize;
        location.scope = resource.scope;
        location.entryPointIndex = resource.entryPointIndex;
        location.offset.uniformOffset = static_cast<uint32_t>(uniformOffset);
        location.offset.bindingRangeIndex = bindingRangeIndex;
        location.debugName = resource.debugName.empty() ? nullptr : resource.debugName.c_str();

        syntheticLocations.push_back(location);
    }

    return syntheticResources->setResolvedLocations(syntheticLocations);
}

int RootShaderObjectLayoutImpl::getEntryPointIndex(std::string_view kernelName)
{
    for (SlangUInt i = 0; i < m_programLayout->getEntryPointCount(); i++)
    {
        auto entryPoint = m_programLayout->getEntryPointByIndex(i);
        if (kernelName == entryPoint->getName())
        {
            return i;
        }
    }
    return -1;
}

void RootShaderObjectLayoutImpl::getEntryPointThreadGroupSize(int entryPointIndex, uint32_t* threadGroupSizes)
{
    auto entryPoint = m_programLayout->getEntryPointByIndex(entryPointIndex);
    SlangUInt sizes[3];
    entryPoint->getComputeThreadGroupSize(3, sizes);
    threadGroupSizes[0] = (uint32_t)sizes[0];
    threadGroupSizes[1] = (uint32_t)sizes[1];
    threadGroupSizes[2] = (uint32_t)sizes[2];
}

} // namespace rhi::cuda
