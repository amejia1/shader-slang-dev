#pragma once

#include "cuda-base.h"
#include "cuda-constant-buffer-pool.h"
#include "cuda-shader-object.h"

#include "core/ring-queue.h"

#include <array>

namespace rhi::cuda {

struct SubmitEvent
{
    CUevent event = nullptr;
    uint64_t submitID = 0;
};

struct TimestampAnchor
{
    CUevent event = nullptr;
    uint64_t generation = kInvalidTimestampAnchorGeneration;
    uint64_t offsetUs = 0;
    bool resolved = false;
};

class CommandQueueImpl : public CommandQueue
{
public:
    static constexpr size_t kMaxSubmitsWithoutEvent = 128;
    static constexpr size_t kTimestampAnchorRingSize = 16;

    CUstream m_stream;
    std::array<TimestampAnchor, kTimestampAnchorRingSize> m_timestampAnchors;
    uint64_t m_currentAnchorGeneration = 0;
    uint64_t m_timestampAnchorTimeNs = 0;

    uint64_t m_lastSubmittedID = 0;
    uint64_t m_lastFinishedID = 0;
    uint64_t m_submitsSinceEvent = 0;

    std::mutex m_mutex;
    std::list<InternalRefPtr<CommandBufferImpl>> m_commandBuffersPool;
    std::list<InternalRefPtr<CommandBufferImpl>> m_commandBuffersInFlight;
    std::list<SubmitEvent> m_submitEvents;

    // Deferred delete queue for GPU resources.
    // Resources are held here until the GPU has finished using them.
    struct DeferredDelete
    {
        uint64_t submissionID;
        Resource* resource;
    };
    std::mutex m_deferredDeleteQueueMutex;
    RingQueue<DeferredDelete> m_deferredDeleteQueue;

    CommandQueueImpl(Device* device, QueueType type);
    ~CommandQueueImpl();

    Result init();
    // Wait for GPU work and release command buffers before releasing device-owned heaps.
    void waitAndReleaseCommandBuffers();
    // Drain deferred deletes and destroy native queue services after command buffers and device-owned heaps are
    // released.
    void shutdown();

    Result createCommandBuffer(CommandBufferImpl** outCommandBuffer);
    Result getOrCreateCommandBuffer(CommandBufferImpl** outCommandBuffer);
    void retireCommandBuffer(CommandBufferImpl* commandBuffer);
    Result retireCommandBuffers();
    Result retireCommandBuffersLocked();

    Result resolveTimestampQueries(CommandBufferImpl* commandBuffer);
    Result signalFence(CUstream stream, uint64_t* outId);
    Result updateFence();

    /// Queue a resource for deferred deletion. The resource will be deleted
    /// once the GPU has finished all work submitted up to this point.
    void deferDelete(Resource* resource);

    /// Delete deferred resources that are no longer in use by the GPU.
    void executeDeferredDeletes();

    // ICommandQueue implementation
    virtual SLANG_NO_THROW Result SLANG_MCALL createCommandEncoder(
        const CommandEncoderDesc& desc,
        ICommandEncoder** outEncoder
    ) override;
    virtual SLANG_NO_THROW Result SLANG_MCALL submit(const SubmitDesc& desc) override;
    virtual SLANG_NO_THROW Result SLANG_MCALL waitOnHost() override;
    virtual SLANG_NO_THROW Result SLANG_MCALL getNativeHandle(NativeHandle* outHandle) override;
    virtual SLANG_NO_THROW Result SLANG_MCALL getTimestampCalibration(TimestampCalibration* outCalibration) override;
};

class CommandEncoderImpl : public CommandEncoder
{
public:
    CommandQueueImpl* m_queue;
    RefPtr<CommandBufferImpl> m_commandBuffer;

    CommandEncoderImpl(Device* device, CommandQueueImpl* queue, const CommandEncoderDesc& desc);
    ~CommandEncoderImpl();

    Result init();

    virtual Result getBindingData(RootShaderObject* rootObject, BindingData*& outBindingData) override;

    // ICommandEncoder implementation
    virtual SLANG_NO_THROW Result SLANG_MCALL finish(
        const CommandBufferDesc& desc,
        ICommandBuffer** outCommandBuffer
    ) override;
    virtual SLANG_NO_THROW Result SLANG_MCALL getNativeHandle(NativeHandle* outHandle) override;
};

class CommandBufferImpl : public CommandBuffer
{
public:
    BindingCache m_bindingCache;
    ConstantBufferPool m_constantBufferPool;
    uint64_t m_submissionID = 0;
    uint64_t m_timestampAnchorGeneration = kInvalidTimestampAnchorGeneration;

    CommandBufferImpl(Device* device);
    virtual ~CommandBufferImpl() = default;

    virtual Result reset() override;

    // ICommandBuffer implementation
    virtual SLANG_NO_THROW Result SLANG_MCALL getNativeHandle(NativeHandle* outHandle) override;
};

} // namespace rhi::cuda
