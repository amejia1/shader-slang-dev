#pragma once

#include <slang-rhi.h>

#include "core/smart-pointer.h"

#include <atomic>
#include <mutex>

namespace rhi {

class Backend;

class RHI : public IRHI
{
public:
    virtual ~RHI() = default;

    Result destroy();

    void incrementLiveDeviceCount();
    void decrementLiveDeviceCount();

    // IRHI implementation

    virtual void enableDebugLayers() override;
    virtual Result setDebugLayerOptions(DebugLayerOptions options) override;
    virtual DebugLayerOptions getDebugLayerOptions() override;

    virtual const FormatInfo& getFormatInfo(Format format) override;
    virtual const char* getDeviceTypeName(DeviceType type) override;
    virtual bool isDeviceTypeSupported(DeviceType type) override;
    virtual const char* getFeatureName(Feature feature) override;
    virtual const char* getCapabilityName(Capability capability) override;

    virtual IAdapter* getAdapter(DeviceType type, uint32_t index) override;
    virtual Result getAdapters(DeviceType type, ISlangBlob** outAdaptersBlob) override;
    virtual Result createDevice(const DeviceDesc& desc, IDevice** outDevice) override;

    virtual Result createBlob(const void* data, size_t size, ISlangBlob** outBlob) override;

    virtual Result reportLiveObjects() override;
    virtual Result setTaskPool(ITaskPool* scheduler) override;
    virtual Result initTaskPool(int workerCount) override;

private:
    Backend* getBackend(DeviceType type);
    Result createDeviceImpl(const DeviceDesc& desc, IDevice** outDevice);

    DebugLayerOptions m_debugLayerOptions = {};
    std::atomic<uint32_t> m_liveDeviceCount = 0;
    std::mutex m_backendsMutex;
    RefPtr<Backend> m_backends[8]; // indexed by DeviceType
};

} // namespace rhi
