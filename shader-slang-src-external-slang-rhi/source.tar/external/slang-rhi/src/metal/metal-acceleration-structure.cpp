#include "metal-acceleration-structure.h"
#include "metal-device.h"
#include "metal-buffer.h"
#include "metal-utils.h"

namespace rhi::metal {

AccelerationStructureImpl::AccelerationStructureImpl(Device* device, const AccelerationStructureDesc& desc)
    : AccelerationStructure(device, desc)
{
}

AccelerationStructureImpl::~AccelerationStructureImpl()
{
    DeviceImpl* device = getDevice<DeviceImpl>();
    if (m_accelerationStructure)
    {
        device->unregisterAccelerationStructure(m_globalIndex, m_accelerationStructure.get());
        device->unregisterResource(m_accelerationStructure.get());
    }
}

void AccelerationStructureImpl::deleteThis()
{
    getDevice<DeviceImpl>()->deferDelete(this);
}

Result AccelerationStructureImpl::getNativeHandle(NativeHandle* outHandle)
{
    outHandle->type = NativeHandleType::MTLAccelerationStructure;
    outHandle->value = (uint64_t)m_accelerationStructure.get();
    return SLANG_OK;
}

AccelerationStructureHandle AccelerationStructureImpl::getHandle()
{
    return AccelerationStructureHandle{m_globalIndex};
}

DeviceAddress AccelerationStructureImpl::getDeviceAddress()
{
    return 0;
}

Result DeviceImpl::createAccelerationStructure(
    const AccelerationStructureDesc& desc,
    IAccelerationStructure** outAccelerationStructure
)
{
    AUTORELEASEPOOL

    SLANG_RETURN_ON_FAIL(initializeDummyAccelerationStructure());

    RefPtr<AccelerationStructureImpl> result = new AccelerationStructureImpl(this, desc);
    result->m_accelerationStructure = NS::TransferPtr(m_device->newAccelerationStructure(desc.size));
    if (!result->m_accelerationStructure)
    {
        return SLANG_FAIL;
    }
    result->m_globalIndex = registerAccelerationStructure(result->m_accelerationStructure.get());
    registerResource(result->m_accelerationStructure.get());

    returnComPtr(outAccelerationStructure, result);
    return SLANG_OK;
}

Result AccelerationStructureBuildDescConverter::convert(
    const AccelerationStructureBuildDesc& buildDesc,
    const NS::Array* accelerationStructureArray,
    IDebugCallback* debugCallback
)
{
    if (buildDesc.inputCount < 1)
    {
        return SLANG_E_INVALID_ARG;
    }

    // Motion blur is not supported in Metal
    if (is_set(buildDesc.flags, AccelerationStructureBuildFlags::CreateMotion))
    {
        return SLANG_E_NOT_AVAILABLE;
    }

    AccelerationStructureBuildInputType type = buildDesc.inputs[0].type;
    for (uint32_t i = 1; i < buildDesc.inputCount; ++i)
    {
        if (buildDesc.inputs[i].type != type)
        {
            return SLANG_E_INVALID_ARG;
        }
    }

    switch (type)
    {
    case AccelerationStructureBuildInputType::Instances:
    {
        if (buildDesc.inputCount > 1)
        {
            return SLANG_E_INVALID_ARG;
        }

        const AccelerationStructureBuildInputInstances& instances = buildDesc.inputs[0].instances;

        MTL::InstanceAccelerationStructureDescriptor* instanceDescriptor =
            MTL::InstanceAccelerationStructureDescriptor::alloc()->init();
        descriptor = NS::TransferPtr(instanceDescriptor);

        instanceDescriptor->setUsage(translateBuildFlags(buildDesc.flags));
        instanceDescriptor->setInstanceDescriptorBuffer(
            checked_cast<BufferImpl*>(instances.instanceBuffer.buffer)->m_buffer.get()
        );
        instanceDescriptor->setInstanceDescriptorBufferOffset(instances.instanceBuffer.offset);
        instanceDescriptor->setInstanceDescriptorStride(instances.instanceStride);
        instanceDescriptor->setInstanceCount(instances.instanceCount);
        instanceDescriptor->setInstanceDescriptorType(MTL::AccelerationStructureInstanceDescriptorTypeUserID);
        instanceDescriptor->setInstancedAccelerationStructures(accelerationStructureArray);

        break;
    }
    case AccelerationStructureBuildInputType::Triangles:
    {
        MTL::PrimitiveAccelerationStructureDescriptor* primitiveDescriptor =
            MTL::PrimitiveAccelerationStructureDescriptor::alloc()->init();
        descriptor = NS::TransferPtr(primitiveDescriptor);

        primitiveDescriptor->setUsage(translateBuildFlags(buildDesc.flags));

        for (uint32_t i = 0; i < buildDesc.inputCount; ++i)
        {
            const AccelerationStructureBuildInputTriangles& triangles = buildDesc.inputs[i].triangles;
            if (triangles.vertexBufferCount != 1)
            {
                return SLANG_E_INVALID_ARG;
            }
        }

        std::vector<MTL::AccelerationStructureTriangleGeometryDescriptor*> triangleDescriptors(buildDesc.inputCount);

        for (uint32_t i = 0; i < buildDesc.inputCount; ++i)
        {
            const AccelerationStructureBuildInputTriangles& triangles = buildDesc.inputs[i].triangles;

            MTL::AccelerationStructureTriangleGeometryDescriptor* triangleDescriptor =
                MTL::AccelerationStructureTriangleGeometryDescriptor::alloc()->init();
            triangleDescriptors[i] = triangleDescriptor;

            triangleDescriptor->setVertexBuffer(
                checked_cast<BufferImpl*>(triangles.vertexBuffers[0].buffer)->m_buffer.get()
            );
            triangleDescriptor->setVertexBufferOffset(triangles.vertexBuffers[0].offset);
            triangleDescriptor->setVertexFormat(translateAttributeFormat(triangles.vertexFormat));
            triangleDescriptor->setVertexStride(triangles.vertexStride);

            if (triangles.indexBuffer)
            {
                triangleDescriptor->setIndexBuffer(
                    checked_cast<BufferImpl*>(triangles.indexBuffer.buffer)->m_buffer.get()
                );
                triangleDescriptor->setIndexBufferOffset(triangles.indexBuffer.offset);
                triangleDescriptor->setIndexType(
                    triangles.indexFormat == IndexFormat::Uint32 ? MTL::IndexTypeUInt32 : MTL::IndexTypeUInt16
                );
            }

            uint32_t triangleCount = max(triangles.vertexCount, triangles.indexCount) / 3;
            triangleDescriptor->setTriangleCount(triangleCount);

            if (triangles.preTransformBuffer)
            {
                triangleDescriptor->setTransformationMatrixBuffer(
                    checked_cast<BufferImpl*>(triangles.preTransformBuffer.buffer)->m_buffer.get()
                );
                triangleDescriptor->setTransformationMatrixBufferOffset(triangles.preTransformBuffer.offset);
            }

            triangleDescriptor->setOpaque(is_set(triangles.flags, AccelerationStructureGeometryFlags::Opaque));
            triangleDescriptor->setAllowDuplicateIntersectionFunctionInvocation(
                !is_set(triangles.flags, AccelerationStructureGeometryFlags::NoDuplicateAnyHitInvocation)
            );
        }

        // Set the geometry descriptors array on the primitive descriptor
        NS::Array* geometryArray =
            NS::Array::alloc()->init((const NS::Object* const*)triangleDescriptors.data(), triangleDescriptors.size());
        primitiveDescriptor->setGeometryDescriptors(geometryArray);
        geometryArray->release();

        // Release the individual descriptors (array retains them)
        for (auto* desc : triangleDescriptors)
        {
            desc->release();
        }

        break;
    }
    case AccelerationStructureBuildInputType::ProceduralPrimitives:
    {
        MTL::PrimitiveAccelerationStructureDescriptor* primitiveDescriptor =
            MTL::PrimitiveAccelerationStructureDescriptor::alloc()->init();
        descriptor = NS::TransferPtr(primitiveDescriptor);

        primitiveDescriptor->setUsage(translateBuildFlags(buildDesc.flags));

        for (uint32_t i = 0; i < buildDesc.inputCount; ++i)
        {
            const AccelerationStructureBuildInputProceduralPrimitives& proceduralPrimitives =
                buildDesc.inputs[i].proceduralPrimitives;
            if (proceduralPrimitives.aabbBufferCount != 1)
            {
                return SLANG_E_INVALID_ARG;
            }
        }

        std::vector<MTL::AccelerationStructureBoundingBoxGeometryDescriptor*> boundingBoxDescriptors(
            buildDesc.inputCount
        );

        for (uint32_t i = 0; i < buildDesc.inputCount; ++i)
        {
            const AccelerationStructureBuildInputProceduralPrimitives& proceduralPrimitives =
                buildDesc.inputs[i].proceduralPrimitives;

            MTL::AccelerationStructureBoundingBoxGeometryDescriptor* boundingBoxDescriptor =
                MTL::AccelerationStructureBoundingBoxGeometryDescriptor::alloc()->init();
            boundingBoxDescriptors[i] = boundingBoxDescriptor;

            boundingBoxDescriptor->setBoundingBoxBuffer(
                checked_cast<BufferImpl*>(proceduralPrimitives.aabbBuffers[0].buffer)->m_buffer.get()
            );
            boundingBoxDescriptor->setBoundingBoxBufferOffset(proceduralPrimitives.aabbBuffers[0].offset);
            boundingBoxDescriptor->setBoundingBoxStride(proceduralPrimitives.aabbStride);
            boundingBoxDescriptor->setBoundingBoxCount(proceduralPrimitives.primitiveCount);

            boundingBoxDescriptor->setOpaque(
                is_set(proceduralPrimitives.flags, AccelerationStructureGeometryFlags::Opaque)
            );
            boundingBoxDescriptor->setAllowDuplicateIntersectionFunctionInvocation(
                !is_set(proceduralPrimitives.flags, AccelerationStructureGeometryFlags::NoDuplicateAnyHitInvocation)
            );
        }

        // Set the geometry descriptors array on the primitive descriptor
        NS::Array* geometryArray = NS::Array::alloc()->init(
            (const NS::Object* const*)boundingBoxDescriptors.data(),
            boundingBoxDescriptors.size()
        );
        primitiveDescriptor->setGeometryDescriptors(geometryArray);
        geometryArray->release();

        // Release the individual descriptors (array retains them)
        for (auto* desc : boundingBoxDescriptors)
        {
            desc->release();
        }

        break;
    }
    case AccelerationStructureBuildInputType::Spheres:
    case AccelerationStructureBuildInputType::LinearSweptSpheres:
        return SLANG_E_NOT_AVAILABLE;
    default:
        return SLANG_E_INVALID_ARG;
    }

    return SLANG_OK;
}

} // namespace rhi::metal
