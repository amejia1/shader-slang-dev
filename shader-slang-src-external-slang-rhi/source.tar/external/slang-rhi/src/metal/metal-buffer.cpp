#include "metal-buffer.h"
#include "metal-command.h"
#include "metal-device.h"
#include "metal-utils.h"

namespace rhi::metal {

BufferImpl::BufferImpl(Device* device, const BufferDesc& desc)
    : Buffer(device, desc)
{
}

BufferImpl::~BufferImpl()
{
    if (m_buffer)
    {
        auto* device = getDevice<DeviceImpl>();
        device->unregisterResource(m_buffer.get());
    }
}

void BufferImpl::deleteThis()
{
    auto* device = getDevice<DeviceImpl>();
    // Stop resolving this raw address to an object whose public reference
    // count has reached zero, even though Metal destruction is deferred.
    if (!device->m_hasResidencySet && m_deviceAddress != 0)
        device->m_addressToBuffer.erase(m_deviceAddress, this);
    device->deferDelete(this);
}

Result BufferImpl::getNativeHandle(NativeHandle* outHandle)
{
    outHandle->type = NativeHandleType::MTLBuffer;
    outHandle->value = (uint64_t)m_buffer.get();
    return SLANG_OK;
}

Result BufferImpl::getSharedHandle(NativeHandle* outHandle)
{
    *outHandle = {};
    return SLANG_E_NOT_AVAILABLE;
}

DeviceAddress BufferImpl::getDeviceAddress()
{
    return m_deviceAddress;
}

Result DeviceImpl::createBuffer(const BufferDesc& desc_, const void* initData, IBuffer** outBuffer)
{
    AUTORELEASEPOOL

    BufferDesc desc = fixupBufferDesc(desc_);

    const Size bufferSize = desc.size;

    MTL::ResourceOptions resourceOptions = MTL::ResourceOptions(0);
    switch (desc.memoryType)
    {
    case MemoryType::DeviceLocal:
        resourceOptions = makeResourceOptions(MTL::ResourceStorageModePrivate);
        break;
    case MemoryType::Upload:
        resourceOptions = makeResourceOptions(MTL::ResourceStorageModeShared, MTL::ResourceCPUCacheModeWriteCombined);
        break;
    case MemoryType::ReadBack:
        resourceOptions = makeResourceOptions(MTL::ResourceStorageModeShared);
        break;
    default:
        SLANG_RHI_ASSERT_FAILURE("Unhandled MemoryType");
        return SLANG_FAIL;
    }

    RefPtr<BufferImpl> buffer(new BufferImpl(this, desc));
    buffer->m_buffer = NS::TransferPtr(m_device->newBuffer(bufferSize, resourceOptions));
    if (!buffer->m_buffer)
    {
        return SLANG_FAIL;
    }

    // GPU virtual address is stable immediately after allocation on Apple Silicon.
    // Residency set commit (in CommandQueueImpl::submit) happens before any
    // render/compute command buffer using this address via argument buffers.
    // Blit encoders handle residency for explicit operands automatically.
    buffer->m_deviceAddress = buffer->m_buffer->gpuAddress();
    if (!m_hasResidencySet && buffer->m_deviceAddress != 0)
        m_addressToBuffer.insert(buffer->m_deviceAddress, buffer->m_buffer->length(), buffer.get());
    registerResource(buffer->m_buffer.get());

    if (desc.label)
        buffer->m_buffer->addDebugMarker(createString(desc.label).get(), NS::Range(0, desc.size));

    if (initData)
    {
        if (desc.memoryType == MemoryType::DeviceLocal)
        {
            auto stagingOpts = makeResourceOptions(MTL::ResourceStorageModeShared);
            NS::SharedPtr<MTL::Buffer> stagingBuffer =
                NS::TransferPtr(m_device->newBuffer(initData, bufferSize, stagingOpts));
            if (!stagingBuffer)
                return SLANG_FAIL;
            MTL::CommandBuffer* commandBuffer = m_commandQueue->commandBuffer();
            if (!commandBuffer)
                return SLANG_FAIL;
            MTL::BlitCommandEncoder* encoder = commandBuffer->blitCommandEncoder();
            if (!encoder)
                return SLANG_FAIL;
            encoder->waitForFence(m_queue->m_queueFence.get());
            encoder->copyFromBuffer(stagingBuffer.get(), 0, buffer->m_buffer.get(), 0, bufferSize);
            encoder->updateFence(m_queue->m_queueFence.get());
            encoder->endEncoding();
            commandBuffer->commit();
            commandBuffer->waitUntilCompleted();
        }
        else
        {
            std::memcpy(buffer->m_buffer->contents(), initData, bufferSize);
        }
    }

    returnComPtr(outBuffer, buffer);
    return SLANG_OK;
}

Result DeviceImpl::createBufferFromNativeHandle(NativeHandle handle, const BufferDesc& desc, IBuffer** outBuffer)
{
    AUTORELEASEPOOL

    if (handle.type != NativeHandleType::MTLBuffer || handle.value == 0)
    {
        *outBuffer = nullptr;
        return SLANG_E_INVALID_HANDLE;
    }

    MTL::Buffer* nativeBuffer = reinterpret_cast<MTL::Buffer*>(handle.value);
    if (nativeBuffer->device() != m_device.get() || desc.size > nativeBuffer->length())
    {
        return SLANG_E_INVALID_ARG;
    }

    BufferDesc fixedDesc = fixupBufferDesc(desc);
    RefPtr<BufferImpl> buffer(new BufferImpl(this, fixedDesc));
    buffer->m_buffer = NS::RetainPtr(nativeBuffer);
    buffer->m_deviceAddress = nativeBuffer->gpuAddress();

    if (!m_hasResidencySet && buffer->m_deviceAddress != 0)
        m_addressToBuffer.insert(buffer->m_deviceAddress, nativeBuffer->length(), buffer.get());
    registerResource(nativeBuffer);

    if (fixedDesc.label)
        nativeBuffer->addDebugMarker(createString(fixedDesc.label).get(), NS::Range(0, fixedDesc.size));

    returnComPtr(outBuffer, buffer);
    return SLANG_OK;
}

Result DeviceImpl::mapBuffer(IBuffer* buffer, CpuAccessMode mode, void** outData)
{
    SLANG_UNUSED(mode);
    BufferImpl* bufferImpl = checked_cast<BufferImpl*>(buffer);
    *outData = bufferImpl->m_buffer->contents();
    return SLANG_OK;
}

Result DeviceImpl::unmapBuffer(IBuffer* buffer)
{
    BufferImpl* bufferImpl = checked_cast<BufferImpl*>(buffer);
    SLANG_UNUSED(bufferImpl);
    return SLANG_OK;
}

} // namespace rhi::metal
