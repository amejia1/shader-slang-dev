#include "d3d11-shader-program.h"
#include "d3d11-device.h"
#include "d3d11-shader-object-layout.h"

namespace rhi::d3d11 {

ShaderProgramImpl::ShaderProgramImpl(Device* device, const ShaderProgramDesc& desc)
    : ShaderProgram(device, desc)
{
}

ShaderProgramImpl::~ShaderProgramImpl()
{
#if SLANG_RHI_ENABLE_AFTERMATH
    DeviceImpl* device = getDevice<DeviceImpl>();
    if (device->m_aftermathCrashDumper)
    {
        for (const Module& module : m_modules)
        {
            device->m_aftermathCrashDumper->unregisterShader(reinterpret_cast<uint64_t>(module.code.get()));
        }
    }
#endif
}

Result ShaderProgramImpl::createShaderModule(const ShaderModuleDesc& desc, ComPtr<ISlangBlob> kernelCode)
{
#if SLANG_RHI_ENABLE_AFTERMATH
    DeviceImpl* device = getDevice<DeviceImpl>();
    if (device->m_aftermathCrashDumper)
    {
        device->m_aftermathCrashDumper->registerShader(
            reinterpret_cast<uint64_t>(kernelCode.get()),
            DeviceType::D3D11,
            kernelCode->getBufferPointer(),
            kernelCode->getBufferSize()
        );
    }
#endif
    m_modules.push_back({desc.stage, kernelCode});
    return SLANG_OK;
}

ShaderObjectLayout* ShaderProgramImpl::getRootShaderObjectLayout()
{
    return m_rootObjectLayout;
}

ShaderProgramImpl::Module* ShaderProgramImpl::findModule(SlangStage stage)
{
    for (auto& module : m_modules)
    {
        if (module.stage == stage)
            return &module;
    }
    return nullptr;
}

} // namespace rhi::d3d11
